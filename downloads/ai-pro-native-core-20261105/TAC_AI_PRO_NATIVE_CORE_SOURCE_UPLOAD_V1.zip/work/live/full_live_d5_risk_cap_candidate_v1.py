from __future__ import annotations

"""Candidate-only D5 structural-risk cap evaluator.

No values are frozen here.  Callers must supply an explicit versioned capital
snapshot and explicit policy fractions from a separately frozen authority.
"""
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from typing import Any, Mapping

from full_live_structural_risk_accounting_v1 import PortfolioStructuralRiskV1


class D5RiskCapCandidateBlock(RuntimeError): pass


@dataclass(frozen=True)
class CapitalBaseSnapshotV1:
    capital_quote: Decimal
    authority: str
    version: str
    as_of_ms: int


@dataclass(frozen=True)
class RiskCapFractionsV1:
    per_trade: Decimal
    per_symbol: Decimal
    total_portfolio: Decimal
    same_direction: Decimal


def _positive(v:Any,label:str)->Decimal:
    try: d=Decimal(str(v))
    except (InvalidOperation,TypeError,ValueError) as exc: raise D5RiskCapCandidateBlock("INVALID_DECIMAL:"+label) from exc
    if not d.is_finite() or d<=0: raise D5RiskCapCandidateBlock("NONPOSITIVE:"+label)
    return d


def capital_snapshot(*,capital_quote:Any,authority:str,version:str,as_of_ms:int)->CapitalBaseSnapshotV1:
    if not authority or not version: raise D5RiskCapCandidateBlock("CAPITAL_AUTHORITY_AND_VERSION_REQUIRED")
    if not isinstance(as_of_ms,int) or as_of_ms<=0: raise D5RiskCapCandidateBlock("CAPITAL_AS_OF_INVALID")
    return CapitalBaseSnapshotV1(_positive(capital_quote,"capital_quote"),authority,version,as_of_ms)


def risk_cap_fractions(*,per_trade:Any,per_symbol:Any,total_portfolio:Any,same_direction:Any)->RiskCapFractionsV1:
    vals=[_positive(x,n) for x,n in ((per_trade,"per_trade"),(per_symbol,"per_symbol"),(total_portfolio,"total_portfolio"),(same_direction,"same_direction"))]
    if any(x>1 for x in vals): raise D5RiskCapCandidateBlock("RISK_FRACTION_ABOVE_ONE")
    return RiskCapFractionsV1(*vals)


def candidate_fits_caps(*,candidate_symbol:str,candidate_direction:str,candidate_risk_quote:Any,
                        portfolio:PortfolioStructuralRiskV1,capital:CapitalBaseSnapshotV1,
                        caps:RiskCapFractionsV1)->Mapping[str,bool]:
    risk=_positive(candidate_risk_quote,"candidate_risk_quote")
    side=candidate_direction.upper()
    if side not in ("LONG","SHORT"): raise D5RiskCapCandidateBlock("DIRECTION_INVALID")
    existing_symbol=portfolio.per_symbol_risk_quote.get(candidate_symbol,Decimal("0"))
    direction_existing=portfolio.long_risk_quote if side=="LONG" else portfolio.short_risk_quote
    base=capital.capital_quote
    return {
      "per_trade": risk <= base*caps.per_trade,
      "per_symbol": existing_symbol+risk <= base*caps.per_symbol,
      "total_portfolio": portfolio.total_risk_quote+risk <= base*caps.total_portfolio,
      "same_direction": direction_existing+risk <= base*caps.same_direction,
    }


def invariants():
    return {"status":"CANDIDATE_NOT_FROZEN","capital_base_explicit_versioned_snapshot":True,
            "unrealized_pnl_used":False,"live_equity_used":False,"policy_values_owned":False,
            "orders":0,"fills":0,"execution_intents":0,"trading_activated":False}
