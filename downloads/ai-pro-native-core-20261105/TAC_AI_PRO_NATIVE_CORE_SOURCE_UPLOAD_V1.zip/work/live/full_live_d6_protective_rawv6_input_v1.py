from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping

from d2_to_b4_d4_causal_evidence_producers_v1 import (
    ClosedPriceObservation,
)
from multisymbol_impl import transactional_batch_staging_v1 as staging
from strategy_rc1.d2_market_state.types import (
    StructuralLayer,
    StructuralPivot,
)
from strategy_rc1.d6_position_execution.types import (
    StrategyPositionSnapshot,
)


rawv6 = staging.rawv6


class FullLiveD6ProtectiveRawV6InputBlock(RuntimeError):
    pass


@dataclass(frozen=True)
class D6ProtectiveRawV6InputsV1:
    information_cutoff: int
    symbol: str
    entry_canonical_segment_id: str
    current_canonical_segment_id: str | None
    confirmed_minor_pivots: tuple[StructuralPivot, ...]
    closed_prices: tuple[ClosedPriceObservation, ...]
    provenance: Mapping[str, str]


def _from_runtime(
    *,
    runtime,
    position: StrategyPositionSnapshot,
    information_cutoff: int,
) -> D6ProtectiveRawV6InputsV1:
    if not isinstance(position, StrategyPositionSnapshot):
        raise FullLiveD6ProtectiveRawV6InputBlock(
            "STRATEGY_POSITION_SNAPSHOT_REQUIRED"
        )
    if int(getattr(runtime.state, "last_cutoff", -1)) != information_cutoff:
        raise FullLiveD6ProtectiveRawV6InputBlock(
            "RAWV6_LAST_CUTOFF_DRIFT"
        )

    entry = position.entry
    adapter = runtime._adapter()
    state = adapter._state(entry.symbol)
    if int(getattr(state, "last_information_cutoff", -1)) != (
        information_cutoff
    ):
        raise FullLiveD6ProtectiveRawV6InputBlock(
            "SYMBOL_DURABLE_LAST_CUTOFF_DRIFT"
        )

    current_segment = getattr(
        state,
        "last_canonical_segment_id",
        None,
    )
    entry_segment = entry.canonical_segment_id

    pivots: list[StructuralPivot] = []
    seen_pivot_ids: set[str] = set()
    for pivot in tuple(getattr(runtime.state, "minor_history", ())):
        if not isinstance(pivot, StructuralPivot):
            raise FullLiveD6ProtectiveRawV6InputBlock(
                "RAWV6_MINOR_HISTORY_TYPED_PIVOT_REQUIRED"
            )
        if pivot.symbol != entry.symbol:
            continue
        if pivot.timeframe_ms != 15 * 60 * 1000:
            continue
        if pivot.layer is not StructuralLayer.MINOR:
            continue
        if pivot.confirmed_at > information_cutoff:
            raise FullLiveD6ProtectiveRawV6InputBlock(
                "FUTURE_MINOR_PIVOT_IN_DURABLE_RAWV6"
            )
        if pivot.canonical_segment_id != entry_segment:
            continue
        if pivot.pivot_id in seen_pivot_ids:
            raise FullLiveD6ProtectiveRawV6InputBlock(
                "DUPLICATE_MINOR_PIVOT_ID:" + pivot.pivot_id
            )
        if not pivot.provenance:
            raise FullLiveD6ProtectiveRawV6InputBlock(
                "MINOR_PIVOT_PROVENANCE_REQUIRED:"
                + pivot.pivot_id
            )
        seen_pivot_ids.add(pivot.pivot_id)
        pivots.append(pivot)

    replay = tuple(getattr(state, "d2_replay", ()))
    closes: list[ClosedPriceObservation] = []
    seen_cutoffs: set[int] = set()
    for index, row in enumerate(replay):
        if not isinstance(row, tuple) or len(row) != 3:
            raise FullLiveD6ProtectiveRawV6InputBlock(
                "D2_REPLAY_ROW_CONTRACT_DRIFT:" + str(index)
            )
        bar, _atr, segment = row
        symbol = str(getattr(bar, "symbol", "") or "")
        cutoff = int(getattr(bar, "close_time", -1))
        if symbol != entry.symbol:
            raise FullLiveD6ProtectiveRawV6InputBlock(
                "D2_REPLAY_SYMBOL_DRIFT:" + str(index)
            )
        if cutoff <= 0 or cutoff > information_cutoff:
            raise FullLiveD6ProtectiveRawV6InputBlock(
                "D2_REPLAY_FUTURE_OR_INVALID_CUTOFF:"
                + str(index)
            )
        if str(segment) != entry_segment:
            continue
        if cutoff in seen_cutoffs:
            raise FullLiveD6ProtectiveRawV6InputBlock(
                "D2_REPLAY_DUPLICATE_CLOSE_CUTOFF:"
                + str(cutoff)
            )
        close = getattr(bar, "close", None)
        if close is None:
            raise FullLiveD6ProtectiveRawV6InputBlock(
                "D2_REPLAY_CLOSE_REQUIRED:" + str(index)
            )
        seen_cutoffs.add(cutoff)
        closes.append(
            ClosedPriceObservation(
                information_cutoff=cutoff,
                close=close,
                provenance={
                    "source": "RAWV6_D2_REPLAY_CANONICAL_BAR",
                    "symbol": entry.symbol,
                    "canonical_segment_id": entry_segment,
                    "cutoff": str(cutoff),
                },
            )
        )

    pivots.sort(key=lambda x: (x.confirmed_at, x.pivot_id))
    closes.sort(key=lambda x: x.information_cutoff)

    return D6ProtectiveRawV6InputsV1(
        information_cutoff=information_cutoff,
        symbol=entry.symbol,
        entry_canonical_segment_id=entry_segment,
        current_canonical_segment_id=(
            None
            if current_segment is None
            else str(current_segment)
        ),
        confirmed_minor_pivots=tuple(pivots),
        closed_prices=tuple(closes),
        provenance={
            "authority": (
                "TAC_FULL_LIVE_D6_PROTECTIVE_RAWV6_INPUT_V1"
            ),
            "rawv6_last_cutoff": str(information_cutoff),
            "pivot_scope": (
                "ALL_CAUSAL_15M_MINOR_PIVOTS_IN_ENTRY_CANONICAL_SEGMENT"
            ),
            "close_scope": (
                "ALL_DURABLE_D2_REPLAY_CLOSES_IN_ENTRY_CANONICAL_SEGMENT"
            ),
            "fixed_window_added": "false",
            "historical_outcome_read": "false",
            "pnl_read": "false",
        },
    )


def project_d6_protective_inputs_from_final_rawv6_state(
    *,
    final_rawv6_state: str,
    position: StrategyPositionSnapshot,
    information_cutoff: int,
) -> D6ProtectiveRawV6InputsV1:
    if not isinstance(final_rawv6_state, str) or not final_rawv6_state:
        raise FullLiveD6ProtectiveRawV6InputBlock(
            "FINAL_RAWV6_STATE_REQUIRED"
        )
    try:
        runtime = (
            rawv6.LiveRuntimeRawAuthorityOrchestrationV6.restore_state(
                final_rawv6_state
            )
        )
    except Exception as exc:
        raise FullLiveD6ProtectiveRawV6InputBlock(
            "RAWV6_STATE_RESTORE_FAILED:"
            + exc.__class__.__name__
            + ":"
            + str(exc)
        ) from exc
    if runtime.export_state() != final_rawv6_state:
        raise FullLiveD6ProtectiveRawV6InputBlock(
            "RAWV6_STATE_NOT_CANONICAL"
        )
    return _from_runtime(
        runtime=runtime,
        position=position,
        information_cutoff=information_cutoff,
    )


def invariants() -> Mapping[str, object]:
    return {
        "raw_state_source": "ADOPTED_CURRENT_CUTOFF_FINAL_RAWV6_STATE",
        "minor_pivot_scope": (
            "ENTRY_SEGMENT_ALL_CAUSAL_CONFIRMED_15M_MINOR"
        ),
        "closed_price_scope": (
            "ENTRY_SEGMENT_DURABLE_D2_REPLAY_NO_FIXED_WINDOW"
        ),
        "future_pivot_or_close": "FAIL_CLOSED",
        "historical_outcome_read": False,
        "pnl_read": False,
        "selector_added": False,
        "ranking_added": False,
        "orders": 0,
        "fills": 0,
        "execution_intents": 0,
        "trading_activated": False,
    }


__all__ = [
    "D6ProtectiveRawV6InputsV1",
    "FullLiveD6ProtectiveRawV6InputBlock",
    "project_d6_protective_inputs_from_final_rawv6_state",
    "invariants",
]
