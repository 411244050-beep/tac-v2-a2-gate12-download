from __future__ import annotations

"""Fail-closed bridge from versioned full-live D5 policy authority to WP5 slots.

This module does not choose policy values.  It converts a separately frozen,
versioned policy document into the historical OperationalInputSet transport
only after every required slot is explicitly authorized.

Important: slot transport is not policy enforcement.  A FROZEN policy still
requires its mechanism-specific runtime enforcement surface before production
ENTRY_READY may be authorized.
"""

import json
from pathlib import Path
from typing import Any, Mapping

from strategy_rc1.d5_risk.operational_inputs import (
    REQUIRED_UNRESOLVED_OPERATIONAL_INPUTS,
    current_unresolved_operational_inputs,
)
from strategy_rc1.d5_risk.types import (
    OperationalInputSet,
    OperationalInputSlot,
    OperationalInputState,
)


LIVE_DIR = Path(__file__).resolve().parent
DEFAULT_AUTHORITY_PATH = (
    LIVE_DIR / "full_live_d5_operational_risk_policy_authority_v1.json"
)

SCHEMA = "TAC_FULL_LIVE_D5_OPERATIONAL_RISK_POLICY_AUTHORITY_V1"
FROZEN_STATUS = "FROZEN"


class FullLiveD5OperationalPolicyBlock(RuntimeError):
    pass


def _canonical(value: Any) -> str:
    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    )


def load_policy_authority(
    path: Path = DEFAULT_AUTHORITY_PATH,
) -> Mapping[str, Any]:
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise FullLiveD5OperationalPolicyBlock(
            "D5_OPERATIONAL_POLICY_AUTHORITY_READ_FAILED"
        ) from exc
    if not isinstance(raw, dict):
        raise FullLiveD5OperationalPolicyBlock(
            "D5_OPERATIONAL_POLICY_AUTHORITY_NOT_OBJECT"
        )
    if raw.get("schema") != SCHEMA:
        raise FullLiveD5OperationalPolicyBlock(
            "D5_OPERATIONAL_POLICY_SCHEMA_DRIFT"
        )
    if raw.get("branch") != "tac-full-live-v1":
        raise FullLiveD5OperationalPolicyBlock(
            "D5_OPERATIONAL_POLICY_BRANCH_DRIFT"
        )
    return raw


def _validate_slot_names(slots: Mapping[str, Any]) -> None:
    required = tuple(REQUIRED_UNRESOLVED_OPERATIONAL_INPUTS)
    if set(slots) != set(required):
        missing = sorted(set(required) - set(slots))
        extra = sorted(set(slots) - set(required))
        raise FullLiveD5OperationalPolicyBlock(
            "D5_OPERATIONAL_POLICY_SLOT_SET_DRIFT:"
            + "missing="
            + ",".join(missing)
            + ":extra="
            + ",".join(extra)
        )


def build_operational_input_set(
    path: Path = DEFAULT_AUTHORITY_PATH,
) -> OperationalInputSet:
    """Return unresolved slots until a complete explicit policy is FROZEN."""

    authority = load_policy_authority(path)
    slots = authority.get("slots")
    if not isinstance(slots, dict):
        raise FullLiveD5OperationalPolicyBlock(
            "D5_OPERATIONAL_POLICY_SLOTS_NOT_OBJECT"
        )
    _validate_slot_names(slots)

    if authority.get("status") != FROZEN_STATUS:
        # Explicitly preserve the historical fail-closed representation.
        return current_unresolved_operational_inputs()

    out: dict[str, OperationalInputSlot] = {}
    for name in REQUIRED_UNRESOLVED_OPERATIONAL_INPUTS:
        row = slots[name]
        if not isinstance(row, dict):
            raise FullLiveD5OperationalPolicyBlock(
                "D5_OPERATIONAL_POLICY_SLOT_NOT_OBJECT:" + name
            )
        if row.get("state") != "KNOWN":
            raise FullLiveD5OperationalPolicyBlock(
                "FROZEN_POLICY_HAS_NONKNOWN_SLOT:" + name
            )
        if row.get("exact_value") is None:
            raise FullLiveD5OperationalPolicyBlock(
                "FROZEN_POLICY_VALUE_MISSING:" + name
            )
        if not row.get("authority"):
            raise FullLiveD5OperationalPolicyBlock(
                "FROZEN_POLICY_AUTHORITY_MISSING:" + name
            )
        if not row.get("version"):
            raise FullLiveD5OperationalPolicyBlock(
                "FROZEN_POLICY_VERSION_MISSING:" + name
            )
        out[name] = OperationalInputSlot(
            name=name,
            state=OperationalInputState.KNOWN,
            exact_value=_canonical(
                {
                    "value": row["exact_value"],
                    "unit": row.get("unit"),
                    "authority": row["authority"],
                    "version": row["version"],
                    "class": row.get("class"),
                }
            ),
        )

    return OperationalInputSet(out)


def policy_enforcement_status(
    path: Path = DEFAULT_AUTHORITY_PATH,
) -> Mapping[str, Any]:
    authority = load_policy_authority(path)
    frozen = authority.get("status") == FROZEN_STATUS
    current = authority.get("current_effect") or {}
    runtime_ready = (
        frozen
        and current.get("runtime_all_ten_slot_enforcement")
        == "IMPLEMENTED_AND_REGRESSION_VALIDATED"
    )
    return {
        "authority_status": authority.get("status"),
        "all_slot_values_frozen": frozen,
        "slot_transport_ready": frozen,
        # KNOWN slot transport alone is insufficient. Production readiness is
        # asserted only after the typed all-ten-slot evaluator and production
        # batch-proof authorization path have passed regression.
        "runtime_policy_enforcement_ready": runtime_ready,
        "opaque_known_strings_sufficient": False,
    }


def invariants() -> Mapping[str, Any]:
    return {
        "agent_selected_defaults": False,
        "conventional_defaults": False,
        "tac_live_notional_usdt_used_as_policy_substitute": False,
        "theta_stop_used_as_policy_substitute": False,
        "unresolved_policy_returns_unresolved_slots": True,
        "frozen_policy_requires_all_ten_slots": True,
        "frozen_policy_requires_authority_and_version": True,
        "slot_transport_is_not_policy_enforcement": True,
        "runtime_ready_requires_frozen_plus_validated_all_ten_enforcement": True,
        "trading_activated": False,
    }
