from __future__ import annotations
from dataclasses import dataclass
from typing import Iterable, Mapping

class KillSwitchMeasurementBlock(RuntimeError): pass

@dataclass(frozen=True)
class OperationalFailureEventV1:
    event_id:str
    occurred_at_ms:int
    category:str

_ALLOWED=frozenset({
 "EXECUTION_AMBIGUITY","ENTRY_SUBMISSION_FAILURE","HARD_STOP_PLACEMENT_FAILURE",
 "READONLY_RECONCILIATION_FAILURE","DATA_CONTINUITY_FAILURE","RISK_AUTHORIZATION_FAILURE",
})

def measure_failure_counts(events:Iterable[OperationalFailureEventV1],*,since_ms:int,through_ms:int)->Mapping[str,int]:
    if not isinstance(since_ms,int) or not isinstance(through_ms,int) or since_ms<0 or through_ms<since_ms:
        raise KillSwitchMeasurementBlock("INVALID_OBSERVATION_INTERVAL")
    seen=set(); counts={k:0 for k in sorted(_ALLOWED)}
    for e in events:
        if not isinstance(e,OperationalFailureEventV1): raise KillSwitchMeasurementBlock("TYPED_EVENT_REQUIRED")
        if not e.event_id or e.event_id in seen: raise KillSwitchMeasurementBlock("EVENT_ID_INVALID_OR_DUPLICATE")
        seen.add(e.event_id)
        if e.category not in _ALLOWED: raise KillSwitchMeasurementBlock("UNKNOWN_FAILURE_CATEGORY:"+e.category)
        if since_ms<=e.occurred_at_ms<=through_ms: counts[e.category]+=1
    return counts

def invariants():
    return {"measurement_only":True,"numeric_trigger_owned":False,"window_owned":False,
      "execution_ambiguity_hard_latch_unchanged":True,"orders":0,"fills":0,"execution_intents":0,"trading_activated":False}
