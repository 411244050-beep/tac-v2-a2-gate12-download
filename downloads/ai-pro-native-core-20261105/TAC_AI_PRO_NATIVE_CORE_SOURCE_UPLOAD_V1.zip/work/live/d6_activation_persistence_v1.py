from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from d6_snapshot_ledger_v1 import build_d6_snapshot_ledger_event
from strategy_rc1.d6_position_execution.types import StrategyPositionSnapshot
from trade_ledger_v1 import LedgerEvent, TradeLedgerV1


class D6ActivationPersistenceBlock(RuntimeError):
    pass


@dataclass(frozen=True)
class D6ActivationPersistenceResultV1:
    snapshot_event: LedgerEvent
    activation_event: LedgerEvent
    write_order: tuple[str, str]


def persist_d6_activation_snapshot_first(
    *,
    ledger: TradeLedgerV1,
    snapshot: StrategyPositionSnapshot,
    entry_ready_id: str,
    opportunity_id: str,
    execution_evidence_id: str,
    opened_real_time: Any,
    hard_stop_price: str,
    snapshot_event_time_ms: int | None = None,
    activation_event_time_ms: int | None = None,
) -> D6ActivationPersistenceResultV1:
    if not isinstance(snapshot, StrategyPositionSnapshot):
        raise D6ActivationPersistenceBlock(
            "STRATEGY_POSITION_SNAPSHOT_REQUIRED"
        )

    position_id = str(getattr(snapshot, "position_id", "") or "")
    entry = getattr(snapshot, "entry", None)

    checks = {
        "entry_ready_id": (
            str(getattr(entry, "entry_ready_id", "") or ""),
            str(entry_ready_id),
        ),
        "opportunity_id": (
            str(getattr(entry, "opportunity_id", "") or ""),
            str(opportunity_id),
        ),
        "execution_evidence_id": (
            str(
                getattr(
                    snapshot,
                    "opened_from_execution_evidence_id",
                    "",
                )
                or ""
            ),
            str(execution_evidence_id),
        ),
        "opened_real_time": (
            getattr(snapshot, "opened_real_time", None),
            opened_real_time,
        ),
    }
    for name, (actual, expected) in checks.items():
        if actual != expected:
            raise D6ActivationPersistenceBlock(
                "D6_ACTIVATION_PERSISTENCE_IDENTITY_DRIFT:"
                + name
                + ":"
                + repr(actual)
                + "!="
                + repr(expected)
            )

    symbol = str(getattr(entry, "symbol", "") or "")
    if not symbol or not position_id:
        raise D6ActivationPersistenceBlock(
            "D6_ACTIVATION_PERSISTENCE_IDENTITY_INCOMPLETE"
        )
    if not hard_stop_price:
        raise D6ActivationPersistenceBlock(
            "HARD_STOP_PRICE_REQUIRED"
        )

    snapshot_event = build_d6_snapshot_ledger_event(
        snapshot=snapshot,
        entry_ready_id=entry_ready_id,
        event_time_ms=snapshot_event_time_ms,
    )
    activation_event = LedgerEvent.build(
        "D6_POSITION_ACTIVATED",
        symbol=symbol,
        event_time_ms=activation_event_time_ms,
        data={
            "position_id": position_id,
            "entry_ready_id": entry_ready_id,
            "opportunity_id": opportunity_id,
            "execution_evidence_id": execution_evidence_id,
            "opened_real_time": opened_real_time,
            "hard_stop_price": str(hard_stop_price),
            "snapshot_event_id": snapshot_event.event_id,
        },
    )

    # Safety ordering is intentional:
    # snapshot-only is recoverable-but-not-activated and restart stays blocked.
    # Activation is appended only after the full typed snapshot is durable.
    try:
        ledger.append(snapshot_event)
    except Exception as exc:
        raise D6ActivationPersistenceBlock(
            "D6_SNAPSHOT_APPEND_FAILED_BEFORE_ACTIVATION:"
            + exc.__class__.__name__
            + ":"
            + str(exc)
        ) from exc

    try:
        ledger.append(activation_event)
    except Exception as exc:
        raise D6ActivationPersistenceBlock(
            "D6_ACTIVATION_APPEND_FAILED_AFTER_SNAPSHOT_DURABLE:"
            + exc.__class__.__name__
            + ":"
            + str(exc)
        ) from exc

    return D6ActivationPersistenceResultV1(
        snapshot_event=snapshot_event,
        activation_event=activation_event,
        write_order=(
            "D6_POSITION_SNAPSHOT",
            "D6_POSITION_ACTIVATED",
        ),
    )


__all__ = [
    "D6ActivationPersistenceBlock",
    "D6ActivationPersistenceResultV1",
    "persist_d6_activation_snapshot_first",
]
