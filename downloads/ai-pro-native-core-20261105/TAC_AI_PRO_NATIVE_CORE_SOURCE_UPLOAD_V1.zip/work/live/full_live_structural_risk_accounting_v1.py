from __future__ import annotations

"""Pure full-live structural-risk accounting.

No policy thresholds are selected here. Risk is computed only from explicit
position quantity, strategy entry reference and an authoritative effective
hard-stop price. Price/PnL movement and unexecuted D6 structural continuation
cannot release budget.
"""

from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from typing import Any, Iterable, Mapping


class FullLiveStructuralRiskAccountingBlock(RuntimeError):
    pass


@dataclass(frozen=True)
class OpenStructuralRiskV1:
    symbol: str
    direction: str
    quantity: Decimal
    strategy_entry_reference_price: Decimal
    effective_hard_stop: Decimal
    risk_quote: Decimal
    hard_stop_authority: str


@dataclass(frozen=True)
class PortfolioStructuralRiskV1:
    total_risk_quote: Decimal
    long_risk_quote: Decimal
    short_risk_quote: Decimal
    per_symbol_risk_quote: Mapping[str, Decimal]
    positions: tuple[OpenStructuralRiskV1, ...]


def _positive(value: Any, label: str) -> Decimal:
    try:
        out = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise FullLiveStructuralRiskAccountingBlock(
            "INVALID_DECIMAL:" + label
        ) from exc
    if not out.is_finite() or out <= 0:
        raise FullLiveStructuralRiskAccountingBlock(
            "NONPOSITIVE_DECIMAL:" + label
        )
    return out


def open_position_structural_risk(
    *,
    symbol: str,
    direction: str,
    quantity: Any,
    strategy_entry_reference_price: Any,
    effective_hard_stop: Any,
    hard_stop_authority: str,
) -> OpenStructuralRiskV1:
    if not symbol:
        raise FullLiveStructuralRiskAccountingBlock("SYMBOL_REQUIRED")
    side = direction.upper()
    if side not in ("LONG", "SHORT"):
        raise FullLiveStructuralRiskAccountingBlock("DIRECTION_INVALID")
    if not hard_stop_authority:
        raise FullLiveStructuralRiskAccountingBlock(
            "EFFECTIVE_HARD_STOP_AUTHORITY_REQUIRED"
        )

    qty = _positive(quantity, "quantity")
    entry = _positive(
        strategy_entry_reference_price,
        "strategy_entry_reference_price",
    )
    stop = _positive(effective_hard_stop, "effective_hard_stop")

    if side == "LONG" and stop >= entry:
        raise FullLiveStructuralRiskAccountingBlock(
            "LONG_EFFECTIVE_HARD_STOP_NOT_ADVERSE_TO_ENTRY"
        )
    if side == "SHORT" and stop <= entry:
        raise FullLiveStructuralRiskAccountingBlock(
            "SHORT_EFFECTIVE_HARD_STOP_NOT_ADVERSE_TO_ENTRY"
        )

    risk = qty * abs(entry - stop)
    if risk <= 0:
        raise FullLiveStructuralRiskAccountingBlock(
            "STRUCTURAL_RISK_NOT_POSITIVE"
        )

    return OpenStructuralRiskV1(
        symbol=symbol,
        direction=side,
        quantity=qty,
        strategy_entry_reference_price=entry,
        effective_hard_stop=stop,
        risk_quote=risk,
        hard_stop_authority=hard_stop_authority,
    )


def aggregate_portfolio_structural_risk(
    positions: Iterable[OpenStructuralRiskV1],
) -> PortfolioStructuralRiskV1:
    rows = tuple(positions)
    by_symbol: dict[str, Decimal] = {}
    long_risk = Decimal("0")
    short_risk = Decimal("0")

    for row in rows:
        if not isinstance(row, OpenStructuralRiskV1):
            raise FullLiveStructuralRiskAccountingBlock(
                "OPEN_STRUCTURAL_RISK_ROW_REQUIRED"
            )
        if row.symbol in by_symbol:
            raise FullLiveStructuralRiskAccountingBlock(
                "MULTIPLE_ACTIVE_STRATEGY_POSITIONS_PER_SYMBOL:"
                + row.symbol
            )
        by_symbol[row.symbol] = row.risk_quote
        if row.direction == "LONG":
            long_risk += row.risk_quote
        elif row.direction == "SHORT":
            short_risk += row.risk_quote
        else:
            raise FullLiveStructuralRiskAccountingBlock(
                "ROW_DIRECTION_INVALID"
            )

    return PortfolioStructuralRiskV1(
        total_risk_quote=long_risk + short_risk,
        long_risk_quote=long_risk,
        short_risk_quote=short_risk,
        per_symbol_risk_quote=dict(sorted(by_symbol.items())),
        positions=rows,
    )


def invariants() -> Mapping[str, Any]:
    return {
        "risk_formula": "quantity*abs(strategy_entry_reference_price-effective_hard_stop)",
        "market_price_used": False,
        "pnl_used": False,
        "unexecuted_d6_pivot_releases_budget": False,
        "effective_hard_stop_authority_required": True,
        "closed_position_risk": "ABSENT_FROM_OPEN_SET_ZERO",
        "policy_thresholds_owned": False,
        "common_factor_model_owned": False,
        "allocation_priority_owned": False,
        "orders": 0,
        "fills": 0,
        "execution_intents": 0,
        "trading_activated": False,
    }


__all__ = [
    "FullLiveStructuralRiskAccountingBlock",
    "OpenStructuralRiskV1",
    "PortfolioStructuralRiskV1",
    "open_position_structural_risk",
    "aggregate_portfolio_structural_risk",
    "invariants",
]
