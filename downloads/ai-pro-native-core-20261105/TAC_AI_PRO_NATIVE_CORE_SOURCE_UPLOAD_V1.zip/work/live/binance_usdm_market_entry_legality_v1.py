from __future__ import annotations

"""Exchange-rule legality measurement for a proposed USD-M market entry.

Pure/nontrading.  It owns no strategy or execution-tolerance thresholds.
"""
from dataclasses import dataclass
from decimal import Decimal, ROUND_DOWN
from typing import Any

from binance_usdm_exchange_info_measurement_v1 import BinanceUSDMSymbolFactsV1


class USDMarketEntryLegalityBlock(RuntimeError): pass


@dataclass(frozen=True)
class USDMarketEntryLegalityV1:
    requested_quote_notional: Decimal
    reference_price: Decimal
    rounded_quantity: Decimal
    rounded_quote_notional: Decimal
    status_trading: bool
    quantity_at_or_above_min: bool
    quantity_at_or_below_max: bool
    notional_at_or_above_min: bool

    @property
    def exchange_legal(self)->bool:
        return all((self.status_trading,self.rounded_quantity>0,self.quantity_at_or_above_min,
                    self.quantity_at_or_below_max,self.notional_at_or_above_min))


def _d(x:Any)->Decimal:
    d=Decimal(str(x))
    if not d.is_finite() or d<=0: raise USDMarketEntryLegalityBlock("POSITIVE_DECIMAL_REQUIRED")
    return d


def measure_market_entry_legality(*,facts:BinanceUSDMSymbolFactsV1,requested_quote_notional:Any,reference_price:Any)->USDMarketEntryLegalityV1:
    target=_d(requested_quote_notional); price=_d(reference_price)
    try:
        step=_d(facts.market_lot_size["stepSize"]); minq=_d(facts.market_lot_size["minQty"]); maxq=_d(facts.market_lot_size["maxQty"])
    except Exception as exc: raise USDMarketEntryLegalityBlock("MARKET_LOT_SIZE_FIELDS_REQUIRED") from exc
    qty=(target/price/step).to_integral_value(rounding=ROUND_DOWN)*step
    quote=qty*price
    return USDMarketEntryLegalityV1(target,price,qty,quote,facts.status=="TRADING",
        qty>=minq,qty<=maxq,quote>=facts.min_notional)


def invariants():
    return {"policy_thresholds_owned":False,"exchange_rules_only":True,"orders":0,"fills":0,"execution_intents":0,"trading_activated":False}
