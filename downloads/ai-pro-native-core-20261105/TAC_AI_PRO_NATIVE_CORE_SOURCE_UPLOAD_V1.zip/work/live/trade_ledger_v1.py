from __future__ import annotations

import hashlib
import json
import os
import pathlib
import time
from dataclasses import dataclass
from typing import Any, Iterable


SCHEMA = "TAC_FULL_LIVE_TRADE_LEDGER_EVENT_V1"

_ALLOWED_TYPES = {
    "SIGNAL_ADMITTED",
    "ORDER_SUBMITTED",
    "ORDER_REJECTED",
    "FILL",
    "POSITION_OPENED",
    "D6_POSITION_ACTIVATED",
    "D6_POSITION_SNAPSHOT",
    "D6_POSITION_CONTINUED",
    "D6_POSITION_CLOSED",
    "INITIAL_STOP_PLACED",
    "PROTECTIVE_STOP_MOVED",
    "STRATEGY_EXIT_REQUESTED",
    "HARD_PROTECTION_TRIGGERED",
    "POSITION_CLOSED",
    "FEE",
    "FUNDING",
    "EQUITY_SNAPSHOT",
    "EXECUTION_ERROR",
}

_LEDGER_FIELDS = frozenset({
    "schema",
    "event_id",
    "event_type",
    "event_time_ms",
    "symbol",
    "data",
})


def canonical_json(value: Any) -> str:
    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    )


@dataclass(frozen=True)
class LedgerEvent:
    event_type: str
    symbol: str | None
    data: dict[str, Any]
    event_time_ms: int
    event_id: str

    @classmethod
    def build(
        cls,
        event_type: str,
        *,
        symbol: str | None = None,
        data: dict[str, Any] | None = None,
        event_time_ms: int | None = None,
    ) -> "LedgerEvent":
        if event_type not in _ALLOWED_TYPES:
            raise ValueError("UNSUPPORTED_LEDGER_EVENT_TYPE:" + event_type)
        ts = int(time.time_ns() // 1_000_000 if event_time_ms is None else event_time_ms)
        payload = {
            "schema": SCHEMA,
            "event_type": event_type,
            "symbol": symbol,
            "event_time_ms": ts,
            "data": dict(data or {}),
        }
        event_id = hashlib.sha256(canonical_json(payload).encode("utf-8")).hexdigest()
        return cls(
            event_type=event_type,
            symbol=symbol,
            data=dict(data or {}),
            event_time_ms=ts,
            event_id=event_id,
        )

    def as_dict(self) -> dict[str, Any]:
        return {
            "schema": SCHEMA,
            "event_id": self.event_id,
            "event_type": self.event_type,
            "event_time_ms": self.event_time_ms,
            "symbol": self.symbol,
            "data": self.data,
        }


class TradeLedgerV1:
    def __init__(self, path: str | os.PathLike[str]):
        self.path = pathlib.Path(path)

    @staticmethod
    def _validate_item(item: Any, *, lineno: int | None = None) -> dict[str, Any]:
        suffix = "" if lineno is None else f"_LINE_{lineno}"
        if not isinstance(item, dict):
            raise RuntimeError("LEDGER_ROW_NOT_OBJECT" + suffix)
        if set(item) != _LEDGER_FIELDS:
            raise RuntimeError("LEDGER_FIELD_DRIFT" + suffix)
        if item.get("schema") != SCHEMA:
            raise RuntimeError("LEDGER_SCHEMA_ERROR" + suffix)
        event_type = item.get("event_type")
        if event_type not in _ALLOWED_TYPES:
            raise RuntimeError("LEDGER_EVENT_TYPE_INVALID" + suffix)
        ts = item.get("event_time_ms")
        if isinstance(ts, bool) or not isinstance(ts, int) or ts <= 0:
            raise RuntimeError("LEDGER_EVENT_TIME_INVALID" + suffix)
        symbol = item.get("symbol")
        if symbol is not None and (not isinstance(symbol, str) or not symbol):
            raise RuntimeError("LEDGER_SYMBOL_INVALID" + suffix)
        if not isinstance(item.get("data"), dict):
            raise RuntimeError("LEDGER_DATA_INVALID" + suffix)
        event_id = item.get("event_id")
        if not isinstance(event_id, str) or len(event_id) != 64:
            raise RuntimeError("LEDGER_EVENT_ID_INVALID" + suffix)
        payload = {
            "schema": SCHEMA,
            "event_type": event_type,
            "symbol": symbol,
            "event_time_ms": ts,
            "data": item["data"],
        }
        expected = hashlib.sha256(
            canonical_json(payload).encode("utf-8")
        ).hexdigest()
        if event_id != expected:
            raise RuntimeError("LEDGER_EVENT_ID_MISMATCH" + suffix)
        return item

    def append(self, event: LedgerEvent) -> None:
        if not isinstance(event, LedgerEvent):
            raise TypeError("LEDGER_EVENT_REQUIRED")
        item = self._validate_item(event.as_dict())
        self.path.parent.mkdir(parents=True, exist_ok=True)
        line = canonical_json(item) + "\n"
        fd = os.open(
            self.path,
            os.O_WRONLY | os.O_CREAT | os.O_APPEND,
            0o600,
        )
        try:
            with os.fdopen(fd, "a", encoding="utf-8") as fh:
                fh.write(line)
                fh.flush()
                os.fsync(fh.fileno())
            dir_fd = os.open(self.path.parent, os.O_RDONLY)
            try:
                os.fsync(dir_fd)
            finally:
                os.close(dir_fd)
        except Exception:
            raise

    def read_all(self) -> tuple[dict[str, Any], ...]:
        if not self.path.exists():
            return ()
        out: list[dict[str, Any]] = []
        seen: set[str] = set()
        with self.path.open("r", encoding="utf-8") as fh:
            for lineno, raw in enumerate(fh, 1):
                raw = raw.strip()
                if not raw:
                    continue
                try:
                    item = json.loads(raw)
                except json.JSONDecodeError as exc:
                    raise RuntimeError(f"LEDGER_JSON_ERROR_LINE_{lineno}") from exc
                item = self._validate_item(item, lineno=lineno)
                event_id = item["event_id"]
                if event_id in seen:
                    raise RuntimeError(
                        f"LEDGER_DUPLICATE_EVENT_ID_LINE_{lineno}"
                    )
                seen.add(event_id)
                out.append(item)
        return tuple(out)

    def tail(self, limit: int = 200) -> tuple[dict[str, Any], ...]:
        rows = self.read_all()
        return rows[-max(0, int(limit)):]
