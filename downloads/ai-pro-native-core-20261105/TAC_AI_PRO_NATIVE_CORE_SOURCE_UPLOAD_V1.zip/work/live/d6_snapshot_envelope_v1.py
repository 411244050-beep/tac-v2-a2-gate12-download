from __future__ import annotations

import collections.abc
import dataclasses
import enum
import hashlib
import json
import types as pytypes
import typing
from fractions import Fraction
from typing import Any, Mapping

from strategy_rc1.d6_position_execution.types import StrategyPositionSnapshot
from strategy_rc1.runtime_guards.information_state import InfoKind, InfoValue


SCHEMA = "TAC_D6_POSITION_SNAPSHOT_ENVELOPE_V1"


class D6SnapshotCodecBlock(RuntimeError):
    pass


def _canonical_json(value: Any) -> str:
    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    )


def _encode(value: Any) -> Any:
    # Enum must precede primitive checks because Strategy enums may mix in
    # str/int and would otherwise lose their type tag.
    if isinstance(value, enum.Enum):
        return {
            "$enum": {
                "class": value.__class__.__name__,
                "name": value.name,
            }
        }

    if value is None or isinstance(value, (bool, int, str)):
        return value

    if isinstance(value, Fraction):
        return {"$fraction": [value.numerator, value.denominator]}

    if dataclasses.is_dataclass(value):
        cls = value.__class__
        return {
            "$dataclass": {
                "class": cls.__name__,
                "fields": {
                    field.name: _encode(getattr(value, field.name))
                    for field in dataclasses.fields(value)
                },
            }
        }

    if isinstance(value, Mapping):
        rows = [
            [str(key), _encode(child)]
            for key, child in value.items()
        ]
        rows.sort(key=lambda row: row[0])
        return {"$map": rows}

    if isinstance(value, tuple):
        return {"$tuple": [_encode(x) for x in value]}

    if isinstance(value, list):
        return {"$list": [_encode(x) for x in value]}

    raise D6SnapshotCodecBlock(
        "ENCODE_UNSUPPORTED_TYPE:"
        + value.__class__.__module__
        + "."
        + value.__class__.__qualname__
    )


def _unwrap_optional(annotation: Any) -> tuple[Any, bool]:
    origin = typing.get_origin(annotation)
    args = typing.get_args(annotation)
    if origin in (typing.Union, pytypes.UnionType):
        non_none = [arg for arg in args if arg is not type(None)]
        if len(non_none) == 1 and len(non_none) != len(args):
            return non_none[0], True
    return annotation, False


def _enum_decode(cls: type[Any], node: Any, path: str) -> Any:
    if not isinstance(node, dict) or set(node) != {"$enum"}:
        raise D6SnapshotCodecBlock("ENUM_TAG_REQUIRED:" + path)
    payload = node["$enum"]
    if not isinstance(payload, dict):
        raise D6SnapshotCodecBlock("ENUM_PAYLOAD_INVALID:" + path)
    if payload.get("class") != cls.__name__:
        raise D6SnapshotCodecBlock(
            "ENUM_CLASS_DRIFT:"
            + path
            + ":"
            + repr(payload.get("class"))
            + "!="
            + cls.__name__
        )
    name = str(payload.get("name", ""))
    if name not in cls.__members__:
        raise D6SnapshotCodecBlock(
            "ENUM_MEMBER_UNKNOWN:" + path + ":" + name
        )
    return cls.__members__[name]


def _decode_info_value(annotation: Any, node: Any, path: str) -> Any:
    if not isinstance(node, dict) or set(node) != {"$dataclass"}:
        raise D6SnapshotCodecBlock("INFOVALUE_TAG_REQUIRED:" + path)
    payload = node["$dataclass"]
    if payload.get("class") != InfoValue.__name__:
        raise D6SnapshotCodecBlock("INFOVALUE_CLASS_DRIFT:" + path)
    fields = payload.get("fields")
    if not isinstance(fields, dict):
        raise D6SnapshotCodecBlock("INFOVALUE_FIELDS_INVALID:" + path)

    required = {field.name for field in dataclasses.fields(InfoValue)}
    if set(fields) != required:
        raise D6SnapshotCodecBlock(
            "INFOVALUE_FIELD_DRIFT:"
            + path
            + ":"
            + repr(sorted(fields))
            + "!="
            + repr(sorted(required))
        )

    args = typing.get_args(annotation)
    value_annotation = args[0] if args else Any

    kind = _decode_expected(
        InfoKind,
        fields["kind"],
        path + ".kind",
    )
    value = _decode_expected(
        value_annotation,
        fields["value"],
        path + ".value",
    ) if fields["value"] is not None else None
    error_ref = _decode_expected(
        str,
        fields["error_ref"],
        path + ".error_ref",
    ) if fields["error_ref"] is not None else None

    try:
        return InfoValue(
            kind=kind,
            value=value,
            error_ref=error_ref,
        )
    except Exception as exc:
        raise D6SnapshotCodecBlock(
            "INFOVALUE_CONSTRUCTION_FAILED:"
            + path
            + ":"
            + exc.__class__.__name__
            + ":"
            + str(exc)
        ) from exc


def _decode_dataclass(cls: type[Any], node: Any, path: str) -> Any:
    if not isinstance(node, dict) or set(node) != {"$dataclass"}:
        raise D6SnapshotCodecBlock("DATACLASS_TAG_REQUIRED:" + path)
    payload = node["$dataclass"]
    if not isinstance(payload, dict):
        raise D6SnapshotCodecBlock("DATACLASS_PAYLOAD_INVALID:" + path)
    if payload.get("class") != cls.__name__:
        raise D6SnapshotCodecBlock(
            "DATACLASS_CLASS_DRIFT:"
            + path
            + ":"
            + repr(payload.get("class"))
            + "!="
            + cls.__name__
        )
    fields = payload.get("fields")
    if not isinstance(fields, dict):
        raise D6SnapshotCodecBlock("DATACLASS_FIELDS_INVALID:" + path)

    expected_fields = {field.name for field in dataclasses.fields(cls)}
    if set(fields) != expected_fields:
        raise D6SnapshotCodecBlock(
            "DATACLASS_FIELD_DRIFT:"
            + path
            + ":"
            + repr(sorted(fields))
            + "!="
            + repr(sorted(expected_fields))
        )

    hints = typing.get_type_hints(cls)
    kwargs: dict[str, Any] = {}
    for field in dataclasses.fields(cls):
        annotation = hints.get(field.name, field.type)
        kwargs[field.name] = _decode_expected(
            annotation,
            fields[field.name],
            path + "." + field.name,
        )

    try:
        return cls(**kwargs)
    except Exception as exc:
        raise D6SnapshotCodecBlock(
            "DATACLASS_CONSTRUCTION_FAILED:"
            + path
            + ":"
            + exc.__class__.__name__
            + ":"
            + str(exc)
        ) from exc


def _decode_any(node: Any, path: str) -> Any:
    if node is None or isinstance(node, (bool, int, str)):
        return node
    if isinstance(node, dict) and set(node) == {"$fraction"}:
        nums = node["$fraction"]
        if (
            not isinstance(nums, list)
            or len(nums) != 2
            or not all(isinstance(x, int) for x in nums)
        ):
            raise D6SnapshotCodecBlock("FRACTION_PAYLOAD_INVALID:" + path)
        return Fraction(nums[0], nums[1])
    if isinstance(node, dict) and set(node) == {"$map"}:
        rows = node["$map"]
        if not isinstance(rows, list):
            raise D6SnapshotCodecBlock("MAP_ROWS_INVALID:" + path)
        out: dict[str, Any] = {}
        for index, row in enumerate(rows):
            if not isinstance(row, list) or len(row) != 2:
                raise D6SnapshotCodecBlock(
                    "MAP_ROW_INVALID:" + path + ":" + str(index)
                )
            key = str(row[0])
            if key in out:
                raise D6SnapshotCodecBlock(
                    "MAP_DUPLICATE_KEY:" + path + ":" + key
                )
            out[key] = _decode_any(row[1], path + "." + key)
        return out
    if isinstance(node, dict) and set(node) == {"$tuple"}:
        return tuple(
            _decode_any(x, path + "[]")
            for x in node["$tuple"]
        )
    if isinstance(node, dict) and set(node) == {"$list"}:
        return [
            _decode_any(x, path + "[]")
            for x in node["$list"]
        ]
    raise D6SnapshotCodecBlock(
        "ANY_TAG_UNSUPPORTED:" + path + ":" + repr(node)
    )


def _decode_expected(annotation: Any, node: Any, path: str) -> Any:
    annotation, optional = _unwrap_optional(annotation)
    if node is None:
        if optional or annotation is Any:
            return None
        raise D6SnapshotCodecBlock("NONOPTIONAL_NONE:" + path)

    origin = typing.get_origin(annotation)
    args = typing.get_args(annotation)

    if annotation is Any:
        return _decode_any(node, path)

    if origin is typing.Annotated:
        return _decode_expected(args[0], node, path)

    if origin is InfoValue or annotation is InfoValue:
        return _decode_info_value(annotation, node, path)

    if annotation is Fraction:
        if not isinstance(node, dict) or set(node) != {"$fraction"}:
            raise D6SnapshotCodecBlock("FRACTION_TAG_REQUIRED:" + path)
        nums = node["$fraction"]
        if (
            not isinstance(nums, list)
            or len(nums) != 2
            or not all(isinstance(x, int) for x in nums)
        ):
            raise D6SnapshotCodecBlock("FRACTION_PAYLOAD_INVALID:" + path)
        return Fraction(nums[0], nums[1])

    if annotation in (str, int, bool):
        if not isinstance(node, annotation):
            raise D6SnapshotCodecBlock(
                "PRIMITIVE_TYPE_DRIFT:"
                + path
                + ":expected="
                + annotation.__name__
                + ":actual="
                + type(node).__name__
            )
        return node

    if isinstance(annotation, type) and issubclass(annotation, enum.Enum):
        return _enum_decode(annotation, node, path)

    if isinstance(annotation, type) and dataclasses.is_dataclass(annotation):
        return _decode_dataclass(annotation, node, path)

    if origin is not None and isinstance(origin, type) and dataclasses.is_dataclass(origin):
        if origin is InfoValue:
            return _decode_info_value(annotation, node, path)
        return _decode_dataclass(origin, node, path)

    if origin in (
        dict,
        Mapping,
        typing.Mapping,
        collections.abc.Mapping,
    ):
        if not isinstance(node, dict) or set(node) != {"$map"}:
            raise D6SnapshotCodecBlock("MAP_TAG_REQUIRED:" + path)
        key_ann = args[0] if len(args) >= 1 else str
        value_ann = args[1] if len(args) >= 2 else Any
        rows = node["$map"]
        if not isinstance(rows, list):
            raise D6SnapshotCodecBlock("MAP_ROWS_INVALID:" + path)
        out: dict[Any, Any] = {}
        for index, row in enumerate(rows):
            if not isinstance(row, list) or len(row) != 2:
                raise D6SnapshotCodecBlock(
                    "MAP_ROW_INVALID:" + path + ":" + str(index)
                )
            key = _decode_expected(
                key_ann,
                row[0],
                path + ".<key>",
            )
            if key in out:
                raise D6SnapshotCodecBlock(
                    "MAP_DUPLICATE_KEY:" + path + ":" + str(key)
                )
            out[key] = _decode_expected(
                value_ann,
                row[1],
                path + "." + str(key),
            )
        return out

    if origin in (tuple, list):
        tag = "$tuple" if origin is tuple else "$list"
        if not isinstance(node, dict) or set(node) != {tag}:
            raise D6SnapshotCodecBlock(
                "SEQUENCE_TAG_REQUIRED:" + path
            )
        item_ann = args[0] if args else Any
        decoded = [
            _decode_expected(item_ann, x, path + "[]")
            for x in node[tag]
        ]
        return tuple(decoded) if origin is tuple else decoded

    raise D6SnapshotCodecBlock(
        "DECODE_ANNOTATION_UNSUPPORTED:"
        + path
        + ":"
        + repr(annotation)
    )


def encode_d6_position_snapshot(
    snapshot: StrategyPositionSnapshot,
) -> bytes:
    if not isinstance(snapshot, StrategyPositionSnapshot):
        raise D6SnapshotCodecBlock(
            "STRATEGY_POSITION_SNAPSHOT_REQUIRED"
        )

    payload = _encode(snapshot)
    payload_bytes = _canonical_json(payload).encode("utf-8")
    envelope = {
        "schema": SCHEMA,
        "payload": payload,
        "payload_sha256": hashlib.sha256(payload_bytes).hexdigest(),
    }
    return _canonical_json(envelope).encode("utf-8")


def decode_d6_position_snapshot(
    envelope_bytes: bytes | str,
) -> StrategyPositionSnapshot:
    text = (
        envelope_bytes.decode("utf-8")
        if isinstance(envelope_bytes, bytes)
        else str(envelope_bytes)
    )
    try:
        envelope = json.loads(text)
    except Exception as exc:
        raise D6SnapshotCodecBlock("ENVELOPE_JSON_INVALID") from exc

    if not isinstance(envelope, dict):
        raise D6SnapshotCodecBlock("ENVELOPE_OBJECT_REQUIRED")
    if set(envelope) != {"schema", "payload", "payload_sha256"}:
        raise D6SnapshotCodecBlock("ENVELOPE_FIELD_DRIFT")
    if envelope.get("schema") != SCHEMA:
        raise D6SnapshotCodecBlock("ENVELOPE_SCHEMA_DRIFT")

    payload = envelope["payload"]
    expected_digest = str(envelope["payload_sha256"])
    actual_digest = hashlib.sha256(
        _canonical_json(payload).encode("utf-8")
    ).hexdigest()
    if actual_digest != expected_digest:
        raise D6SnapshotCodecBlock(
            "ENVELOPE_PAYLOAD_DIGEST_MISMATCH"
        )

    out = _decode_expected(
        StrategyPositionSnapshot,
        payload,
        "StrategyPositionSnapshot",
    )
    if not isinstance(out, StrategyPositionSnapshot):
        raise D6SnapshotCodecBlock("DECODED_SNAPSHOT_TYPE_DRIFT")
    return out


__all__ = [
    "SCHEMA",
    "D6SnapshotCodecBlock",
    "encode_d6_position_snapshot",
    "decode_d6_position_snapshot",
]
