from __future__ import annotations

from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Any, Mapping, Sequence

from full_live_d5_mechanism_source_binding_v1 import (
    ExplicitAdverseDefensePivotAuthorityV1,
)
from strategy_rc1.d2_market_state.types import (
    PivotType,
    PlatformStatus,
    StructuralLayer,
    StructuralPivot,
    TrendDirection,
)
from strategy_rc1.d3_boundary_intelligence.types import (
    BreakState,
    InteractionControl,
    InteractionEvent,
    InteractionResolution,
)
from strategy_rc1.d4_opportunity.types import OpportunityMechanism
from strategy_rc1.ids import deterministic_id
from strategy_rc1.runtime_guards.information_state import InfoKind, InfoValue


class FullLiveD5PlatformAdverseDefenseBlock(RuntimeError):
    pass


@dataclass(frozen=True)
class PlatformAdverseDefenseProjectionV1:
    state: str
    authority: ExplicitAdverseDefensePivotAuthorityV1 | None
    reason: str
    contributing_event_ids: tuple[str, ...]
    event_defense_pivot_ids: tuple[str, ...]
    provenance: Mapping[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "provenance",
            MappingProxyType(dict(self.provenance)),
        )


def _projection(
    *,
    state: str,
    authority: ExplicitAdverseDefensePivotAuthorityV1 | None,
    reason: str,
    event_ids: tuple[str, ...],
    defense_ids: tuple[str, ...] = (),
    provenance: Mapping[str, str] | None = None,
) -> PlatformAdverseDefenseProjectionV1:
    return PlatformAdverseDefenseProjectionV1(
        state=state,
        authority=authority,
        reason=reason,
        contributing_event_ids=event_ids,
        event_defense_pivot_ids=defense_ids,
        provenance=provenance or {},
    )


def _canonical_events(
    events: Sequence[InteractionEvent],
) -> dict[str, InteractionEvent]:
    out: dict[str, InteractionEvent] = {}
    for event in events:
        old = out.get(event.event_id)
        if old is not None and old != event:
            raise FullLiveD5PlatformAdverseDefenseBlock(
                "DIVERGENT_DUPLICATE_INTERACTION_EVENT:" + event.event_id
            )
        out[event.event_id] = event
    return out


def _canonical_pivots(
    pivots: Sequence[StructuralPivot],
) -> dict[str, StructuralPivot]:
    out: dict[str, StructuralPivot] = {}
    for pivot in pivots:
        old = out.get(pivot.pivot_id)
        if old is not None and old != pivot:
            raise FullLiveD5PlatformAdverseDefenseBlock(
                "DIVERGENT_DUPLICATE_STRUCTURAL_PIVOT:" + pivot.pivot_id
            )
        out[pivot.pivot_id] = pivot
    return out


def _trend_side_type(direction: TrendDirection) -> PivotType:
    if direction is TrendDirection.LONG:
        return PivotType.HIGH
    if direction is TrendDirection.SHORT:
        return PivotType.LOW
    raise FullLiveD5PlatformAdverseDefenseBlock(
        "PLATFORM_DIRECTION_NOT_LONG_OR_SHORT"
    )


def _adverse_type(direction: TrendDirection) -> PivotType:
    if direction is TrendDirection.LONG:
        return PivotType.LOW
    if direction is TrendDirection.SHORT:
        return PivotType.HIGH
    raise FullLiveD5PlatformAdverseDefenseBlock(
        "PLATFORM_DIRECTION_NOT_LONG_OR_SHORT"
    )


def _pick_unique_adverse_most(
    pivots: Sequence[StructuralPivot],
    *,
    direction: TrendDirection,
    conflict_prefix: str,
) -> StructuralPivot:
    if not pivots:
        raise FullLiveD5PlatformAdverseDefenseBlock(
            conflict_prefix + ":NO_ELIGIBLE_ADVERSE_DEFENSE_PIVOT"
        )
    if direction is TrendDirection.LONG:
        price = min(p.extreme_price for p in pivots)
    elif direction is TrendDirection.SHORT:
        price = max(p.extreme_price for p in pivots)
    else:
        raise FullLiveD5PlatformAdverseDefenseBlock(
            "PLATFORM_DIRECTION_NOT_LONG_OR_SHORT"
        )
    winners = tuple(p for p in pivots if p.extreme_price == price)
    ids = tuple(sorted({p.pivot_id for p in winners}))
    if len(ids) != 1:
        raise FullLiveD5PlatformAdverseDefenseBlock(
            conflict_prefix + ":EQUAL_PRICE_CONFLICT_NO_WINNER:" + ",".join(ids)
        )
    return winners[0]


def produce_platform_adverse_defense_authority(
    *,
    platform_memory: Any,
    events: Sequence[InteractionEvent],
    all_minor: Sequence[StructuralPivot],
    information_cutoff: int,
    history_complete_through_platform_confirmation: InfoValue[bool],
) -> PlatformAdverseDefenseProjectionV1:
    """Produce exact Platform Risk-Anchor source authority.

    Semantic freeze:
      - use only the two frozen contributing Platform source interactions,
      - for each event, use adverse MINOR pivots whose extreme interval occurred
        inside that interaction active interval and which were confirmed no
        later than the event's frozen source p1 confirmation,
      - choose unique adverse-most within each event and then unique
        adverse-most across the confirmed Platform episode.

    No numeric threshold, fixed window, recency selector, or position-size
    fitting is introduced.
    """

    platform = getattr(platform_memory, "platform", None)
    if platform is None:
        return _projection(
            state="UNKNOWN",
            authority=None,
            reason="PLATFORM_MEMORY_PLATFORM_MISSING",
            event_ids=(),
        )
    if platform.status is not PlatformStatus.PLATFORM_CONFIRMED:
        return _projection(
            state="N/A",
            authority=None,
            reason="PLATFORM_NOT_CONFIRMED",
            event_ids=tuple(getattr(platform, "contributing_event_ids", ())),
        )
    confirmed_at = platform.confirmed_at
    memory_cutoff = getattr(platform_memory, "last_evaluated_cutoff", None)
    if memory_cutoff is None or int(memory_cutoff) < int(confirmed_at or 0):
        return _projection(
            state="UNKNOWN",
            authority=None,
            reason="PLATFORM_MEMORY_NOT_COMPLETE_THROUGH_CONFIRMATION",
            event_ids=tuple(getattr(platform, "contributing_event_ids", ())),
        )
    if confirmed_at is None:
        raise FullLiveD5PlatformAdverseDefenseBlock(
            "CONFIRMED_PLATFORM_WITHOUT_CONFIRMED_AT"
        )
    if confirmed_at > information_cutoff:
        raise FullLiveD5PlatformAdverseDefenseBlock(
            "FUTURE_PLATFORM_CONFIRMATION_FORBIDDEN"
        )

    event_ids = tuple(platform.contributing_event_ids)
    if len(event_ids) != 2 or len(set(event_ids)) != 2:
        raise FullLiveD5PlatformAdverseDefenseBlock(
            "CONFIRMED_PLATFORM_REQUIRES_EXACTLY_TWO_DISTINCT_CONTRIBUTING_EVENTS"
        )

    direction = getattr(platform_memory, "direction", None)
    trend_episode_id = getattr(platform_memory, "trend_episode_id", None)
    segment = getattr(platform_memory, "canonical_segment_id", None)
    if direction not in (TrendDirection.LONG, TrendDirection.SHORT):
        raise FullLiveD5PlatformAdverseDefenseBlock(
            "PLATFORM_MEMORY_DIRECTION_INVALID"
        )
    if not trend_episode_id:
        raise FullLiveD5PlatformAdverseDefenseBlock(
            "PLATFORM_MEMORY_TREND_EPISODE_ID_REQUIRED"
        )
    if not segment:
        return _projection(
            state="UNKNOWN",
            authority=None,
            reason="PLATFORM_CANONICAL_SEGMENT_AUTHORITY_MISSING",
            event_ids=event_ids,
        )

    if history_complete_through_platform_confirmation.kind is InfoKind.ERROR:
        return _projection(
            state="ERROR",
            authority=None,
            reason="PLATFORM_PIVOT_HISTORY_COMPLETENESS_ERROR",
            event_ids=event_ids,
        )
    if (
        history_complete_through_platform_confirmation.kind is not InfoKind.KNOWN
        or history_complete_through_platform_confirmation.value is not True
    ):
        return _projection(
            state="UNKNOWN",
            authority=None,
            reason="PLATFORM_PIVOT_HISTORY_NOT_PROVEN_COMPLETE",
            event_ids=event_ids,
            provenance={"absence_not_treated_as_defense": "true"},
        )

    event_map = _canonical_events(events)
    pivot_map = _canonical_pivots(all_minor)
    source_pairs = dict(
        getattr(platform_memory, "source_pivot_by_event_id", ())
    )

    per_event: list[StructuralPivot] = []
    for event_id in event_ids:
        event = event_map.get(event_id)
        if event is None:
            return _projection(
                state="UNKNOWN",
                authority=None,
                reason="CONTRIBUTING_INTERACTION_EVENT_MISSING:" + event_id,
                event_ids=event_ids,
                defense_ids=tuple(p.pivot_id for p in per_event),
            )
        if (
            event.target_trend_episode_id != trend_episode_id
            or event.target_direction is not direction
        ):
            raise FullLiveD5PlatformAdverseDefenseBlock(
                "CONTRIBUTING_INTERACTION_LINEAGE_CONFLICT:" + event_id
            )
        if (
            event.control is not InteractionControl.RESOLVED
            or event.resolution is not InteractionResolution.RESOLVED_CORRECT_SIDE
            or event.break_state is BreakState.TRUE_BREAK
        ):
            raise FullLiveD5PlatformAdverseDefenseBlock(
                "CONTRIBUTING_INTERACTION_NOT_FROZEN_PLATFORM_SOURCE:"
                + event_id
            )
        if event.started_at is None or event.resolved_at is None:
            return _projection(
                state="UNKNOWN",
                authority=None,
                reason="CONTRIBUTING_INTERACTION_INTERVAL_UNKNOWN:" + event_id,
                event_ids=event_ids,
                defense_ids=tuple(p.pivot_id for p in per_event),
            )
        if event.started_at > event.resolved_at:
            raise FullLiveD5PlatformAdverseDefenseBlock(
                "CONTRIBUTING_INTERACTION_INTERVAL_INVALID:" + event_id
            )

        p1_id = source_pairs.get(event_id)
        if not p1_id:
            return _projection(
                state="UNKNOWN",
                authority=None,
                reason="PLATFORM_SOURCE_P1_ASSOCIATION_MISSING:" + event_id,
                event_ids=event_ids,
                defense_ids=tuple(p.pivot_id for p in per_event),
            )
        p1 = pivot_map.get(p1_id)
        if p1 is None:
            return _projection(
                state="UNKNOWN",
                authority=None,
                reason="PLATFORM_SOURCE_P1_RECORD_MISSING:" + p1_id,
                event_ids=event_ids,
                defense_ids=tuple(p.pivot_id for p in per_event),
            )
        if (
            p1.layer is not StructuralLayer.MINOR
            or p1.timeframe_ms != 15 * 60 * 1000
            or p1.pivot_type is not _trend_side_type(direction)
            or p1.canonical_segment_id != segment
            or not p1.provenance
        ):
            raise FullLiveD5PlatformAdverseDefenseBlock(
                "PLATFORM_SOURCE_P1_CONTRACT_CONFLICT:" + p1_id
            )
        if p1.confirmed_at <= event.resolved_at:
            raise FullLiveD5PlatformAdverseDefenseBlock(
                "PLATFORM_SOURCE_P1_NOT_AFTER_INTERACTION_RESOLUTION:" + p1_id
            )
        if p1.confirmed_at > confirmed_at:
            raise FullLiveD5PlatformAdverseDefenseBlock(
                "PLATFORM_SOURCE_P1_AFTER_PLATFORM_CONFIRMATION:" + p1_id
            )

        candidates = tuple(
            p
            for p in pivot_map.values()
            if (
                p.symbol == p1.symbol
                and p.timeframe_ms == p1.timeframe_ms
                and p.layer is StructuralLayer.MINOR
                and p.pivot_type is _adverse_type(direction)
                and p.canonical_segment_id == segment
                and p.extreme_first_time >= event.started_at
                and p.extreme_last_time <= event.resolved_at
                and p.confirmed_at >= event.started_at
                and p.confirmed_at <= p1.confirmed_at
            )
        )
        for candidate in candidates:
            if not candidate.provenance:
                raise FullLiveD5PlatformAdverseDefenseBlock(
                    "PLATFORM_ADVERSE_DEFENSE_PIVOT_PROVENANCE_MISSING:"
                    + candidate.pivot_id
                )
        if not candidates:
            return _projection(
                state="UNKNOWN",
                authority=None,
                reason="NO_CONFIRMED_ADVERSE_DEFENSE_PIVOT_FOR_EVENT:" + event_id,
                event_ids=event_ids,
                defense_ids=tuple(p.pivot_id for p in per_event),
            )

        chosen = _pick_unique_adverse_most(
            candidates,
            direction=direction,
            conflict_prefix="PLATFORM_EVENT_DEFENSE:" + event_id,
        )
        per_event.append(chosen)

    episode_pivot = _pick_unique_adverse_most(
        per_event,
        direction=direction,
        conflict_prefix="PLATFORM_EPISODE_DEFENSE",
    )
    lineage_id = deterministic_id(
        "D5-PLATFORM-EPISODE-RISK",
        trend_episode_id,
        *event_ids,
        str(confirmed_at),
    )
    source_authority_id = deterministic_id(
        "D5-PLATFORM-ADVERSE-DEFENSE",
        lineage_id,
        episode_pivot.pivot_id,
    )
    authority = ExplicitAdverseDefensePivotAuthorityV1(
        mechanism=OpportunityMechanism.PLATFORM_REEXPANSION,
        pivot=episode_pivot,
        lineage_id=lineage_id,
        source_authority_id=source_authority_id,
        provenance={
            "semantic_id": (
                "TAC_FULL_LIVE_D5_PLATFORM_ADVERSE_DEFENSE_"
                "SOURCE_ASSOCIATION_SEMANTIC_V1"
            ),
            "trend_episode_id": trend_episode_id,
            "platform_confirmed_at": str(confirmed_at),
            "contributing_event_ids": ",".join(event_ids),
            "event_defense_pivot_ids": ",".join(
                p.pivot_id for p in per_event
            ),
            "selection": "UNIQUE_ADVERSE_MOST_OF_CAUSAL_EVENT_DEFENSE_PIVOTS",
            "new_numeric_threshold": "false",
            "fixed_window_used": "false",
            "protected_intermediate_used_as_risk_anchor": "false",
        },
    )
    return _projection(
        state="BOUND",
        authority=authority,
        reason="PLATFORM_ADVERSE_DEFENSE_AUTHORITY_BOUND",
        event_ids=event_ids,
        defense_ids=tuple(p.pivot_id for p in per_event),
        provenance={
            "selected_pivot_id": episode_pivot.pivot_id,
            "source_authority_id": source_authority_id,
        },
    )
