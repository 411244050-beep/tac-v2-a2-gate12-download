from __future__ import annotations
from dataclasses import dataclass
import hashlib, json
from typing import Mapping

SLOTS=(
"per_trade_account_risk","per_symbol_risk_cap","total_portfolio_risk_cap",
"same_direction_aggregate_cap","correlation_common_factor_budget",
"listing_liquidity_capacity_thresholds","spread_slippage_depth_feasibility_boundaries",
"execution_allowance","kill_switch_numeric_triggers","PORT_007_allocation_priority_policy",
)

class OperationalEnforcementEvidenceBlock(RuntimeError): pass

@dataclass(frozen=True)
class SlotEnforcementResultV1:
    state:str
    evidence_id:str
    mechanism:str

@dataclass(frozen=True)
class OperationalEnforcementEvidenceV1:
    evidence_id:str
    symbol:str
    entry_ready_id:str
    information_cutoff:int
    slot_results:Mapping[str,str]
    slot_evidence:Mapping[str,str]

def compose_operational_enforcement_evidence(
    results:Mapping[str,SlotEnforcementResultV1],
    *,
    symbol:str,
    entry_ready_id:str,
    information_cutoff:int,
)->OperationalEnforcementEvidenceV1:
    if set(results)!=set(SLOTS):
        raise OperationalEnforcementEvidenceBlock("TEN_SLOT_SET_REQUIRED")
    if not symbol or not entry_ready_id:
        raise OperationalEnforcementEvidenceBlock("ENTRY_SUBJECT_REQUIRED")
    if not isinstance(information_cutoff,int) or information_cutoff<0:
        raise OperationalEnforcementEvidenceBlock("ENTRY_SUBJECT_CUTOFF_INVALID")
    bad=sorted(k for k,v in results.items() if not isinstance(v,SlotEnforcementResultV1) or v.state!="PASS")
    if bad: raise OperationalEnforcementEvidenceBlock("NONPASS_SLOTS:"+",".join(bad))
    if any(not v.evidence_id or not v.mechanism for v in results.values()):
        raise OperationalEnforcementEvidenceBlock("SLOT_PROVENANCE_REQUIRED")
    canonical=json.dumps({
        "subject":{
            "symbol":symbol,
            "entry_ready_id":entry_ready_id,
            "information_cutoff":information_cutoff,
        },
        "slots":{k:{"evidence_id":results[k].evidence_id,"mechanism":results[k].mechanism}
                 for k in SLOTS},
    },sort_keys=True,separators=(",",":"))
    eid="OPERATIONAL_ENFORCEMENT_SHA256:"+hashlib.sha256(canonical.encode()).hexdigest()
    return OperationalEnforcementEvidenceV1(
        eid,symbol,entry_ready_id,information_cutoff,
        {k:"PASS" for k in SLOTS},{k:results[k].evidence_id for k in SLOTS},
    )

def invariants():
    return {"exact_ten_slots_required":True,"all_slots_pass_required":True,"slot_provenance_required":True,
            "entry_subject_bound_into_evidence_id":True,"thresholds_owned":False,"selector_added":False,"ranking_added":False,
            "orders":0,"fills":0,"execution_intents":0,"trading_activated":False}
