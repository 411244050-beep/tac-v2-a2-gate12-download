from __future__ import annotations

import json
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Any, Mapping, Sequence

from full_live_d5_mechanism_source_binding_v1 import (
    ExplicitAdverseDefensePivotAuthorityV1,
)
from strategy_rc1.d2_market_state.types import (
    PivotType,
    StructuralLayer,
    StructuralPivot,
    TrendDirection,
)
from strategy_rc1.d3_boundary_intelligence.types import RoleTransition
from strategy_rc1.d4_opportunity.types import OpportunityMechanism
from strategy_rc1.ids import deterministic_id
from strategy_rc1.runtime_guards.information_state import InfoKind, InfoValue


class FullLiveD5DeepAdverseDefenseBlock(RuntimeError):
    pass


@dataclass(frozen=True)
class DeepAdverseDefenseProjectionV1:
    state: str
    authority: ExplicitAdverseDefensePivotAuthorityV1 | None
    reason: str
    source_pivot_ids: tuple[str, ...]
    adverse_source_pivot_ids: tuple[str, ...]
    provenance: Mapping[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "provenance",
            MappingProxyType(dict(self.provenance)),
        )


def _projection(
    *,
    state: str,
    authority: ExplicitAdverseDefensePivotAuthorityV1 | None,
    reason: str,
    source_ids: tuple[str, ...] = (),
    adverse_ids: tuple[str, ...] = (),
    provenance: Mapping[str, str] | None = None,
) -> DeepAdverseDefenseProjectionV1:
    return DeepAdverseDefenseProjectionV1(
        state=state,
        authority=authority,
        reason=reason,
        source_pivot_ids=source_ids,
        adverse_source_pivot_ids=adverse_ids,
        provenance=provenance or {},
    )


def _adverse_type(direction: TrendDirection) -> PivotType:
    if direction is TrendDirection.LONG:
        return PivotType.LOW
    if direction is TrendDirection.SHORT:
        return PivotType.HIGH
    raise FullLiveD5DeepAdverseDefenseBlock(
        "DEEP_DIRECTION_NOT_LONG_OR_SHORT"
    )


def _parse_source_ids(provenance: Mapping[str, str]) -> tuple[str, ...]:
    raw = provenance.get("source_pivot_ids")
    if not raw:
        raise FullLiveD5DeepAdverseDefenseBlock(
            "DEEP_REGAIN_SOURCE_PIVOT_IDS_MISSING"
        )
    try:
        decoded = json.loads(raw)
    except Exception as exc:
        raise FullLiveD5DeepAdverseDefenseBlock(
            "DEEP_REGAIN_SOURCE_PIVOT_IDS_INVALID_JSON"
        ) from exc
    if not isinstance(decoded, list) or not decoded:
        raise FullLiveD5DeepAdverseDefenseBlock(
            "DEEP_REGAIN_SOURCE_PIVOT_IDS_EMPTY"
        )
    ids = tuple(str(x) for x in decoded)
    if any(not x for x in ids) or len(set(ids)) != len(ids):
        raise FullLiveD5DeepAdverseDefenseBlock(
            "DEEP_REGAIN_SOURCE_PIVOT_IDS_INVALID_OR_DUPLICATE"
        )
    return ids


def _canonical_pivots(
    pivots: Sequence[StructuralPivot],
) -> dict[str, StructuralPivot]:
    out: dict[str, StructuralPivot] = {}
    for pivot in pivots:
        old = out.get(pivot.pivot_id)
        if old is not None and old != pivot:
            raise FullLiveD5DeepAdverseDefenseBlock(
                "DIVERGENT_DUPLICATE_STRUCTURAL_PIVOT:" + pivot.pivot_id
            )
        out[pivot.pivot_id] = pivot
    return out


def _pick_unique_adverse_most(
    pivots: Sequence[StructuralPivot],
    *,
    direction: TrendDirection,
) -> StructuralPivot:
    if not pivots:
        raise FullLiveD5DeepAdverseDefenseBlock(
            "DEEP_CONFIRMATION_SEQUENCE_HAS_NO_ADVERSE_PIVOT"
        )
    price = (
        min(p.extreme_price for p in pivots)
        if direction is TrendDirection.LONG
        else max(p.extreme_price for p in pivots)
    )
    winners = tuple(p for p in pivots if p.extreme_price == price)
    ids = tuple(sorted({p.pivot_id for p in winners}))
    if len(ids) != 1:
        raise FullLiveD5DeepAdverseDefenseBlock(
            "DEEP_ADVERSE_EXTREME_EQUAL_PRICE_CONFLICT_NO_WINNER:"
            + ",".join(ids)
        )
    return winners[0]


def produce_deep_adverse_defense_authority(
    *,
    deep_evidence: Any,
    symbol: str,
    canonical_segment_id: str,
    confirmed_minor_pivots: Sequence[StructuralPivot],
    information_cutoff: int,
    history_complete_through_confirmation: InfoValue[bool],
) -> DeepAdverseDefenseProjectionV1:
    """Produce Deep Structure Takeover adverse-defense source authority.

    Only the exact D2 pivot ids frozen into the Deep mechanism's
    LocalTrendControlRegain provenance are eligible.  No arbitrary deeper
    history/window is scanned.
    """

    if not symbol:
        raise FullLiveD5DeepAdverseDefenseBlock("SYMBOL_REQUIRED")
    if not canonical_segment_id:
        return _projection(
            state="UNKNOWN",
            authority=None,
            reason="DEEP_CANONICAL_SEGMENT_AUTHORITY_MISSING",
        )
    if (
        getattr(
            deep_evidence,
            "shallow_operating_defense_no_longer_completes_setup",
            None,
        )
        is not True
        or getattr(deep_evidence, "deeper_boundary_independent", None)
        is not True
    ):
        return _projection(
            state="N/A",
            authority=None,
            reason="DEEP_TAKEOVER_BASE_EVIDENCE_NOT_EXECUTABLE_TRUE",
        )

    interaction = getattr(deep_evidence, "deeper_interaction", None)
    if interaction is None:
        return _projection(
            state="UNKNOWN",
            authority=None,
            reason="DEEPER_INTERACTION_MISSING",
        )
    direction = getattr(interaction, "target_direction", None)
    if direction not in (TrendDirection.LONG, TrendDirection.SHORT):
        raise FullLiveD5DeepAdverseDefenseBlock(
            "DEEP_INTERACTION_DIRECTION_INVALID"
        )
    if interaction.started_at is None or interaction.started_at > information_cutoff:
        return _projection(
            state="UNKNOWN",
            authority=None,
            reason="DEEPER_INTERACTION_NOT_CAUSAL_BY_CUTOFF",
        )

    regain = getattr(deep_evidence, "local_control_regain", None)
    if regain is None:
        return _projection(
            state="UNKNOWN",
            authority=None,
            reason="DEEP_LOCAL_CONTROL_REGAIN_MISSING",
        )
    if regain.direction is not direction:
        raise FullLiveD5DeepAdverseDefenseBlock(
            "DEEP_LOCAL_CONTROL_REGAIN_DIRECTION_CONFLICT"
        )
    if regain.confirmation_cutoff > information_cutoff:
        raise FullLiveD5DeepAdverseDefenseBlock(
            "FUTURE_DEEP_LOCAL_CONTROL_REGAIN_FORBIDDEN"
        )

    role_transition = getattr(deep_evidence, "role_transition", None)
    promotion_cutoff = getattr(
        deep_evidence,
        "promotion_confirmed_at",
        None,
    )
    if role_transition is not RoleTransition.PROMOTION:
        return _projection(
            state="N/A",
            authority=None,
            reason="DEEP_ROLE_PROMOTION_NOT_CONFIRMED",
        )
    if promotion_cutoff is None:
        return _projection(
            state="UNKNOWN",
            authority=None,
            reason="DEEP_PROMOTION_CUTOFF_UNKNOWN",
        )
    if promotion_cutoff > information_cutoff:
        raise FullLiveD5DeepAdverseDefenseBlock(
            "FUTURE_DEEP_PROMOTION_FORBIDDEN"
        )

    if history_complete_through_confirmation.kind is InfoKind.ERROR:
        return _projection(
            state="ERROR",
            authority=None,
            reason="DEEP_PIVOT_HISTORY_COMPLETENESS_ERROR",
        )
    if (
        history_complete_through_confirmation.kind is not InfoKind.KNOWN
        or history_complete_through_confirmation.value is not True
    ):
        return _projection(
            state="UNKNOWN",
            authority=None,
            reason="DEEP_PIVOT_HISTORY_NOT_PROVEN_COMPLETE",
            provenance={"absence_not_treated_as_defense": "true"},
        )

    source_ids = _parse_source_ids(regain.provenance)
    by_id = _canonical_pivots(confirmed_minor_pivots)
    missing = tuple(x for x in source_ids if x not in by_id)
    if missing:
        return _projection(
            state="UNKNOWN",
            authority=None,
            reason=(
                "DEEP_REGAIN_SOURCE_PIVOT_NOT_IN_AUTHORITATIVE_HISTORY:"
                + ",".join(missing)
            ),
            source_ids=source_ids,
        )

    rows = tuple(by_id[x] for x in source_ids)
    for pivot in rows:
        if (
            pivot.symbol != symbol
            or pivot.timeframe_ms != 15 * 60 * 1000
            or pivot.layer is not StructuralLayer.MINOR
            or pivot.canonical_segment_id != canonical_segment_id
        ):
            raise FullLiveD5DeepAdverseDefenseBlock(
                "DEEP_REGAIN_SOURCE_PIVOT_LINEAGE_CONFLICT:" + pivot.pivot_id
            )
        if pivot.confirmed_at > regain.confirmation_cutoff:
            raise FullLiveD5DeepAdverseDefenseBlock(
                "DEEP_REGAIN_SOURCE_PIVOT_AFTER_REGAIN_CONFIRMATION:"
                + pivot.pivot_id
            )
        if not pivot.provenance:
            raise FullLiveD5DeepAdverseDefenseBlock(
                "DEEP_REGAIN_SOURCE_PIVOT_PROVENANCE_MISSING:"
                + pivot.pivot_id
            )

    adverse = tuple(
        p for p in rows if p.pivot_type is _adverse_type(direction)
    )
    if not adverse:
        return _projection(
            state="UNKNOWN",
            authority=None,
            reason="DEEP_CONFIRMATION_SEQUENCE_ADVERSE_PIVOT_MISSING",
            source_ids=source_ids,
        )

    selected = _pick_unique_adverse_most(adverse, direction=direction)
    deep_prov = dict(getattr(deep_evidence, "provenance", {}) or {})
    opportunity_id = str(deep_prov.get("opportunity_id", ""))
    market_event_id = str(deep_prov.get("market_event_id", ""))
    lineage_id = deterministic_id(
        "D5-DEEP-TAKEOVER-RISK-LINEAGE",
        interaction.event_id,
        str(promotion_cutoff),
        *source_ids,
    )
    source_authority_id = deterministic_id(
        "D5-DEEP-ADVERSE-DEFENSE",
        lineage_id,
        selected.pivot_id,
    )
    authority = ExplicitAdverseDefensePivotAuthorityV1(
        mechanism=OpportunityMechanism.DEEP_STRUCTURE_TAKEOVER,
        pivot=selected,
        lineage_id=lineage_id,
        source_authority_id=source_authority_id,
        provenance={
            "semantic_id": (
                "TAC_FULL_LIVE_D5_DEEP_ADVERSE_DEFENSE_"
                "SOURCE_ASSOCIATION_SEMANTIC_V1"
            ),
            "deeper_interaction_event_id": interaction.event_id,
            "local_control_regain_confirmation_cutoff": str(
                regain.confirmation_cutoff
            ),
            "promotion_confirmed_at": str(promotion_cutoff),
            "source_pivot_ids": ",".join(source_ids),
            "adverse_source_pivot_ids": ",".join(
                p.pivot_id for p in adverse
            ),
            "opportunity_id": opportunity_id,
            "market_event_id": market_event_id,
            "selection": (
                "UNIQUE_ADVERSE_MOST_WITHIN_EXACT_"
                "LOCAL_CONTROL_REGAIN_SOURCE_SET"
            ),
            "new_numeric_threshold": "false",
            "fixed_window_used": "false",
        },
    )
    return _projection(
        state="BOUND",
        authority=authority,
        reason="DEEP_ADVERSE_DEFENSE_AUTHORITY_BOUND",
        source_ids=source_ids,
        adverse_ids=tuple(p.pivot_id for p in adverse),
        provenance={
            "selected_pivot_id": selected.pivot_id,
            "source_authority_id": source_authority_id,
        },
    )
