from __future__ import annotations

"""Causal timing authority for active B4 production.

No scientific threshold is introduced here.  The helper mechanically
reconstructs frozen Interaction timing from the immutable event reference and
D1 canonical closed bars:
- arming bar open time from the bar whose close_time == event.armed_at;
- first wrong-side close from event.started_at onward;
- later correct-side reclaim close cutoffs after that first attempt.
"""

from dataclasses import dataclass, field
from fractions import Fraction
from types import MappingProxyType
from typing import Any, Mapping

from strategy_rc1.d2_market_state.types import TrendDirection
from strategy_rc1.d3_boundary_intelligence.types import InteractionEvent


class FullLiveActiveD4CausalTimeBlock(RuntimeError):
    pass


class FullLiveActiveD4CausalTimeConflict(FullLiveActiveD4CausalTimeBlock):
    pass


@dataclass(frozen=True)
class ActiveB4CausalTimeAuthorityV1:
    arming_open_time: int
    arming_cutoff: int
    interaction_started_at: int | None
    first_wrong_side_attempt_open_time: int | None
    first_wrong_side_attempt_cutoff: int | None
    reclaim_cutoffs: tuple[int, ...]
    provenance: Mapping[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "provenance",
            MappingProxyType(dict(self.provenance)),
        )


def _records_by_close(
    canonical_records: tuple[Any, ...],
    *,
    information_cutoff: int,
    canonical_segment_id: str,
) -> dict[int, Any]:
    out: dict[int, Any] = {}
    for rec in canonical_records:
        bar = getattr(rec, "bar", None)
        segment = getattr(rec, "canonical_segment_id", None)
        if bar is None:
            raise FullLiveActiveD4CausalTimeBlock(
                "CANONICAL_RECORD_BAR_MISSING"
            )
        close_time = getattr(bar, "close_time", None)
        if close_time is None:
            raise FullLiveActiveD4CausalTimeBlock(
                "CANONICAL_RECORD_CLOSE_TIME_MISSING"
            )
        close_time = int(close_time)
        if close_time > information_cutoff:
            raise FullLiveActiveD4CausalTimeConflict(
                "FUTURE_CANONICAL_RECORD"
            )
        if str(segment) != canonical_segment_id:
            continue
        old = out.get(close_time)
        if old is not None and old != rec:
            raise FullLiveActiveD4CausalTimeConflict(
                "DIVERGENT_CANONICAL_RECORD_AT_CUTOFF:"
                + str(close_time)
            )
        out[close_time] = rec
    return out


def _wrong_side(
    close: Fraction,
    boundary: Fraction,
    direction: TrendDirection,
) -> bool:
    if direction is TrendDirection.LONG:
        return close < boundary
    if direction is TrendDirection.SHORT:
        return close > boundary
    raise FullLiveActiveD4CausalTimeBlock(
        "DIRECTION_NOT_LONG_OR_SHORT"
    )


def derive_active_b4_causal_time_authority(
    *,
    event: InteractionEvent,
    direction: TrendDirection,
    information_cutoff: int,
    canonical_segment_id: str,
    canonical_records: tuple[Any, ...],
) -> ActiveB4CausalTimeAuthorityV1:
    if event.target_direction is not direction:
        raise FullLiveActiveD4CausalTimeConflict(
            "EVENT_DIRECTION_MISMATCH"
        )
    if event.armed_at is None:
        raise FullLiveActiveD4CausalTimeBlock(
            "EVENT_ARMED_AT_REQUIRED"
        )
    if event.armed_at > information_cutoff:
        raise FullLiveActiveD4CausalTimeConflict(
            "FUTURE_EVENT_ARMING"
        )

    by_close = _records_by_close(
        canonical_records,
        information_cutoff=information_cutoff,
        canonical_segment_id=canonical_segment_id,
    )
    arming_rec = by_close.get(int(event.armed_at))
    if arming_rec is None:
        raise FullLiveActiveD4CausalTimeBlock(
            "ARMING_CANONICAL_BAR_MISSING"
        )
    arming_bar = arming_rec.bar
    arming_open = getattr(arming_bar, "open_time", None)
    if arming_open is None:
        raise FullLiveActiveD4CausalTimeBlock(
            "ARMING_OPEN_TIME_MISSING"
        )

    started = event.started_at
    if started is None:
        return ActiveB4CausalTimeAuthorityV1(
            arming_open_time=int(arming_open),
            arming_cutoff=int(event.armed_at),
            interaction_started_at=None,
            first_wrong_side_attempt_open_time=None,
            first_wrong_side_attempt_cutoff=None,
            reclaim_cutoffs=(),
            provenance={
                "source": "D1_CANONICAL_RECORDS_PLUS_FROZEN_INTERACTION_EVENT",
                "attempt_state": "NOT_APPLICABLE_NO_INTERACTION_START",
            },
        )
    if started > information_cutoff:
        raise FullLiveActiveD4CausalTimeConflict(
            "FUTURE_INTERACTION_START"
        )
    if event.event_reference_boundary is None:
        raise FullLiveActiveD4CausalTimeBlock(
            "EVENT_REFERENCE_BOUNDARY_REQUIRED_AFTER_START"
        )
    boundary = Fraction(event.event_reference_boundary)

    eligible = [
        rec for cutoff, rec in sorted(by_close.items())
        if cutoff >= int(started)
    ]
    if not eligible:
        raise FullLiveActiveD4CausalTimeBlock(
            "CANONICAL_HISTORY_MISSING_FROM_INTERACTION_START"
        )

    first_attempt = None
    for rec in eligible:
        close = Fraction(rec.bar.close)
        if _wrong_side(close, boundary, direction):
            first_attempt = rec
            break

    if first_attempt is None:
        if event.attempted_wrong_side_acceptance:
            raise FullLiveActiveD4CausalTimeConflict(
                "EVENT_ATTEMPT_TRUE_WITHOUT_CAUSAL_WRONG_SIDE_CLOSE"
            )
        return ActiveB4CausalTimeAuthorityV1(
            arming_open_time=int(arming_open),
            arming_cutoff=int(event.armed_at),
            interaction_started_at=int(started),
            first_wrong_side_attempt_open_time=None,
            first_wrong_side_attempt_cutoff=None,
            reclaim_cutoffs=(),
            provenance={
                "source": "D1_CANONICAL_RECORDS_PLUS_FROZEN_EVENT_REFERENCE",
                "attempt_state": "NO_WRONG_SIDE_CLOSE_YET",
            },
        )

    attempt_cutoff = int(first_attempt.bar.close_time)
    attempt_open = int(first_attempt.bar.open_time)
    reclaim: list[int] = []
    for rec in eligible:
        cutoff = int(rec.bar.close_time)
        if cutoff <= attempt_cutoff:
            continue
        close = Fraction(rec.bar.close)
        if not _wrong_side(close, boundary, direction):
            reclaim.append(cutoff)

    if event.attempted_wrong_side_acceptance is False:
        # The current bar may be the first wrong-side close and UPDATE-007 has
        # not yet materialized it into the pre-bar event.  That is causal and
        # expected.  A historical attempt before the current cutoff, however,
        # must already be reflected in durable Interaction state.
        if attempt_cutoff < information_cutoff:
            raise FullLiveActiveD4CausalTimeConflict(
                "HISTORICAL_ATTEMPT_NOT_REFLECTED_IN_EVENT_STATE"
            )

    return ActiveB4CausalTimeAuthorityV1(
        arming_open_time=int(arming_open),
        arming_cutoff=int(event.armed_at),
        interaction_started_at=int(started),
        first_wrong_side_attempt_open_time=attempt_open,
        first_wrong_side_attempt_cutoff=attempt_cutoff,
        reclaim_cutoffs=tuple(reclaim),
        provenance={
            "source": "D1_CANONICAL_RECORDS_PLUS_FROZEN_EVENT_REFERENCE",
            "wrong_side_close_threshold_added": "false",
            "event_reference_boundary_frozen": "true",
        },
    )


def invariants() -> Mapping[str, Any]:
    return {
        "arming_time_guessed_by_subtraction": False,
        "attempt_cutoff_inferred_from_event_boolean_only": False,
        "attempt_cutoff_from_first_wrong_side_canonical_close": True,
        "reclaim_history_from_later_correct_side_canonical_closes": True,
        "event_reference_boundary_reused": True,
        "new_threshold_added": False,
        "fixed_window_added": False,
        "trading_activated": False,
    }
