from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Mapping

SCHEMA = "TAC_FULL_LIVE_D6_CONTINUITY_MANUAL_HANDOFF_V1"
FILENAME = "full_live_d6_continuity_manual_handoff_v1.json"


class D6ContinuityManualHandoffBlock(RuntimeError):
    pass


def require_no_d6_continuity_manual_handoff(*, state_root: Path) -> None:
    """Never resume new live risk while an unresolved D6 continuity hold exists."""
    path = Path(state_root) / FILENAME
    if path.exists() or path.is_symlink():
        raise D6ContinuityManualHandoffBlock("D6_CONTINUITY_MANUAL_HANDOFF_UNRESOLVED")


def _active_or_unknown(runtime: Any) -> bool:
    """A nonempty durable ledger is conservatively treated as uncertain."""
    if runtime is None:
        return True
    store = getattr(runtime, "store", None)
    ledger = getattr(runtime, "ledger", None)
    if store is None or ledger is None:
        return True
    active_positions = getattr(store, "active_positions", None)
    read_all = getattr(ledger, "read_all", None)
    if not callable(active_positions) or not callable(read_all):
        return True
    try:
        if tuple(active_positions()):
            return True
        # Even formerly closed ledger events are treated as needing an
        # operator check on unexpected collector failure. Do not infer a
        # clean restart from a partial ledger interpretation here.
        return bool(tuple(read_all()))
    except Exception:
        return True


def record_failed_live_cutoff_for_d6_handoff(
    *,
    state_root: Path,
    runtime: Any,
    failure: Exception,
    phase: str,
    last_complete_cutoff: int | None,
) -> Mapping[str, Any]:
    """Escalate missed D6 management without backfill or invented market data.

    The existing exchange hard protection remains the only exchange action.
    Persist a non-authorizing operator alert when existing active positions,
    ledger lineage, or reconciliation uncertainty could require D6 attention.
    """
    root = Path(state_root)
    if not root.is_dir() or root.is_symlink():
        raise D6ContinuityManualHandoffBlock("D6_CONTINUITY_STATE_ROOT_INVALID")
    if not isinstance(failure, Exception):
        raise D6ContinuityManualHandoffBlock("D6_CONTINUITY_FAILURE_REQUIRED")
    if not isinstance(phase, str) or not phase:
        raise D6ContinuityManualHandoffBlock("D6_CONTINUITY_PHASE_REQUIRED")
    if not _active_or_unknown(runtime):
        return {
            "status": "NO_ACTIVE_OR_UNCERTAIN_D6_LINEAGE",
            "new_risk": "BLOCKED_BY_ORIGINAL_FORWARD_FAILURE",
            "record_written": False,
        }
    path = root / FILENAME
    if path.is_symlink():
        raise D6ContinuityManualHandoffBlock("D6_CONTINUITY_HOLD_SYMLINK")
    if path.exists():
        return {
            "status": "MANUAL_HANDOFF_ALREADY_PERSISTED",
            "new_risk": "BLOCKED_MANUAL_D6_HANDOFF",
            "record_written": False,
        }
    payload = {
        "schema": SCHEMA,
        "status": "FAIL_CLOSED_MANUAL_D6_HANDOFF_REQUIRED",
        "phase": phase,
        "failure_class": type(failure).__name__,
        "last_complete_cutoff": last_complete_cutoff,
        "new_risk": "BLOCKED",
        "historical_backfill": False,
        "d6_update010_without_authoritative_cutoff": False,
        "manual_operator_handoff_required": True,
        "stop_exchange_orders_submitted": False,
        "orders": 0,
        "fills": 0,
        "execution_intents": 0,
    }
    encoded = (json.dumps(payload, sort_keys=True, separators=(",", ":")) + "\n").encode("utf-8")
    try:
        fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        with os.fdopen(fd, "wb") as out:
            out.write(encoded)
            out.flush()
            os.fsync(out.fileno())
        dir_fd = os.open(root, os.O_RDONLY)
        try:
            os.fsync(dir_fd)
        finally:
            os.close(dir_fd)
    except FileExistsError:
        return {
            "status": "MANUAL_HANDOFF_ALREADY_PERSISTED",
            "new_risk": "BLOCKED_MANUAL_D6_HANDOFF",
            "record_written": False,
        }
    except Exception as exc:
        raise D6ContinuityManualHandoffBlock("D6_HANDOFF_DURABILITY_FAILED") from exc
    return {
        "status": payload["status"],
        "new_risk": "BLOCKED_MANUAL_D6_HANDOFF",
        "record_written": True,
    }


__all__ = [
    "D6ContinuityManualHandoffBlock",
    "FILENAME",
    "record_failed_live_cutoff_for_d6_handoff",
    "require_no_d6_continuity_manual_handoff",
]
