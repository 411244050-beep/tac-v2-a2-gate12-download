from __future__ import annotations
from dataclasses import dataclass
from typing import Mapping

class ExecutionAllowanceBlock(RuntimeError): pass

REQUIRED=(
 "update014_admitted","exchange_legal","structural_risk_caps","common_factor_budget",
 "listing_liquidity_capacity","spread_slippage_depth","port007_admitted",
 "execution_uncertainty_clear","hard_stop_authority",
)

@dataclass(frozen=True)
class ExecutionAllowanceEvidenceV1:
    state:str
    evidence_id:str
    checks:Mapping[str,str]

def compose_execution_allowance(*,checks:Mapping[str,str],evidence_ids:Mapping[str,str])->ExecutionAllowanceEvidenceV1:
    if set(checks)!=set(REQUIRED) or set(evidence_ids)!=set(REQUIRED):
        raise ExecutionAllowanceBlock("EXACT_REQUIRED_CHECK_SET")
    if any(not evidence_ids[k] for k in REQUIRED): raise ExecutionAllowanceBlock("CHECK_EVIDENCE_REQUIRED")
    failed=[k for k in REQUIRED if checks[k]!="PASS"]
    if failed:
        return ExecutionAllowanceEvidenceV1("BLOCKED","",dict(checks))
    import hashlib,json
    raw=json.dumps({k:evidence_ids[k] for k in REQUIRED},sort_keys=True,separators=(",",":"))
    eid="EXECUTION_ALLOWANCE_SHA256:"+hashlib.sha256(raw.encode()).hexdigest()
    return ExecutionAllowanceEvidenceV1("PASS",eid,dict(checks))

def invariants():
    return {"update014_can_only_be_consumed_not_created":True,"all_operational_checks_required":True,
      "thresholds_owned":False,"selector_added":False,"ranking_added":False,
      "orders":0,"fills":0,"execution_intents":0,"trading_activated":False}
