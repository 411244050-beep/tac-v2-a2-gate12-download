from __future__ import annotations

"""Pure parser for current Binance USD-M exchangeInfo symbol facts.

No threshold or eligibility decision is owned here.
"""
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from typing import Any, Mapping


class BinanceUSDMExchangeInfoBlock(RuntimeError):
    pass


@dataclass(frozen=True)
class BinanceUSDMSymbolFactsV1:
    symbol: str
    status: str
    onboard_date_ms: int
    contract_type: str
    base_asset: str
    quote_asset: str
    margin_asset: str
    price_filter: Mapping[str, str]
    lot_size: Mapping[str, str]
    market_lot_size: Mapping[str, str]
    min_notional: Decimal
    percent_price: Mapping[str, str] | None
    market_take_bound: Decimal | None


def _decimal(v: Any, label: str) -> Decimal:
    try: d=Decimal(str(v))
    except (InvalidOperation,TypeError,ValueError) as exc:
        raise BinanceUSDMExchangeInfoBlock("INVALID_DECIMAL:"+label) from exc
    if not d.is_finite() or d < 0: raise BinanceUSDMExchangeInfoBlock("INVALID_DECIMAL:"+label)
    return d


def parse_usdm_symbol_facts(*, raw_exchange_info: Mapping[str, Any], symbol: str) -> BinanceUSDMSymbolFactsV1:
    if not isinstance(raw_exchange_info, Mapping): raise BinanceUSDMExchangeInfoBlock("EXCHANGE_INFO_MAPPING_REQUIRED")
    target=symbol.upper()
    rows=raw_exchange_info.get("symbols")
    if not isinstance(rows, list): raise BinanceUSDMExchangeInfoBlock("SYMBOLS_REQUIRED")
    matches=[r for r in rows if isinstance(r,Mapping) and r.get("symbol")==target]
    if len(matches)!=1: raise BinanceUSDMExchangeInfoBlock("SYMBOL_NOT_UNIQUE:"+target)
    r=matches[0]
    try: onboard=int(r["onboardDate"])
    except Exception as exc: raise BinanceUSDMExchangeInfoBlock("ONBOARD_DATE_REQUIRED") from exc
    if onboard < 0: raise BinanceUSDMExchangeInfoBlock("ONBOARD_DATE_INVALID")
    filters={}
    for f in r.get("filters",[]):
        if isinstance(f,Mapping) and isinstance(f.get("filterType"),str):
            if f["filterType"] in filters: raise BinanceUSDMExchangeInfoBlock("DUPLICATE_FILTER:"+f["filterType"])
            filters[f["filterType"]]=f
    required=("PRICE_FILTER","LOT_SIZE","MARKET_LOT_SIZE","MIN_NOTIONAL")
    missing=[x for x in required if x not in filters]
    if missing: raise BinanceUSDMExchangeInfoBlock("REQUIRED_FILTER_MISSING:"+",".join(missing))
    mn=_decimal(filters["MIN_NOTIONAL"].get("notional"),"MIN_NOTIONAL")
    mtb=None if r.get("marketTakeBound") is None else _decimal(r["marketTakeBound"],"marketTakeBound")
    def clean(name):
        return {str(k):str(v) for k,v in filters[name].items() if k!="filterType"}
    return BinanceUSDMSymbolFactsV1(
        symbol=target,status=str(r.get("status","")),onboard_date_ms=onboard,
        contract_type=str(r.get("contractType","")),base_asset=str(r.get("baseAsset","")),
        quote_asset=str(r.get("quoteAsset","")),margin_asset=str(r.get("marginAsset","")),
        price_filter=clean("PRICE_FILTER"),lot_size=clean("LOT_SIZE"),
        market_lot_size=clean("MARKET_LOT_SIZE"),min_notional=mn,
        percent_price=clean("PERCENT_PRICE") if "PERCENT_PRICE" in filters else None,
        market_take_bound=mtb,
    )


def listing_age_ms(*, facts: BinanceUSDMSymbolFactsV1, observation_time_ms: int) -> int:
    if not isinstance(observation_time_ms,int) or observation_time_ms < facts.onboard_date_ms:
        raise BinanceUSDMExchangeInfoBlock("OBSERVATION_TIME_PRECEDES_ONBOARD")
    return observation_time_ms-facts.onboard_date_ms


def invariants():
    return {"policy_thresholds_owned":False,"listing_age_threshold_owned":False,"exchange_filters_dynamic":True,
            "orders":0,"fills":0,"execution_intents":0,"trading_activated":False}
