from __future__ import annotations
import json,os
from dataclasses import asdict
from pathlib import Path
from typing import Iterable
from full_live_prospective_execution_evidence_v1 import ProspectiveExecutionEvidenceV1,validate_prospective_execution_evidence
from full_live_forward_execution_evidence_v1 import ForwardExecutionEvidenceAccumulatorV1
class DurableExecutionEvidenceLedgerBlock(RuntimeError): pass
_FIELDS=tuple(ProspectiveExecutionEvidenceV1.__dataclass_fields__)
class DurableExecutionEvidenceLedgerV1:
    def __init__(self,*,path:Path,collector_started_at_ms:int,frozen_symbols:Iterable[str]):
        self.path=Path(path); self.start=collector_started_at_ms; self.symbols=tuple(frozen_symbols)
        self.acc=ForwardExecutionEvidenceAccumulatorV1(collector_started_at_ms=collector_started_at_ms,frozen_symbols=self.symbols)
        self.ids=set(); self.by_entry_ready={}; self._restore()
    def _restore(self):
        if not self.path.exists(): return
        try:
            for n,line in enumerate(self.path.read_text(encoding="utf-8").splitlines(),1):
                raw=json.loads(line)
                if set(raw)!=set(_FIELDS): raise DurableExecutionEvidenceLedgerBlock(f"ROW_SCHEMA_MISMATCH:{n}")
                e=ProspectiveExecutionEvidenceV1(**raw)
                try: e=validate_prospective_execution_evidence(e)
                except Exception as exc: raise DurableExecutionEvidenceLedgerBlock(f"EVIDENCE_INTEGRITY_INVALID:{n}") from exc
                if e.evidence_id in self.ids: raise DurableExecutionEvidenceLedgerBlock(f"DUPLICATE_DURABLE_EVIDENCE:{n}")
                prior=self.by_entry_ready.get(e.entry_ready_id)
                if prior is not None: raise DurableExecutionEvidenceLedgerBlock(f"DUPLICATE_ENTRY_READY_EVIDENCE:{n}")
                self.acc.add(e); self.ids.add(e.evidence_id); self.by_entry_ready[e.entry_ready_id]=e
        except DurableExecutionEvidenceLedgerBlock: raise
        except Exception as exc: raise DurableExecutionEvidenceLedgerBlock("LEDGER_RESTORE_FAILED") from exc
    def get_by_entry_ready(self,entry_ready_id:str): return self.by_entry_ready.get(str(entry_ready_id))
    def append(self,e:ProspectiveExecutionEvidenceV1)->str:
        if not isinstance(e,ProspectiveExecutionEvidenceV1): raise DurableExecutionEvidenceLedgerBlock("TYPED_EVIDENCE_REQUIRED")
        try: e=validate_prospective_execution_evidence(e)
        except Exception as exc: raise DurableExecutionEvidenceLedgerBlock("EVIDENCE_INTEGRITY_INVALID") from exc
        # Only the exact same source-bound evidence is idempotent.
        # A changed book / side / cutoff / intended size for one EntryReady
        # is a provenance conflict, never a second permissible observation.
        prior = self.by_entry_ready.get(e.entry_ready_id)
        if prior is not None:
            if prior == e and e.evidence_id in self.ids:
                return "IDEMPOTENT_REPLAY"
            raise DurableExecutionEvidenceLedgerBlock(
                "ENTRY_READY_CONFLICTING_EVIDENCE_FAIL_CLOSED"
            )
        if e.evidence_id in self.ids:
            raise DurableExecutionEvidenceLedgerBlock(
                "EVIDENCE_ID_DUPLICATED_WITHOUT_ENTRY_READY"
            )
        staged=ForwardExecutionEvidenceAccumulatorV1(collector_started_at_ms=self.start,frozen_symbols=self.symbols)
        for old in self.acc.rows: staged.add(old)
        staged.add(e); row=json.dumps(asdict(e),sort_keys=True,separators=(",",":"))+"\n"; self.path.parent.mkdir(parents=True,exist_ok=True)
        fd=os.open(self.path,os.O_WRONLY|os.O_CREAT|os.O_APPEND,0o600)
        try:
            with os.fdopen(fd,"a",encoding="utf-8") as f: f.write(row); f.flush(); os.fsync(f.fileno())
            dir_fd=os.open(self.path.parent,os.O_RDONLY)
            try: os.fsync(dir_fd)
            finally: os.close(dir_fd)
        except Exception as exc: raise DurableExecutionEvidenceLedgerBlock("LEDGER_APPEND_FAILED") from exc
        self.acc=staged; self.ids.add(e.evidence_id); self.by_entry_ready[e.entry_ready_id]=e; return "COMMITTED"
    def report(self): return self.acc.report()
def invariants():
    return {"restart_restore":True,"duplicate_evidence":"IDEMPOTENT_REPLAY","one_durable_sample_per_entry_ready":True,"restart_resampling_bias_prevented":True,
    "corrupt_or_conflicting_ledger":"FAIL_CLOSED","restored_evidence_digest_revalidated":True,"directory_fsync_after_append":True,"threshold_selected":False,"orders":0,"fills":0,"execution_intents":0,"trading_activated":False}
