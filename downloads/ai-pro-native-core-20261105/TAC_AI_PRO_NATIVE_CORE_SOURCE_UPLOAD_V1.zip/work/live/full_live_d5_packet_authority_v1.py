from __future__ import annotations

"""Typed authority -> frozen D5EvidencePacket bridge for full-live runtime."""

from dataclasses import dataclass, field, fields, is_dataclass
from fractions import Fraction
from pathlib import Path
import sys
from types import MappingProxyType
from typing import Any, Mapping

from strategy_rc1.d2_market_state.types import (
    PivotType,
    StructuralPivot,
    TrendDirection,
)
from strategy_rc1.d5_risk.risk_anchor import (
    DeepTakeoverRiskEvidence,
    FalseBreakRiskEvidence,
    NormalRetestRiskEvidence,
    PlatformRiskEvidence,
)
from strategy_rc1.runtime_guards.information_state import InfoKind, InfoValue


REPO_ROOT = Path(__file__).resolve().parents[2]
WORK_SRC = REPO_ROOT / "work" / "src"
if str(WORK_SRC) not in sys.path:
    sys.path.insert(0, str(WORK_SRC))

from multisymbol_impl import transactional_batch_composition_v1 as batch


class FullLiveD5PacketAuthorityBlock(RuntimeError):
    pass


@dataclass(frozen=True)
class D5PacketAuthorityV1:
    information_cutoff: int
    direction: TrendDirection
    canonical_segment_id: str
    risk_evidence: Any
    risk_anchor_pivot: StructuralPivot
    strategy_entry_reference_price: Fraction
    canonical_continuity_intact: InfoValue[bool]
    risk_anchor_not_invalidated: InfoValue[bool]
    operational_inputs: Any
    provenance: Mapping[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "provenance",
            MappingProxyType(
                {str(k): str(v) for k, v in self.provenance.items()}
            ),
        )


def _adverse_type(direction: TrendDirection) -> PivotType:
    if direction is TrendDirection.LONG:
        return PivotType.LOW
    if direction is TrendDirection.SHORT:
        return PivotType.HIGH
    raise FullLiveD5PacketAuthorityBlock(
        "D5_PACKET_DIRECTION_NOT_LONG_OR_SHORT"
    )


def _expected_anchor_from_risk_evidence(
    evidence: Any,
    direction: TrendDirection,
) -> StructuralPivot:
    if isinstance(evidence, NormalRetestRiskEvidence):
        pivots = tuple(evidence.participating_minor_pivots)
        if not pivots:
            raise FullLiveD5PacketAuthorityBlock(
                "NORMAL_RETEST_RISK_SOURCE_EMPTY"
            )
        return (
            min(pivots, key=lambda p: p.extreme_price)
            if direction is TrendDirection.LONG
            else max(pivots, key=lambda p: p.extreme_price)
        )

    if isinstance(evidence, FalseBreakRiskEvidence):
        pivot = evidence.wrong_side_extreme
    elif isinstance(evidence, PlatformRiskEvidence):
        pivot = evidence.adverse_defense_extreme
    elif isinstance(evidence, DeepTakeoverRiskEvidence):
        pivot = evidence.adverse_defense_extreme
    else:
        raise FullLiveD5PacketAuthorityBlock(
            "UNSUPPORTED_EXECUTABLE_RISK_EVIDENCE_TYPE:"
            + type(evidence).__name__
        )

    if not isinstance(pivot, StructuralPivot):
        raise FullLiveD5PacketAuthorityBlock(
            "MECHANISM_RISK_SOURCE_PIVOT_MISSING"
        )
    return pivot


def _known_bool(value: InfoValue[bool], label: str) -> bool:
    if value.kind is not InfoKind.KNOWN:
        raise FullLiveD5PacketAuthorityBlock(
            label + "_NOT_KNOWN"
        )
    if value.value not in (True, False):
        raise FullLiveD5PacketAuthorityBlock(
            label + "_NONBOOLEAN"
        )
    return bool(value.value)


def validate_packet_authority(authority: D5PacketAuthorityV1) -> None:
    if authority.information_cutoff < 0:
        raise FullLiveD5PacketAuthorityBlock(
            "D5_PACKET_CUTOFF_NEGATIVE"
        )
    if not authority.canonical_segment_id:
        raise FullLiveD5PacketAuthorityBlock(
            "D5_PACKET_CANONICAL_SEGMENT_REQUIRED"
        )
    if authority.strategy_entry_reference_price <= 0:
        raise FullLiveD5PacketAuthorityBlock(
            "D5_PACKET_ENTRY_REFERENCE_NONPOSITIVE"
        )

    pivot = authority.risk_anchor_pivot
    if pivot.pivot_type is not _adverse_type(authority.direction):
        raise FullLiveD5PacketAuthorityBlock(
            "D5_PACKET_RISK_ANCHOR_NOT_ADVERSE_TYPE"
        )
    if pivot.confirmed_at > authority.information_cutoff:
        raise FullLiveD5PacketAuthorityBlock(
            "D5_PACKET_FUTURE_RISK_ANCHOR"
        )
    if pivot.canonical_segment_id != authority.canonical_segment_id:
        raise FullLiveD5PacketAuthorityBlock(
            "D5_PACKET_RISK_ANCHOR_SEGMENT_MISMATCH"
        )
    if pivot.scale_at_extreme <= 0:
        raise FullLiveD5PacketAuthorityBlock(
            "D5_PACKET_ATR_AT_RISK_REFERENCE_NONPOSITIVE"
        )
    if not pivot.provenance:
        raise FullLiveD5PacketAuthorityBlock(
            "D5_PACKET_RISK_ANCHOR_PROVENANCE_MISSING"
        )

    expected = _expected_anchor_from_risk_evidence(
        authority.risk_evidence,
        authority.direction,
    )
    if expected != pivot:
        raise FullLiveD5PacketAuthorityBlock(
            "D5_PACKET_RISK_SOURCE_SELECTED_PIVOT_DRIFT:"
            + expected.pivot_id
            + ":"
            + pivot.pivot_id
        )

    validity = _known_bool(
        authority.risk_anchor_not_invalidated,
        "RISK_ANCHOR_VALIDITY",
    )
    evidence_validity = getattr(
        authority.risk_evidence,
        "risk_anchor_not_invalidated",
        None,
    )
    if evidence_validity is not validity:
        raise FullLiveD5PacketAuthorityBlock(
            "D5_PACKET_VALIDITY_EVIDENCE_DRIFT"
        )

    # Known FALSE is intentionally transportable. Frozen D5 owns the
    # semantic FAIL decision for a known continuity break. UNKNOWN/ERROR must
    # remain non-authoritative and therefore cannot be promoted here.
    _known_bool(
        authority.canonical_continuity_intact,
        "CANONICAL_CONTINUITY",
    )

    slots = getattr(authority.operational_inputs, "slots", None)
    if slots is None:
        raise FullLiveD5PacketAuthorityBlock(
            "D5_PACKET_OPERATIONAL_INPUT_SET_MISSING"
        )


def build_frozen_d5_evidence_packet(
    authority: D5PacketAuthorityV1,
) -> Any:
    validate_packet_authority(authority)

    cls = getattr(batch.frozen, "D5EvidencePacket", None)
    if cls is None or not is_dataclass(cls):
        raise FullLiveD5PacketAuthorityBlock(
            "FROZEN_D5_EVIDENCE_PACKET_CONTRACT_MISSING"
        )

    expected_fields = {
        "risk_evidence",
        "strategy_entry_reference_price",
        "atr_at_risk_reference",
        "canonical_continuity_intact",
        "risk_anchor_not_invalidated",
        "operational_inputs",
    }
    actual_fields = {f.name for f in fields(cls)}
    if actual_fields != expected_fields:
        raise FullLiveD5PacketAuthorityBlock(
            "FROZEN_D5_EVIDENCE_PACKET_FIELD_DRIFT:"
            + ",".join(sorted(actual_fields))
        )

    return cls(
        risk_evidence=authority.risk_evidence,
        strategy_entry_reference_price=InfoValue.known(
            authority.strategy_entry_reference_price
        ),
        atr_at_risk_reference=InfoValue.known(
            authority.risk_anchor_pivot.scale_at_extreme
        ),
        canonical_continuity_intact=(
            authority.canonical_continuity_intact
        ),
        risk_anchor_not_invalidated=(
            authority.risk_anchor_not_invalidated
        ),
        operational_inputs=authority.operational_inputs,
    )


def invariants() -> Mapping[str, Any]:
    return {
        "strategy_entry_reference_is_same_cutoff_close_authority": True,
        "atr_at_risk_reference_is_selected_pivot_scale": True,
        "risk_anchor_selection_rule_reused_not_extended": True,
        "risk_anchor_validity_must_be_known": True,
        "canonical_continuity_must_be_known_boolean": True,
        "known_false_continuity_transported_to_frozen_d5": True,
        "unresolved_operational_inputs_remain_transportable_and_block_d5": True,
        "selector_added": False,
        "ranking_added": False,
        "threshold_added": False,
        "trading_activated": False,
    }
