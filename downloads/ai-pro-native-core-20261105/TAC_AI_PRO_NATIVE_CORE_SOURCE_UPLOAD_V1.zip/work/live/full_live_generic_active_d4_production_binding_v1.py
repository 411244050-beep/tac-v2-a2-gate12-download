from __future__ import annotations

"""Generic active-D4 production binding, phase 1: same live Opportunity.

This binding extends the already-frozen Raw-V6 / generic-known-cohort
orchestration only where the prior binding deliberately stopped:
- a mature ARMED lineage reaches a causal TEST/contact this cutoff;
- an Interaction is already active/resolved and needs B4 continuation/rearm;
- or frozen Platform production becomes active.

It does not create new strategy science.  It reuses the frozen Runtime-B3,
B4, UPDATE-007, UPDATE-008/B5, Normal/FBR/Platform/Deep, D4 lineage,
D4 static and packet-assembler producers.  Durable RawV6 state is adopted
only after the full staged cutoff succeeds.
"""

from dataclasses import dataclass, replace
from pathlib import Path
import sys
from typing import Any

REPO_ROOT = Path(__file__).resolve().parents[2]
PROVISIONAL_DIR = REPO_ROOT / "provisional_shadow_v1"
if str(PROVISIONAL_DIR) not in sys.path:
    sys.path.insert(0, str(PROVISIONAL_DIR))

import minimal_runnable_v1_baseline as minimal
import nontrading_adapter_integration_v1 as frozen
import authoritative_d3_d4_evidence_packet_assembler_resumption_v2 as assembler
import authoritative_d3_b5_d4_base_runtime_producers_v1 as b5prod
import d1_d2_to_d3_candidate_production_v1 as candidate_prod
import d2_to_b4_d4_causal_evidence_producers_v1 as b4prod
import runtime_b3_price_driven_return_production_state_v1 as b3prod
import qbu_same_event_negotiation_identity_production_binding_v1 as qid
import qbu_material_trend_side_minor_progress_production_binding_v1 as qprog
import platform_failed_reexpansion_event_and_state_production_binding_v1 as platform_prod
import d4_market_event_lineage_production_binding_v2 as lineage_prod
import d4_deep_takeover_preidentity_causal_fact_production_interface_decoupling_v1 as deep_bind
import d4_static_detector_critical_production_binding_v1 as d4static
import live_runtime_authority_extraction_packet_orchestration_binding_v3 as live
import live_runtime_raw_authority_extraction_packet_orchestration_binding_v6 as v6
import live_runtime_raw_authority_extraction_packet_orchestration_binding_v7 as v7

from d2_to_b4_d4_causal_evidence_producers_v1 import EvidenceState
from strategy_rc1.d3_boundary_intelligence.types import (
    CandidateAvailability,
    InteractionControl,
)
from strategy_rc1.d2_market_state.types import TrendDirection
from strategy_rc1.runtime_guards.information_state import InfoKind, InfoValue

from full_live_active_b4_projection_v1 import project_active_b4
from full_live_active_d4_mechanism_composer_v1 import (
    ActiveD4CompositionInputV1,
    compose_active_d4_mechanisms,
)


BINDING_ID = "FULL_LIVE_GENERIC_ACTIVE_D4_PRODUCTION_BINDING_V1"
CONSUMABLE_REASON = "LATCHED_RETURN_CONSUMABLE"
NEW_ARM_REASON = "ARMED_FROZEN_CURRENT_CUTOFF_NO_RETURN"
PREQUALIFICATION_REASON = "RETURN_NOT_YET_QUALIFIED"
QUALIFICATION_LATCH_REASON = (
    "RETURN_QUALIFIED_LATCHED_NOT_CONSUMABLE_SAME_CUTOFF"
)
NEGATIVE_SIGNED_REASON = "NEGATIVE_SIGNED_NOT_ADVERSE_YET"
ACTIVE_RESET_REASON = "RESET:INTERACTION_NO_LONGER_PENDING"
PASSIVE_UNARMED_REASON = "UNARMED_NO_SEPARATION"


class FullLiveActiveD4Block(RuntimeError):
    pass


class FullLiveActiveD4Conflict(FullLiveActiveD4Block):
    pass


@dataclass(frozen=True)
class ActiveD4SurfaceProbeV1:
    active: bool
    prebar_snapshot_count: int
    reasons: tuple[str, ...]
    # Typed operational lane only; never a strategy admission or selector.
    nonconsumable_d3_only: bool = False


def probe_active_d4_surface(
    runtime: v6.LiveRuntimeRawAuthorityOrchestrationV6,
    bar: Any,
) -> ActiveD4SurfaceProbeV1:
    """Pure typed routing probe for the generic active-D4 surface.

    The probe owns no Strategy decision. It only detects producer states that
    the older no-active generic cohort binding explicitly does not support.
    """
    if not isinstance(runtime, v6.LiveRuntimeRawAuthorityOrchestrationV6):
        raise FullLiveActiveD4Conflict("V6_RUNTIME_SCHEMA")

    durable_d3 = runtime._adapter()._d3_rebuild(bar.symbol)
    prebar = durable_d3.update_000_pre_bar_view(bar.open_time)
    pre_snaps = tuple(
        sorted(tuple(prebar.snapshots), key=lambda x: x.snapshot_id)
    )
    if not pre_snaps:
        return ActiveD4SurfaceProbeV1(False, 0, ())

    target_candidate_ids = {s.candidate_id for s in pre_snaps}
    events = tuple(
        e for e in v6._event_rows(durable_d3)
        if e.candidate_id in target_candidate_ids
    )
    if len(events) != len(target_candidate_ids):
        raise FullLiveActiveD4Conflict(
            "PREBAR_EVENT_MULTIPLICITY_OR_MISSING"
        )

    reasons: list[str] = []
    for event in events:
        if event.control in (
            InteractionControl.INTERACTION_ACTIVE,
            InteractionControl.RESOLVED,
        ):
            reasons.append("DURABLE_INTERACTION_" + _enum(event.control))
            continue
        if (
            event.started_at is not None
            or event.attempted_wrong_side_acceptance
            or event.terminal
            or _enum(event.break_state) != "NONE"
        ):
            reasons.append("DURABLE_INTERACTION_CAUSAL_ACTIVITY")

    raw_adapter, _, _, raw_sr, raw_cache = runtime._raw_shadow(bar)
    trend = raw_cache.d2.update_006_trend
    geometries = v7._geometry_map(raw_cache.d3_geometry)
    expected_snapshot_ids = set(v7._snapshot_ids(prebar))
    if set(geometries) != expected_snapshot_ids:
        raise FullLiveActiveD4Conflict(
            "RAW_GEOMETRY_PREBAR_SNAPSHOT_SET_MISMATCH"
        )
    if any(geometries[s.snapshot_id].test for s in pre_snaps):
        reasons.append("CURRENT_TYPED_GEOMETRY_TEST")

    if trend.episode_id is not None:
        platform_rt = (
            platform_prod.PlatformFailedReexpansionProductionRuntimeV1.restore_state(
                dict(runtime.state.platform_state)
            )
        )
        memory = platform_rt._memory.get(trend.episode_id)
        if (
            memory is not None
            and _enum(memory.platform.status) == "PLATFORM_CONFIRMED"
        ):
            reasons.append("DURABLE_PLATFORM_CONFIRMED")

    # The old Known-Cohort binding predates frozen UNARMED_NO_SEPARATION.
    # When there is NO active-D4 reason, classify frozen B3 on a disposable
    # copy rather than exception-text dispatch or misrouting a mixed benign
    # cohort to that older binding. This authorizes NO D4/entry; the chosen
    # D3-only lane independently verifies B3 and all UPDATE-011..014 N/A.
    nonconsumable_d3_only = False
    if (
        not reasons
        and trend.episode_id is not None
        and trend.episode_start_cutoff is not None
        and trend.episode_start_cutoff < bar.close_time
    ):
        segment = (
            raw_sr.canonical_segment_id
            or raw_adapter._state(bar.symbol).last_canonical_segment_id
        )
        if not segment:
            raise FullLiveActiveD4Block("PROBE_CURRENT_CANONICAL_SEGMENT_REQUIRED")
        candidate_rt = candidate_prod.D1D2D3CandidateProductionRuntimeV1.restore_state(
            runtime.state.candidate_state
        )
        observations = _runtime_b3_observations(
            bar=bar,
            pre_snaps=pre_snaps,
            event_by_candidate=v7._event_by_candidate(events),
            durable_candidates=dict(candidate_rt.state.candidates),
            geometries=geometries,
            trend=trend,
            segment=segment,
            params=frozen.frozen_d3_parameters(
                minimal.current_partial_parameter_snapshot()
            ),
        )
        b3_rt = b3prod.RuntimeB3PriceDrivenReturnProducerV1.restore_state(
            runtime.state.b3_state
        )
        b3_results = b3_rt.process_batch(
            raw_sr.transaction_id + ":B3", observations
        )
        b3_by_snapshot = {x.snapshot_ref: x for x in b3_results}
        if (
            len(b3_results) != len(pre_snaps)
            or set(b3_by_snapshot) != {s.snapshot_id for s in pre_snaps}
        ):
            raise FullLiveActiveD4Conflict("PROBE_RUNTIME_B3_SNAPSHOT_SET_DRIFT")
        cohorts = _classify_b3(
            pre_snaps=pre_snaps,
            event_by_candidate=v7._event_by_candidate(events),
            results_by_snapshot=b3_by_snapshot,
            geometries=geometries,
        )
        eligible = (
            cohorts["passive_unarmed"]
            | cohorts["new_arm"]
            | cohorts["prequalification"]
        )
        nonconsumable_d3_only = (
            bool(cohorts["passive_unarmed"])
            and len(eligible) == len(pre_snaps)
        )

    # raw shadow, B3 and candidate runtime are disposable and never adopted.
    return ActiveD4SurfaceProbeV1(
        active=bool(reasons),
        prebar_snapshot_count=len(pre_snaps),
        reasons=tuple(sorted(set(reasons))),
        nonconsumable_d3_only=nonconsumable_d3_only,
    )


def _enum(value: Any) -> str:
    return value.value if hasattr(value, "value") else str(value)


def _require_canonical_records(d1: Any, cutoff: int) -> tuple[Any, ...]:
    rows = tuple(getattr(d1, "canonical_records", ()))
    if not rows:
        raise FullLiveActiveD4Block(
            "D1_CANONICAL_RECORD_HISTORY_REQUIRED"
        )
    current = [
        r for r in rows
        if getattr(getattr(r, "bar", None), "close_time", None) == cutoff
    ]
    if len(current) != 1:
        raise FullLiveActiveD4Block(
            "D1_CANONICAL_RECORD_CURRENT_CUTOFF_NOT_UNIQUE"
        )
    return rows


def _runtime_b3_observations(
    *,
    bar: Any,
    pre_snaps: tuple[Any, ...],
    event_by_candidate: dict[str, Any],
    durable_candidates: dict[str, Any],
    geometries: dict[str, Any],
    trend: Any,
    segment: str,
    params: Any,
) -> tuple[b3prod.RuntimeB3Observation, ...]:
    rows: list[b3prod.RuntimeB3Observation] = []
    for snapshot in pre_snaps:
        event = event_by_candidate.get(snapshot.candidate_id)
        candidate = durable_candidates.get(snapshot.candidate_id)
        if event is None or candidate is None:
            raise FullLiveActiveD4Block(
                "PREBAR_CANDIDATE_AUTHORITY_REQUIRED:"
                + snapshot.candidate_id
            )
        rows.append(
            b3prod.RuntimeB3Observation(
                bar=bar,
                snapshot=snapshot,
                geometry=geometries[snapshot.snapshot_id],
                interaction_control=event.control,
                params=params,
                symbol=bar.symbol,
                candidate_id=snapshot.candidate_id,
                source_segment_id=snapshot.source_segment_id,
                target_trend_episode_id=snapshot.target_trend_episode_id,
                target_direction=snapshot.target_direction,
                current_trend_episode_id=trend.episode_id,
                current_trend_direction=trend.direction,
                canonical_continuity_intact=(
                    snapshot.source_segment_id == segment
                ),
                candidate_available=(
                    candidate.availability
                    is CandidateAvailability.AVAILABLE
                ),
                terminal_candidate_replacement=False,
                interaction_terminal=event.terminal,
            )
        )
    return tuple(rows)


def _classify_b3(
    *,
    pre_snaps: tuple[Any, ...],
    event_by_candidate: dict[str, Any],
    results_by_snapshot: dict[str, Any],
    geometries: dict[str, Any],
) -> dict[str, set[str]]:
    out = {
        "mature": set(),
        "new_arm": set(),
        "prequalification": set(),
        "qualification_latch": set(),
        "negative_signed": set(),
        "active_or_resolved": set(),
        "passive_unarmed": set(),
    }
    for snapshot in pre_snaps:
        event = event_by_candidate[snapshot.candidate_id]
        result = results_by_snapshot[snapshot.snapshot_id]
        pending = result.pending_lineage

        # Frozen B3 explicitly emits this neutral state when an UNARMED
        # candidate has not separated, even when D3 geometry.test is true.
        # No arm, return, or B4 can be inferred from geometry.TEST alone.
        if (
            result.reason == PASSIVE_UNARMED_REASON
            and event.control is InteractionControl.UNARMED
        ):
            geometry = geometries.get(snapshot.snapshot_id)
            if (
                geometry is None
                or geometry.separated is not False
                or result.return_evidence is not None
                or result.latched_evidence is not None
                or result.continuity_resolution is not None
                or pending is not None
            ):
                raise FullLiveActiveD4Block(
                    "PASSIVE_UNARMED_B3_AUTHORITY_MISMATCH"
                )
            out["passive_unarmed"].add(snapshot.candidate_id)
            continue

        if (
            result.reason == CONSUMABLE_REASON
            and event.control is InteractionControl.ARMED
        ):
            if (
                result.return_evidence is None
                or not result.return_evidence.passed
                or result.latched_evidence is None
                or not result.latched_evidence.passed
                or result.continuity_resolution is not None
                or pending is None
            ):
                raise FullLiveActiveD4Block(
                    "MATURE_B3_SURFACE_MISMATCH"
                )
            out["mature"].add(snapshot.candidate_id)
            continue

        if (
            result.reason == NEW_ARM_REASON
            and event.control is InteractionControl.UNARMED
        ):
            out["new_arm"].add(snapshot.candidate_id)
            continue

        if (
            result.reason == PREQUALIFICATION_REASON
            and event.control is InteractionControl.ARMED
        ):
            out["prequalification"].add(snapshot.candidate_id)
            continue

        if (
            result.reason == QUALIFICATION_LATCH_REASON
            and event.control is InteractionControl.ARMED
        ):
            out["qualification_latch"].add(snapshot.candidate_id)
            continue

        if (
            result.reason == NEGATIVE_SIGNED_REASON
            and event.control is InteractionControl.ARMED
        ):
            out["negative_signed"].add(snapshot.candidate_id)
            continue

        if (
            result.reason == ACTIVE_RESET_REASON
            and event.control
            in (
                InteractionControl.INTERACTION_ACTIVE,
                InteractionControl.RESOLVED,
            )
            and result.return_evidence is None
            and result.latched_evidence is None
            and result.pending_lineage is None
            and result.continuity_resolution is None
        ):
            out["active_or_resolved"].add(snapshot.candidate_id)
            continue

        raise FullLiveActiveD4Block(
            "UNSUPPORTED_ACTIVE_D4_RUNTIME_B3_SURFACE:"
            + result.reason
            + ":CONTROL="
            + _enum(event.control)
        )

    all_ids = {s.candidate_id for s in pre_snaps}
    classified = set().union(*out.values())
    if classified != all_ids:
        raise FullLiveActiveD4Conflict(
            "ACTIVE_D4_COHORT_PARTITION_NOT_TOTAL"
        )
    return out


def _stage_fixed_updates(b5_rt: Any, updates: Any) -> None:
    for key, fixed in dict(updates).items():
        old = b5_rt._fixed_adverse.get(key)
        if old is not None and old != fixed:
            raise FullLiveActiveD4Conflict(
                "FIXED_ADVERSE_DIVERGENCE:" + str(key)
            )
        if old is None:
            b5_rt._fixed_adverse[key] = fixed


def run_full_live_generic_active_d4(
    runtime: v6.LiveRuntimeRawAuthorityOrchestrationV6,
    bar: Any,
) -> v6.RawV6CutoffResult:
    if not isinstance(runtime, v6.LiveRuntimeRawAuthorityOrchestrationV6):
        raise FullLiveActiveD4Conflict("V6_RUNTIME_SCHEMA")

    if (
        runtime.state.last_cutoff is not None
        and bar.close_time <= runtime.state.last_cutoff
    ):
        prior = runtime.state.completed.get(
            f"{bar.symbol}:{bar.close_time}"
        )
        if prior is not None and prior[0] == live.digest(bar):
            return prior[1]
        raise FullLiveActiveD4Block(
            "NON_MONOTONIC_OR_DUPLICATE_CUTOFF"
        )

    before_state = runtime.export_state()
    before_digest = runtime.state_digest()

    durable_adapter = runtime._adapter()
    durable_d3 = durable_adapter._d3_rebuild(bar.symbol)
    prebar = durable_d3.update_000_pre_bar_view(bar.open_time)
    pre_snaps = tuple(
        sorted(tuple(prebar.snapshots), key=lambda x: x.snapshot_id)
    )
    if not pre_snaps:
        raise FullLiveActiveD4Block(
            "CAUSAL_PREBAR_SNAPSHOT_REQUIRED"
        )

    raw_adapter, _, _, raw_sr, raw_cache = runtime._raw_shadow(bar)
    trend = raw_cache.d2.update_006_trend
    if (
        trend.episode_id is None
        or trend.episode_start_cutoff is None
        or trend.episode_start_cutoff >= bar.close_time
    ):
        raise FullLiveActiveD4Block(
            "MATURE_ACTIVE_TREND_REQUIRED"
        )
    if trend.direction not in (
        TrendDirection.LONG,
        TrendDirection.SHORT,
    ):
        raise FullLiveActiveD4Block("MATURE_DIRECTION_REQUIRED")

    segment = (
        raw_sr.canonical_segment_id
        or raw_adapter._state(bar.symbol).last_canonical_segment_id
    )
    if not segment:
        raise FullLiveActiveD4Block(
            "CURRENT_CANONICAL_SEGMENT_REQUIRED"
        )

    canonical_records = _require_canonical_records(
        raw_cache.d1,
        bar.close_time,
    )
    params = frozen.frozen_d3_parameters(
        minimal.current_partial_parameter_snapshot()
    )
    geometries = v7._geometry_map(raw_cache.d3_geometry)
    if set(geometries) != set(v7._snapshot_ids(prebar)):
        raise FullLiveActiveD4Conflict(
            "RAW_GEOMETRY_PREBAR_SNAPSHOT_SET_MISMATCH"
        )

    pre_events = v6._event_rows(durable_d3)
    event_by_candidate = v7._event_by_candidate(pre_events)
    cand_rt = (
        candidate_prod.D1D2D3CandidateProductionRuntimeV1.restore_state(
            runtime.state.candidate_state
        )
    )
    durable_candidates = dict(cand_rt.state.candidates)

    b3_rt = (
        b3prod.RuntimeB3PriceDrivenReturnProducerV1.restore_state(
            runtime.state.b3_state
        )
    )
    observations = _runtime_b3_observations(
        bar=bar,
        pre_snaps=pre_snaps,
        event_by_candidate=event_by_candidate,
        durable_candidates=durable_candidates,
        geometries=geometries,
        trend=trend,
        segment=segment,
        params=params,
    )
    b3_results = b3_rt.process_batch(
        raw_sr.transaction_id + ":B3",
        observations,
    )
    if len(b3_results) != len(pre_snaps):
        raise FullLiveActiveD4Conflict(
            "RUNTIME_B3_RESULT_MULTIPLICITY"
        )
    b3_by_snapshot = {
        x.snapshot_ref: x for x in b3_results
    }
    if set(b3_by_snapshot) != {
        s.snapshot_id for s in pre_snaps
    }:
        raise FullLiveActiveD4Conflict(
            "RUNTIME_B3_SNAPSHOT_SET_MISMATCH"
        )

    cohorts = _classify_b3(
        pre_snaps=pre_snaps,
        event_by_candidate=event_by_candidate,
        results_by_snapshot=b3_by_snapshot,
        geometries=geometries,
    )

    # All-passive snapshot cohort has exact B3 no-separation authority.
    # Use the narrow *frozen D3 only* lane; it carries no D4 packet and
    # enforces UPDATE-011..014 N/A, without overriding frozen B3/D3.
    nonconsumable_ids = (
        cohorts["passive_unarmed"]
        | cohorts["new_arm"]
        | cohorts["prequalification"]
    )
    if cohorts["passive_unarmed"] and len(nonconsumable_ids) == len(pre_snaps):
        from full_live_passive_unarmed_no_separation_d3_v1 import (
            run_passive_unarmed_no_separation_d3,
        )
        return run_passive_unarmed_no_separation_d3(runtime, bar)

    # State-driven phase-1 discriminator.  This is typed producer state, not
    # exception text/cutoff/candidate identity.
    mature_test = {
        s.candidate_id
        for s in pre_snaps
        if s.candidate_id in cohorts["mature"]
        and geometries[s.snapshot_id].test
    }
    if not cohorts["active_or_resolved"] and not mature_test:
        # A confirmed/candidate Platform may still become actionable on the
        # current close without a new TEST; allow that surface below.
        platform_state = dict(runtime.state.platform_state)
        if "PLATFORM_CONFIRMED" not in repr(platform_state):
            raise FullLiveActiveD4Block(
                "ACTIVE_D4_SURFACE_NOT_PRESENT"
            )

    minor_history = v6._append_pivots(
        runtime.state.minor_history,
        tuple(raw_cache.d2.update_005_minor),
    )
    intermediate_history = v6._append_pivots(
        runtime.state.intermediate_history,
        tuple(raw_cache.d2.update_005_intermediate),
    )

    b4_by_candidate: dict[str, Any] = {}
    for snapshot in pre_snaps:
        cid = snapshot.candidate_id
        event = event_by_candidate[cid]
        if (
            cid in cohorts["mature"]
            or cid in cohorts["active_or_resolved"]
        ):
            proj = project_active_b4(
                symbol=bar.symbol,
                trend_episode_id=trend.episode_id,
                direction=trend.direction,
                information_cutoff=bar.close_time,
                canonical_segment_id=segment,
                event=event,
                geometry=geometries[snapshot.snapshot_id],
                current_close=bar.close,
                minor_history=minor_history,
                canonical_records=canonical_records,
                theta_progress=params.theta_progress,
            )
            b4_by_candidate[cid] = proj

    cand_result = cand_rt.project_candidate_updates(
        candidate_prod.CandidateProductionRequest(
            transaction_id=raw_sr.transaction_id + ":CANDIDATE",
            symbol=bar.symbol,
            information_cutoff=bar.close_time,
            d1=raw_cache.d1,
            target_trend=trend,
            interaction_events=pre_events,
        )
    )

    snapshot_authorities_list = []
    for snapshot in pre_snaps:
        cid = snapshot.candidate_id
        result = b3_by_snapshot[snapshot.snapshot_id]
        b4 = b4_by_candidate.get(cid)
        sa_consumer = (
            None
            if b4 is None
            else b4prod.safe_b4_consumer(
                b4.structural_acceptance
            )
        )
        cr_consumer = (
            None
            if b4 is None
            else b4prod.safe_b4_consumer(
                b4.correct_side_recovery
            )
        )
        source_refs = [
            "CausalBoundarySnapshot:" + snapshot.snapshot_id,
            "RuntimeB3:" + result.reason + ":" + cid,
        ]
        if b4 is not None:
            source_refs.extend(
                [
                    "B4:STRUCTURAL_ACCEPTANCE:"
                    + b4.structural_acceptance.reason
                    + ":"
                    + cid,
                    "B4:CORRECT_SIDE_RECOVERY:"
                    + b4.correct_side_recovery.reason
                    + ":"
                    + cid,
                ]
            )
        snapshot_authorities_list.append(
            live.snapshot_projection_from_authoritative_producers(
                snapshot_ref=snapshot.snapshot_id,
                runtime_b3_result=result,
                structural_acceptance=sa_consumer,
                correct_side_recovery=cr_consumer,
                source_evidence_refs=tuple(source_refs),
                provenance={
                    "producer_id": BINDING_ID,
                    "active_d4_b4_evaluated": str(
                        b4 is not None
                    ).lower(),
                },
            )
        )

    initial = live.initial_authority_from_frozen_producers(
        candidate_result=cand_result,
        snapshot_projections=tuple(snapshot_authorities_list),
    )

    post_adapter, _, _, post_sr, _ = runtime._post_d3_shadow(
        bar,
        initial,
    )
    if post_sr.transaction_id != raw_sr.transaction_id:
        raise FullLiveActiveD4Conflict(
            "POST_D3_TRANSACTION_ID_DRIFT"
        )
    formal_tx = post_sr.transaction_id
    post_d3 = post_adapter._d3_rebuild(bar.symbol)
    snapshots = v6._snapshot_rows(post_d3)
    episodes = v6._episode_rows(post_d3)
    events = v6._event_rows(post_d3)

    by_id: dict[str, Any] = {}
    for row in cand_result.updates:
        candidate = row.candidate
        old = by_id.get(candidate.candidate_id)
        if old is not None and old != candidate:
            raise FullLiveActiveD4Conflict(
                "DIVERGENT_CANDIDATE:"
                + candidate.candidate_id
            )
        by_id[candidate.candidate_id] = candidate
    current_candidates = tuple(by_id[k] for k in sorted(by_id))
    continuity = runtime._continuity_map(
        current_candidates,
        segment,
    )

    segment_by_anchor: dict[str, str] = {}
    for ep in episodes:
        vals = {
            c.source_segment_id
            for c in current_candidates
            if c.candidate_id == ep.candidate_id
        }
        if len(vals) > 1:
            raise FullLiveActiveD4Conflict(
                "ANCHOR_CANDIDATE_SEGMENT_CONFLICT:"
                + ep.anchor_episode_id
            )
        if vals:
            segment_by_anchor[ep.anchor_episode_id] = next(iter(vals))

    corridor_info = raw_cache.d2.update_009_structural_corridor
    corridor = (
        corridor_info.require_known()
        if corridor_info.kind is InfoKind.KNOWN
        else None
    )
    protected = trend.protected_pivot

    base_u8 = b5prod.Update008Request(
        information_cutoff=bar.close_time,
        trend_episode_id=trend.episode_id,
        direction=trend.direction,
        snapshots=snapshots,
        candidates=current_candidates,
        episodes=episodes,
        events=events,
        progress_evidence=(),
        negotiation_identity_by_event_id={},
        canonical_segment_id_by_anchor_episode_id=segment_by_anchor,
        continuity_by_candidate_id=continuity,
        corridor=corridor,
        protected_price=(
            None if protected is None else protected.extreme_price
        ),
        protected_scale=(
            None if protected is None else protected.scale_at_extreme
        ),
        theta_test=params.theta_test,
        theta_progress=params.theta_progress,
        provenance={
            "producer_id": BINDING_ID,
            "f9_stage": "UPDATE-008",
            "no_update002_backflow": "true",
            "runtime_contract_id": b5prod.RUNTIME_CONTRACT_ID,
        },
    )

    qid_projection = qid.project_negotiation_identity(
        qid.NegotiationIdentityRequest(
            information_cutoff=bar.close_time,
            trend_episode_id=trend.episode_id,
            direction=trend.direction,
            events=events,
            episodes=episodes,
            continuity_by_candidate_id=continuity,
            theta_test=params.theta_test,
            rearm_predecessor_by_event_id={},
            history_complete=True,
            provenance={"producer_id": BINDING_ID},
        )
    )
    if qid_projection.status != qid.STATUS_KNOWN:
        raise FullLiveActiveD4Block(
            "NEGOTIATION_IDENTITY_NOT_KNOWN:"
            + str(qid_projection.reason)
        )
    u8_qid = qid.bind_update008_request(
        base_u8,
        qid_projection,
    )

    qprog_projection = qprog.project_qbu_progress_evidence(
        qprog.QBUProgressProductionRequest(
            update008_request=u8_qid,
            all_minor=minor_history,
            trend_episode_start_cutoff=trend.episode_start_cutoff,
            trend_episode_terminal_cutoff=None,
            history_complete=True,
            history_coverage_ref=(
                "FULL_LIVE_ACTIVE_D4:MINOR_HISTORY:"
                + trend.episode_id
            ),
            theta_progress_parameter_ref="PARAM:theta_progress",
            provenance={"producer_id": BINDING_ID},
        )
    )
    if qprog_projection.state is not EvidenceState.TRUE:
        raise FullLiveActiveD4Block("QBU_PROGRESS_NOT_TRUE")
    u8_request = qprog.bind_update008_request(
        u8_qid,
        qprog_projection,
    )

    zones_probe = b5prod.produce_boundary_contact_zones(
        u8_request
    )
    qbus_probe = b5prod.produce_qbus(u8_request)
    if (
        zones_probe.conflict_anchor_ids
        or zones_probe.state is EvidenceState.CONFLICT
    ):
        raise FullLiveActiveD4Conflict(
            "BOUNDARY_CONTACT_ZONE_CONFLICT"
        )
    if (
        qbus_probe.conflict_event_ids
        or qbus_probe.state is EvidenceState.CONFLICT
    ):
        raise FullLiveActiveD4Conflict("QBU_CONFLICT")

    b5_rt = b5prod.AuthoritativeD3B5D4BaseRuntimeV1.restore_state(
        dict(runtime.state.b5_state)
    )
    prior_role_memory = b5_rt._role_memory.get(trend.episode_id)
    u8_output = b5_rt.process_update008(
        formal_tx + ":U8",
        u8_request,
    )
    if u8_output.roles is None:
        raise FullLiveActiveD4Block(
            "UPDATE008_ROLE_ASSIGNMENT_MISSING"
        )
    cand_rt.record_post_update008_role_transition(
        candidate_prod.PostUpdate008RoleTransitionRequest(
            transaction_id=formal_tx + ":ROLE",
            information_cutoff=bar.close_time,
            role_assignment=u8_output.roles,
            prior_role_memory=prior_role_memory,
            anchor_episodes=tuple(u8_output.episodes),
        )
    )

    platform_rt = (
        platform_prod.PlatformFailedReexpansionProductionRuntimeV1.restore_state(
            dict(runtime.state.platform_state)
        )
    )
    current_d1 = raw_cache.d1.math_15m[-1]
    platform_projection = platform_rt.prepare(
        formal_tx,
        platform_prod.PlatformProductionRequest(
            information_cutoff=bar.close_time,
            symbol=bar.symbol,
            trend_episode_id=trend.episode_id,
            direction=trend.direction,
            trend_state=trend,
            all_minor=minor_history,
            events=events,
            episodes=episodes,
            canonical_segment_id_by_anchor_episode_id=(
                segment_by_anchor
            ),
            continuity_by_candidate_id=continuity,
            rearm_predecessor_by_event_id={},
            rearm_cutoff_by_event_id={},
            canonical_continuity=True,
            atr14_at_confirmation=InfoValue.known(
                current_d1.atr14
            ),
            theta_progress=params.theta_progress,
            theta_progress_parameter_ref="PARAM:theta_progress",
            history_complete=True,
            history_coverage_ref=(
                "FULL_LIVE_ACTIVE_D4:RAW_D2_HISTORY:"
                + trend.episode_id
            ),
            current_close=bar.close,
            setup_lineage=(),
            provenance={"producer_id": BINDING_ID},
        ),
    )
    if platform_projection.state is EvidenceState.CONFLICT:
        platform_rt.abort(formal_tx)
        raise FullLiveActiveD4Conflict(
            "PLATFORM_PRODUCTION_CONFLICT:"
            + platform_projection.reason
        )

    existing_opportunity = durable_adapter._state(
        bar.symbol
    ).current_opportunity
    if (
        existing_opportunity is None
        or existing_opportunity.terminal
    ):
        platform_rt.abort(formal_tx)
        raise FullLiveActiveD4Block(
            "PHASE1_REQUIRES_NONTERMINAL_EXISTING_OPPORTUNITY"
        )
    if (
        existing_opportunity.trend_episode_id
        != trend.episode_id
        or existing_opportunity.direction is not trend.direction
    ):
        platform_rt.abort(formal_tx)
        raise FullLiveActiveD4Conflict(
            "EXISTING_OPPORTUNITY_TREND_LINEAGE_MISMATCH"
        )

    b4_structural = {
        cid: row.structural_acceptance
        for cid, row in b4_by_candidate.items()
    }
    b4_recovery = {
        cid: row.correct_side_recovery
        for cid, row in b4_by_candidate.items()
    }
    fixed_before = dict(b5_rt._fixed_adverse)
    comp = compose_active_d4_mechanisms(
        ActiveD4CompositionInputV1(
            information_cutoff=bar.close_time,
            symbol=bar.symbol,
            trend_episode_id=trend.episode_id,
            direction=trend.direction,
            canonical_segment_id=segment,
            current_close=bar.close,
            theta_progress=params.theta_progress,
            opportunity=existing_opportunity,
            market_event_id=existing_opportunity.market_event_id,
            setup_lineage=tuple(
                existing_opportunity.setup_lineage
            ),
            events=events,
            episodes=tuple(u8_output.episodes),
            units=tuple(u8_output.units),
            role_runtime=u8_output.role_runtime,
            minor_history=minor_history,
            canonical_records=canonical_records,
            structural_by_candidate=b4_structural,
            recovery_by_candidate=b4_recovery,
            platform_projection=platform_projection,
            existing_fixed_adverse_by_setup=fixed_before,
            shallow_behavior_confirmation_cutoff=None,
            shallow_behavior_confirmation_authority_complete=(
                len(
                    tuple(
                        existing_opportunity.confirmation_mechanism_history
                    )
                )
                == 0
            ),
        )
    )
    _stage_fixed_updates(
        b5_rt,
        comp.fixed_adverse_updates,
    )

    lineage_rt = (
        lineage_prod.D4MarketEventLineageProductionProjectorV2.restore_state(
            runtime.state.lineage_state
        )
    )
    prior_lineage_ledger = lineage_rt.ledger_for(
        bar.symbol,
        trend.episode_id,
        trend.direction,
    )
    if prior_lineage_ledger is None:
        platform_rt.abort(formal_tx)
        raise FullLiveActiveD4Block(
            "PRIOR_LINEAGE_LEDGER_REQUIRED"
        )

    lineage_request = lineage_prod.D4LineageProductionRequest(
        symbol=bar.symbol,
        information_cutoff=bar.close_time,
        trend_episode_id=trend.episode_id,
        direction=trend.direction,
        canonical_continuity_known=True,
        canonical_continuity_intact=True,
        active_mechanisms=comp.active_mechanisms,
        trend_establishment_record=None,
        existing_opportunity=existing_opportunity,
        interaction_events=events,
        runtime_b3_results=tuple(b3_results),
        local_control_regain_results=(
            comp.local_control_regain_results
        ),
        mechanisms=comp.mechanisms,
        deep_preidentity=comp.deep_preidentity,
        anchor_episode_ids=tuple(
            ep.anchor_episode_id for ep in u8_output.episodes
        ),
        future_evidence_detected=False,
        provenance={"producer_id": BINDING_ID},
    )

    final_mechanisms = comp.mechanisms
    if lineage_prod.MECH_DEEP in comp.active_mechanisms:
        if (
            comp.deep_preidentity is None
            or comp.unbound_deep_request is None
        ):
            platform_rt.abort(formal_tx)
            raise FullLiveActiveD4Conflict(
                "ACTIVE_DEEP_WITHOUT_PREIDENTITY_AND_UNBOUND_REQUEST"
            )
        deep_tx = deep_bind.prepare_d4_same_event_then_produce_deep(
            projector=lineage_rt,
            transaction_id=formal_tx,
            preidentity=comp.deep_preidentity,
            lineage_request=lineage_request,
            deep_request=comp.unbound_deep_request,
        )
        lineage_projection = deep_tx.lineage_projection
        final_mechanisms = replace(
            comp.mechanisms,
            deep_takeover=deep_tx.deep_projection,
        )
    else:
        if comp.deep_preidentity is not None or comp.unbound_deep_request is not None:
            platform_rt.abort(formal_tx)
            raise FullLiveActiveD4Conflict(
                "INACTIVE_DEEP_CARRIED_PREIDENTITY_AUTHORITY"
            )
        lineage_projection = lineage_rt.prepare(
            formal_tx,
            lineage_request,
        )

    has_causal_gap = bool(
        zones_probe.unknown_anchor_ids
        or qbus_probe.unknown_event_ids
        or u8_output.unknown_lineage_refs
        or zones_probe.state is EvidenceState.UNKNOWN
        or qbus_probe.state is EvidenceState.UNKNOWN
    )
    update008_status = (
        "UNKNOWN" if has_causal_gap else "COMPLETE"
    )
    b4_refs = tuple(
        ref
        for cid in sorted(b4_by_candidate)
        for ref in (
            "B4:STRUCTURAL_ACCEPTANCE:"
            + b4_by_candidate[cid].structural_acceptance.reason
            + ":"
            + cid,
            "B4:CORRECT_SIDE_RECOVERY:"
            + b4_by_candidate[cid].correct_side_recovery.reason
            + ":"
            + cid,
        )
    )
    coverage = d4static.D4CriticalCoverageProof(
        raw_and_d2_state=d4static.SourceCoverageFact(
            "COMPLETE",
            (
                "CanonicalBar:" + str(bar.open_time),
                "D1Math15M:" + str(bar.close_time),
                "TrendEpisode:" + trend.episode_id,
            ),
            provenance={"producer_id": BINDING_ID},
        ),
        d3_candidate_and_runtime_b3=d4static.SourceCoverageFact(
            "COMPLETE",
            (
                "CandidateBatch:" + cand_result.output_digest,
                "RuntimeB3:ACTIVE_D4:" + b3_rt.state_digest(),
            ),
            provenance={
                "prebar_snapshot_count": str(len(pre_snaps)),
                "active_or_resolved_count": str(
                    len(cohorts["active_or_resolved"])
                ),
                "mature_count": str(len(cohorts["mature"])),
            },
        ),
        d2_b4_d4_causal_projections=d4static.SourceCoverageFact(
            "COMPLETE",
            b4_refs
            or ("B4:FULL_APPLICABILITY_EVALUATED_NONE",),
            provenance={"producer_id": BINDING_ID},
        ),
        update008_d3_b5_state=d4static.SourceCoverageFact(
            update008_status,
            tuple(
                "Update008UnknownLineage:" + x
                for x in sorted(u8_output.unknown_lineage_refs)
            )
            or ("Update008:FULL_TYPED_EVALUATION",),
            provenance={"producer_id": BINDING_ID},
        ),
        d4_mechanism_source_coverage=d4static.SourceCoverageFact(
            "COMPLETE",
            tuple(
                "MechanismActive:" + x
                for x in comp.active_mechanisms
            )
            or ("Mechanism:ALL_FROZEN_PRODUCERS_EVALUATED_NONE_ACTIVE",),
            provenance={"producer_id": BINDING_ID},
        ),
        d4_market_event_lineage=d4static.SourceCoverageFact(
            "COMPLETE",
            tuple(lineage_projection.lineage_evidence_refs)
            or (
                "LineageStatus:"
                + str(lineage_projection.status),
            ),
            provenance={"producer_id": BINDING_ID},
        ),
        future_evidence_detected=False,
        provenance={"producer_id": BINDING_ID},
    )

    static_proj = d4static.project_d4_static_source_association(
        d4static.D4StaticAssociationRequest(
            information_cutoff=bar.close_time,
            trend_episode_id=trend.episode_id,
            direction=trend.direction,
            trend=trend,
            trend_position=raw_cache.d2.update_009_position,
            update008_output=u8_output,
            mechanisms=final_mechanisms,
            lineage_projection=lineage_projection,
            coverage=coverage,
            termination=None,
            provenance={"producer_id": BINDING_ID},
        )
    )

    asm_rt = (
        assembler.AuthoritativeD3D4PacketAssemblerV2.restore_state(
            dict(runtime.state.assembler_state)
        )
    )
    initial_packet = asm_rt.begin(initial)
    if getattr(initial_packet, "d4", None) is not None:
        lineage_rt.abort(formal_tx)
        platform_rt.abort(formal_tx)
        raise FullLiveActiveD4Conflict(
            "INITIAL_PACKET_D4_MUST_BE_NONE"
        )

    assembled = None
    if (
        static_proj.status == "READY"
        and static_proj.d4_static_authority is not None
    ):
        assembled = asm_rt.complete(
            formal_tx,
            initial,
            assembler.PostUpdate008Authority(
                information_cutoff=bar.close_time,
                update008_output=u8_output,
                d4_static=static_proj.d4_static_authority,
                mechanisms=final_mechanisms,
                existing_opportunity=existing_opportunity,
                provenance={"producer_id": BINDING_ID},
            ),
        )
        final_packet = assembled.final_packet
    else:
        # Source coverage/lineage may be scientifically UNKNOWN at a fully
        # evaluated cutoff.  Preserve that epistemic state by withholding D4.
        final_packet = initial_packet

    formal_adapter = runtime._adapter()
    formal_ledger = runtime._ledger()
    session = v6._PreassembledPacketSession(
        formal_adapter,
        initial_packet,
        final_packet,
    )
    engine = minimal.DeterministicCutoffEngine(
        adapters=session.registry(),
        ledger=formal_ledger,
    )
    formal_result = engine.run_cutoff_batch(
        (runtime._input(bar),)
    )
    formal_sr = formal_result.symbol_results[0]
    if formal_sr.transaction_id != formal_tx:
        lineage_rt.abort(formal_tx)
        platform_rt.abort(formal_tx)
        raise FullLiveActiveD4Conflict(
            "FORMAL_TRANSACTION_ID_DRIFT"
        )

    if formal_result.terminal in (
        minimal.TransactionTerminal.ABORTED_ERROR,
        minimal.TransactionTerminal.ABORTED_AMBIGUITY,
    ):
        lineage_rt.abort(formal_tx)
        platform_rt.abort(formal_tx)
        if (
            runtime.export_state() != before_state
            or runtime.state_digest() != before_digest
        ):
            raise FullLiveActiveD4Conflict(
                "ABORT_MUTATED_DURABLE_STATE"
            )
        return v6.RawV6CutoffResult(
            mode="FULL_LIVE_GENERIC_ACTIVE_D4_ABORTED",
            engine_result=formal_result,
            trend_episode_id=trend.episode_id,
            relation=lineage_projection.relation,
            coverage_statuses=static_proj.coverage_statuses,
            candidate_update_count=len(cand_result.updates),
            prebar_snapshot_count=len(pre_snaps),
            final_packet_digest=assembler.digest(final_packet),
            persistent_state_committed=False,
            blocker="FORMAL_STAGED_ENGINE_ABORT",
            provenance={
                "binding_id": BINDING_ID,
                "abort_is_atomic": "true",
            },
        )

    if (
        tuple(session.initial_steps) != live.INITIAL_VISIBLE_STEPS
        or tuple(session.final_steps) != live.FINAL_VISIBLE_STEPS
    ):
        lineage_rt.abort(formal_tx)
        platform_rt.abort(formal_tx)
        raise FullLiveActiveD4Conflict(
            "FORMAL_PACKET_STAGE_VISIBILITY_VIOLATION"
        )
    if getattr(initial_packet, "d4", None) is not None:
        raise FullLiveActiveD4Conflict(
            "D4_VISIBLE_BEFORE_UPDATE011"
        )
    if static_proj.status == "READY":
        if getattr(final_packet, "d4", None) is None:
            raise FullLiveActiveD4Conflict(
                "READY_STATIC_WITHOUT_FINAL_D4_PACKET"
            )
    else:
        if getattr(final_packet, "d4", None) is not None:
            raise FullLiveActiveD4Conflict(
                "BLOCKED_STATIC_EXPOSED_D4_PACKET"
            )

    lineage_rt.commit(formal_tx)
    platform_rt.commit(formal_tx)

    snaps = dict(runtime.state.next_snapshots)
    if formal_sr.next_bar_snapshot is not None:
        snaps[formal_sr.symbol] = formal_sr.next_bar_snapshot

    result = v6.RawV6CutoffResult(
        mode="FULL_LIVE_GENERIC_ACTIVE_D4_TYPED_STAGED",
        engine_result=formal_result,
        trend_episode_id=trend.episode_id,
        relation=lineage_projection.relation,
        coverage_statuses=static_proj.coverage_statuses,
        candidate_update_count=len(cand_result.updates),
        prebar_snapshot_count=len(pre_snaps),
        final_packet_digest=assembler.digest(final_packet),
        persistent_state_committed=True,
        provenance={
            "binding_id": BINDING_ID,
            "active_mechanisms": ",".join(comp.active_mechanisms),
            "d4_static_status": static_proj.status,
            "post_update007_active_count": str(
                sum(
                    e.control
                    is InteractionControl.INTERACTION_ACTIVE
                    for e in events
                )
            ),
            "post_update007_resolved_count": str(
                sum(
                    e.control is InteractionControl.RESOLVED
                    for e in events
                )
            ),
            "b4_evaluated_count": str(len(b4_by_candidate)),
            "fixed_adverse_update_count": str(
                len(comp.fixed_adverse_updates)
            ),
            "generic_active_d4_phase": "SAME_NONTERMINAL_OPPORTUNITY",
            "deep_identity_binding": (
                "PREIDENTITY_THEN_D4_SAME_EVENT_THEN_FROZEN_DEEP"
                if lineage_prod.MECH_DEEP in comp.active_mechanisms
                else "NOT_ACTIVE"
            ),
            "new_threshold_added": "false",
            "fixed_window_added": "false",
            "trading": "FORBIDDEN",
        },
    )

    completed = dict(runtime.state.completed)
    completed[f"{bar.symbol}:{bar.close_time}"] = (
        live.digest(bar),
        result,
    )
    runtime.state = v6.RawV6State(
        adapter_state=formal_adapter.export_state(),
        ledger_events=formal_ledger.snapshot(),
        next_snapshots=snaps,
        assembler_state=dict(asm_rt.export_state()),
        lineage_state=lineage_rt.export_state(),
        candidate_state=cand_rt.export_state(),
        b3_state=b3_rt.export_state(),
        b5_state=dict(b5_rt.export_state()),
        platform_state=dict(platform_rt.export_state()),
        minor_history=minor_history,
        intermediate_history=intermediate_history,
        completed=completed,
        last_cutoff=bar.close_time,
    )
    return result


def invariants() -> dict[str, Any]:
    return {
        "state_driven_active_surface_probe": True,
        "exception_text_dispatch": False,
        "same_rawv6_durable_state": True,
        "same_candidate_runtime": True,
        "same_runtime_b3": True,
        "same_update007_adapter": True,
        "same_update008_b5_runtime": True,
        "same_platform_runtime": True,
        "same_d4_lineage_projector": True,
        "same_d4_static_projector": True,
        "same_packet_assembler": True,
        "deep_preidentity_same_event_binding": True,
        "deep_self_authorization": False,
        "d4_visible_before_update011": False,
        "new_selector": False,
        "new_ranking": False,
        "new_threshold": False,
        "fixed_window": False,
        "trading_activated": False,
        "phase1_terminal_opportunity_new_event_supported": False,
    }
