from __future__ import annotations

"""Injected-I/O Binance USD-M public depth snapshot adapter.

Official public REST contract:
  base: https://fapi.binance.com
  path: /fapi/v1/depth
This module performs no network I/O itself. The caller supplies an injected
public-read-only GET function. RPI liquidity is intentionally not merged into
this standard-book snapshot.
"""

from dataclasses import dataclass
from typing import Any, Callable, Mapping


SOURCE = "BINANCE_USDM_STANDARD_ORDER_BOOK_DEPTH_REST_V1"
BASE_URL = "https://fapi.binance.com"
DEPTH_PATH = "/fapi/v1/depth"
ALLOWED_STANDARD_DEPTH_LIMITS = frozenset({5, 10, 20, 50, 100, 500, 1000})


class BinanceUSDMPublicDepthSnapshotBlock(RuntimeError):
    pass


@dataclass(frozen=True)
class BinanceUSDMPublicDepthSnapshotV1:
    symbol: str
    last_update_id: int
    message_output_time_ms: int
    transaction_time_ms: int
    bids: tuple[tuple[str, str], ...]
    asks: tuple[tuple[str, str], ...]
    source: str = SOURCE
    rpi_liquidity_included: bool = False

    def measurement_book(self) -> Mapping[str, Any]:
        return {"bids": self.bids, "asks": self.asks}


def _side(raw: Any, label: str) -> tuple[tuple[str, str], ...]:
    if not isinstance(raw, list) or not raw:
        raise BinanceUSDMPublicDepthSnapshotBlock(label + "_REQUIRED")
    out: list[tuple[str, str]] = []
    for idx, row in enumerate(raw):
        if not isinstance(row, (list, tuple)) or len(row) < 2:
            raise BinanceUSDMPublicDepthSnapshotBlock(
                label + "_ROW_INVALID:" + str(idx)
            )
        out.append((str(row[0]), str(row[1])))
    return tuple(out)


def parse_usdm_public_depth_snapshot(
    *, symbol: str, raw: Any
) -> BinanceUSDMPublicDepthSnapshotV1:
    if not symbol:
        raise BinanceUSDMPublicDepthSnapshotBlock("SYMBOL_REQUIRED")
    if not isinstance(raw, Mapping):
        raise BinanceUSDMPublicDepthSnapshotBlock("DEPTH_MAPPING_REQUIRED")
    try:
        update_id = int(raw["lastUpdateId"])
        message_output_time_ms = int(raw["E"])
        transaction_time_ms = int(raw["T"])
    except Exception as exc:
        raise BinanceUSDMPublicDepthSnapshotBlock(
            "DEPTH_PROVENANCE_FIELDS_REQUIRED"
        ) from exc
    if update_id < 0:
        raise BinanceUSDMPublicDepthSnapshotBlock("LAST_UPDATE_ID_INVALID")
    if message_output_time_ms <= 0 or transaction_time_ms <= 0:
        raise BinanceUSDMPublicDepthSnapshotBlock("DEPTH_TIME_INVALID")
    if transaction_time_ms > message_output_time_ms:
        raise BinanceUSDMPublicDepthSnapshotBlock("DEPTH_TIME_ORDER_INVALID")
    return BinanceUSDMPublicDepthSnapshotV1(
        symbol=symbol.upper(),
        last_update_id=update_id,
        message_output_time_ms=message_output_time_ms,
        transaction_time_ms=transaction_time_ms,
        bids=_side(raw.get("bids"), "BIDS"),
        asks=_side(raw.get("asks"), "ASKS"),
    )


def acquire_usdm_public_depth_snapshot(
    *,
    symbol: str,
    limit: int,
    public_get: Callable[..., Any],
) -> BinanceUSDMPublicDepthSnapshotV1:
    """Acquire only through injected public GET; no credentials or writes."""
    if not callable(public_get):
        raise BinanceUSDMPublicDepthSnapshotBlock("PUBLIC_GET_REQUIRED")
    if not isinstance(limit, int) or limit not in ALLOWED_STANDARD_DEPTH_LIMITS:
        raise BinanceUSDMPublicDepthSnapshotBlock("DEPTH_LIMIT_NOT_OFFICIAL_STANDARD_VALUE")
    raw = public_get(
        BASE_URL + DEPTH_PATH,
        params={"symbol": symbol.upper(), "limit": limit},
    )
    return parse_usdm_public_depth_snapshot(symbol=symbol, raw=raw)


def invariants() -> Mapping[str, Any]:
    return {
        "market": "BINANCE_USDM_FUTURES",
        "public_read_only": True,
        "network_io_injected": True,
        "credentials_required": False,
        "orders": 0,
        "fills": 0,
        "execution_intents": 0,
        "rpi_liquidity_included": False,
        "policy_thresholds_owned": False,
        "official_standard_depth_limits_enforced": True,
        "exchange_message_and_transaction_times_bound": True,
        "strategy_source_changed": False,
    }
