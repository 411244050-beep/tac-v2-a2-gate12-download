from __future__ import annotations

import dataclasses
from dataclasses import dataclass
from typing import Any, Mapping

from d6_continuation_guard_v1 import (
    D6ContinuationGuardResultV1,
    run_structural_only_update_010,
)
from d6_continuation_persistence_v1 import (
    D6CommittedSnapshotRecoveryV1,
    D6ContinuationPersistenceBlock,
    D6ContinuationPersistenceResultV1,
    persist_d6_continuation_snapshot_first,
    recover_latest_committed_d6_snapshot,
)
from d6_position_store_v1 import (
    AuthoritativeD6PositionStoreV1,
    D6PositionStoreBlock,
)
from full_live_position_coordinator_v1 import FullLivePositionCoordinatorV1
from strategy_rc1.d6_position_execution import engine
from strategy_rc1.d6_position_execution.types import StrategyPositionSnapshot
from trade_ledger_v1 import TradeLedgerV1


class FullLiveD6PositionManagerBlock(RuntimeError):
    pass


@dataclass(frozen=True)
class D6ContinuationApplicationResultV1:
    status: str
    position_before: StrategyPositionSnapshot
    position_after: StrategyPositionSnapshot | None
    guard_result: D6ContinuationGuardResultV1
    committed_snapshot: D6ContinuationPersistenceResultV1 | None
    prior_recovery: D6CommittedSnapshotRecoveryV1
    exit_record: Any | None
    close_application_result: Any | None


def _text(value: Any) -> str:
    raw = getattr(value, "value", value)
    return str(raw)


def _activation_initial_snapshot_id(
    rows: tuple[Mapping[str, Any], ...],
    *,
    symbol: str,
    position_id: str,
    entry_ready_id: str,
) -> str:
    matches: list[Mapping[str, Any]] = []
    for row in rows:
        if row.get("event_type") != "D6_POSITION_ACTIVATED":
            continue
        if str(row.get("symbol", "")) != symbol:
            continue
        data = row.get("data")
        if not isinstance(data, Mapping):
            raise FullLiveD6PositionManagerBlock(
                "D6_ACTIVATION_DATA_INVALID"
            )
        if str(data.get("position_id", "")) != position_id:
            continue
        if str(data.get("entry_ready_id", "")) != entry_ready_id:
            continue
        matches.append(row)

    if len(matches) != 1:
        raise FullLiveD6PositionManagerBlock(
            "D6_ACTIVATION_EVENT_NOT_UNIQUE:"
            + symbol
            + ":"
            + position_id
        )

    data = matches[0]["data"]
    snapshot_event_id = str(
        data.get("snapshot_event_id", "") or ""
    )
    if not snapshot_event_id:
        raise FullLiveD6PositionManagerBlock(
            "D6_ACTIVATION_SNAPSHOT_EVENT_ID_REQUIRED"
        )
    return snapshot_event_id


def _current_committed_recovery(
    *,
    ledger: TradeLedgerV1,
    position: StrategyPositionSnapshot,
) -> D6CommittedSnapshotRecoveryV1:
    entry = getattr(position, "entry", None)
    symbol = str(getattr(entry, "symbol", "") or "")
    entry_ready_id = str(
        getattr(entry, "entry_ready_id", "") or ""
    )
    position_id = str(
        getattr(position, "position_id", "") or ""
    )
    if not symbol or not entry_ready_id or not position_id:
        raise FullLiveD6PositionManagerBlock(
            "D6_POSITION_IDENTITY_INCOMPLETE"
        )

    rows = tuple(ledger.read_all())
    initial_snapshot_event_id = _activation_initial_snapshot_id(
        rows,
        symbol=symbol,
        position_id=position_id,
        entry_ready_id=entry_ready_id,
    )
    try:
        recovery = recover_latest_committed_d6_snapshot(
            ledger_rows=rows,
            symbol=symbol,
            position_id=position_id,
            entry_ready_id=entry_ready_id,
            initial_snapshot_event_id=initial_snapshot_event_id,
        )
    except D6ContinuationPersistenceBlock as exc:
        raise FullLiveD6PositionManagerBlock(
            "D6_CONTINUATION_LINEAGE_RECOVERY_FAILED:"
            + str(exc)
        ) from exc

    if recovery.snapshot != position:
        raise FullLiveD6PositionManagerBlock(
            "D6_STORE_LEDGER_SNAPSHOT_DRIFT:"
            + recovery.snapshot_event_id
        )
    return recovery


def _candidate_open_snapshot(
    *,
    position_before: StrategyPositionSnapshot,
    guard: D6ContinuationGuardResultV1,
) -> StrategyPositionSnapshot:
    view = guard.update_result
    exit_eval = getattr(view, "exit_evaluation", None)
    if exit_eval is None:
        raise FullLiveD6PositionManagerBlock(
            "D6_EXIT_EVALUATION_REQUIRED"
        )
    if getattr(exit_eval, "exit_record", None) is not None:
        raise FullLiveD6PositionManagerBlock(
            "EXIT_RECORD_CANNOT_BUILD_OPEN_CONTINUATION_SNAPSHOT"
        )

    mode = getattr(view, "position_mode", None)
    if _text(mode) == "CLOSED":
        raise FullLiveD6PositionManagerBlock(
            "CLOSED_VIEW_REQUIRES_EXIT_RECORD"
        )

    pivot = getattr(
        getattr(view, "qualified_protective_pivot", None),
        "pivot",
        None,
    )
    latest = getattr(
        position_before,
        "latest_qualified_protective_pivot",
        None,
    )
    if guard.structural_reference_advanced:
        if pivot is None:
            raise FullLiveD6PositionManagerBlock(
                "STRUCTURAL_ADVANCE_REQUIRES_PIVOT"
            )
        latest = pivot

    try:
        candidate = dataclasses.replace(
            position_before,
            mode=mode,
            latest_qualified_protective_pivot=latest,
        )
    except Exception as exc:
        raise FullLiveD6PositionManagerBlock(
            "D6_CONTINUATION_SNAPSHOT_CONSTRUCTION_FAILED:"
            + exc.__class__.__name__
            + ":"
            + str(exc)
        ) from exc

    if (
        getattr(candidate, "current_protective_stop", None)
        != getattr(position_before, "current_protective_stop", None)
    ):
        raise FullLiveD6PositionManagerBlock(
            "D6_NUMERIC_PROTECTIVE_STOP_CHANGED"
        )
    if getattr(candidate, "closed_exit_id", None) is not None:
        raise FullLiveD6PositionManagerBlock(
            "OPEN_CONTINUATION_SNAPSHOT_CANNOT_BE_CLOSED"
        )
    return candidate


class FullLiveD6PositionManagerV1:
    def __init__(
        self,
        *,
        store: AuthoritativeD6PositionStoreV1,
        ledger: TradeLedgerV1,
        coordinator: FullLivePositionCoordinatorV1,
        update_010_callable: Any = engine.update_010,
    ) -> None:
        self.store = store
        self.ledger = ledger
        self.coordinator = coordinator
        self.update_010_callable = update_010_callable

        if getattr(coordinator, "ledger", None) is not ledger:
            raise FullLiveD6PositionManagerBlock(
                "D6_MANAGER_COORDINATOR_LEDGER_IDENTITY_DRIFT"
            )
        if getattr(coordinator, "registry", None) is not store:
            raise FullLiveD6PositionManagerBlock(
                "D6_MANAGER_COORDINATOR_STORE_IDENTITY_DRIFT"
            )

    def apply_cutoff(
        self,
        *,
        inp: Any,
    ) -> D6ContinuationApplicationResultV1:
        supplied_position = getattr(inp, "position", None)
        entry = getattr(supplied_position, "entry", None)
        symbol = str(getattr(entry, "symbol", "") or "")
        if not symbol:
            raise FullLiveD6PositionManagerBlock(
                "D6_CUTOFF_INPUT_SYMBOL_REQUIRED"
            )

        position_before = self.store.active(symbol)
        if position_before is None:
            raise FullLiveD6PositionManagerBlock(
                "D6_ACTIVE_POSITION_REQUIRED:" + symbol
            )
        if supplied_position != position_before:
            raise FullLiveD6PositionManagerBlock(
                "D6_CUTOFF_INPUT_POSITION_DRIFT:" + symbol
            )

        parameters = getattr(inp, "parameters", None)
        if parameters is None:
            raise FullLiveD6PositionManagerBlock(
                "D6_PARAMETER_VIEW_REQUIRED"
            )

        prior_recovery = _current_committed_recovery(
            ledger=self.ledger,
            position=position_before,
        )

        guard = run_structural_only_update_010(
            update_010_callable=self.update_010_callable,
            kwargs={"inp": inp},
            position_before=position_before,
            parameter_view=parameters,
        )
        view = guard.update_result
        exit_eval = getattr(view, "exit_evaluation", None)
        if exit_eval is None:
            raise FullLiveD6PositionManagerBlock(
                "D6_EXIT_EVALUATION_REQUIRED"
            )
        exit_record = getattr(exit_eval, "exit_record", None)

        if exit_record is not None:
            record_position_id = str(
                getattr(exit_record, "position_id", "") or ""
            )
            if record_position_id != position_before.position_id:
                raise FullLiveD6PositionManagerBlock(
                    "D6_EXIT_RECORD_POSITION_ID_DRIFT"
                )

            exit_id = str(
                getattr(exit_record, "exit_id", "") or ""
            )
            if not exit_id:
                raise FullLiveD6PositionManagerBlock(
                    "D6_EXIT_RECORD_EXIT_ID_REQUIRED"
                )

            primary_reason = _text(
                getattr(exit_record, "primary_reason", None)
            )
            if not primary_reason:
                raise FullLiveD6PositionManagerBlock(
                    "D6_EXIT_RECORD_PRIMARY_REASON_REQUIRED"
                )

            direction = _text(
                getattr(position_before.entry, "direction", None)
            ).upper()
            if direction not in ("LONG", "SHORT"):
                raise FullLiveD6PositionManagerBlock(
                    "D6_POSITION_DIRECTION_INVALID:" + direction
                )

            close_result = self.coordinator.close_after_d6_exit(
                position_id=position_before.position_id,
                symbol=symbol,
                direction=direction,
                exit_id=exit_id,
                primary_reason=primary_reason,
            )
            if self.store.active(symbol) is not None:
                raise FullLiveD6PositionManagerBlock(
                    "D6_STORE_STILL_ACTIVE_AFTER_EXIT:" + symbol
                )

            return D6ContinuationApplicationResultV1(
                status="D6_EXIT_APPLIED_EXCHANGE_CLOSE_FIRST",
                position_before=position_before,
                position_after=close_result,
                guard_result=guard,
                committed_snapshot=None,
                prior_recovery=prior_recovery,
                exit_record=exit_record,
                close_application_result=close_result,
            )

        candidate = _candidate_open_snapshot(
            position_before=position_before,
            guard=guard,
        )

        if candidate == position_before:
            return D6ContinuationApplicationResultV1(
                status="D6_CONTINUED_NO_STATE_CHANGE",
                position_before=position_before,
                position_after=position_before,
                guard_result=guard,
                committed_snapshot=None,
                prior_recovery=prior_recovery,
                exit_record=None,
                close_application_result=None,
            )

        try:
            persisted = persist_d6_continuation_snapshot_first(
                ledger=self.ledger,
                previous_snapshot_event_id=(
                    prior_recovery.snapshot_event_id
                ),
                snapshot=candidate,
                entry_ready_id=str(
                    position_before.entry.entry_ready_id
                ),
                information_cutoff=int(
                    getattr(view, "information_cutoff")
                ),
                update_step=str(
                    getattr(view, "update_step", "")
                ),
                mode_text=guard.mode_text,
                structural_reference_advanced=(
                    guard.structural_reference_advanced
                ),
                new_risk_blocked=guard.new_risk_blocked,
            )
        except Exception as exc:
            raise FullLiveD6PositionManagerBlock(
                "D6_CONTINUATION_PERSISTENCE_FAILED:"
                + exc.__class__.__name__
                + ":"
                + str(exc)
            ) from exc

        try:
            position_after = self.store.replace_active(candidate)
        except D6PositionStoreBlock as exc:
            raise FullLiveD6PositionManagerBlock(
                "FATAL_D6_CONTINUATION_COMMITTED_BUT_STORE_UPDATE_FAILED:"
                + str(exc)
            ) from exc

        if position_after != candidate:
            raise FullLiveD6PositionManagerBlock(
                "D6_CONTINUATION_STORE_ROUNDTRIP_DRIFT"
            )

        return D6ContinuationApplicationResultV1(
            status="D6_CONTINUATION_COMMITTED",
            position_before=position_before,
            position_after=position_after,
            guard_result=guard,
            committed_snapshot=persisted,
            prior_recovery=prior_recovery,
            exit_record=None,
            close_application_result=None,
        )


__all__ = [
    "FullLiveD6PositionManagerBlock",
    "D6ContinuationApplicationResultV1",
    "FullLiveD6PositionManagerV1",
]
