from __future__ import annotations

import dataclasses
from typing import Any

from strategy_rc1.d6_position_execution.position import StrategyPositionRegistry
from strategy_rc1.d6_position_execution.types import StrategyPositionSnapshot


class D6PositionStoreBlock(RuntimeError):
    pass


def _symbol(position: StrategyPositionSnapshot) -> str:
    symbol = str(
        getattr(getattr(position, "entry", None), "symbol", "") or ""
    )
    if not symbol:
        raise D6PositionStoreBlock("POSITION_SYMBOL_REQUIRED")
    return symbol


def _position_id(position: StrategyPositionSnapshot) -> str:
    value = str(getattr(position, "position_id", "") or "")
    if not value:
        raise D6PositionStoreBlock("POSITION_ID_REQUIRED")
    return value


class AuthoritativeD6PositionStoreV1:
    """Own current live snapshots without mutating Strategy registry internals.

    The frozen StrategyPositionRegistry remains the lifecycle firewall for
    register/close.  This wrapper carries the latest active snapshot across
    structural-only continuation updates, for which the frozen registry exposes
    no public replace/update API.
    """

    def __init__(
        self,
        registry: StrategyPositionRegistry | None = None,
    ) -> None:
        self._registry = registry or StrategyPositionRegistry()
        self._current_by_symbol: dict[str, StrategyPositionSnapshot] = {}

    @property
    def native_registry(self) -> StrategyPositionRegistry:
        return self._registry

    def register(self, position: StrategyPositionSnapshot) -> None:
        if not isinstance(position, StrategyPositionSnapshot):
            raise D6PositionStoreBlock(
                "STRATEGY_POSITION_SNAPSHOT_REQUIRED"
            )
        if getattr(position, "closed_exit_id", None) is not None:
            raise D6PositionStoreBlock(
                "CLOSED_POSITION_CANNOT_REGISTER"
            )

        symbol = _symbol(position)
        if symbol in self._current_by_symbol:
            raise D6PositionStoreBlock(
                "POSITION_STORE_SYMBOL_ALREADY_ACTIVE:" + symbol
            )

        try:
            self._registry.register(position)
        except Exception as exc:
            raise D6PositionStoreBlock(
                "NATIVE_REGISTRY_REGISTER_FAILED:"
                + exc.__class__.__name__
                + ":"
                + str(exc)
            ) from exc

        native = self._registry.active(symbol)
        if native is None or _position_id(native) != _position_id(position):
            raise D6PositionStoreBlock(
                "NATIVE_REGISTRY_REGISTER_ROUNDTRIP_DRIFT:" + symbol
            )

        self._current_by_symbol[symbol] = position

    def active(self, symbol: str) -> StrategyPositionSnapshot | None:
        if not symbol:
            raise D6PositionStoreBlock("SYMBOL_REQUIRED")

        current = self._current_by_symbol.get(symbol)
        native = self._registry.active(symbol)

        if current is None:
            if native is not None:
                raise D6PositionStoreBlock(
                    "POSITION_STORE_NATIVE_REGISTRY_UNMIRRORED:" + symbol
                )
            return None

        if native is None:
            raise D6PositionStoreBlock(
                "POSITION_STORE_NATIVE_REGISTRY_MISSING:" + symbol
            )
        if _position_id(native) != _position_id(current):
            raise D6PositionStoreBlock(
                "POSITION_STORE_NATIVE_POSITION_ID_DRIFT:" + symbol
            )
        return current

    def active_positions(self) -> tuple[StrategyPositionSnapshot, ...]:
        """Return all active snapshots after native-registry mirror checks."""
        rows: list[StrategyPositionSnapshot] = []
        for symbol in sorted(self._current_by_symbol):
            current = self.active(symbol)
            if current is None:
                raise D6PositionStoreBlock(
                    "POSITION_STORE_ENUMERATION_ACTIVE_MISSING:"
                    + symbol
                )
            rows.append(current)
        return tuple(rows)

    def replace_active(
        self,
        position: StrategyPositionSnapshot,
    ) -> StrategyPositionSnapshot:
        if not isinstance(position, StrategyPositionSnapshot):
            raise D6PositionStoreBlock(
                "STRATEGY_POSITION_SNAPSHOT_REQUIRED"
            )
        if getattr(position, "closed_exit_id", None) is not None:
            raise D6PositionStoreBlock(
                "CLOSED_POSITION_CANNOT_REPLACE_ACTIVE"
            )

        symbol = _symbol(position)
        before = self.active(symbol)
        if before is None:
            raise D6PositionStoreBlock(
                "POSITION_STORE_ACTIVE_REQUIRED:" + symbol
            )

        immutable_checks = {
            "position_id": (
                _position_id(position),
                _position_id(before),
            ),
            "entry": (
                getattr(position, "entry", None),
                getattr(before, "entry", None),
            ),
            "opened_from_execution_evidence_id": (
                getattr(
                    position,
                    "opened_from_execution_evidence_id",
                    None,
                ),
                getattr(
                    before,
                    "opened_from_execution_evidence_id",
                    None,
                ),
            ),
            "opened_real_time": (
                getattr(position, "opened_real_time", None),
                getattr(before, "opened_real_time", None),
            ),
        }
        for name, (actual, expected) in immutable_checks.items():
            if actual != expected:
                raise D6PositionStoreBlock(
                    "POSITION_STORE_IMMUTABLE_IDENTITY_DRIFT:"
                    + name
                )

        self._current_by_symbol[symbol] = position
        if self.active(symbol) != position:
            raise D6PositionStoreBlock(
                "POSITION_STORE_REPLACE_ROUNDTRIP_DRIFT:" + symbol
            )
        return position

    def close(
        self,
        position_id: str,
        exit_id: str,
    ) -> StrategyPositionSnapshot:
        if not position_id:
            raise D6PositionStoreBlock("POSITION_ID_REQUIRED")
        if not exit_id:
            raise D6PositionStoreBlock("EXIT_ID_REQUIRED")

        matches = [
            (symbol, position)
            for symbol, position in self._current_by_symbol.items()
            if _position_id(position) == position_id
        ]
        if len(matches) != 1:
            raise D6PositionStoreBlock(
                "POSITION_STORE_ACTIVE_POSITION_ID_NOT_UNIQUE:"
                + position_id
            )
        symbol, current = matches[0]

        try:
            native_closed = self._registry.close(position_id, exit_id)
        except Exception as exc:
            raise D6PositionStoreBlock(
                "NATIVE_REGISTRY_CLOSE_FAILED:"
                + exc.__class__.__name__
                + ":"
                + str(exc)
            ) from exc

        if _position_id(native_closed) != position_id:
            raise D6PositionStoreBlock(
                "NATIVE_REGISTRY_CLOSE_POSITION_ID_DRIFT"
            )
        if str(getattr(native_closed, "closed_exit_id", "") or "") != exit_id:
            raise D6PositionStoreBlock(
                "NATIVE_REGISTRY_CLOSE_EXIT_ID_DRIFT"
            )

        # The frozen registry owns the legal OPEN -> CLOSED transition.
        # Its returned snapshot already satisfies the Strategy invariants
        # (including CLOSED mode + closed_exit_id).  Preserve that lifecycle
        # state and overlay only the latest continuation-managed fields.
        native_identity_checks = {
            "position_id": (
                _position_id(native_closed),
                _position_id(current),
            ),
            "entry": (
                getattr(native_closed, "entry", None),
                getattr(current, "entry", None),
            ),
            "opened_from_execution_evidence_id": (
                getattr(
                    native_closed,
                    "opened_from_execution_evidence_id",
                    None,
                ),
                getattr(
                    current,
                    "opened_from_execution_evidence_id",
                    None,
                ),
            ),
            "opened_real_time": (
                getattr(native_closed, "opened_real_time", None),
                getattr(current, "opened_real_time", None),
            ),
        }
        for name, (actual, expected) in native_identity_checks.items():
            if actual != expected:
                raise D6PositionStoreBlock(
                    "NATIVE_REGISTRY_CLOSE_IDENTITY_DRIFT:" + name
                )

        try:
            closed = dataclasses.replace(
                native_closed,
                latest_qualified_protective_pivot=getattr(
                    current,
                    "latest_qualified_protective_pivot",
                    None,
                ),
                current_protective_stop=getattr(
                    current,
                    "current_protective_stop",
                    None,
                ),
                observer_label=getattr(
                    current,
                    "observer_label",
                    None,
                ),
                provenance=dict(
                    getattr(current, "provenance", {}) or {}
                ),
            )
        except Exception as exc:
            raise D6PositionStoreBlock(
                "POSITION_STORE_CLOSE_SNAPSHOT_FAILED:"
                + exc.__class__.__name__
                + ":"
                + str(exc)
            ) from exc

        if str(getattr(closed, "closed_exit_id", "") or "") != exit_id:
            raise D6PositionStoreBlock(
                "POSITION_STORE_CLOSE_EXIT_ID_DRIFT"
            )

        del self._current_by_symbol[symbol]
        if self._registry.active(symbol) is not None:
            raise D6PositionStoreBlock(
                "NATIVE_REGISTRY_STILL_ACTIVE_AFTER_CLOSE:" + symbol
            )
        return closed


__all__ = [
    "D6PositionStoreBlock",
    "AuthoritativeD6PositionStoreV1",
]
