from __future__ import annotations

"""Pure, nontrading execution-feasibility measurements for full-live D5.

This module owns no policy thresholds and performs no network or exchange I/O.
It converts an explicitly supplied public order-book snapshot plus intended
quote notional into deterministic measurements. Policy enforcement is a
separate, versioned authority.
"""

from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from typing import Any, Iterable, Mapping


class FullLiveExecutionFeasibilityMeasurementBlock(RuntimeError):
    pass


@dataclass(frozen=True)
class ExecutionFeasibilityMeasurementV1:
    symbol: str
    direction: str
    intended_quote_notional: Decimal
    best_bid: Decimal
    best_ask: Decimal
    midpoint: Decimal
    spread_bps: Decimal
    executable_quote_notional: Decimal
    executable_base_quantity: Decimal
    vwap: Decimal | None
    impact_from_best_bps: Decimal | None
    fully_fillable: bool


def _d(value: Any, label: str) -> Decimal:
    try:
        out = Decimal(str(value))
    except (InvalidOperation, ValueError, TypeError) as exc:
        raise FullLiveExecutionFeasibilityMeasurementBlock(
            "INVALID_DECIMAL:" + label
        ) from exc
    if not out.is_finite() or out <= 0:
        raise FullLiveExecutionFeasibilityMeasurementBlock(
            "NONPOSITIVE_DECIMAL:" + label
        )
    return out


def _levels(raw: Iterable[Any], label: str) -> tuple[tuple[Decimal, Decimal], ...]:
    out: list[tuple[Decimal, Decimal]] = []
    for idx, row in enumerate(raw):
        if not isinstance(row, (list, tuple)) or len(row) < 2:
            raise FullLiveExecutionFeasibilityMeasurementBlock(
                "INVALID_BOOK_LEVEL:" + label + ":" + str(idx)
            )
        out.append((_d(row[0], label + "_price"), _d(row[1], label + "_qty")))
    if not out:
        raise FullLiveExecutionFeasibilityMeasurementBlock(
            "EMPTY_BOOK_SIDE:" + label
        )
    prices = [p for p, _ in out]
    if label == "bids" and any(a <= b for a, b in zip(prices, prices[1:])):
        raise FullLiveExecutionFeasibilityMeasurementBlock("BIDS_NOT_STRICTLY_DESCENDING")
    if label == "asks" and any(a >= b for a, b in zip(prices, prices[1:])):
        raise FullLiveExecutionFeasibilityMeasurementBlock("ASKS_NOT_STRICTLY_ASCENDING")
    return tuple(out)


def measure_execution_feasibility(
    *,
    symbol: str,
    direction: str,
    intended_quote_notional: Any,
    order_book: Mapping[str, Any],
) -> ExecutionFeasibilityMeasurementV1:
    """Measure spread and market-order book consumption without policy judgment."""

    if not symbol:
        raise FullLiveExecutionFeasibilityMeasurementBlock("SYMBOL_REQUIRED")
    side = direction.upper()
    if side not in ("LONG", "SHORT"):
        raise FullLiveExecutionFeasibilityMeasurementBlock(
            "DIRECTION_INVALID:" + direction
        )
    target = _d(intended_quote_notional, "intended_quote_notional")
    if not isinstance(order_book, Mapping):
        raise FullLiveExecutionFeasibilityMeasurementBlock("ORDER_BOOK_REQUIRED")

    bids = _levels(order_book.get("bids", ()), "bids")
    asks = _levels(order_book.get("asks", ()), "asks")
    best_bid = bids[0][0]
    best_ask = asks[0][0]
    if best_ask <= best_bid:
        raise FullLiveExecutionFeasibilityMeasurementBlock(
            "CROSSED_OR_LOCKED_BOOK"
        )

    midpoint = (best_bid + best_ask) / Decimal("2")
    spread_bps = (best_ask - best_bid) / midpoint * Decimal("10000")

    consume = asks if side == "LONG" else bids
    best = best_ask if side == "LONG" else best_bid
    remaining = target
    quote_done = Decimal("0")
    base_done = Decimal("0")

    for price, qty in consume:
        level_quote = price * qty
        take_quote = min(remaining, level_quote)
        take_base = take_quote / price
        quote_done += take_quote
        base_done += take_base
        remaining -= take_quote
        if remaining <= 0:
            break

    full = remaining <= 0
    vwap = quote_done / base_done if base_done > 0 else None
    impact = None
    if vwap is not None:
        if side == "LONG":
            impact = (vwap - best) / best * Decimal("10000")
        else:
            impact = (best - vwap) / best * Decimal("10000")

    return ExecutionFeasibilityMeasurementV1(
        symbol=symbol,
        direction=side,
        intended_quote_notional=target,
        best_bid=best_bid,
        best_ask=best_ask,
        midpoint=midpoint,
        spread_bps=spread_bps,
        executable_quote_notional=quote_done,
        executable_base_quantity=base_done,
        vwap=vwap,
        impact_from_best_bps=impact,
        fully_fillable=full,
    )


def invariants() -> Mapping[str, Any]:
    return {
        "network_io": False,
        "exchange_io": False,
        "orders": 0,
        "fills": 0,
        "execution_intents": 0,
        "policy_thresholds_owned": False,
        "selector_added": False,
        "ranking_added": False,
        "historical_outcome_read": False,
        "pnl_read": False,
        "book_price_levels_strictly_monotonic": True,
    }


__all__ = [
    "FullLiveExecutionFeasibilityMeasurementBlock",
    "ExecutionFeasibilityMeasurementV1",
    "measure_execution_feasibility",
    "invariants",
]
