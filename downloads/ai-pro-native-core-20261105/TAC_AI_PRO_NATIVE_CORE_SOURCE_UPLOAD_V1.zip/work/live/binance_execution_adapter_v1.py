from __future__ import annotations

import json
import os
import subprocess
from dataclasses import dataclass
from decimal import Decimal
from typing import Any

from trade_ledger_v1 import LedgerEvent, TradeLedgerV1


class BinanceExecutionError(RuntimeError):
    pass


def entry_client_order_id(entry_ready_id: str) -> str:
    if not entry_ready_id:
        raise BinanceExecutionError("ENTRY_READY_ID_REQUIRED")
    return ("tac-" + entry_ready_id[:28]).replace("_", "-")


def hard_stop_client_algo_id(entry_ready_id: str) -> str:
    if not entry_ready_id:
        raise BinanceExecutionError("ENTRY_READY_ID_REQUIRED")
    return ("tac-stop-" + entry_ready_id[:23]).replace("_", "-")


def _parse_json_stdout(stdout: str) -> Any:
    text = stdout.strip()
    if not text:
        return None
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    for line in reversed(text.splitlines()):
        line = line.strip()
        if not line:
            continue
        try:
            return json.loads(line)
        except json.JSONDecodeError:
            continue
    return {"raw_stdout": text[-4000:]}


@dataclass(frozen=True)
class EntryRequest:
    symbol: str
    direction: str
    quantity: Decimal
    opportunity_id: str
    entry_ready_id: str
    cutoff: int
    hard_stop_price: Decimal


class BinanceCliExecutionAdapterV1:
    """Thin Binance CLI boundary for TAC_FULL_LIVE_V1.

    No strategy selection occurs here. This layer only executes an already
    admitted TAC entry, installs exchange-side hard protection, and can close
    that same strategy position when D6 requests an exit.
    """

    def __init__(self, ledger: TradeLedgerV1):
        self.ledger = ledger

    def _append_best_effort(self, event: LedgerEvent) -> bool:
        """Never let post-exchange audit logging change safety semantics."""
        try:
            self.ledger.append(event)
            return True
        except Exception:
            return False

    @staticmethod
    def _require_live_enabled() -> None:
        if os.environ.get("TAC_LIVE_ENABLED") != "1":
            raise BinanceExecutionError("LIVE_EXECUTION_DISABLED")

    @staticmethod
    def _run(args: list[str]) -> Any:
        p = subprocess.run(
            ["binance-cli", *args],
            text=True,
            capture_output=True,
            check=False,
        )
        if p.returncode != 0:
            detail = (p.stderr or p.stdout or "")[-3000:]
            raise BinanceExecutionError(
                "BINANCE_CLI_FAILURE:" + str(p.returncode) + ":" + detail
            )
        return _parse_json_stdout(p.stdout)

    @staticmethod
    def _side(direction: str) -> tuple[str, str, str]:
        d = direction.upper()
        if d == "LONG":
            return "BUY", "SELL", "LONG"
        if d == "SHORT":
            return "SELL", "BUY", "SHORT"
        raise BinanceExecutionError("UNSUPPORTED_DIRECTION:" + direction)

    def set_one_x_leverage(self, symbol: str) -> Any:
        self._require_live_enabled()
        return self._run([
            "futures-usds",
            "change-initial-leverage",
            "--symbol", symbol,
            "--leverage", "1",
        ])

    def position_snapshot(self, symbol: str) -> Any:
        return self._run([
            "futures-usds",
            "position-information-v3",
            "--symbol", symbol,
        ])

    def all_position_snapshots(self) -> Any:
        return self._run([
            "futures-usds",
            "position-information-v3",
        ])

    def query_algo_order_by_client_id(
        self,
        client_algo_id: str,
    ) -> Any:
        if not client_algo_id:
            raise BinanceExecutionError("CLIENT_ALGO_ID_REQUIRED")
        return self._run([
            "futures-usds",
            "query-algo-order",
            "--client-algo-id", client_algo_id,
        ])

    def server_time_snapshot(self) -> Any:
        return self._run([
            "futures-usds",
            "check-server-time",
        ])

    def account_snapshot(self) -> Any:
        """Signed Binance USD-M /fapi/v3/account, read-only; no trading flag."""
        return self._run([
            "futures-usds", "account-information-v3",
            "--recv-window", "5000",
        ])

    def multi_assets_mode_snapshot(self) -> Any:
        """Independent signed mode check; never switch margin mode."""
        return self._run([
            "futures-usds", "get-current-multi-assets-mode",
            "--recv-window", "5000",
        ])

    def open_orders(self, symbol: str | None = None) -> Any:
        args = ["futures-usds", "current-all-open-orders"]
        if symbol:
            args += ["--symbol", symbol]
        return self._run(args)

    def algo_open_orders(self) -> Any:
        return self._run([
            "futures-usds",
            "current-all-algo-open-orders",
        ])

    def cancel_algo_order_by_client_id(self, client_algo_id: str) -> Any:
        self._require_live_enabled()
        if not client_algo_id or not client_algo_id.startswith("tac-stop-"):
            raise BinanceExecutionError("EXACT_TAC_STOP_CLIENT_ID_REQUIRED")
        return self._run([
            "futures-usds",
            "cancel-algo-order",
            "--client-algo-id", client_algo_id,
        ])

    def cancel_all_algo_open_orders(self, symbol: str) -> Any:
        self._require_live_enabled()
        if not symbol:
            raise BinanceExecutionError("SYMBOL_REQUIRED")
        return self._run([
            "futures-usds",
            "cancel-all-algo-open-orders",
            "--symbol", symbol,
        ])

    def place_market_entry(self, request: EntryRequest) -> Any:
        self._require_live_enabled()
        entry_side, _, position_side = self._side(request.direction)
        client_id = entry_client_order_id(request.entry_ready_id)

        self.set_one_x_leverage(request.symbol)

        result = self._run([
            "futures-usds",
            "new-order",
            "--symbol", request.symbol,
            "--side", entry_side,
            "--position-side", position_side,
            "--type", "MARKET",
            "--quantity", str(request.quantity),
            "--new-order-resp-type", "RESULT",
            "--new-client-order-id", client_id,
        ])

        self._append_best_effort(LedgerEvent.build(
            "ORDER_SUBMITTED",
            symbol=request.symbol,
            data={
                "kind": "ENTRY_MARKET",
                "direction": request.direction,
                "position_side": position_side,
                "quantity": str(request.quantity),
                "client_order_id": client_id,
                "response": result,
            },
        ))
        return result

    def place_full_position_hard_stop(self, request: EntryRequest) -> Any:
        self._require_live_enabled()
        _, exit_side, position_side = self._side(request.direction)
        client_id = hard_stop_client_algo_id(request.entry_ready_id)

        result = self._run([
            "futures-usds",
            "new-algo-order",
            "--algo-type", "CONDITIONAL",
            "--symbol", request.symbol,
            "--side", exit_side,
            "--position-side", position_side,
            "--type", "STOP_MARKET",
            "--trigger-price", str(request.hard_stop_price),
            "--working-type", "MARK_PRICE",
            "--close-position", "true",
            "--price-protect", "true",
            "--client-algo-id", client_id,
        ])

        self._append_best_effort(LedgerEvent.build(
            "INITIAL_STOP_PLACED",
            symbol=request.symbol,
            data={
                "direction": request.direction,
                "position_side": position_side,
                "stop_price": str(request.hard_stop_price),
                "client_algo_id": client_id,
                "response": result,
            },
        ))
        return result

    def close_position_market(
        self,
        *,
        symbol: str,
        direction: str,
        quantity: Decimal,
        reason: str,
        reference_id: str,
    ) -> Any:
        self._require_live_enabled()
        _, exit_side, position_side = self._side(direction)
        client_id = ("tac-exit-" + reference_id[:23]).replace("_", "-")

        self._append_best_effort(LedgerEvent.build(
            "STRATEGY_EXIT_REQUESTED",
            symbol=symbol,
            data={
                "direction": direction,
                "position_side": position_side,
                "quantity": str(quantity),
                "reason": reason,
                "reference_id": reference_id,
            },
        ))

        result = self._run([
            "futures-usds",
            "new-order",
            "--symbol", symbol,
            "--side", exit_side,
            "--position-side", position_side,
            "--type", "MARKET",
            "--quantity", str(quantity),
            "--new-order-resp-type", "RESULT",
            "--new-client-order-id", client_id,
        ])

        self._append_best_effort(LedgerEvent.build(
            "ORDER_SUBMITTED",
            symbol=symbol,
            data={
                "kind": "EXIT_MARKET",
                "direction": direction,
                "position_side": position_side,
                "quantity": str(quantity),
                "reason": reason,
                "client_order_id": client_id,
                "response": result,
            },
        ))
        return result
