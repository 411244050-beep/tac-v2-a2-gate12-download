from __future__ import annotations

"""Typed fail-closed runtime enforcement for the eight user-authorized D5 slots.

This module owns no strategy admission, selector, ranking, or policy value.
It consumes the versioned frozen authority and current causal observations,
then composes all ten D5 slot PASS results together with the separately frozen
execution-feasibility enforcement evidence.

PORT_007 is a capacity tie-break only. Candidates that fail ordinary
per-trade/per-symbol/listing/execution gates are excluded before allocation.
For the remaining eligible simultaneous candidates, the frozen rotated
canonical-universe order is applied and portfolio/directional capacity admits
only a strict prefix with no skipping.
"""

from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
import hashlib
import json
from pathlib import Path
from types import MappingProxyType
from typing import Any, Mapping, Sequence

from binance_usdm_market_entry_legality_v1 import USDMarketEntryLegalityV1
from execution_uncertainty_latch_v1 import (
    ExecutionUncertaintyLatchBlock,
    ExecutionUncertaintyLatchV1,
)
from full_live_d5_operational_policy_v1 import (
    DEFAULT_AUTHORITY_PATH,
    FROZEN_STATUS,
    load_policy_authority,
)
from full_live_d5_risk_cap_candidate_v1 import CapitalBaseSnapshotV1
from full_live_execution_feasibility_enforcement_v1 import (
    ExecutionFeasibilityEnforcementV1,
)
from full_live_operational_enforcement_evidence_v1 import (
    OperationalEnforcementEvidenceV1,
    SlotEnforcementResultV1,
    compose_operational_enforcement_evidence,
)
from full_live_portfolio_policy_candidate_v1 import (
    AllocationCandidateV1,
    cutoff_rotated_canonical_order,
)
from full_live_pre_execution_policy_gate_v1 import (
    load_frozen_execution_feasibility_policy,
)
from full_live_structural_risk_accounting_v1 import PortfolioStructuralRiskV1


class RemainingD5PolicyEnforcementBlock(RuntimeError):
    pass


@dataclass(frozen=True)
class RemainingD5PolicyV1:
    per_trade_fraction: Decimal
    per_symbol_fraction: Decimal
    total_portfolio_fraction: Decimal
    same_direction_fraction: Decimal
    common_factor_policy: str
    common_factor_fraction: Decimal
    listing_policy: str
    kill_switch_mode: str
    port007_policy: str
    authority: str
    version: str
    authority_digest: str


@dataclass(frozen=True)
class OperationalCandidateV1:
    symbol: str
    direction: str
    entry_ready_id: str
    transaction_id: str
    information_cutoff: int
    authorized_quantity: Decimal
    per_unit_structural_risk: Decimal
    numeric_hard_stop: Decimal
    structural_risk_quote: Decimal
    legality: USDMarketEntryLegalityV1
    execution_enforcement: ExecutionFeasibilityEnforcementV1


@dataclass(frozen=True)
class OperationalExecutionBindingV1:
    symbol: str
    direction: str
    entry_ready_id: str
    information_cutoff: int
    authorized_quantity: Decimal
    per_unit_structural_risk: Decimal
    structural_risk_quote: Decimal
    numeric_hard_stop: Decimal
    legality_reference_price: Decimal
    rounded_quote_notional: Decimal
    execution_enforcement_id: str


@dataclass(frozen=True)
class FrozenOperationalBatchEnforcementV1:
    policy_version: str
    authority_digest: str
    batch_evidence_id: str
    information_cutoff: int
    ordered_preallocation_eligible_entry_ready_ids: tuple[str, ...]
    admitted_entry_ready_ids: tuple[str, ...]
    rejected_preallocation: Mapping[str, str]
    capacity_blocked_entry_ready_ids: tuple[str, ...]
    evidence_by_entry_ready_id: Mapping[str, OperationalEnforcementEvidenceV1]
    execution_binding_by_entry_ready_id: Mapping[str, OperationalExecutionBindingV1]

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "rejected_preallocation",
            MappingProxyType(dict(self.rejected_preallocation)),
        )
        object.__setattr__(
            self,
            "evidence_by_entry_ready_id",
            MappingProxyType(dict(self.evidence_by_entry_ready_id)),
        )
        object.__setattr__(
            self,
            "execution_binding_by_entry_ready_id",
            MappingProxyType(dict(self.execution_binding_by_entry_ready_id)),
        )


def _canonical(value: Any) -> str:
    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    )


def _digest(label: str, value: Any) -> str:
    return label + hashlib.sha256(_canonical(value).encode("utf-8")).hexdigest()


def _positive_decimal(value: Any, label: str) -> Decimal:
    try:
        out = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise RemainingD5PolicyEnforcementBlock(
            "INVALID_DECIMAL:" + label
        ) from exc
    if not out.is_finite() or out <= 0:
        raise RemainingD5PolicyEnforcementBlock(
            "NONPOSITIVE_DECIMAL:" + label
        )
    return out


def _fraction_slot(
    slots: Mapping[str, Any],
    name: str,
) -> Decimal:
    row = slots.get(name)
    if not isinstance(row, Mapping) or row.get("state") != "KNOWN":
        raise RemainingD5PolicyEnforcementBlock(
            "POLICY_SLOT_NOT_KNOWN:" + name
        )
    value = row.get("exact_value")
    if not isinstance(value, Mapping):
        raise RemainingD5PolicyEnforcementBlock(
            "POLICY_FRACTION_VALUE_MAPPING_REQUIRED:" + name
        )
    if value.get("denominator") != (
        "EXPLICIT_VERSIONED_CAPITAL_BASE_SNAPSHOT_V1"
    ):
        raise RemainingD5PolicyEnforcementBlock(
            "CAPITAL_DENOMINATOR_POLICY_DRIFT:" + name
        )
    fraction = _positive_decimal(value.get("fraction"), name)
    if fraction > 1:
        raise RemainingD5PolicyEnforcementBlock(
            "RISK_FRACTION_ABOVE_ONE:" + name
        )
    return fraction


def load_frozen_remaining_d5_policy(
    path: Path = DEFAULT_AUTHORITY_PATH,
) -> RemainingD5PolicyV1:
    authority = load_policy_authority(path)
    if authority.get("status") != FROZEN_STATUS:
        raise RemainingD5PolicyEnforcementBlock(
            "D5_OPERATIONAL_POLICY_NOT_FROZEN"
        )
    slots = authority.get("slots")
    if not isinstance(slots, Mapping):
        raise RemainingD5PolicyEnforcementBlock("D5_POLICY_SLOTS_REQUIRED")

    per_trade = _fraction_slot(slots, "per_trade_account_risk")
    per_symbol = _fraction_slot(slots, "per_symbol_risk_cap")
    total = _fraction_slot(slots, "total_portfolio_risk_cap")
    same_direction = _fraction_slot(
        slots,
        "same_direction_aggregate_cap",
    )

    common = slots.get("correlation_common_factor_budget")
    common_value = (
        common.get("exact_value")
        if isinstance(common, Mapping)
        else None
    )
    if (
        not isinstance(common, Mapping)
        or common.get("state") != "KNOWN"
        or not isinstance(common_value, Mapping)
        or common_value.get("factor_policy")
        != "SYSTEMIC_DIRECTION_EXPOSURE_V1"
        or common_value.get("budget_relationship")
        != "SAME_NUMERIC_CAP_AS_same_direction_aggregate_cap"
        or common_value.get("statistical_correlation_claim") is not False
        or common_value.get("historical_correlation_window") is not None
        or common_value.get("sector_taxonomy") is not None
    ):
        raise RemainingD5PolicyEnforcementBlock(
            "COMMON_FACTOR_POLICY_DRIFT"
        )
    common_fraction = _positive_decimal(
        common_value.get("cap_fraction"),
        "correlation_common_factor_budget",
    )
    if common_fraction != same_direction:
        raise RemainingD5PolicyEnforcementBlock(
            "COMMON_FACTOR_CAP_MUST_EQUAL_DIRECTION_CAP"
        )

    listing = slots.get("listing_liquidity_capacity_thresholds")
    listing_value = (
        listing.get("exact_value")
        if isinstance(listing, Mapping)
        else None
    )
    if (
        not isinstance(listing, Mapping)
        or listing.get("state") != "KNOWN"
        or not isinstance(listing_value, Mapping)
        or listing_value.get("policy")
        != "NO_LISTING_AGE_SELECTOR_CURRENT_EXCHANGE_LEGALITY_AND_80USDT_CAPACITY_V1"
        or listing_value.get("listing_age_numeric_threshold") is not None
        or listing_value.get("listing_age_role") != "AUDIT_ONLY"
    ):
        raise RemainingD5PolicyEnforcementBlock(
            "LISTING_LIQUIDITY_POLICY_DRIFT"
        )

    kill = slots.get("kill_switch_numeric_triggers")
    kill_value = (
        kill.get("exact_value")
        if isinstance(kill, Mapping)
        else None
    )
    if (
        not isinstance(kill, Mapping)
        or kill.get("state") != "KNOWN"
        or not isinstance(kill_value, Mapping)
        or kill_value.get("mode")
        != "NO_ADDITIONAL_NUMERIC_TRIGGER_EXISTING_EXECUTION_UNCERTAINTY_LATCH_ONLY"
        or kill_value.get("numeric_trigger") is not None
        or kill_value.get("window") is not None
        or kill_value.get("immediate_execution_uncertainty_latch") is not True
        or kill_value.get("latch_policy")
        != "IMMEDIATE_DURABLE_GLOBAL_EXECUTION_UNCERTAINTY_LATCH"
    ):
        raise RemainingD5PolicyEnforcementBlock(
            "KILL_SWITCH_POLICY_DRIFT"
        )

    port = slots.get("PORT_007_allocation_priority_policy")
    port_value = (
        port.get("exact_value")
        if isinstance(port, Mapping)
        else None
    )
    if (
        not isinstance(port, Mapping)
        or port.get("state") != "KNOWN"
        or not isinstance(port_value, Mapping)
        or port_value.get("policy")
        != "CUTOFF_ROTATED_FROZEN_CANONICAL_UNIVERSE_V1"
        or port_value.get("scarce_capacity")
        != "STRICT_ORDERED_PREFIX_NO_SKIP"
        or port_value.get("quality_ranking") is not False
        or port_value.get("signal_score") is not False
        or port_value.get("pnl") is not False
        or port_value.get("historical_performance") is not False
    ):
        raise RemainingD5PolicyEnforcementBlock(
            "PORT007_POLICY_DRIFT"
        )

    raw = Path(path).read_bytes()
    authority_name = str(authority.get("authority") or "")
    version = str(authority.get("version") or "")
    if not authority_name or not version:
        raise RemainingD5PolicyEnforcementBlock(
            "GLOBAL_POLICY_AUTHORITY_VERSION_REQUIRED"
        )

    return RemainingD5PolicyV1(
        per_trade_fraction=per_trade,
        per_symbol_fraction=per_symbol,
        total_portfolio_fraction=total,
        same_direction_fraction=same_direction,
        common_factor_policy=str(common_value["factor_policy"]),
        common_factor_fraction=common_fraction,
        listing_policy=str(listing_value["policy"]),
        kill_switch_mode=str(kill_value["mode"]),
        port007_policy=str(port_value["policy"]),
        authority=authority_name,
        version=version,
        authority_digest="SHA256:" + hashlib.sha256(raw).hexdigest(),
    )


def _validate_candidate(
    candidate: OperationalCandidateV1,
    *,
    execution_policy_version: str,
    execution_policy_digest: str,
) -> None:
    if not isinstance(candidate, OperationalCandidateV1):
        raise RemainingD5PolicyEnforcementBlock(
            "TYPED_OPERATIONAL_CANDIDATE_REQUIRED"
        )
    if not candidate.symbol or not candidate.entry_ready_id:
        raise RemainingD5PolicyEnforcementBlock(
            "CANDIDATE_SUBJECT_REQUIRED"
        )
    if not candidate.transaction_id:
        raise RemainingD5PolicyEnforcementBlock(
            "CANDIDATE_TRANSACTION_ID_REQUIRED"
        )
    if candidate.direction.upper() not in ("LONG", "SHORT"):
        raise RemainingD5PolicyEnforcementBlock(
            "CANDIDATE_DIRECTION_INVALID"
        )
    if (
        not isinstance(candidate.information_cutoff, int)
        or candidate.information_cutoff < 0
    ):
        raise RemainingD5PolicyEnforcementBlock(
            "CANDIDATE_CUTOFF_INVALID"
        )
    quantity = _positive_decimal(
        candidate.authorized_quantity,
        "candidate_authorized_quantity",
    )
    per_unit = _positive_decimal(
        candidate.per_unit_structural_risk,
        "candidate_per_unit_structural_risk",
    )
    numeric_stop = _positive_decimal(
        candidate.numeric_hard_stop,
        "candidate_numeric_hard_stop",
    )
    risk = _positive_decimal(
        candidate.structural_risk_quote,
        "candidate_structural_risk_quote",
    )
    if any(
        actual != expected
        for actual, expected in (
            (quantity, candidate.authorized_quantity),
            (per_unit, candidate.per_unit_structural_risk),
            (numeric_stop, candidate.numeric_hard_stop),
            (risk, candidate.structural_risk_quote),
        )
    ):
        raise RemainingD5PolicyEnforcementBlock(
            "CANDIDATE_EXECUTION_RISK_DECIMAL_REQUIRED"
        )
    if risk != quantity * per_unit:
        raise RemainingD5PolicyEnforcementBlock(
            "STRUCTURAL_RISK_QUANTITY_BINDING_DRIFT"
        )
    if not isinstance(candidate.legality, USDMarketEntryLegalityV1):
        raise RemainingD5PolicyEnforcementBlock(
            "TYPED_MARKET_ENTRY_LEGALITY_REQUIRED"
        )
    if candidate.legality.rounded_quantity != quantity:
        raise RemainingD5PolicyEnforcementBlock(
            "AUTHORIZED_QUANTITY_LEGALITY_DRIFT"
        )
    execution = candidate.execution_enforcement
    if not isinstance(execution, ExecutionFeasibilityEnforcementV1):
        raise RemainingD5PolicyEnforcementBlock(
            "TYPED_EXECUTION_ENFORCEMENT_REQUIRED"
        )
    subject = (
        execution.symbol,
        execution.direction.upper(),
        execution.entry_ready_id,
        execution.information_cutoff,
    )
    expected = (
        candidate.symbol,
        candidate.direction.upper(),
        candidate.entry_ready_id,
        candidate.information_cutoff,
    )
    if subject != expected:
        raise RemainingD5PolicyEnforcementBlock(
            "EXECUTION_ENFORCEMENT_SUBJECT_DRIFT"
        )
    if execution.policy_version != execution_policy_version:
        raise RemainingD5PolicyEnforcementBlock(
            "EXECUTION_POLICY_VERSION_DRIFT"
        )
    if execution.policy_authority_digest != execution_policy_digest:
        raise RemainingD5PolicyEnforcementBlock(
            "EXECUTION_POLICY_DIGEST_DRIFT"
        )


def recompute_batch_evidence_id(
    batch: FrozenOperationalBatchEnforcementV1,
) -> str:
    return _digest(
        "D5_OPERATIONAL_BATCH_ENFORCEMENT_SHA256:",
        {
            "policy_version": batch.policy_version,
            "authority_digest": batch.authority_digest,
            "information_cutoff": batch.information_cutoff,
            "ordered_preallocation_eligible_entry_ready_ids": list(
                batch.ordered_preallocation_eligible_entry_ready_ids
            ),
            "admitted_entry_ready_ids": list(
                batch.admitted_entry_ready_ids
            ),
            "rejected_preallocation": dict(
                batch.rejected_preallocation
            ),
            "capacity_blocked_entry_ready_ids": list(
                batch.capacity_blocked_entry_ready_ids
            ),
            "evidence_by_entry_ready_id": {
                key: value.evidence_id
                for key, value in sorted(
                    batch.evidence_by_entry_ready_id.items()
                )
            },
            "execution_binding_by_entry_ready_id": {
                key: {
                    "symbol": value.symbol,
                    "direction": value.direction,
                    "entry_ready_id": value.entry_ready_id,
                    "information_cutoff": value.information_cutoff,
                    "authorized_quantity": str(value.authorized_quantity),
                    "per_unit_structural_risk": str(
                        value.per_unit_structural_risk
                    ),
                    "structural_risk_quote": str(
                        value.structural_risk_quote
                    ),
                    "numeric_hard_stop": str(value.numeric_hard_stop),
                    "legality_reference_price": str(
                        value.legality_reference_price
                    ),
                    "rounded_quote_notional": str(
                        value.rounded_quote_notional
                    ),
                    "execution_enforcement_id": (
                        value.execution_enforcement_id
                    ),
                }
                for key, value in sorted(
                    batch.execution_binding_by_entry_ready_id.items()
                )
            },
        },
    )


def _result(
    *,
    state: str,
    mechanism: str,
    payload: Mapping[str, Any],
) -> SlotEnforcementResultV1:
    if state not in ("PASS", "FAIL"):
        raise RemainingD5PolicyEnforcementBlock(
            "SLOT_RESULT_STATE_INVALID"
        )
    return SlotEnforcementResultV1(
        state=state,
        evidence_id=_digest(
            "D5_SLOT_ENFORCEMENT_SHA256:",
            {
                "mechanism": mechanism,
                "state": state,
                "payload": dict(payload),
            },
        ),
        mechanism=mechanism,
    )


def enforce_frozen_operational_policy_batch(
    *,
    candidates: Sequence[OperationalCandidateV1],
    portfolio: PortfolioStructuralRiskV1,
    capital: CapitalBaseSnapshotV1,
    execution_uncertainty_latch: ExecutionUncertaintyLatchV1,
    frozen_universe: Sequence[str],
    policy_path: Path = DEFAULT_AUTHORITY_PATH,
) -> FrozenOperationalBatchEnforcementV1:
    """Enforce all ten D5 slots for one simultaneous candidate cutoff batch."""

    policy = load_frozen_remaining_d5_policy(policy_path)
    execution_policy = load_frozen_execution_feasibility_policy()

    if not isinstance(portfolio, PortfolioStructuralRiskV1):
        raise RemainingD5PolicyEnforcementBlock(
            "TYPED_PORTFOLIO_STRUCTURAL_RISK_REQUIRED"
        )
    if not isinstance(capital, CapitalBaseSnapshotV1):
        raise RemainingD5PolicyEnforcementBlock(
            "TYPED_VERSIONED_CAPITAL_SNAPSHOT_REQUIRED"
        )
    if not capital.authority or not capital.version or capital.as_of_ms <= 0:
        raise RemainingD5PolicyEnforcementBlock(
            "CAPITAL_SNAPSHOT_PROVENANCE_REQUIRED"
        )
    base = _positive_decimal(capital.capital_quote, "capital_quote")

    if not isinstance(
        execution_uncertainty_latch,
        ExecutionUncertaintyLatchV1,
    ):
        raise RemainingD5PolicyEnforcementBlock(
            "EXECUTION_UNCERTAINTY_LATCH_REQUIRED"
        )
    try:
        execution_uncertainty_latch.assert_new_risk_allowed()
    except ExecutionUncertaintyLatchBlock as exc:
        raise RemainingD5PolicyEnforcementBlock(
            "KILL_SWITCH_EXECUTION_UNCERTAINTY_LATCHED:" + str(exc)
        ) from exc

    universe = tuple(str(x) for x in frozen_universe)
    if len(universe) != 528 or len(set(universe)) != 528:
        raise RemainingD5PolicyEnforcementBlock(
            "FROZEN_CANONICAL_528_UNIVERSE_REQUIRED"
        )

    rows = tuple(candidates)
    if not rows:
        raise RemainingD5PolicyEnforcementBlock(
            "OPERATIONAL_CANDIDATE_BATCH_REQUIRED"
        )

    cutoffs = {row.information_cutoff for row in rows}
    if len(cutoffs) != 1:
        raise RemainingD5PolicyEnforcementBlock(
            "SIMULTANEOUS_CANDIDATES_MUST_SHARE_CUTOFF"
        )
    cutoff = next(iter(cutoffs))

    if len({row.entry_ready_id for row in rows}) != len(rows):
        raise RemainingD5PolicyEnforcementBlock(
            "DUPLICATE_ENTRY_READY_ID"
        )
    if len({row.transaction_id for row in rows}) != len(rows):
        raise RemainingD5PolicyEnforcementBlock(
            "DUPLICATE_TRANSACTION_ID"
        )
    if len({row.symbol for row in rows}) != len(rows):
        raise RemainingD5PolicyEnforcementBlock(
            "DUPLICATE_SIMULTANEOUS_SYMBOL_FORBIDDEN"
        )

    per_trade_cap = base * policy.per_trade_fraction
    per_symbol_cap = base * policy.per_symbol_fraction
    total_cap = base * policy.total_portfolio_fraction
    direction_cap = base * policy.same_direction_fraction
    factor_cap = base * policy.common_factor_fraction

    pre_pass: list[OperationalCandidateV1] = []
    rejected: dict[str, str] = {}
    pre_slot_results: dict[str, dict[str, SlotEnforcementResultV1]] = {}

    for row in rows:
        _validate_candidate(
            row,
            execution_policy_version=execution_policy.version,
            execution_policy_digest=execution_policy.authority_digest,
        )
        risk = row.structural_risk_quote
        existing_symbol = portfolio.per_symbol_risk_quote.get(
            row.symbol,
            Decimal("0"),
        )

        per_trade_pass = risk <= per_trade_cap
        per_symbol_pass = existing_symbol + risk <= per_symbol_cap
        execution_pass = (
            row.execution_enforcement.feasibility_state == "PASS"
            and row.execution_enforcement.execution_allowance_state == "PASS"
            and all(
                r.state == "PASS"
                for r in row.execution_enforcement.slot_results.values()
            )
        )
        listing_pass = (
            row.legality.status_trading
            and row.legality.exchange_legal
            and execution_pass
        )

        if not per_trade_pass:
            rejected[row.entry_ready_id] = "PER_TRADE_ACCOUNT_RISK_CAP"
            continue
        if not per_symbol_pass:
            rejected[row.entry_ready_id] = "PER_SYMBOL_RISK_CAP"
            continue
        if not listing_pass:
            rejected[row.entry_ready_id] = (
                "LISTING_LIQUIDITY_CAPACITY_POLICY"
            )
            continue

        pre_slot_results[row.entry_ready_id] = {
            "per_trade_account_risk": _result(
                state="PASS",
                mechanism="PER_TRADE_STRUCTURAL_RISK_CAP_V1",
                payload={
                    "symbol": row.symbol,
                    "entry_ready_id": row.entry_ready_id,
                    "risk_quote": str(risk),
                    "cap_quote": str(per_trade_cap),
                    "capital_authority": capital.authority,
                    "capital_version": capital.version,
                },
            ),
            "per_symbol_risk_cap": _result(
                state="PASS",
                mechanism="PER_SYMBOL_STRUCTURAL_RISK_CAP_V1",
                payload={
                    "symbol": row.symbol,
                    "entry_ready_id": row.entry_ready_id,
                    "existing_symbol_risk_quote": str(existing_symbol),
                    "candidate_risk_quote": str(risk),
                    "cap_quote": str(per_symbol_cap),
                },
            ),
            "listing_liquidity_capacity_thresholds": _result(
                state="PASS",
                mechanism=policy.listing_policy,
                payload={
                    "symbol": row.symbol,
                    "entry_ready_id": row.entry_ready_id,
                    "status_trading": row.legality.status_trading,
                    "exchange_legal": row.legality.exchange_legal,
                    "execution_enforcement_id": (
                        row.execution_enforcement.evidence_id
                    ),
                    "listing_age_numeric_threshold": None,
                },
            ),
            "kill_switch_numeric_triggers": _result(
                state="PASS",
                mechanism=policy.kill_switch_mode,
                payload={
                    "active_execution_uncertainty_latch": False,
                    "numeric_trigger": None,
                    "window": None,
                },
            ),
            **dict(row.execution_enforcement.slot_results),
        }
        pre_pass.append(row)

    order_input = tuple(
        AllocationCandidateV1(
            symbol=row.symbol,
            transaction_id=row.transaction_id,
            direction=row.direction,
        )
        for row in pre_pass
    )
    ordered_alloc = cutoff_rotated_canonical_order(
        order_input,
        frozen_universe=universe,
        information_cutoff=cutoff,
    )
    by_key = {
        (row.symbol, row.transaction_id): row
        for row in pre_pass
    }
    ordered = tuple(
        by_key[(item.symbol, item.transaction_id)]
        for item in ordered_alloc
    )

    total_running = portfolio.total_risk_quote
    long_running = portfolio.long_risk_quote
    short_running = portfolio.short_risk_quote
    evidence: dict[str, OperationalEnforcementEvidenceV1] = {}
    execution_bindings: dict[str, OperationalExecutionBindingV1] = {}
    admitted: list[str] = []
    capacity_blocked: list[str] = []

    for index, row in enumerate(ordered):
        risk = row.structural_risk_quote
        side = row.direction.upper()
        projected_total = total_running + risk
        current_side = long_running if side == "LONG" else short_running
        projected_side = current_side + risk

        total_pass = projected_total <= total_cap
        direction_pass = projected_side <= direction_cap
        factor_pass = projected_side <= factor_cap

        if not (total_pass and direction_pass and factor_pass):
            capacity_blocked.extend(
                candidate.entry_ready_id
                for candidate in ordered[index:]
            )
            break

        slots = dict(pre_slot_results[row.entry_ready_id])
        slots["total_portfolio_risk_cap"] = _result(
            state="PASS",
            mechanism="TOTAL_PORTFOLIO_STRUCTURAL_RISK_CAP_V1",
            payload={
                "projected_total_risk_quote": str(projected_total),
                "cap_quote": str(total_cap),
                "capital_authority": capital.authority,
                "capital_version": capital.version,
            },
        )
        slots["same_direction_aggregate_cap"] = _result(
            state="PASS",
            mechanism="SAME_DIRECTION_AGGREGATE_STRUCTURAL_RISK_CAP_V1",
            payload={
                "direction": side,
                "projected_direction_risk_quote": str(projected_side),
                "cap_quote": str(direction_cap),
            },
        )
        slots["correlation_common_factor_budget"] = _result(
            state="PASS",
            mechanism=policy.common_factor_policy,
            payload={
                "factor": "SYSTEMIC_DIRECTION_" + side,
                "projected_factor_risk_quote": str(projected_side),
                "cap_quote": str(factor_cap),
                "statistical_correlation_claim": False,
            },
        )
        slots["PORT_007_allocation_priority_policy"] = _result(
            state="PASS",
            mechanism=policy.port007_policy,
            payload={
                "information_cutoff": cutoff,
                "ordered_prefix_index": index,
                "symbol": row.symbol,
                "transaction_id": row.transaction_id,
                "strict_ordered_prefix_no_skip": True,
            },
        )

        composed = compose_operational_enforcement_evidence(
            slots,
            symbol=row.symbol,
            entry_ready_id=row.entry_ready_id,
            information_cutoff=row.information_cutoff,
        )
        evidence[row.entry_ready_id] = composed
        execution_bindings[row.entry_ready_id] = OperationalExecutionBindingV1(
            symbol=row.symbol,
            direction=row.direction.upper(),
            entry_ready_id=row.entry_ready_id,
            information_cutoff=row.information_cutoff,
            authorized_quantity=row.authorized_quantity,
            per_unit_structural_risk=row.per_unit_structural_risk,
            structural_risk_quote=row.structural_risk_quote,
            numeric_hard_stop=row.numeric_hard_stop,
            legality_reference_price=row.legality.reference_price,
            rounded_quote_notional=row.legality.rounded_quote_notional,
            execution_enforcement_id=row.execution_enforcement.evidence_id,
        )
        admitted.append(row.entry_ready_id)

        total_running = projected_total
        if side == "LONG":
            long_running = projected_side
        else:
            short_running = projected_side

    provisional = FrozenOperationalBatchEnforcementV1(
        policy_version=policy.version,
        authority_digest=policy.authority_digest,
        batch_evidence_id="PENDING",
        information_cutoff=cutoff,
        ordered_preallocation_eligible_entry_ready_ids=tuple(
            row.entry_ready_id for row in ordered
        ),
        admitted_entry_ready_ids=tuple(admitted),
        rejected_preallocation=dict(sorted(rejected.items())),
        capacity_blocked_entry_ready_ids=tuple(capacity_blocked),
        evidence_by_entry_ready_id=evidence,
        execution_binding_by_entry_ready_id=execution_bindings,
    )
    return FrozenOperationalBatchEnforcementV1(
        policy_version=provisional.policy_version,
        authority_digest=provisional.authority_digest,
        batch_evidence_id=recompute_batch_evidence_id(provisional),
        information_cutoff=provisional.information_cutoff,
        ordered_preallocation_eligible_entry_ready_ids=(
            provisional.ordered_preallocation_eligible_entry_ready_ids
        ),
        admitted_entry_ready_ids=provisional.admitted_entry_ready_ids,
        rejected_preallocation=provisional.rejected_preallocation,
        capacity_blocked_entry_ready_ids=(
            provisional.capacity_blocked_entry_ready_ids
        ),
        evidence_by_entry_ready_id=provisional.evidence_by_entry_ready_id,
        execution_binding_by_entry_ready_id=(
            provisional.execution_binding_by_entry_ready_id
        ),
    )


def invariants() -> Mapping[str, Any]:
    return {
        "policy_values_selected_here": False,
        "frozen_policy_required": True,
        "versioned_capital_snapshot_required": True,
        "unrealized_pnl_used": False,
        "live_mark_to_market_equity_used": False,
        "listing_age_selector_added": False,
        "statistical_correlation_model_added": False,
        "historical_correlation_window_added": False,
        "kill_switch_numeric_trigger_added": False,
        "existing_execution_uncertainty_latch_required_clear": True,
        "port007_capacity_order": (
            "CUTOFF_ROTATED_FROZEN_CANONICAL_UNIVERSE_V1"
        ),
        "port007_strict_prefix_no_skip": True,
        "signal_quality_ranking": False,
        "pnl_ranking": False,
        "historical_performance_ranking": False,
        "all_ten_slot_pass_evidence_composed": True,
        "authorized_quantity_bound_to_legality": True,
        "structural_risk_bound_to_authorized_quantity": True,
        "execution_binding_in_batch_digest": True,
        "update014_semantics_changed": False,
        "orders": 0,
        "fills": 0,
        "execution_intents": 0,
        "trading_activated": False,
    }


__all__ = [
    "RemainingD5PolicyEnforcementBlock",
    "RemainingD5PolicyV1",
    "OperationalCandidateV1",
    "OperationalExecutionBindingV1",
    "FrozenOperationalBatchEnforcementV1",
    "load_frozen_remaining_d5_policy",
    "recompute_batch_evidence_id",
    "enforce_frozen_operational_policy_batch",
    "invariants",
]
