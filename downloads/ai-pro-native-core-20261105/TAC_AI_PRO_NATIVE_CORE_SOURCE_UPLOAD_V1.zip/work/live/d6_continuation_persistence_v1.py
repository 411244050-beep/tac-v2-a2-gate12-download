from __future__ import annotations

import hashlib
from dataclasses import dataclass
from typing import Any, Iterable, Mapping

from d6_snapshot_envelope_v1 import decode_d6_position_snapshot
from d6_snapshot_ledger_v1 import (
    D6SnapshotLedgerBlock,
    build_d6_snapshot_ledger_event,
)
from strategy_rc1.d6_position_execution.types import StrategyPositionSnapshot
from trade_ledger_v1 import LedgerEvent, TradeLedgerV1


class D6ContinuationPersistenceBlock(RuntimeError):
    pass


@dataclass(frozen=True)
class D6ContinuationPersistenceResultV1:
    snapshot_event: LedgerEvent
    continuation_event: LedgerEvent
    write_order: tuple[str, str]


@dataclass(frozen=True)
class D6CommittedSnapshotRecoveryV1:
    snapshot: StrategyPositionSnapshot
    snapshot_event_id: str
    snapshot_event_time_ms: int
    envelope_sha256: str
    initial_snapshot_event_id: str
    initial_snapshot_event_time_ms: int
    continuation_event_ids: tuple[str, ...]
    continuation_count: int


def persist_d6_continuation_snapshot_first(
    *,
    ledger: TradeLedgerV1,
    previous_snapshot_event_id: str,
    snapshot: StrategyPositionSnapshot,
    entry_ready_id: str,
    information_cutoff: int,
    update_step: str,
    mode_text: str,
    structural_reference_advanced: bool,
    new_risk_blocked: bool,
    snapshot_event_time_ms: int | None = None,
    continuation_event_time_ms: int | None = None,
) -> D6ContinuationPersistenceResultV1:
    if not previous_snapshot_event_id:
        raise D6ContinuationPersistenceBlock(
            "PREVIOUS_SNAPSHOT_EVENT_ID_REQUIRED"
        )
    if not isinstance(snapshot, StrategyPositionSnapshot):
        raise D6ContinuationPersistenceBlock(
            "STRATEGY_POSITION_SNAPSHOT_REQUIRED"
        )
    if not entry_ready_id:
        raise D6ContinuationPersistenceBlock(
            "ENTRY_READY_ID_REQUIRED"
        )
    try:
        cutoff = int(information_cutoff)
    except Exception as exc:
        raise D6ContinuationPersistenceBlock(
            "INFORMATION_CUTOFF_INVALID"
        ) from exc
    if cutoff <= 0:
        raise D6ContinuationPersistenceBlock(
            "INFORMATION_CUTOFF_NONPOSITIVE"
        )
    if not update_step:
        raise D6ContinuationPersistenceBlock(
            "UPDATE_STEP_REQUIRED"
        )
    if not mode_text:
        raise D6ContinuationPersistenceBlock(
            "MODE_TEXT_REQUIRED"
        )

    position_id = str(getattr(snapshot, "position_id", "") or "")
    entry = getattr(snapshot, "entry", None)
    symbol = str(getattr(entry, "symbol", "") or "")
    snapshot_entry_ready_id = str(
        getattr(entry, "entry_ready_id", "") or ""
    )
    if not position_id or not symbol:
        raise D6ContinuationPersistenceBlock(
            "D6_CONTINUATION_IDENTITY_INCOMPLETE"
        )
    if snapshot_entry_ready_id != entry_ready_id:
        raise D6ContinuationPersistenceBlock(
            "D6_CONTINUATION_ENTRY_READY_ID_DRIFT"
        )
    if getattr(snapshot, "closed_exit_id", None) is not None:
        raise D6ContinuationPersistenceBlock(
            "CLOSED_SNAPSHOT_CANNOT_CONTINUE"
        )

    snapshot_event = build_d6_snapshot_ledger_event(
        snapshot=snapshot,
        entry_ready_id=entry_ready_id,
        event_time_ms=snapshot_event_time_ms,
    )
    continuation_event = LedgerEvent.build(
        "D6_POSITION_CONTINUED",
        symbol=symbol,
        event_time_ms=continuation_event_time_ms,
        data={
            "position_id": position_id,
            "entry_ready_id": entry_ready_id,
            "previous_snapshot_event_id": previous_snapshot_event_id,
            "snapshot_event_id": snapshot_event.event_id,
            "information_cutoff": cutoff,
            "update_step": str(update_step),
            "mode_text": str(mode_text),
            "structural_reference_advanced": bool(
                structural_reference_advanced
            ),
            "new_risk_blocked": bool(new_risk_blocked),
        },
    )

    try:
        ledger.append(snapshot_event)
    except Exception as exc:
        raise D6ContinuationPersistenceBlock(
            "D6_CONTINUATION_SNAPSHOT_APPEND_FAILED:"
            + exc.__class__.__name__
            + ":"
            + str(exc)
        ) from exc

    try:
        ledger.append(continuation_event)
    except Exception as exc:
        raise D6ContinuationPersistenceBlock(
            "D6_CONTINUATION_COMMIT_APPEND_FAILED_AFTER_SNAPSHOT_DURABLE:"
            + exc.__class__.__name__
            + ":"
            + str(exc)
        ) from exc

    return D6ContinuationPersistenceResultV1(
        snapshot_event=snapshot_event,
        continuation_event=continuation_event,
        write_order=(
            "D6_POSITION_SNAPSHOT",
            "D6_POSITION_CONTINUED",
        ),
    )


def _snapshot_event_by_id(
    rows: tuple[Mapping[str, Any], ...],
    *,
    event_id: str,
    symbol: str,
    position_id: str,
    entry_ready_id: str,
) -> tuple[StrategyPositionSnapshot, int, str]:
    matches = [
        row
        for row in rows
        if row.get("event_type") == "D6_POSITION_SNAPSHOT"
        and str(row.get("event_id", "")) == event_id
    ]
    if len(matches) != 1:
        raise D6ContinuationPersistenceBlock(
            "D6_SNAPSHOT_EVENT_ID_NOT_UNIQUE:" + event_id
        )

    row = matches[0]
    if str(row.get("symbol", "")) != symbol:
        raise D6ContinuationPersistenceBlock(
            "D6_SNAPSHOT_EVENT_SYMBOL_DRIFT:" + event_id
        )
    data = row.get("data")
    if not isinstance(data, Mapping):
        raise D6ContinuationPersistenceBlock(
            "D6_SNAPSHOT_EVENT_DATA_INVALID:" + event_id
        )

    expected_fields = {
        "position_id",
        "entry_ready_id",
        "snapshot_envelope",
        "snapshot_envelope_sha256",
    }
    if set(data) != expected_fields:
        raise D6ContinuationPersistenceBlock(
            "D6_SNAPSHOT_EVENT_FIELD_DRIFT:" + event_id
        )
    if str(data.get("position_id", "")) != position_id:
        raise D6ContinuationPersistenceBlock(
            "D6_SNAPSHOT_EVENT_POSITION_ID_DRIFT:" + event_id
        )
    if str(data.get("entry_ready_id", "")) != entry_ready_id:
        raise D6ContinuationPersistenceBlock(
            "D6_SNAPSHOT_EVENT_ENTRY_READY_ID_DRIFT:" + event_id
        )

    envelope_text = data.get("snapshot_envelope")
    envelope_sha256 = str(
        data.get("snapshot_envelope_sha256", "")
    )
    if not isinstance(envelope_text, str) or not envelope_text:
        raise D6ContinuationPersistenceBlock(
            "D6_SNAPSHOT_EVENT_ENVELOPE_REQUIRED:" + event_id
        )
    actual = hashlib.sha256(
        envelope_text.encode("utf-8")
    ).hexdigest()
    if actual != envelope_sha256:
        raise D6ContinuationPersistenceBlock(
            "D6_SNAPSHOT_EVENT_OUTER_DIGEST_MISMATCH:" + event_id
        )

    try:
        snapshot = decode_d6_position_snapshot(envelope_text)
    except Exception as exc:
        raise D6ContinuationPersistenceBlock(
            "D6_SNAPSHOT_EVENT_DECODE_FAILED:"
            + event_id
            + ":"
            + exc.__class__.__name__
            + ":"
            + str(exc)
        ) from exc

    if str(getattr(snapshot, "position_id", "") or "") != position_id:
        raise D6ContinuationPersistenceBlock(
            "D6_SNAPSHOT_DECODED_POSITION_ID_DRIFT:" + event_id
        )
    entry = getattr(snapshot, "entry", None)
    if str(getattr(entry, "entry_ready_id", "") or "") != entry_ready_id:
        raise D6ContinuationPersistenceBlock(
            "D6_SNAPSHOT_DECODED_ENTRY_READY_ID_DRIFT:" + event_id
        )
    if str(getattr(entry, "symbol", "") or "") != symbol:
        raise D6ContinuationPersistenceBlock(
            "D6_SNAPSHOT_DECODED_SYMBOL_DRIFT:" + event_id
        )

    try:
        event_time_ms = int(row.get("event_time_ms"))
    except Exception as exc:
        raise D6ContinuationPersistenceBlock(
            "D6_SNAPSHOT_EVENT_TIME_INVALID:" + event_id
        ) from exc

    return snapshot, event_time_ms, envelope_sha256


def recover_latest_committed_d6_snapshot(
    *,
    ledger_rows: Iterable[Mapping[str, Any]],
    symbol: str,
    position_id: str,
    entry_ready_id: str,
    initial_snapshot_event_id: str,
) -> D6CommittedSnapshotRecoveryV1:
    if not all(
        (symbol, position_id, entry_ready_id, initial_snapshot_event_id)
    ):
        raise D6ContinuationPersistenceBlock(
            "D6_COMMITTED_RECOVERY_IDENTITY_REQUIRED"
        )

    rows = tuple(ledger_rows)
    _, initial_snapshot_time, _ = _snapshot_event_by_id(
        rows,
        event_id=initial_snapshot_event_id,
        symbol=symbol,
        position_id=position_id,
        entry_ready_id=entry_ready_id,
    )
    current_snapshot_id = initial_snapshot_event_id
    continuation_event_ids: list[str] = []
    last_continuation_time = -1
    seen_snapshot_ids = {initial_snapshot_event_id}

    relevant = [
        row
        for row in rows
        if row.get("event_type") == "D6_POSITION_CONTINUED"
        and str(row.get("symbol", "")) == symbol
    ]

    while True:
        candidates: list[Mapping[str, Any]] = []
        for row in relevant:
            data = row.get("data")
            if not isinstance(data, Mapping):
                raise D6ContinuationPersistenceBlock(
                    "D6_CONTINUATION_EVENT_DATA_INVALID"
                )
            if str(data.get("position_id", "")) != position_id:
                continue
            if str(data.get("entry_ready_id", "")) != entry_ready_id:
                continue
            if str(data.get("previous_snapshot_event_id", "")) == (
                current_snapshot_id
            ):
                candidates.append(row)

        if not candidates:
            break
        if len(candidates) != 1:
            raise D6ContinuationPersistenceBlock(
                "D6_CONTINUATION_LINEAGE_FORK:"
                + current_snapshot_id
            )

        row = candidates[0]
        data = row["data"]
        next_snapshot_id = str(data.get("snapshot_event_id", ""))
        if not next_snapshot_id:
            raise D6ContinuationPersistenceBlock(
                "D6_CONTINUATION_SNAPSHOT_EVENT_ID_REQUIRED"
            )
        if next_snapshot_id in seen_snapshot_ids:
            raise D6ContinuationPersistenceBlock(
                "D6_CONTINUATION_LINEAGE_CYCLE:"
                + next_snapshot_id
            )

        event_id = str(row.get("event_id", "") or "")
        if not event_id:
            raise D6ContinuationPersistenceBlock(
                "D6_CONTINUATION_EVENT_ID_REQUIRED"
            )
        try:
            event_time = int(row.get("event_time_ms"))
        except Exception as exc:
            raise D6ContinuationPersistenceBlock(
                "D6_CONTINUATION_EVENT_TIME_INVALID"
            ) from exc

        snapshot, snapshot_time, _ = _snapshot_event_by_id(
            rows,
            event_id=next_snapshot_id,
            symbol=symbol,
            position_id=position_id,
            entry_ready_id=entry_ready_id,
        )
        if snapshot_time > event_time:
            raise D6ContinuationPersistenceBlock(
                "D6_CONTINUATION_SNAPSHOT_MUST_PRECEDE_COMMIT:"
                + event_id
            )
        if event_time < last_continuation_time:
            raise D6ContinuationPersistenceBlock(
                "D6_CONTINUATION_EVENT_TIME_REGRESSION"
            )

        current_snapshot_id = next_snapshot_id
        seen_snapshot_ids.add(next_snapshot_id)
        continuation_event_ids.append(event_id)
        last_continuation_time = event_time

    # Reject committed continuation events for the same identity that are not
    # reachable from the activation snapshot.  This catches gaps/orphans.
    reachable = set(continuation_event_ids)
    for row in relevant:
        data = row.get("data")
        if not isinstance(data, Mapping):
            continue
        if str(data.get("position_id", "")) != position_id:
            continue
        if str(data.get("entry_ready_id", "")) != entry_ready_id:
            continue
        event_id = str(row.get("event_id", "") or "")
        if event_id not in reachable:
            raise D6ContinuationPersistenceBlock(
                "D6_CONTINUATION_LINEAGE_ORPHAN:" + event_id
            )

    snapshot, snapshot_time, envelope_sha256 = _snapshot_event_by_id(
        rows,
        event_id=current_snapshot_id,
        symbol=symbol,
        position_id=position_id,
        entry_ready_id=entry_ready_id,
    )

    return D6CommittedSnapshotRecoveryV1(
        snapshot=snapshot,
        snapshot_event_id=current_snapshot_id,
        snapshot_event_time_ms=snapshot_time,
        envelope_sha256=envelope_sha256,
        initial_snapshot_event_id=initial_snapshot_event_id,
        initial_snapshot_event_time_ms=initial_snapshot_time,
        continuation_event_ids=tuple(continuation_event_ids),
        continuation_count=len(continuation_event_ids),
    )


__all__ = [
    "D6ContinuationPersistenceBlock",
    "D6ContinuationPersistenceResultV1",
    "D6CommittedSnapshotRecoveryV1",
    "persist_d6_continuation_snapshot_first",
    "recover_latest_committed_d6_snapshot",
]
