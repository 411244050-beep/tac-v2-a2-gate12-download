from __future__ import annotations

import dataclasses
import json
import os
from decimal import Decimal
from pathlib import Path
from typing import Any, Mapping

from strategy_rc1.parameter_snapshot import (
    ParameterSlot,
    ParameterSnapshot,
    ParameterState,
)


class ExperimentalOperationalSnapshotBlock(RuntimeError):
    pass


SNAPSHOT_PATH = (
    Path(__file__).resolve().parent
    / "experimental_operational_parameter_snapshot_v1.json"
)


def load_operational_parameters() -> Mapping[str, Decimal]:
    if os.environ.get(
        "TAC_LIVE_ALLOW_EXPERIMENTAL_PARAMETER_SNAPSHOT"
    ) != "1":
        raise ExperimentalOperationalSnapshotBlock(
            "EXPERIMENTAL_OPERATIONAL_PARAMETER_SNAPSHOT_NOT_AUTHORIZED"
        )

    payload = json.loads(SNAPSHOT_PATH.read_text(encoding="utf-8"))

    if payload.get("scientific_complete") is not False:
        raise ExperimentalOperationalSnapshotBlock(
            "SCIENTIFIC_COMPLETENESS_MUST_REMAIN_FALSE"
        )
    if payload.get("operational_complete_for_live_overlay") is not True:
        raise ExperimentalOperationalSnapshotBlock(
            "OPERATIONAL_SNAPSHOT_NOT_COMPLETE"
        )

    params = payload.get("parameters") or {}
    required = {
        "theta_minor",
        "theta_intermediate",
        "theta_major",
        "theta_progress",
        "theta_rate",
        "theta_test",
        "theta_approach",
        "theta_separation",
        "theta_accept",
        "theta_overextension",
        "theta_stop",
    }
    if set(params) != required:
        raise ExperimentalOperationalSnapshotBlock(
            "PARAMETER_SET_MISMATCH"
        )

    out = {
        name: Decimal(str(row["value"]))
        for name, row in params.items()
    }

    if any(value <= 0 for value in out.values()):
        raise ExperimentalOperationalSnapshotBlock(
            "NONPOSITIVE_OPERATIONAL_PARAMETER"
        )
    if not (
        out["theta_test"]
        < out["theta_approach"]
        < out["theta_separation"]
    ):
        raise ExperimentalOperationalSnapshotBlock(
            "B3_PARAMETER_ORDERING_INVALID"
        )
    if not (
        out["theta_minor"]
        < out["theta_intermediate"]
        < out["theta_major"]
    ):
        raise ExperimentalOperationalSnapshotBlock(
            "STRUCTURAL_SCALE_ORDERING_INVALID"
        )

    return out


def _required_without_default(cls: type[Any]) -> set[str]:
    out = set()
    for f in dataclasses.fields(cls):
        if (
            f.default is dataclasses.MISSING
            and f.default_factory is dataclasses.MISSING
        ):
            out.add(f.name)
    return out


def _build_native_slot(name: str, value: Decimal) -> ParameterSlot:
    if not dataclasses.is_dataclass(ParameterSlot):
        raise ExperimentalOperationalSnapshotBlock(
            "PARAMETER_SLOT_NOT_DATACLASS"
        )

    field_names = {f.name for f in dataclasses.fields(ParameterSlot)}
    required = _required_without_default(ParameterSlot)

    if "state" not in field_names or "exact_value" not in field_names:
        raise ExperimentalOperationalSnapshotBlock(
            "PARAMETER_SLOT_CONTRACT_DRIFT"
        )

    kwargs: dict[str, Any] = {
        "state": ParameterState.FROZEN,
        "exact_value": value,
    }

    # Some versions key the slot only by the outer mapping, while others also
    # carry the parameter identifier inside the slot. Support only explicit,
    # semantically equivalent names and fail closed for anything else.
    id_fields = [
        f for f in (
            "parameter_id",
            "parameter_name",
            "name",
            "slot_id",
        )
        if f in field_names
    ]
    if len(id_fields) > 1:
        raise ExperimentalOperationalSnapshotBlock(
            "PARAMETER_SLOT_AMBIGUOUS_ID_FIELDS:"
            + ",".join(id_fields)
        )
    if id_fields:
        kwargs[id_fields[0]] = name

    missing_required = required - set(kwargs)
    if missing_required:
        raise ExperimentalOperationalSnapshotBlock(
            "PARAMETER_SLOT_UNRESOLVED_REQUIRED_FIELDS:"
            + ",".join(sorted(missing_required))
        )

    try:
        slot = ParameterSlot(**kwargs)
    except Exception as exc:
        raise ExperimentalOperationalSnapshotBlock(
            "PARAMETER_SLOT_CONSTRUCTION_FAILED:"
            + name
            + ":"
            + exc.__class__.__name__
            + ":"
            + str(exc)
        ) from exc

    if slot.state is not ParameterState.FROZEN:
        raise ExperimentalOperationalSnapshotBlock(
            "PARAMETER_SLOT_NOT_FROZEN:" + name
        )
    if Decimal(str(slot.exact_value)) != value:
        raise ExperimentalOperationalSnapshotBlock(
            "PARAMETER_SLOT_VALUE_DRIFT:" + name
        )
    return slot


def build_native_operational_snapshot() -> ParameterSnapshot:
    """Create a native runtime-usable ParameterSnapshot for full-live only.

    This does not modify current_partial_parameter_snapshot() and does not
    relabel the historical research snapshot as scientifically complete.
    """
    params = load_operational_parameters()
    slots = {
        name: _build_native_slot(name, value)
        for name, value in sorted(params.items())
    }

    try:
        snapshot = ParameterSnapshot(
            snapshot_id="TAC_FULL_LIVE_EXP_OPS_V1",
            slots=slots,
            complete_strategy_parameter_snapshot=True,
            runtime_usable=True,
            source_status=(
                "FULL_LIVE_EXPERIMENTAL_OPERATIONAL_SNAPSHOT_"
                "NOT_SCIENTIFICALLY_COMPLETE"
            ),
        )
    except Exception as exc:
        raise ExperimentalOperationalSnapshotBlock(
            "PARAMETER_SNAPSHOT_CONSTRUCTION_FAILED:"
            + exc.__class__.__name__
            + ":"
            + str(exc)
        ) from exc

    if snapshot.complete_strategy_parameter_snapshot is not True:
        raise ExperimentalOperationalSnapshotBlock(
            "NATIVE_SNAPSHOT_NOT_COMPLETE"
        )
    if snapshot.runtime_usable is not True:
        raise ExperimentalOperationalSnapshotBlock(
            "NATIVE_SNAPSHOT_NOT_RUNTIME_USABLE"
        )
    if snapshot.frozen_count != len(slots):
        raise ExperimentalOperationalSnapshotBlock(
            "NATIVE_SNAPSHOT_FROZEN_COUNT_MISMATCH"
        )

    for name, expected in params.items():
        slot = snapshot.slot(name)
        if slot.state is not ParameterState.FROZEN:
            raise ExperimentalOperationalSnapshotBlock(
                "NATIVE_SNAPSHOT_SLOT_NOT_FROZEN:" + name
            )
        if Decimal(str(slot.exact_value)) != expected:
            raise ExperimentalOperationalSnapshotBlock(
                "NATIVE_SNAPSHOT_SLOT_VALUE_DRIFT:" + name
            )

    return snapshot
