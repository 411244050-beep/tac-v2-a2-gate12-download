from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Mapping

from full_live_d5_operational_policy_v1 import (
    DEFAULT_AUTHORITY_PATH,
    FROZEN_STATUS,
    build_operational_input_set,
    load_policy_authority,
)
from full_live_operational_entry_authorization_v1 import (
    OperationalEntryAuthorizationV1,
    PRODUCTION_ISSUER,
)
from full_live_operational_enforcement_evidence_v1 import (
    OperationalEnforcementEvidenceV1,
)
from full_live_remaining_d5_policy_enforcement_v1 import (
    FrozenOperationalBatchEnforcementV1,
    OperationalExecutionBindingV1,
    recompute_batch_evidence_id,
)


class ProductionOperationalAuthorizationBlock(RuntimeError):
    pass


def _enforcement_subject_digest(
    *,
    evidence_id: str,
    symbol: str,
    entry_ready_id: str,
    information_cutoff: int,
) -> str:
    canonical = json.dumps(
        {
            "evidence_id": evidence_id,
            "subject": {
                "symbol": symbol,
                "entry_ready_id": entry_ready_id,
                "information_cutoff": information_cutoff,
            },
        },
        sort_keys=True,
        separators=(",", ":"),
    )
    return "SHA256:" + hashlib.sha256(canonical.encode()).hexdigest()


def _execution_binding_digest(
    *,
    binding: OperationalExecutionBindingV1,
    batch_evidence_id: str,
) -> str:
    canonical = json.dumps(
        {
            "batch_evidence_id": batch_evidence_id,
            "symbol": binding.symbol,
            "direction": binding.direction,
            "entry_ready_id": binding.entry_ready_id,
            "information_cutoff": binding.information_cutoff,
            "authorized_quantity": str(binding.authorized_quantity),
            "per_unit_structural_risk": str(
                binding.per_unit_structural_risk
            ),
            "structural_risk_quote": str(
                binding.structural_risk_quote
            ),
            "numeric_hard_stop": str(binding.numeric_hard_stop),
            "legality_reference_price": str(
                binding.legality_reference_price
            ),
            "rounded_quote_notional": str(
                binding.rounded_quote_notional
            ),
            "execution_enforcement_id": (
                binding.execution_enforcement_id
            ),
        },
        sort_keys=True,
        separators=(",", ":"),
    )
    return (
        "ENTRY_EXECUTION_BINDING_SHA256:"
        + hashlib.sha256(canonical.encode()).hexdigest()
    )


def _validated_frozen_authority(
    path: Path,
) -> tuple[dict, str]:
    authority = dict(load_policy_authority(path))
    if authority.get("status") != FROZEN_STATUS:
        raise ProductionOperationalAuthorizationBlock(
            "POLICY_AUTHORITY_NOT_FROZEN"
        )
    # Reuse exact ten-slot KNOWN/value/authority/version validation.
    build_operational_input_set(path)
    slots = authority.get("slots")
    if not isinstance(slots, dict):
        raise ProductionOperationalAuthorizationBlock(
            "AUTHORITY_SLOTS_REQUIRED"
        )
    digest = hashlib.sha256(Path(path).read_bytes()).hexdigest()
    return authority, digest


def _build_subject_bound_token(
    *,
    evidence: OperationalEnforcementEvidenceV1,
    execution_binding: OperationalExecutionBindingV1,
    batch_evidence_id: str,
    authority: Mapping[str, object],
    authority_digest: str,
) -> OperationalEntryAuthorizationV1:
    slots = authority.get("slots")
    if not isinstance(slots, dict):
        raise ProductionOperationalAuthorizationBlock(
            "AUTHORITY_SLOTS_REQUIRED"
        )
    names = set(slots)
    if set(evidence.slot_results) != names:
        raise ProductionOperationalAuthorizationBlock(
            "ENFORCEMENT_EVIDENCE_SLOT_SET_DRIFT"
        )
    failed = sorted(
        k for k, v in evidence.slot_results.items() if v != "PASS"
    )
    if failed:
        raise ProductionOperationalAuthorizationBlock(
            "ENFORCEMENT_NOT_PASS:" + ",".join(failed)
        )
    if not evidence.evidence_id:
        raise ProductionOperationalAuthorizationBlock(
            "EVIDENCE_ID_REQUIRED"
        )
    if not evidence.symbol or not evidence.entry_ready_id:
        raise ProductionOperationalAuthorizationBlock(
            "ENFORCEMENT_SUBJECT_REQUIRED"
        )
    if (
        not isinstance(evidence.information_cutoff, int)
        or evidence.information_cutoff < 0
    ):
        raise ProductionOperationalAuthorizationBlock(
            "ENFORCEMENT_SUBJECT_CUTOFF_INVALID"
        )

    versions = sorted(
        {str(slots[n]["version"]) for n in names}
    )
    return OperationalEntryAuthorizationV1(
        state="PASS",
        authority_version=(
            "AUTHORITY_SHA256:"
            + authority_digest
            + ";SLOT_VERSIONS:"
            + ",".join(versions)
        ),
        evidence_id=evidence.evidence_id,
        policy_status="FROZEN",
        issuer=PRODUCTION_ISSUER,
        authority_digest="SHA256:" + authority_digest,
        enforcement_digest=_enforcement_subject_digest(
            evidence_id=evidence.evidence_id,
            symbol=evidence.symbol,
            entry_ready_id=evidence.entry_ready_id,
            information_cutoff=evidence.information_cutoff,
        ),
        subject_symbol=evidence.symbol,
        subject_entry_ready_id=evidence.entry_ready_id,
        subject_information_cutoff=evidence.information_cutoff,
        batch_evidence_id=batch_evidence_id,
        execution_binding_digest=_execution_binding_digest(
            binding=execution_binding,
            batch_evidence_id=batch_evidence_id,
        ),
    )


def build_production_operational_authorization(
    *,
    evidence: OperationalEnforcementEvidenceV1,
    path: Path = DEFAULT_AUTHORITY_PATH,
) -> OperationalEntryAuthorizationV1:
    """Deprecated raw-evidence surface: production issuance is forbidden.

    Raw ten-slot PASS evidence is mechanically composable and therefore is not
    sufficient provenance for production issuance. Callers must use the typed
    batch-proof builder below, which binds the frozen policy digest/version and
    PORT_007 allocation outcome.
    """
    del evidence, path
    raise ProductionOperationalAuthorizationBlock(
        "RAW_ENFORCEMENT_EVIDENCE_PRODUCTION_ISSUANCE_FORBIDDEN:"
        "USE_BUILD_PRODUCTION_OPERATIONAL_AUTHORIZATIONS_FROM_BATCH"
    )


def build_production_operational_authorizations_from_batch(
    *,
    enforcement_batch: FrozenOperationalBatchEnforcementV1,
    path: Path = DEFAULT_AUTHORITY_PATH,
) -> Mapping[str, OperationalEntryAuthorizationV1]:
    if not isinstance(
        enforcement_batch,
        FrozenOperationalBatchEnforcementV1,
    ):
        raise ProductionOperationalAuthorizationBlock(
            "TYPED_FROZEN_OPERATIONAL_BATCH_ENFORCEMENT_REQUIRED"
        )

    authority, digest = _validated_frozen_authority(path)
    version = str(authority.get("version") or "")
    if not version:
        raise ProductionOperationalAuthorizationBlock(
            "GLOBAL_POLICY_VERSION_REQUIRED"
        )
    if enforcement_batch.policy_version != version:
        raise ProductionOperationalAuthorizationBlock(
            "BATCH_POLICY_VERSION_DRIFT"
        )
    if enforcement_batch.authority_digest != "SHA256:" + digest:
        raise ProductionOperationalAuthorizationBlock(
            "BATCH_AUTHORITY_DIGEST_DRIFT"
        )
    expected_batch_id = recompute_batch_evidence_id(
        enforcement_batch
    )
    if enforcement_batch.batch_evidence_id != expected_batch_id:
        raise ProductionOperationalAuthorizationBlock(
            "BATCH_ENFORCEMENT_EVIDENCE_ID_DRIFT"
        )

    admitted = tuple(enforcement_batch.admitted_entry_ready_ids)
    capacity_blocked = tuple(
        enforcement_batch.capacity_blocked_entry_ready_ids
    )
    ordered = tuple(
        enforcement_batch.ordered_preallocation_eligible_entry_ready_ids
    )
    rejected = set(enforcement_batch.rejected_preallocation)
    evidence = dict(enforcement_batch.evidence_by_entry_ready_id)
    execution_bindings = dict(
        enforcement_batch.execution_binding_by_entry_ready_id
    )

    if len(set(admitted)) != len(admitted):
        raise ProductionOperationalAuthorizationBlock(
            "DUPLICATE_ADMITTED_ENTRY_READY_ID"
        )
    if ordered != admitted + capacity_blocked:
        raise ProductionOperationalAuthorizationBlock(
            "PORT007_STRICT_PREFIX_BATCH_SHAPE_DRIFT"
        )
    if set(evidence) != set(admitted):
        raise ProductionOperationalAuthorizationBlock(
            "ADMITTED_EVIDENCE_SET_DRIFT"
        )
    if set(execution_bindings) != set(admitted):
        raise ProductionOperationalAuthorizationBlock(
            "ADMITTED_EXECUTION_BINDING_SET_DRIFT"
        )
    if (
        set(admitted) & set(capacity_blocked)
        or set(admitted) & rejected
        or set(capacity_blocked) & rejected
    ):
        raise ProductionOperationalAuthorizationBlock(
            "BATCH_RESULT_PARTITION_OVERLAP"
        )

    out: dict[str, OperationalEntryAuthorizationV1] = {}
    for entry_ready_id in admitted:
        row = evidence[entry_ready_id]
        if row.entry_ready_id != entry_ready_id:
            raise ProductionOperationalAuthorizationBlock(
                "BATCH_EVIDENCE_ENTRY_READY_ID_DRIFT"
            )
        if row.information_cutoff != enforcement_batch.information_cutoff:
            raise ProductionOperationalAuthorizationBlock(
                "BATCH_EVIDENCE_CUTOFF_DRIFT"
            )
        binding = execution_bindings[entry_ready_id]
        if (
            binding.symbol != row.symbol
            or binding.entry_ready_id != row.entry_ready_id
            or binding.information_cutoff != row.information_cutoff
        ):
            raise ProductionOperationalAuthorizationBlock(
                "EXECUTION_BINDING_SUBJECT_DRIFT"
            )
        out[entry_ready_id] = _build_subject_bound_token(
            evidence=row,
            execution_binding=binding,
            batch_evidence_id=enforcement_batch.batch_evidence_id,
            authority=authority,
            authority_digest=digest,
        )
    return out


def invariants() -> Mapping[str, object]:
    return {
        "authority_document_must_be_frozen": True,
        "all_ten_slots_must_validate": True,
        "all_ten_enforcement_results_must_pass": True,
        "raw_enforcement_evidence_can_issue_production_token": False,
        "typed_batch_enforcement_proof_required": True,
        "batch_policy_version_bound": True,
        "batch_authority_digest_bound": True,
        "batch_evidence_id_recomputed": True,
        "port007_strict_prefix_shape_bound": True,
        "capacity_blocked_candidate_authorized": False,
        "preallocation_rejected_candidate_authorized": False,
        "authority_sha256_bound": True,
        "entry_subject_bound": True,
        "entry_subject_cryptographically_bound": True,
        "batch_evidence_id_bound": True,
        "execution_quantity_risk_binding_bound": True,
        "orders": 0,
        "fills": 0,
        "execution_intents": 0,
        "trading_activated": False,
    }


def verify_production_operational_authorization(
    *,
    authorization: OperationalEntryAuthorizationV1,
    enforcement_batch: FrozenOperationalBatchEnforcementV1 | None = None,
    path: Path = DEFAULT_AUTHORITY_PATH,
) -> None:
    authorization.assert_pass(require_production_issuer=True)
    try:
        authority = load_policy_authority(path)
    except Exception as exc:
        raise ProductionOperationalAuthorizationBlock(
            "POLICY_AUTHORITY_VERIFICATION_FAILED"
        ) from exc
    if authority.get("status") != FROZEN_STATUS:
        raise ProductionOperationalAuthorizationBlock(
            "POLICY_AUTHORITY_NOT_FROZEN"
        )
    build_operational_input_set(path)
    digest = hashlib.sha256(Path(path).read_bytes()).hexdigest()
    if authorization.authority_digest != "SHA256:" + digest:
        raise ProductionOperationalAuthorizationBlock(
            "AUTHORITY_DIGEST_DRIFT"
        )
    if (
        "AUTHORITY_SHA256:" + digest
        not in authorization.authority_version
    ):
        raise ProductionOperationalAuthorizationBlock(
            "AUTHORITY_VERSION_DIGEST_DRIFT"
        )
    expected = _enforcement_subject_digest(
        evidence_id=authorization.evidence_id,
        symbol=authorization.subject_symbol,
        entry_ready_id=authorization.subject_entry_ready_id,
        information_cutoff=authorization.subject_information_cutoff,
    )
    if authorization.enforcement_digest != expected:
        raise ProductionOperationalAuthorizationBlock(
            "ENFORCEMENT_SUBJECT_DIGEST_DRIFT"
        )
    if enforcement_batch is not None:
        if not isinstance(
            enforcement_batch,
            FrozenOperationalBatchEnforcementV1,
        ):
            raise ProductionOperationalAuthorizationBlock(
                "TYPED_FROZEN_OPERATIONAL_BATCH_ENFORCEMENT_REQUIRED"
            )
        if (
            enforcement_batch.batch_evidence_id
            != recompute_batch_evidence_id(enforcement_batch)
        ):
            raise ProductionOperationalAuthorizationBlock(
                "BATCH_ENFORCEMENT_EVIDENCE_ID_DRIFT"
            )
        if authorization.batch_evidence_id != (
            enforcement_batch.batch_evidence_id
        ):
            raise ProductionOperationalAuthorizationBlock(
                "AUTHORIZATION_BATCH_EVIDENCE_DRIFT"
            )
        entry_ready_id = authorization.subject_entry_ready_id
        if entry_ready_id not in (
            enforcement_batch.admitted_entry_ready_ids
        ):
            raise ProductionOperationalAuthorizationBlock(
                "AUTHORIZATION_SUBJECT_NOT_BATCH_ADMITTED"
            )
        binding = (
            enforcement_batch.execution_binding_by_entry_ready_id.get(
                entry_ready_id
            )
        )
        if binding is None:
            raise ProductionOperationalAuthorizationBlock(
                "AUTHORIZATION_EXECUTION_BINDING_MISSING"
            )
        expected_binding = _execution_binding_digest(
            binding=binding,
            batch_evidence_id=enforcement_batch.batch_evidence_id,
        )
        if authorization.execution_binding_digest != expected_binding:
            raise ProductionOperationalAuthorizationBlock(
                "AUTHORIZATION_EXECUTION_BINDING_DRIFT"
            )


__all__ = [
    "ProductionOperationalAuthorizationBlock",
    "build_production_operational_authorization",
    "build_production_operational_authorizations_from_batch",
    "verify_production_operational_authorization",
    "invariants",
]
