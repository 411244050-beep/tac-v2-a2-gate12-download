from __future__ import annotations

import json
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Any, Mapping

from strategy_rc1.d2_market_state.types import (
    PivotType,
    StructuralLayer,
    StructuralPivot,
    TrendDirection,
)
from strategy_rc1.d4_opportunity.types import OpportunityMechanism
from strategy_rc1.d5_risk.risk_anchor import (
    DeepTakeoverRiskEvidence,
    FalseBreakRiskEvidence,
    MechanismRiskEvidence,
    NormalRetestRiskEvidence,
    PlatformRiskEvidence,
)
from strategy_rc1.runtime_guards.information_state import InfoKind, InfoValue


class FullLiveD5MechanismSourceBindingBlock(RuntimeError):
    pass


@dataclass(frozen=True)
class ExplicitAdverseDefensePivotAuthorityV1:
    """Typed handoff for mechanisms whose current D4 evidence lacks the D5 pivot.

    This object does not select a pivot.  A mechanism-specific authoritative
    producer must already have designated the exact adverse-defense
    StructuralPivot and its lineage ID before constructing this handoff.
    """

    mechanism: OpportunityMechanism
    pivot: StructuralPivot
    lineage_id: str
    source_authority_id: str
    provenance: Mapping[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.mechanism not in (
            OpportunityMechanism.PLATFORM_REEXPANSION,
            OpportunityMechanism.DEEP_STRUCTURE_TAKEOVER,
        ):
            raise ValueError("EXPLICIT_ADVERSE_DEFENSE_MECHANISM_INVALID")
        if not self.lineage_id:
            raise ValueError("EXPLICIT_ADVERSE_DEFENSE_LINEAGE_ID_REQUIRED")
        if not self.source_authority_id:
            raise ValueError(
                "EXPLICIT_ADVERSE_DEFENSE_SOURCE_AUTHORITY_ID_REQUIRED"
            )
        object.__setattr__(
            self,
            "provenance",
            MappingProxyType(dict(self.provenance)),
        )


@dataclass(frozen=True)
class D5MechanismSourceBindingResultV1:
    status: str
    mechanism: OpportunityMechanism
    risk_evidence: MechanismRiskEvidence | None
    risk_anchor_not_invalidated: InfoValue[bool]
    reason: str
    provenance: Mapping[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.status == "BOUND" and self.risk_evidence is None:
            raise ValueError("BOUND_REQUIRES_RISK_EVIDENCE")
        object.__setattr__(
            self,
            "provenance",
            MappingProxyType(dict(self.provenance)),
        )


def _selected_candidate(d4_view: Any, mechanism: OpportunityMechanism) -> Any:
    opportunity = getattr(d4_view, "opportunity", None)
    candidate = getattr(d4_view, "confirmation_candidate", None)
    cutoff = getattr(d4_view, "information_cutoff", None)
    if opportunity is None or candidate is None:
        raise FullLiveD5MechanismSourceBindingBlock(
            "CURRENT_B7A_CONFIRMATION_REQUIRED"
        )
    if candidate.confirmation_cutoff != cutoff:
        raise FullLiveD5MechanismSourceBindingBlock(
            "CURRENT_B7A_CONFIRMATION_CUTOFF_DRIFT"
        )
    if candidate.mechanism is not mechanism:
        raise FullLiveD5MechanismSourceBindingBlock(
            "CURRENT_B7A_MECHANISM_MISMATCH"
        )
    if candidate.opportunity_id != opportunity.opportunity_id:
        raise FullLiveD5MechanismSourceBindingBlock(
            "CURRENT_B7A_OPPORTUNITY_LINEAGE_MISMATCH"
        )
    if candidate.trend_episode_id != opportunity.trend_episode_id:
        raise FullLiveD5MechanismSourceBindingBlock(
            "CURRENT_B7A_TREND_LINEAGE_MISMATCH"
        )
    if candidate.direction is not opportunity.direction:
        raise FullLiveD5MechanismSourceBindingBlock(
            "CURRENT_B7A_DIRECTION_MISMATCH"
        )
    if candidate.market_event_id != opportunity.market_event_id:
        raise FullLiveD5MechanismSourceBindingBlock(
            "CURRENT_B7A_MARKET_EVENT_MISMATCH"
        )
    return candidate


def _validity_value(
    value: InfoValue[bool],
) -> tuple[bool | None, str | None]:
    if value.kind is InfoKind.ERROR:
        return None, "RISK_ANCHOR_VALIDITY_ERROR"
    if value.kind is InfoKind.UNKNOWN:
        return None, "RISK_ANCHOR_VALIDITY_UNKNOWN"
    if value.kind is not InfoKind.KNOWN:
        return None, "RISK_ANCHOR_VALIDITY_NOT_APPLICABLE"
    if value.value not in (True, False):
        return None, "RISK_ANCHOR_VALIDITY_NONBOOLEAN"
    return bool(value.value), None


def _pivot_index(
    pivots: tuple[StructuralPivot, ...],
) -> dict[str, StructuralPivot]:
    out: dict[str, StructuralPivot] = {}
    for pivot in pivots:
        old = out.get(pivot.pivot_id)
        if old is not None and old != pivot:
            raise FullLiveD5MechanismSourceBindingBlock(
                "DIVERGENT_DUPLICATE_PIVOT_ID:" + pivot.pivot_id
            )
        out[pivot.pivot_id] = pivot
    return out


def _adverse_type(direction: TrendDirection) -> PivotType:
    if direction is TrendDirection.LONG:
        return PivotType.LOW
    if direction is TrendDirection.SHORT:
        return PivotType.HIGH
    raise FullLiveD5MechanismSourceBindingBlock(
        "RISK_EVIDENCE_DIRECTION_NOT_LONG_OR_SHORT"
    )


def _validate_source_pivot(
    pivot: StructuralPivot,
    *,
    direction: TrendDirection,
    information_cutoff: int,
    canonical_segment_id: str,
    require_minor: bool,
) -> None:
    if pivot.confirmed_at > information_cutoff:
        raise FullLiveD5MechanismSourceBindingBlock(
            "FUTURE_RISK_SOURCE_PIVOT:" + pivot.pivot_id
        )
    if pivot.canonical_segment_id != canonical_segment_id:
        raise FullLiveD5MechanismSourceBindingBlock(
            "RISK_SOURCE_PIVOT_CANONICAL_SEGMENT_MISMATCH:"
            + pivot.pivot_id
        )
    if require_minor and pivot.layer is not StructuralLayer.MINOR:
        raise FullLiveD5MechanismSourceBindingBlock(
            "NORMAL_RETEST_SOURCE_PIVOT_NOT_MINOR:" + pivot.pivot_id
        )
    if pivot.pivot_type is not _adverse_type(direction):
        raise FullLiveD5MechanismSourceBindingBlock(
            "RISK_SOURCE_PIVOT_NOT_ADVERSE_TYPE:" + pivot.pivot_id
        )
    if not pivot.provenance:
        raise FullLiveD5MechanismSourceBindingBlock(
            "RISK_SOURCE_PIVOT_PROVENANCE_MISSING:" + pivot.pivot_id
        )


def _parse_source_pivot_ids(provenance: Mapping[str, str]) -> tuple[str, ...]:
    raw = provenance.get("source_pivot_ids")
    if not raw:
        raise FullLiveD5MechanismSourceBindingBlock(
            "SOURCE_PIVOT_IDS_PROVENANCE_MISSING"
        )
    try:
        decoded = json.loads(raw)
    except Exception as exc:
        raise FullLiveD5MechanismSourceBindingBlock(
            "SOURCE_PIVOT_IDS_PROVENANCE_INVALID_JSON"
        ) from exc
    if not isinstance(decoded, list) or not decoded:
        raise FullLiveD5MechanismSourceBindingBlock(
            "SOURCE_PIVOT_IDS_PROVENANCE_EMPTY"
        )
    ids = tuple(str(x) for x in decoded)
    if any(not x for x in ids) or len(set(ids)) != len(ids):
        raise FullLiveD5MechanismSourceBindingBlock(
            "SOURCE_PIVOT_IDS_PROVENANCE_INVALID"
        )
    return ids


def _blocked_for_validity(
    mechanism: OpportunityMechanism,
    risk_anchor_not_invalidated: InfoValue[bool],
    reason: str,
) -> D5MechanismSourceBindingResultV1:
    return D5MechanismSourceBindingResultV1(
        status="BLOCKED",
        mechanism=mechanism,
        risk_evidence=None,
        risk_anchor_not_invalidated=risk_anchor_not_invalidated,
        reason=reason,
        provenance={
            "binding": "FULL_LIVE_D5_MECHANISM_SOURCE_BINDING_V1",
            "unknown_not_coerced": "true",
        },
    )


def bind_normal_retest_risk_source(
    *,
    d4_view: Any,
    normal_retest_evidence: Any,
    confirmed_minor_pivots: tuple[StructuralPivot, ...],
    canonical_segment_id: str,
    risk_anchor_not_invalidated: InfoValue[bool],
) -> D5MechanismSourceBindingResultV1:
    mechanism = OpportunityMechanism.NORMAL_RETEST_CONTINUATION
    candidate = _selected_candidate(d4_view, mechanism)
    opportunity = d4_view.opportunity

    if tuple(candidate.setup_lineage) != tuple(
        normal_retest_evidence.setup_lineage
    ):
        raise FullLiveD5MechanismSourceBindingBlock(
            "NORMAL_RETEST_SETUP_LINEAGE_MISMATCH"
        )
    regain = getattr(normal_retest_evidence, "local_control_regain", None)
    if regain is None:
        raise FullLiveD5MechanismSourceBindingBlock(
            "NORMAL_RETEST_LOCAL_CONTROL_REGAIN_REQUIRED"
        )
    if regain.confirmation_cutoff > d4_view.information_cutoff:
        raise FullLiveD5MechanismSourceBindingBlock(
            "NORMAL_RETEST_FUTURE_LOCAL_CONTROL_REGAIN"
        )

    validity, blocked = _validity_value(risk_anchor_not_invalidated)
    if blocked is not None:
        return _blocked_for_validity(
            mechanism,
            risk_anchor_not_invalidated,
            blocked,
        )

    source_ids = _parse_source_pivot_ids(regain.provenance)
    by_id = _pivot_index(confirmed_minor_pivots)
    missing = tuple(x for x in source_ids if x not in by_id)
    if missing:
        raise FullLiveD5MechanismSourceBindingBlock(
            "NORMAL_RETEST_SOURCE_PIVOT_NOT_IN_AUTHORITATIVE_HISTORY:"
            + ",".join(missing)
        )

    adverse = tuple(
        by_id[x]
        for x in source_ids
        if by_id[x].pivot_type is _adverse_type(candidate.direction)
    )
    if not adverse:
        raise FullLiveD5MechanismSourceBindingBlock(
            "NORMAL_RETEST_NO_ADVERSE_MINOR_SOURCE_PIVOT"
        )
    for pivot in adverse:
        _validate_source_pivot(
            pivot,
            direction=candidate.direction,
            information_cutoff=d4_view.information_cutoff,
            canonical_segment_id=canonical_segment_id,
            require_minor=True,
        )

    risk = NormalRetestRiskEvidence(
        opportunity_id=opportunity.opportunity_id,
        confirmation_candidate_id=candidate.candidate_id,
        belongs_to_opportunity_lineage=True,
        thesis_defining=True,
        risk_anchor_not_invalidated=bool(validity),
        participating_minor_pivots=adverse,
        provenance={
            "binding": "FULL_LIVE_D5_MECHANISM_SOURCE_BINDING_V1",
            "source": "LOCAL_TREND_CONTROL_REGAIN_TYPED_PROVENANCE",
            "source_pivot_ids": json.dumps(
                [x.pivot_id for x in adverse],
                separators=(",", ":"),
            ),
            "no_adverse_most_selection_here": "true",
        },
    )
    return D5MechanismSourceBindingResultV1(
        status="BOUND",
        mechanism=mechanism,
        risk_evidence=risk,
        risk_anchor_not_invalidated=risk_anchor_not_invalidated,
        reason="NORMAL_RETEST_TYPED_SOURCE_BOUND",
        provenance={"frozen_d5_retains_adverse_most_selection": "true"},
    )


def bind_false_break_risk_source(
    *,
    d4_view: Any,
    false_break_evidence: Any,
    correct_side_recovery_projection: Any,
    confirmed_minor_pivots: tuple[StructuralPivot, ...],
    canonical_segment_id: str,
    risk_anchor_not_invalidated: InfoValue[bool],
) -> D5MechanismSourceBindingResultV1:
    mechanism = OpportunityMechanism.FALSE_BREAK_RECLAIM
    candidate = _selected_candidate(d4_view, mechanism)
    opportunity = d4_view.opportunity

    if tuple(candidate.setup_lineage) != tuple(
        false_break_evidence.setup_lineage
    ):
        raise FullLiveD5MechanismSourceBindingBlock(
            "FALSE_BREAK_SETUP_LINEAGE_MISMATCH"
        )
    event = false_break_evidence.interaction
    if event.event_id not in tuple(candidate.source_event_ids):
        raise FullLiveD5MechanismSourceBindingBlock(
            "FALSE_BREAK_EVENT_NOT_IN_B7A_SOURCE_EVENTS"
        )
    if getattr(event.break_state, "value", event.break_state) != "FALSE_BREAK":
        raise FullLiveD5MechanismSourceBindingBlock(
            "FALSE_BREAK_EVENT_NOT_TERMINAL_FALSE_BREAK"
        )
    if event.resolved_at != d4_view.information_cutoff:
        raise FullLiveD5MechanismSourceBindingBlock(
            "FALSE_BREAK_NOT_CONFIRMED_CURRENT_CUTOFF"
        )

    if (
        getattr(correct_side_recovery_projection, "producer", "")
        != "B4_CORRECT_SIDE_RECOVERY_D2_PROJECTION_V1"
    ):
        raise FullLiveD5MechanismSourceBindingBlock(
            "FALSE_BREAK_RECOVERY_PRODUCER_MISMATCH"
        )
    if (
        getattr(
            getattr(correct_side_recovery_projection, "state", None),
            "value",
            getattr(correct_side_recovery_projection, "state", None),
        )
        != "TRUE"
    ):
        raise FullLiveD5MechanismSourceBindingBlock(
            "FALSE_BREAK_RECOVERY_NOT_TRUE"
        )
    recovery = getattr(
        correct_side_recovery_projection,
        "consumer_evidence",
        None,
    )
    turning_id = getattr(recovery, "turning_pivot_id", None)
    if not turning_id:
        raise FullLiveD5MechanismSourceBindingBlock(
            "FALSE_BREAK_TURNING_PIVOT_ID_MISSING"
        )

    prov_event = str(
        getattr(correct_side_recovery_projection, "provenance", {}).get(
            "interaction_event_id",
            "",
        )
    )
    if prov_event and prov_event != event.event_id:
        raise FullLiveD5MechanismSourceBindingBlock(
            "FALSE_BREAK_RECOVERY_EVENT_LINEAGE_MISMATCH"
        )

    validity, blocked = _validity_value(risk_anchor_not_invalidated)
    if blocked is not None:
        return _blocked_for_validity(
            mechanism,
            risk_anchor_not_invalidated,
            blocked,
        )

    by_id = _pivot_index(confirmed_minor_pivots)
    pivot = by_id.get(str(turning_id))
    if pivot is None:
        raise FullLiveD5MechanismSourceBindingBlock(
            "FALSE_BREAK_TURNING_PIVOT_NOT_IN_AUTHORITATIVE_HISTORY:"
            + str(turning_id)
        )
    _validate_source_pivot(
        pivot,
        direction=candidate.direction,
        information_cutoff=d4_view.information_cutoff,
        canonical_segment_id=canonical_segment_id,
        require_minor=True,
    )

    risk = FalseBreakRiskEvidence(
        opportunity_id=opportunity.opportunity_id,
        confirmation_candidate_id=candidate.candidate_id,
        belongs_to_opportunity_lineage=True,
        thesis_defining=True,
        risk_anchor_not_invalidated=bool(validity),
        wrong_side_extreme=pivot,
        false_break_event_id=event.event_id,
        provenance={
            "binding": "FULL_LIVE_D5_MECHANISM_SOURCE_BINDING_V1",
            "source": "B4_CORRECT_SIDE_RECOVERY_TURNING_PIVOT",
            "turning_pivot_id": pivot.pivot_id,
        },
    )
    return D5MechanismSourceBindingResultV1(
        status="BOUND",
        mechanism=mechanism,
        risk_evidence=risk,
        risk_anchor_not_invalidated=risk_anchor_not_invalidated,
        reason="FALSE_BREAK_TYPED_SOURCE_BOUND",
        provenance={"wrong_side_extreme_selection_added": "false"},
    )


def bind_explicit_adverse_defense_risk_source(
    *,
    d4_view: Any,
    source_authority: ExplicitAdverseDefensePivotAuthorityV1 | None,
    canonical_segment_id: str,
    risk_anchor_not_invalidated: InfoValue[bool],
) -> D5MechanismSourceBindingResultV1:
    candidate = getattr(d4_view, "confirmation_candidate", None)
    if candidate is None:
        raise FullLiveD5MechanismSourceBindingBlock(
            "CURRENT_B7A_CONFIRMATION_REQUIRED"
        )
    mechanism = candidate.mechanism
    if mechanism not in (
        OpportunityMechanism.PLATFORM_REEXPANSION,
        OpportunityMechanism.DEEP_STRUCTURE_TAKEOVER,
    ):
        raise FullLiveD5MechanismSourceBindingBlock(
            "EXPLICIT_ADVERSE_DEFENSE_ONLY_PLATFORM_OR_DEEP"
        )
    _selected_candidate(d4_view, mechanism)

    if source_authority is None:
        return D5MechanismSourceBindingResultV1(
            status="BLOCKED",
            mechanism=mechanism,
            risk_evidence=None,
            risk_anchor_not_invalidated=risk_anchor_not_invalidated,
            reason="MECHANISM_SPECIFIC_ADVERSE_DEFENSE_AUTHORITY_MISSING",
            provenance={
                "binding": "FULL_LIVE_D5_MECHANISM_SOURCE_BINDING_V1",
                "selector_added": "false",
            },
        )
    if source_authority.mechanism is not mechanism:
        raise FullLiveD5MechanismSourceBindingBlock(
            "EXPLICIT_ADVERSE_DEFENSE_MECHANISM_MISMATCH"
        )

    validity, blocked = _validity_value(risk_anchor_not_invalidated)
    if blocked is not None:
        return _blocked_for_validity(
            mechanism,
            risk_anchor_not_invalidated,
            blocked,
        )

    pivot = source_authority.pivot
    _validate_source_pivot(
        pivot,
        direction=candidate.direction,
        information_cutoff=d4_view.information_cutoff,
        canonical_segment_id=canonical_segment_id,
        require_minor=False,
    )
    opportunity = d4_view.opportunity
    common = dict(
        opportunity_id=opportunity.opportunity_id,
        confirmation_candidate_id=candidate.candidate_id,
        belongs_to_opportunity_lineage=True,
        thesis_defining=True,
        risk_anchor_not_invalidated=bool(validity),
        adverse_defense_extreme=pivot,
        provenance={
            "binding": "FULL_LIVE_D5_MECHANISM_SOURCE_BINDING_V1",
            "source_authority_id": source_authority.source_authority_id,
            **dict(source_authority.provenance),
        },
    )
    if mechanism is OpportunityMechanism.PLATFORM_REEXPANSION:
        risk: MechanismRiskEvidence = PlatformRiskEvidence(
            **common,
            platform_episode_id=source_authority.lineage_id,
        )
    else:
        risk = DeepTakeoverRiskEvidence(
            **common,
            deeper_takeover_lineage_id=source_authority.lineage_id,
        )

    return D5MechanismSourceBindingResultV1(
        status="BOUND",
        mechanism=mechanism,
        risk_evidence=risk,
        risk_anchor_not_invalidated=risk_anchor_not_invalidated,
        reason="EXPLICIT_ADVERSE_DEFENSE_TYPED_SOURCE_BOUND",
        provenance={
            "source_authority_id": source_authority.source_authority_id,
            "selector_added": "false",
        },
    )
