from __future__ import annotations

"""Typed enforcement bridge for the two authorized execution-related D5 slots.

This module does not create UPDATE-014 admission. It consumes one durable
post-UPDATE-014 prospective execution observation plus exchange-rule legality
and the frozen execution-feasibility authority. It produces only slot-level
PASS/FAIL evidence for:
- spread_slippage_depth_feasibility_boundaries
- execution_allowance

All other D5 slots remain outside this module.
"""

from dataclasses import dataclass
import hashlib
import json
from typing import Mapping, Any

from binance_usdm_market_entry_legality_v1 import USDMarketEntryLegalityV1
from full_live_operational_enforcement_evidence_v1 import (
    SlotEnforcementResultV1,
)
from full_live_pre_execution_policy_gate_v1 import (
    FrozenExecutionFeasibilityPolicyV1,
    evaluate_prospective_execution_evidence,
    load_frozen_execution_feasibility_policy,
)
from full_live_prospective_execution_evidence_v1 import (
    ProspectiveExecutionEvidenceV1,
    validate_prospective_execution_evidence,
)


class ExecutionFeasibilityEnforcementBlock(RuntimeError):
    pass


@dataclass(frozen=True)
class ExecutionFeasibilityEnforcementV1:
    symbol: str
    direction: str
    entry_ready_id: str
    information_cutoff: int
    policy_version: str
    policy_authority_digest: str
    feasibility_state: str
    execution_allowance_state: str
    evidence_id: str
    slot_results: Mapping[str, SlotEnforcementResultV1]
    detail: Mapping[str, Any]


def _digest(payload: Mapping[str, Any]) -> str:
    raw = json.dumps(
        payload,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    ).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def enforce_authorized_execution_slots(
    *,
    evidence: ProspectiveExecutionEvidenceV1,
    legality: USDMarketEntryLegalityV1,
    policy: FrozenExecutionFeasibilityPolicyV1 | None = None,
) -> ExecutionFeasibilityEnforcementV1:
    evidence = validate_prospective_execution_evidence(evidence)
    if not isinstance(legality, USDMarketEntryLegalityV1):
        raise ExecutionFeasibilityEnforcementBlock(
            "TYPED_MARKET_ENTRY_LEGALITY_REQUIRED"
        )
    actual_policy = (
        load_frozen_execution_feasibility_policy()
        if policy is None
        else policy
    )
    if not isinstance(actual_policy, FrozenExecutionFeasibilityPolicyV1):
        raise ExecutionFeasibilityEnforcementBlock(
            "TYPED_EXECUTION_POLICY_REQUIRED"
        )

    detail = dict(
        evaluate_prospective_execution_evidence(
            legality=legality,
            evidence=evidence,
            policy=actual_policy,
        )
    )
    feasibility_state = str(detail.get("state"))
    allowance_state = str(detail.get("execution_allowance_state"))
    if feasibility_state not in ("PASS", "FAIL"):
        raise ExecutionFeasibilityEnforcementBlock(
            "FEASIBILITY_STATE_INVALID"
        )
    if allowance_state not in ("PASS", "FAIL"):
        raise ExecutionFeasibilityEnforcementBlock(
            "EXECUTION_ALLOWANCE_STATE_INVALID"
        )

    identity = {
        "schema": "TAC_FULL_LIVE_EXECUTION_FEASIBILITY_ENFORCEMENT_V1",
        "subject": {
            "symbol": evidence.symbol,
            "direction": evidence.direction,
            "entry_ready_id": evidence.entry_ready_id,
            "information_cutoff": evidence.information_cutoff,
            "execution_evidence_id": evidence.evidence_id,
        },
        "policy": {
            "version": actual_policy.version,
            "authority": actual_policy.authority,
            "authority_digest": actual_policy.authority_digest,
        },
        "legality": {
            "requested_quote_notional": str(
                legality.requested_quote_notional
            ),
            "reference_price": str(legality.reference_price),
            "rounded_quantity": str(legality.rounded_quantity),
            "rounded_quote_notional": str(
                legality.rounded_quote_notional
            ),
            "status_trading": legality.status_trading,
            "quantity_at_or_above_min": (
                legality.quantity_at_or_above_min
            ),
            "quantity_at_or_below_max": (
                legality.quantity_at_or_below_max
            ),
            "notional_at_or_above_min": (
                legality.notional_at_or_above_min
            ),
            "exchange_legal": legality.exchange_legal,
        },
        "evaluation": detail,
    }
    base_hash = _digest(identity)
    evidence_id = (
        "EXECUTION_FEASIBILITY_ENFORCEMENT_SHA256:" + base_hash
    )

    spread_id = (
        "D5_SPREAD_SLIPPAGE_DEPTH_ENFORCEMENT_SHA256:"
        + _digest(
            {
                "base": evidence_id,
                "slot": "spread_slippage_depth_feasibility_boundaries",
                "state": feasibility_state,
            }
        )
    )
    allowance_id = (
        "D5_EXECUTION_ALLOWANCE_ENFORCEMENT_SHA256:"
        + _digest(
            {
                "base": evidence_id,
                "slot": "execution_allowance",
                "state": allowance_state,
            }
        )
    )

    slot_results = {
        "spread_slippage_depth_feasibility_boundaries":
            SlotEnforcementResultV1(
                feasibility_state,
                spread_id,
                (
                    "FROZEN_80_USDT_SPREAD_IMPACT_FILLABILITY_"
                    "POST_UPDATE014_GATE_V1"
                ),
            ),
        "execution_allowance":
            SlotEnforcementResultV1(
                allowance_state,
                allowance_id,
                "D5_FEASIBILITY_GATED_ONLY_V1",
            ),
    }

    return ExecutionFeasibilityEnforcementV1(
        symbol=evidence.symbol,
        direction=evidence.direction,
        entry_ready_id=evidence.entry_ready_id,
        information_cutoff=evidence.information_cutoff,
        policy_version=actual_policy.version,
        policy_authority_digest=actual_policy.authority_digest,
        feasibility_state=feasibility_state,
        execution_allowance_state=allowance_state,
        evidence_id=evidence_id,
        slot_results=slot_results,
        detail=detail,
    )


def invariants() -> Mapping[str, object]:
    return {
        "authorized_slots": (
            "spread_slippage_depth_feasibility_boundaries",
            "execution_allowance",
        ),
        "other_d5_slots_modified": False,
        "post_update014_evidence_required": True,
        "frozen_policy_required": True,
        "entry_ready_created_here": False,
        "update014_semantics_changed": False,
        "selector_added": False,
        "ranking_added": False,
        "orders": 0,
        "fills": 0,
        "execution_intents": 0,
        "trading_activated": False,
    }
