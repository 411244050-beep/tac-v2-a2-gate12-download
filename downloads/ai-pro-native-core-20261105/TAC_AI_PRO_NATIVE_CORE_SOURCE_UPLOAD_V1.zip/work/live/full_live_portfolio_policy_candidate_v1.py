from __future__ import annotations

"""Candidate-only portfolio policy semantics.

This module deliberately does not freeze operational values.  It provides
deterministic mechanics that may be activated only by a separately frozen
D5 operational-risk authority.
"""

from dataclasses import dataclass
from typing import Iterable, Mapping, Sequence


class CandidatePortfolioPolicyBlock(RuntimeError):
    pass


@dataclass(frozen=True)
class AllocationCandidateV1:
    symbol: str
    transaction_id: str
    direction: str


def systemic_direction_factor(direction: str) -> str:
    side = direction.upper()
    if side not in ("LONG", "SHORT"):
        raise CandidatePortfolioPolicyBlock("DIRECTION_INVALID")
    return "SYSTEMIC_DIRECTION_" + side


def cutoff_rotated_canonical_order(
    candidates: Iterable[AllocationCandidateV1],
    *,
    frozen_universe: Sequence[str],
    information_cutoff: int,
) -> tuple[AllocationCandidateV1, ...]:
    """Fair deterministic capacity order without signal/performance ranking.

    Rotation is derived only from the causal cutoff and frozen canonical
    universe position. It must never be interpreted as opportunity quality.
    """
    universe = tuple(frozen_universe)
    if not universe or len(set(universe)) != len(universe):
        raise CandidatePortfolioPolicyBlock("FROZEN_UNIVERSE_INVALID")
    if not isinstance(information_cutoff, int) or information_cutoff < 0:
        raise CandidatePortfolioPolicyBlock("INFORMATION_CUTOFF_INVALID")

    rows = tuple(candidates)
    index = {s: i for i, s in enumerate(universe)}
    seen: set[tuple[str, str]] = set()
    for row in rows:
        if row.symbol not in index:
            raise CandidatePortfolioPolicyBlock(
                "CANDIDATE_OUTSIDE_FROZEN_UNIVERSE:" + row.symbol
            )
        if row.direction.upper() not in ("LONG", "SHORT"):
            raise CandidatePortfolioPolicyBlock("DIRECTION_INVALID")
        key = (row.symbol, row.transaction_id)
        if key in seen:
            raise CandidatePortfolioPolicyBlock("DUPLICATE_CANDIDATE")
        seen.add(key)

    rotation = information_cutoff % len(universe)
    return tuple(sorted(
        rows,
        key=lambda r: (
            (index[r.symbol] - rotation) % len(universe),
            r.transaction_id,
        ),
    ))


def invariants() -> Mapping[str, object]:
    return {
        "status": "CANDIDATE_NOT_FROZEN",
        "common_factor_policy": "SYSTEMIC_DIRECTION_EXPOSURE_V1",
        "common_factor_is_statistical_correlation_model": False,
        "historical_correlation_window_added": False,
        "sector_taxonomy_added": False,
        "port007_capacity_order": "CUTOFF_ROTATED_FROZEN_CANONICAL_UNIVERSE_V1",
        "capacity_order_is_signal_ranking": False,
        "signal_score_used": False,
        "historical_performance_used": False,
        "pnl_used": False,
        "alphabetical_symbol_priority_used": False,
        "policy_thresholds_owned": False,
        "requires_separate_operational_policy_freeze": True,
        "orders": 0,
        "fills": 0,
        "execution_intents": 0,
        "trading_activated": False,
    }


__all__ = [
    "AllocationCandidateV1",
    "CandidatePortfolioPolicyBlock",
    "systemic_direction_factor",
    "cutoff_rotated_canonical_order",
    "invariants",
]
