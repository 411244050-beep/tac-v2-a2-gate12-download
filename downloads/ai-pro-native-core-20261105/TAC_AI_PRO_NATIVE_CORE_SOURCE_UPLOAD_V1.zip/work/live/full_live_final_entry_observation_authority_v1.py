from __future__ import annotations
from dataclasses import dataclass
import json
from typing import Any
class FinalEntryObservationAuthorityBlock(RuntimeError): pass
@dataclass(frozen=True)
class PostUpdate014CandidateObservationAuthorityV1:
    symbol:str; direction:str; information_cutoff:int; entry_ready_ref:str; transaction_id:str; update013_output_digest:str; update014_output_digest:str
def _text(x): return str(getattr(x,"value",x))
def _stage(sr,name):
    rows=[x for x in tuple(getattr(sr,"stages",())) if _text(getattr(x,"step",None))==name]
    if len(rows)!=1: raise FinalEntryObservationAuthorityBlock(name+"_STAGE_CARDINALITY")
    return rows[0]
def _payload(stage):
    raw=getattr(stage,"payload_json",None)
    if not isinstance(raw,str): raise FinalEntryObservationAuthorityBlock("STAGE_PAYLOAD_JSON_REQUIRED")
    try: return json.loads(raw)
    except Exception as exc: raise FinalEntryObservationAuthorityBlock("STAGE_PAYLOAD_JSON_INVALID") from exc
def _values(node,key):
    out=[]
    if isinstance(node,dict):
        for k,v in node.items():
            if k==key: out.append(v)
            out.extend(_values(v,key))
    elif isinstance(node,list):
        for v in node: out.extend(_values(v,key))
    return out
def _one(node,key):
    vals=_values(node,key)
    if not vals: raise FinalEntryObservationAuthorityBlock("PAYLOAD_FIELD_MISSING:"+key)
    first=vals[0]
    if any(v!=first for v in vals[1:]): raise FinalEntryObservationAuthorityBlock("PAYLOAD_FIELD_CONFLICT:"+key)
    return first
def _enum_value(v):
    if isinstance(v,str): return v
    strings=[]
    def walk(x):
        if isinstance(x,str): strings.append(x)
        elif isinstance(x,dict):
            for y in x.values(): walk(y)
        elif isinstance(x,list):
            for y in x: walk(y)
    walk(v)
    hits=[x for x in strings if x in ("LONG","SHORT")]
    if len(set(hits))!=1: raise FinalEntryObservationAuthorityBlock("DIRECTION_ENUM_ENCODING_INVALID")
    return hits[0]
def extract_from_authoritative_symbol_result(sr):
    symbol=str(getattr(sr,"symbol","") or ""); tx=str(getattr(sr,"transaction_id","") or ""); cutoff=getattr(sr,"information_cutoff",None)
    if not symbol or not tx or not isinstance(cutoff,int) or cutoff<0: raise FinalEntryObservationAuthorityBlock("AUTHORITATIVE_SYMBOL_IDENTITY_INVALID")
    if getattr(sr,"entry_ready_admitted_by_update014",None) is not True: raise FinalEntryObservationAuthorityBlock("UPDATE014_ADMISSION_REQUIRED")
    u12,u13,u14=(_stage(sr,x) for x in ("UPDATE-012","UPDATE-013","UPDATE-014"))
    if any(_text(getattr(x,"state",None))!="PASS" for x in (u12,u13,u14)): raise FinalEntryObservationAuthorityBlock("FINAL_ENTRY_STAGES_NOT_PASS")
    p12,p13,p14=_payload(u12),_payload(u13),_payload(u14)
    direction=_enum_value(_one(_one(p12,"risk_feasibility"),"direction"))
    emitted=_one(p13,"semantic_entry_ready_emitted"); ref=_one(p13,"entry_ready_id"); c13=_one(p13,"information_cutoff")
    if emitted is not True or not isinstance(ref,str) or not ref: raise FinalEntryObservationAuthorityBlock("UPDATE013_ENTRY_READY_REQUIRED")
    if c13!=cutoff: raise FinalEntryObservationAuthorityBlock("UPDATE013_CUTOFF_DRIFT")
    if not isinstance(p14,dict) or p14.get("entry_ready_ref")!=ref or p14.get("exit_same_cutoff") is not False: raise FinalEntryObservationAuthorityBlock("UPDATE014_ENTRY_READY_REF_DRIFT")
    return PostUpdate014CandidateObservationAuthorityV1(symbol,direction,cutoff,ref,tx,str(getattr(u13,"output_digest","")),str(getattr(u14,"output_digest","")))
def extract_admitted_authorities(batch_result):
    terminal=_text(getattr(batch_result,"terminal",None))
    if terminal not in ("COMMITTED","COMMITTED_WITH_BLOCKS"): raise FinalEntryObservationAuthorityBlock("AUTHORITATIVE_BATCH_NOT_COMMITTED")
    return tuple(extract_from_authoritative_symbol_result(sr) for sr in tuple(getattr(batch_result,"symbol_results",())) if getattr(sr,"entry_ready_admitted_by_update014",False) is True)
def invariants():
    return {"authority_source":"AUTHORITATIVE_CUTOFF_BATCH_RESULT_ONLY","direction_from_update012_risk_feasibility":True,"entry_ready_identity_from_update013":True,
    "update014_ref_must_equal_update013":True,"restart_recoverable_from_stage_payload_json":True,"manual_symbol_direction_cutoff_injection":False,
    "portfolio_allocation_authority_claimed":False,"selector_added":False,"ranking_added":False,"orders":0,"fills":0,"execution_intents":0,"trading_activated":False}
