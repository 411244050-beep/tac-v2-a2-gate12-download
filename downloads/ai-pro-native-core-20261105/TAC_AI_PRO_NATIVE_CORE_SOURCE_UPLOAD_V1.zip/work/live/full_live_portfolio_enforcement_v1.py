from __future__ import annotations
from dataclasses import dataclass
from decimal import Decimal
from typing import Iterable,Mapping,Sequence
from full_live_portfolio_policy_candidate_v1 import AllocationCandidateV1, cutoff_rotated_canonical_order

class PortfolioEnforcementBlock(RuntimeError): pass

@dataclass(frozen=True)
class PortfolioCapacityCandidateV1:
    candidate:AllocationCandidateV1
    structural_risk_quote:Decimal

def enforce_direction_factor_budget(*,direction:str,current_direction_risk:Decimal,candidate_risk:Decimal,
                                    factor_cap_quote:Decimal,authority:str)->Mapping[str,object]:
    if not authority: raise PortfolioEnforcementBlock("FACTOR_AUTHORITY_REQUIRED")
    if direction.upper() not in ("LONG","SHORT"): raise PortfolioEnforcementBlock("DIRECTION_INVALID")
    vals=(current_direction_risk,candidate_risk,factor_cap_quote)
    if any(not isinstance(x,Decimal) or not x.is_finite() or x<0 for x in vals): raise PortfolioEnforcementBlock("RISK_DECIMAL_INVALID")
    passed=current_direction_risk+candidate_risk<=factor_cap_quote
    return {"state":"PASS" if passed else "FAIL","factor":"SYSTEMIC_DIRECTION_"+direction.upper(),
            "projected_risk_quote":str(current_direction_risk+candidate_risk),"authority":authority}

def allocate_with_capacity(*,candidates:Iterable[PortfolioCapacityCandidateV1],capacity_quote:Decimal,
                           frozen_universe:Sequence[str],information_cutoff:int,authority:str)->tuple[AllocationCandidateV1,...]:
    if not authority: raise PortfolioEnforcementBlock("PORT007_AUTHORITY_REQUIRED")
    if not isinstance(capacity_quote,Decimal) or not capacity_quote.is_finite() or capacity_quote<0:
        raise PortfolioEnforcementBlock("CAPACITY_INVALID")
    rows=tuple(candidates)
    if any((not isinstance(r.structural_risk_quote,Decimal) or not r.structural_risk_quote.is_finite() or r.structural_risk_quote<=0) for r in rows):
        raise PortfolioEnforcementBlock("CANDIDATE_RISK_INVALID")
    by={(r.candidate.symbol,r.candidate.transaction_id):r for r in rows}
    ordered=cutoff_rotated_canonical_order((r.candidate for r in rows),frozen_universe=frozen_universe,information_cutoff=information_cutoff)
    admitted=[]; remaining=capacity_quote
    for c in ordered:
        risk=by[(c.symbol,c.transaction_id)].structural_risk_quote
        if risk>remaining:
            break
        admitted.append(c); remaining-=risk
    return tuple(admitted)

def invariants():
    return {"status":"MECHANICS_ONLY_REQUIRES_FROZEN_AUTHORITY","signal_score_used":False,"historical_performance_used":False,
      "pnl_used":False,"thresholds_owned":False,"risk_size_backfill_optimization":False,"scarce_capacity_prefix_only":True,"orders":0,"fills":0,"execution_intents":0,"trading_activated":False}
