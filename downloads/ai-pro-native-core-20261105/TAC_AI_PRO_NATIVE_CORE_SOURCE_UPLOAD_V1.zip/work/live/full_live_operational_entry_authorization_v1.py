from __future__ import annotations
from dataclasses import dataclass

class OperationalEntryAuthorizationBlock(RuntimeError): pass
PRODUCTION_ISSUER="TAC_FULL_LIVE_PRODUCTION_OPERATIONAL_AUTHORIZATION_V1"

@dataclass(frozen=True)
class OperationalEntryAuthorizationV1:
    state:str
    authority_version:str
    evidence_id:str
    policy_status:str
    issuer:str=""
    authority_digest:str=""
    enforcement_digest:str=""
    subject_symbol:str=""
    subject_entry_ready_id:str=""
    subject_information_cutoff:int|None=None
    batch_evidence_id:str=""
    execution_binding_digest:str=""
    def assert_pass(self,*,require_production_issuer:bool=False)->None:
        if self.state!="PASS": raise OperationalEntryAuthorizationBlock("OPERATIONAL_ENTRY_NOT_PASS")
        if self.policy_status!="FROZEN": raise OperationalEntryAuthorizationBlock("OPERATIONAL_POLICY_NOT_FROZEN")
        if not self.authority_version or not self.evidence_id: raise OperationalEntryAuthorizationBlock("OPERATIONAL_AUTHORITY_PROVENANCE_REQUIRED")
        if require_production_issuer:
            if self.issuer!=PRODUCTION_ISSUER: raise OperationalEntryAuthorizationBlock("PRODUCTION_OPERATIONAL_ISSUER_REQUIRED")
            if not self.authority_digest.startswith("SHA256:") or not self.enforcement_digest.startswith("SHA256:"):
                raise OperationalEntryAuthorizationBlock("PRODUCTION_OPERATIONAL_DIGESTS_REQUIRED")
            if not self.subject_symbol or not self.subject_entry_ready_id:
                raise OperationalEntryAuthorizationBlock("PRODUCTION_OPERATIONAL_SUBJECT_REQUIRED")
            if not isinstance(self.subject_information_cutoff,int) or self.subject_information_cutoff<0:
                raise OperationalEntryAuthorizationBlock("PRODUCTION_OPERATIONAL_SUBJECT_CUTOFF_INVALID")

def invariants():
    return {"frozen_policy_required":True,"pass_required":True,"evidence_required":True,
      "runtime_requires_production_issuer":True,"authority_and_enforcement_digests_required":True,
      "production_authorization_subject_required":True,
      "batch_and_execution_binding_required_by_strict_production_verifier":True,
      "orders":0,"fills":0,"execution_intents":0,"trading_activated":False}
