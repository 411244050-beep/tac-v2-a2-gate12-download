from __future__ import annotations
from typing import Callable,Any
from binance_usdm_public_depth_snapshot_v1 import acquire_usdm_public_depth_snapshot
from full_live_execution_feasibility_measurement_v1 import measure_execution_feasibility
from full_live_prospective_execution_evidence_v1 import build_prospective_execution_evidence
from full_live_final_entry_observation_authority_v1 import PostUpdate014CandidateObservationAuthorityV1
from full_live_durable_execution_evidence_ledger_v1 import DurableExecutionEvidenceLedgerV1
class PostUpdate014ObservationBlock(RuntimeError): pass
class PostUpdate014ExecutionObserverV1:
    def __init__(self,*,ledger:DurableExecutionEvidenceLedgerV1,collector_started_at_ms:int,public_get:Callable[...,Any],clock_ms:Callable[[],int],clock_authority:str,depth_limit:int=100):
        if collector_started_at_ms<=0 or not clock_authority: raise PostUpdate014ObservationBlock("OBSERVER_PROVENANCE_REQUIRED")
        if not isinstance(ledger,DurableExecutionEvidenceLedgerV1): raise PostUpdate014ObservationBlock("DURABLE_LEDGER_REQUIRED")
        self.ledger=ledger; self.start=collector_started_at_ms; self.public_get=public_get; self.clock_ms=clock_ms; self.clock_authority=clock_authority; self.depth_limit=depth_limit
    def observe(self,*,authority:PostUpdate014CandidateObservationAuthorityV1,intended_quote_notional:str,recovery_existing_only:bool=False):
        if not isinstance(authority,PostUpdate014CandidateObservationAuthorityV1): raise PostUpdate014ObservationBlock("FINAL_ENTRY_OBSERVATION_AUTHORITY_REQUIRED")
        prior=self.ledger.get_by_entry_ready(authority.entry_ready_ref)
        if prior is not None:
            # Restart uses an existing durable read-only depth sample.
            # EntryReady ID alone is insufficient authority: an ID collision
            # must not recycle evidence for another symbol/side/cutoff/size.
            self._require_source_binding(
                authority=authority,
                evidence=prior,
                intended_quote_notional=intended_quote_notional,
            )
            return prior
        if recovery_existing_only:
            # After restart an old adopted cutoff is not a prospective
            # depth request. Never backfill it with a new present-time book.
            raise PostUpdate014ObservationBlock(
                "RECOVERY_MISSING_DURABLE_EXECUTION_EVIDENCE_NO_BACKFILL"
            )
        request_started_at_ms=int(self.clock_ms())
        depth=acquire_usdm_public_depth_snapshot(symbol=authority.symbol,limit=self.depth_limit,public_get=self.public_get)
        observed=int(self.clock_ms())
        if observed<request_started_at_ms: raise PostUpdate014ObservationBlock("OBSERVER_CLOCK_NON_MONOTONIC")
        m=measure_execution_feasibility(symbol=authority.symbol,direction=authority.direction,intended_quote_notional=intended_quote_notional,order_book=depth.measurement_book())
        e=build_prospective_execution_evidence(entry_ready_id=authority.entry_ready_ref,information_cutoff=authority.information_cutoff,observed_at_ms=observed,
          collector_started_at_ms=self.start,clock_authority=self.clock_authority,depth=depth,measurement=m)
        # Exact same source binding is mandatory for a freshly observed
        # read-only snapshot before it is appended durably.
        self._require_source_binding(
            authority=authority,
            evidence=e,
            intended_quote_notional=intended_quote_notional,
        )
        self.ledger.append(e); return e

    @staticmethod
    def _require_source_binding(*, authority, evidence, intended_quote_notional):
        from full_live_prospective_execution_evidence_v1 import validate_prospective_execution_evidence
        try:
            validate_prospective_execution_evidence(evidence)
        except Exception as exc:
            raise PostUpdate014ObservationBlock("SOURCE_EVIDENCE_INTEGRITY_DRIFT") from exc
        if evidence.entry_ready_id != authority.entry_ready_ref:
            raise PostUpdate014ObservationBlock("SOURCE_ENTRY_READY_DRIFT")
        if evidence.symbol != authority.symbol:
            raise PostUpdate014ObservationBlock("SOURCE_SYMBOL_DRIFT")
        if evidence.direction != authority.direction:
            raise PostUpdate014ObservationBlock("SOURCE_DIRECTION_DRIFT")
        if evidence.information_cutoff != authority.information_cutoff:
            raise PostUpdate014ObservationBlock("SOURCE_CUTOFF_DRIFT")
        if evidence.intended_quote_notional != str(intended_quote_notional):
            raise PostUpdate014ObservationBlock("SOURCE_INTENDED_NOTIONAL_DRIFT")

def invariants():
    return {"position":"POST_UPDATE014_PRE_OPERATIONAL_AUTHORIZATION","authoritative_batch_lineage_required":True,"restart_duplicate_depth_read_prevented":True,
      "observation_failure_changes_strategy_state":False,"observed_at_is_response_receipt_time":True,"public_read_only":True,"orders":0,"fills":0,"execution_intents":0,"trading_activated":False}
