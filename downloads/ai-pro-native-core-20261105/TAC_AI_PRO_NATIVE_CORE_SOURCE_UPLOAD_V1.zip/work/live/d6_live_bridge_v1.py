from __future__ import annotations

from dataclasses import fields, is_dataclass
from typing import Any, Mapping

from strategy_rc1.d6_position_execution.position import StrategyPositionRegistry
from strategy_rc1.d6_position_execution.types import (
    FrozenEntryProvenance,
    StrategyPositionSnapshot,
)


class D6LiveBridgeBlock(RuntimeError):
    pass


_FROZEN_ENTRY_REQUIRED = {
    "provenance_class",
    "entry_ready_id",
    "entry_ready_cutoff",
    "symbol",
    "direction",
    "trend_episode_id",
    "opportunity_id",
    "market_event_id",
    "entry_boundary_unit_id",
    "risk_anchor_id",
    "risk_anchor_pivot_id",
    "risk_anchor_layer",
    "risk_anchor_price",
    "risk_anchor_scale",
    "risk_anchor_confirmed_at",
    "risk_anchor_timeframe_ms",
    "canonical_segment_id",
    "strategy_entry_reference_price",
    "initial_hard_stop_state",
    "initial_hard_stop_numeric",
}


def _field_names(cls: type[Any]) -> set[str]:
    if not is_dataclass(cls):
        raise D6LiveBridgeBlock("TARGET_IS_NOT_DATACLASS:" + cls.__name__)
    return {f.name for f in fields(cls)}


def build_frozen_entry_provenance(
    *,
    fields_from_tac: Mapping[str, Any],
    provenance: Mapping[str, str] | None = None,
) -> FrozenEntryProvenance:
    """Build the authoritative D6 entry lineage without reinterpreting enums.

    Every Strategy-owned value must already come from TAC. This bridge adds no
    selector, direction rule, layer rule, state coercion, or synthetic price.
    """
    supplied = dict(fields_from_tac)
    keys = set(supplied)

    missing = sorted(_FROZEN_ENTRY_REQUIRED - keys)
    extra = sorted(keys - _FROZEN_ENTRY_REQUIRED)
    if missing:
        raise D6LiveBridgeBlock(
            "FROZEN_ENTRY_REQUIRED_FIELDS_MISSING:" + ",".join(missing)
        )
    if extra:
        raise D6LiveBridgeBlock(
            "FROZEN_ENTRY_UNEXPECTED_FIELDS:" + ",".join(extra)
        )

    supplied["provenance"] = dict(provenance or {})

    allowed = _field_names(FrozenEntryProvenance)
    if set(supplied) != allowed:
        raise D6LiveBridgeBlock(
            "FROZEN_ENTRY_CONSTRUCTOR_DRIFT:"
            + " expected="
            + ",".join(sorted(allowed))
            + " supplied="
            + ",".join(sorted(supplied))
        )

    try:
        return FrozenEntryProvenance(**supplied)
    except Exception as exc:
        raise D6LiveBridgeBlock(
            "FROZEN_ENTRY_CONSTRUCTION_FAILED:"
            + exc.__class__.__name__
            + ":"
            + str(exc)
        ) from exc


def activate_authoritative_position(
    *,
    position_id: str,
    entry: FrozenEntryProvenance,
    execution_evidence_id: str,
    opened_real_time: Any,
    mode: Any,
    latest_qualified_protective_pivot: Any,
    current_protective_stop: Any,
    observer_label: Any = None,
    provenance: Mapping[str, str] | None = None,
) -> StrategyPositionSnapshot:
    """Create a real D6 Position only from confirmed external execution."""
    if not position_id:
        raise D6LiveBridgeBlock("POSITION_ID_REQUIRED")
    if not execution_evidence_id:
        raise D6LiveBridgeBlock("EXECUTION_EVIDENCE_ID_REQUIRED")
    if opened_real_time is None:
        raise D6LiveBridgeBlock("OPENED_REAL_TIME_REQUIRED")

    try:
        out = StrategyPositionSnapshot(
            position_id=position_id,
            entry=entry,
            opened_from_execution_evidence_id=execution_evidence_id,
            opened_real_time=opened_real_time,
            mode=mode,
            latest_qualified_protective_pivot=latest_qualified_protective_pivot,
            current_protective_stop=current_protective_stop,
            observer_label=observer_label,
            closed_exit_id=None,
            provenance=dict(provenance or {}),
        )
    except Exception as exc:
        raise D6LiveBridgeBlock(
            "D6_POSITION_CONSTRUCTION_FAILED:"
            + exc.__class__.__name__
            + ":"
            + str(exc)
        ) from exc

    if out.opened_from_execution_evidence_id != execution_evidence_id:
        raise D6LiveBridgeBlock("EXECUTION_EVIDENCE_NOT_PRESERVED")
    if out.opened_real_time != opened_real_time:
        raise D6LiveBridgeBlock("OPENED_REAL_TIME_NOT_PRESERVED")
    if out.closed_exit_id is not None:
        raise D6LiveBridgeBlock("NEW_POSITION_CANNOT_START_CLOSED")

    return out


def register_authoritative_position(
    *,
    registry: StrategyPositionRegistry,
    position: StrategyPositionSnapshot,
) -> None:
    """Use the original D6 POSITION-001/002/003 firewall unchanged."""
    try:
        registry.register(position)
    except Exception as exc:
        raise D6LiveBridgeBlock(
            "D6_POSITION_REGISTER_FAILED:"
            + exc.__class__.__name__
            + ":"
            + str(exc)
        ) from exc


def active_authoritative_position(
    *,
    registry: StrategyPositionRegistry,
    symbol: str,
) -> StrategyPositionSnapshot | None:
    return registry.active(symbol)


def close_authoritative_position(
    *,
    registry: StrategyPositionRegistry,
    position_id: str,
    exit_id: str,
) -> StrategyPositionSnapshot:
    if not exit_id:
        raise D6LiveBridgeBlock("EXIT_ID_REQUIRED")
    try:
        return registry.close(position_id, exit_id)
    except Exception as exc:
        raise D6LiveBridgeBlock(
            "D6_POSITION_CLOSE_FAILED:"
            + exc.__class__.__name__
            + ":"
            + str(exc)
        ) from exc


def run_update_010(
    *,
    update_010_callable: Any,
    kwargs: Mapping[str, Any],
) -> Any:
    """Invoke the original D6 UPDATE-010 implementation unchanged."""
    if not callable(update_010_callable):
        raise D6LiveBridgeBlock("UPDATE010_NOT_CALLABLE")
    try:
        return update_010_callable(**dict(kwargs))
    except Exception as exc:
        raise D6LiveBridgeBlock(
            "D6_UPDATE010_FAILED:"
            + exc.__class__.__name__
            + ":"
            + str(exc)
        ) from exc
