from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable, Mapping

from full_live_d6_hard_protection_evidence_v1 import (
    D6HardProtectionProjectionV1,
    produce_hard_protection_evidence,
)
from full_live_d6_protective_pivot_evidence_v1 import (
    D6ProtectivePivotProjectionV1,
    produce_d6_protective_pivot_evidence,
)
from full_live_d6_protective_rawv6_input_v1 import (
    D6ProtectiveRawV6InputsV1,
    project_d6_protective_inputs_from_final_rawv6_state,
)
from full_live_d6_strategy_evidence_binding_v1 import (
    D6StrategyEvidenceBindingV1,
    build_d6_strategy_cutoff_input,
)
from strategy_rc1.d6_position_execution.parameters import (
    d6_parameter_view,
)
from strategy_rc1.d6_position_execution.types import (
    ExitCandidateEvidence,
    StrategyPositionSnapshot,
)
from strategy_rc1.parameter_snapshot import (
    current_partial_parameter_snapshot,
)


class FullLiveD6ProductionCutoffInputBlock(RuntimeError):
    pass


@dataclass(frozen=True)
class D6ProductionCutoffInputV1:
    strategy: D6StrategyEvidenceBindingV1
    rawv6_inputs: D6ProtectiveRawV6InputsV1
    protective: D6ProtectivePivotProjectionV1
    hard_protection: D6HardProtectionProjectionV1
    provenance: Mapping[str, str]


def build_d6_production_cutoff_input(
    *,
    symbol_result: Any,
    final_rawv6_state: str,
    position: StrategyPositionSnapshot,
    exchange_position_snapshot: Any,
    exchange_open_orders: Any,
    ledger_rows: Iterable[Mapping[str, Any]],
    exit_candidate_evidence: ExitCandidateEvidence | None = None,
) -> D6ProductionCutoffInputV1:
    if not isinstance(position, StrategyPositionSnapshot):
        raise FullLiveD6ProductionCutoffInputBlock(
            "STRATEGY_POSITION_SNAPSHOT_REQUIRED"
        )
    cutoff = int(getattr(symbol_result, "information_cutoff", -1))
    symbol = str(getattr(symbol_result, "symbol", ""))
    if cutoff <= 0 or symbol != position.entry.symbol:
        raise FullLiveD6ProductionCutoffInputBlock(
            "D6_PRODUCTION_SUBJECT_OR_CUTOFF_DRIFT"
        )

    params = d6_parameter_view(
        current_partial_parameter_snapshot()
    )

    hard = produce_hard_protection_evidence(
        position=position,
        information_cutoff=cutoff,
        exchange_position_snapshot=exchange_position_snapshot,
        exchange_open_orders=exchange_open_orders,
        ledger_rows=tuple(ledger_rows),
    )

    base = build_d6_strategy_cutoff_input(
        symbol_result=symbol_result,
        position=position,
        hard_protection=hard.evidence,
        exit_candidate_evidence=exit_candidate_evidence,
        parameter_view=params,
    )
    trend_thesis = (
        base.cutoff_input
        .protective_pivot_evidence
        .trend_thesis_intact
    )

    raw_inputs = (
        project_d6_protective_inputs_from_final_rawv6_state(
            final_rawv6_state=final_rawv6_state,
            position=position,
            information_cutoff=cutoff,
        )
    )

    protective = produce_d6_protective_pivot_evidence(
        position=position,
        information_cutoff=cutoff,
        current_canonical_segment_id=(
            raw_inputs.current_canonical_segment_id
        ),
        confirmed_minor_pivots=(
            raw_inputs.confirmed_minor_pivots
        ),
        closed_prices=raw_inputs.closed_prices,
        theta_progress=params.theta_progress,
        trend_thesis_intact=trend_thesis,
    )

    final = build_d6_strategy_cutoff_input(
        symbol_result=symbol_result,
        position=position,
        hard_protection=hard.evidence,
        protective_pivot_evidence=protective.evidence,
        exit_candidate_evidence=exit_candidate_evidence,
        parameter_view=params,
    )

    base_semantics = (
        base.canonical_continuity_state,
        base.protected_intermediate_structure_state,
        base.trend_episode_end_cause,
        base.new_adverse_pivot_id,
    )
    final_semantics = (
        final.canonical_continuity_state,
        final.protected_intermediate_structure_state,
        final.trend_episode_end_cause,
        final.new_adverse_pivot_id,
    )
    if base_semantics != final_semantics:
        raise FullLiveD6ProductionCutoffInputBlock(
            "PROTECTIVE_COMPOSITION_CHANGED_BASE_D6_SEMANTICS"
        )

    return D6ProductionCutoffInputV1(
        strategy=final,
        rawv6_inputs=raw_inputs,
        protective=protective,
        hard_protection=hard,
        provenance={
            "binding": "TAC_FULL_LIVE_D6_PRODUCTION_CUTOFF_INPUT_V1",
            "symbol": symbol,
            "information_cutoff": str(cutoff),
            "strategy_base_semantics_preserved": "true",
            "hard_protection_read_only": "true",
            "rawv6_prospective_state_only": "true",
            "new_numeric_threshold": "false",
            "new_selector": "false",
            "ranking_added": "false",
        },
    )


def invariants() -> Mapping[str, object]:
    return {
        "hard_protection": (
            "EXCHANGE_READ_PLUS_DURABLE_TRIGGER_EVIDENCE"
        ),
        "strategy_base": "UPDATE001_UPDATE005_UPDATE006",
        "protective_structure": (
            "FROZEN_LOCAL_TREND_CONTROL_REGAIN"
        ),
        "rawv6_source": "CURRENT_ADOPTED_CUTOFF_FINAL_STATE",
        "base_d6_semantics_preserved_after_protective_composition": True,
        "historical_outcome_read": False,
        "pnl_read": False,
        "new_numeric_threshold": False,
        "new_selector": False,
        "ranking_added": False,
        "orders": 0,
        "fills": 0,
        "execution_intents": 0,
        "trading_activated": False,
    }


__all__ = [
    "D6ProductionCutoffInputV1",
    "FullLiveD6ProductionCutoffInputBlock",
    "build_d6_production_cutoff_input",
    "invariants",
]
