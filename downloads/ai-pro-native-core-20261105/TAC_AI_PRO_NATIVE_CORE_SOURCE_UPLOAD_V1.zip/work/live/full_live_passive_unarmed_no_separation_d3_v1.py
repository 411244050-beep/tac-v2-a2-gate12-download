"""Frozen D3-only continuation for nonconsumable B3 pending/neutral cohorts.

Engineering bridge for frozen Runtime-B3's explicit non-return state. This
produces *no* D4, D5 authorization, entry opportunity, or synthetic return.
Requires each prebar snapshot to be passive, newly armed, or armed but not
yet qualified, with no consumable return. Active, qualified and unknown
states remain fail-closed.
No external IO, no new strategy selectors, thresholds, or windows.
"""
from __future__ import annotations

import os
from typing import Any

import minimal_runnable_v1_baseline as minimal
import nontrading_adapter_integration_v1 as frozen
import authoritative_d3_d4_evidence_packet_assembler_resumption_v2 as assembler
import d1_d2_to_d3_candidate_production_v1 as candidate_prod
import runtime_b3_price_driven_return_production_state_v1 as b3prod
import live_runtime_authority_extraction_packet_orchestration_binding_v3 as live
import live_runtime_raw_authority_extraction_packet_orchestration_binding_v6 as v6
import live_runtime_raw_authority_extraction_packet_orchestration_binding_v7 as v7

from strategy_rc1.d3_boundary_intelligence.types import InteractionControl
from strategy_rc1.d2_market_state.types import TrendDirection


class PassiveUnarmedD3Block(RuntimeError):
    pass


def run_passive_unarmed_no_separation_d3(
    runtime: v6.LiveRuntimeRawAuthorityOrchestrationV6,
    bar: Any,
) -> v6.RawV6CutoffResult:
    # This narrowly scoped new engineering lane has no live-activation
    # authority until a source-bound whole-universe E2E and safety audit.
    # A future operator setting TAC_LIVE_ENABLED must not silently promote it.
    if os.environ.get("TAC_LIVE_ENABLED", "").lower() not in ("", "0", "false"):
        raise PassiveUnarmedD3Block("PASSIVE_D3_LANE_NOT_VALIDATED_FOR_LIVE")
    if not isinstance(runtime, v6.LiveRuntimeRawAuthorityOrchestrationV6):
        raise PassiveUnarmedD3Block("RUNTIME_SCHEMA")
    if runtime.state.last_cutoff is not None and bar.close_time <= runtime.state.last_cutoff:
        raise PassiveUnarmedD3Block("NON_PROSPECTIVE_CUTOFF")
    before = runtime.export_state()
    adapter_before = runtime._adapter()
    durable_d3 = adapter_before._d3_rebuild(bar.symbol)
    prebar = durable_d3.update_000_pre_bar_view(bar.open_time)
    snapshots = tuple(sorted(prebar.snapshots, key=lambda x: x.snapshot_id))
    if not snapshots:
        raise PassiveUnarmedD3Block("CAUSAL_PREBAR_REQUIRED")

    # The frozen raw pass is a disposable preflight, never an extra durable
    # mutation. All geometry, trends, pivots and candidates remain original.
    raw_adapter, _, _, raw_sr, raw_cache = runtime._raw_shadow(bar)
    trend = raw_cache.d2.update_006_trend
    if (
        trend.episode_id is None
        or trend.episode_start_cutoff is None
        or trend.episode_start_cutoff >= bar.close_time
        or trend.direction not in (TrendDirection.LONG, TrendDirection.SHORT)
    ):
        raise PassiveUnarmedD3Block("MATURE_TREND_REQUIRED")
    segment = (
        raw_sr.canonical_segment_id
        or raw_adapter._state(bar.symbol).last_canonical_segment_id
    )
    if not segment:
        raise PassiveUnarmedD3Block("CANONICAL_SEGMENT_REQUIRED")
    geometries = v7._geometry_map(raw_cache.d3_geometry)
    if set(geometries) != set(v7._snapshot_ids(prebar)):
        raise PassiveUnarmedD3Block("D3_GEOMETRY_PREBAR_SET_DRIFT")

    # Fail closed on any durable active interaction or platform confirmation,
    # and on unaccounted-for records: this is a no-D4 bridge, not an
    # alternative route for any actionable surface.
    events = v6._event_rows(durable_d3)
    by_candidate = v7._event_by_candidate(events)
    passive_target_ids = {snap.candidate_id for snap in snapshots}
    # Frozen D3 may retain a wrong-side observation without ever arming
    # the interaction. This is a negative source state, not return evidence.
    inert_break_states = frozenset(("NONE", "WRONG_SIDE_UNARMED"))
    bad_events = tuple(
        e for e in events
        if e.candidate_id in passive_target_ids and (
            e.control not in (InteractionControl.UNARMED, InteractionControl.ARMED)
            or (
                e.control is InteractionControl.ARMED
                and getattr(e.break_state, "value", e.break_state) != "NONE"
            )
            or e.started_at is not None
            or e.terminal
            or e.attempted_wrong_side_acceptance
            or getattr(e.break_state, "value", e.break_state) not in inert_break_states
        )
    )
    if bad_events:
        first = bad_events[0]
        # Diagnostic is strictly synthetic/source-bound: log typed state,
        # not the private account or any market data.
        raise PassiveUnarmedD3Block(
            "DURABLE_INTERACTION_NOT_PASSIVE:"
            + "control=" + str(getattr(first.control, "value", first.control))
            + ";started=" + str(first.started_at is not None)
            + ";terminal=" + str(first.terminal)
            + ";wrong_side=" + str(first.attempted_wrong_side_acceptance)
            + ";break=" + str(getattr(first.break_state, "value", first.break_state))
        )
    platform_state = repr(dict(runtime.state.platform_state))
    if "PLATFORM_CONFIRMED" in platform_state:
        raise PassiveUnarmedD3Block("POTENTIALLY_ACTIVE_PLATFORM")

    candidate_rt = candidate_prod.D1D2D3CandidateProductionRuntimeV1.restore_state(
        runtime.state.candidate_state
    )
    import full_live_generic_active_d4_production_binding_v1 as active
    observations = active._runtime_b3_observations(
        bar=bar, pre_snaps=snapshots,
        event_by_candidate=by_candidate,
        durable_candidates=dict(candidate_rt.state.candidates),
        geometries=geometries, trend=trend, segment=segment,
        params=frozen.frozen_d3_parameters(
            minimal.current_partial_parameter_snapshot()
        ),
    )
    b3_rt = b3prod.RuntimeB3PriceDrivenReturnProducerV1.restore_state(
        runtime.state.b3_state
    )
    b3_results = b3_rt.process_batch(raw_sr.transaction_id + ":B3", observations)
    if len(b3_results) != len(snapshots):
        raise PassiveUnarmedD3Block("B3_COUNT_DRIFT")
    b3_by_snapshot = {x.snapshot_ref: x for x in b3_results}
    if set(b3_by_snapshot) != {s.snapshot_id for s in snapshots}:
        raise PassiveUnarmedD3Block("B3_SNAPSHOT_ID_DRIFT")
    new_arm_candidate_ids = set()
    prequalification_candidate_ids = set()
    for snap in snapshots:
        g = geometries[snap.snapshot_id]
        ev = by_candidate.get(snap.candidate_id)
        b3 = b3_by_snapshot[snap.snapshot_id]
        if ev is None or b3.candidate_id != snap.candidate_id:
            raise PassiveUnarmedD3Block("B3_EVENT_IDENTITY_DRIFT")
        if (
            b3.return_evidence is not None
            or b3.latched_evidence is not None
            or b3.continuity_resolution is not None
        ):
            raise PassiveUnarmedD3Block("INERT_B3_HAS_CONSUMABLE_EVIDENCE")
        if b3.reason == "UNARMED_NO_SEPARATION":
            if (ev.control is not InteractionControl.UNARMED
                    or g.separated is not False or b3.pending_lineage is not None):
                raise PassiveUnarmedD3Block("PASSIVE_B3_SEPARATION_OR_PENDING_DRIFT")
        elif b3.reason == "ARMED_FROZEN_CURRENT_CUTOFF_NO_RETURN":
            pending = b3.pending_lineage
            if (
                ev.control is not InteractionControl.UNARMED
                or g.separated is not True
                or pending is None
                or pending.symbol != bar.symbol
                or pending.candidate_id != snap.candidate_id
                or pending.arming_information_cutoff != bar.close_time
                or pending.last_observed_information_cutoff != bar.close_time
                or pending.evidence is not None
                or pending.qualifying_return_information_cutoff is not None
            ):
                raise PassiveUnarmedD3Block("NEW_ARM_B3_PENDING_LINEAGE_INVALID")
            new_arm_candidate_ids.add(snap.candidate_id)
        elif b3.reason == "RETURN_NOT_YET_QUALIFIED":
            pending = b3.pending_lineage
            if (
                ev.control is not InteractionControl.ARMED
                or getattr(ev.break_state, "value", ev.break_state) != "NONE"
                or pending is None
                or pending.symbol != bar.symbol
                or pending.candidate_id != snap.candidate_id
                or pending.evidence is not None
                or pending.qualifying_return_information_cutoff is not None
                or pending.first_eligible_return_information_cutoff is None
                or pending.first_eligible_return_information_cutoff > bar.close_time
                or pending.last_observed_information_cutoff != bar.close_time
                or pending.arming_information_cutoff >= bar.close_time
            ):
                raise PassiveUnarmedD3Block("PREQUALIFICATION_PENDING_LINEAGE_INVALID")
            prequalification_candidate_ids.add(snap.candidate_id)
        else:
            raise PassiveUnarmedD3Block("NONCONSUMABLE_B3_REASON_NOT_SUPPORTED:" + b3.reason)

    # Both candidate and D3 projections are from the frozen source. No
    # fabricated B4 or confirmation; the frozen engine itself must decide
    # UPDATE-007..014. No D4 or D5 packet is produced or injected.
    candidate_output = candidate_rt.project_candidate_updates(
        candidate_prod.CandidateProductionRequest(
            transaction_id=raw_sr.transaction_id + ":CANDIDATE",
            symbol=bar.symbol,
            information_cutoff=bar.close_time,
            d1=raw_cache.d1,
            target_trend=trend,
            interaction_events=events,
        )
    )
    snap_projection = tuple(
        live.snapshot_projection_from_authoritative_producers(
            snapshot_ref=snap.snapshot_id,
            runtime_b3_result=b3_by_snapshot[snap.snapshot_id],
            structural_acceptance=None,
            correct_side_recovery=None,
            source_evidence_refs=(
                "CausalBoundarySnapshot:" + snap.snapshot_id,
                "RuntimeB3:" + b3_by_snapshot[snap.snapshot_id].reason + ":" + snap.candidate_id,
            ),
            provenance={
                "producer_id": "FULL_LIVE_PASSIVE_UNARMED_NO_SEPARATION_D3_V1",
                "no_b4_or_d4_authority": "true",
            },
        )
        for snap in snapshots
    )
    initial_authority = live.initial_authority_from_frozen_producers(
        candidate_result=candidate_output, snapshot_projections=snap_projection
    )
    # Pure frozen assembler initial packet, not a D4-ready 'complete'.
    packet = assembler.assemble_initial_cutoff_packet(initial_authority)
    if packet.d4 is not None or getattr(packet, "d5", None) is not None:
        raise PassiveUnarmedD3Block("PASSIVE_CANNOT_CARRY_D4_D5")

    formal_adapter = runtime._adapter()
    formal_ledger = runtime._ledger()
    session = v6._PreassembledPacketSession(formal_adapter, packet, packet)
    engine = minimal.DeterministicCutoffEngine(
        adapters=session.registry(), ledger=formal_ledger
    )
    result = engine.run_cutoff_batch((runtime._input(bar),))
    term = getattr(result.terminal, "value", result.terminal)
    if term != "COMMITTED":
        raise PassiveUnarmedD3Block("FROZEN_PASSIVE_ENGINE_NOT_COMMITTED:" + str(term))
    rows = tuple(result.symbol_results)
    if len(rows) != 1 or rows[0].transaction_id != raw_sr.transaction_id:
        raise PassiveUnarmedD3Block("PASSIVE_TRANSACTION_ID_DRIFT")
    stages = {
        getattr(x.step, "value", x.step): x
        for x in tuple(rows[0].stages)
    }
    for name in ("UPDATE-011", "UPDATE-012", "UPDATE-013", "UPDATE-014"):
        stage = stages.get(name)
        if stage is None or getattr(stage.state, "value", stage.state) not in ("N/A", "NA"):
            raise PassiveUnarmedD3Block("PASSIVE_PRODUCED_ACTIONABLE_STAGE:" + name)
    if getattr(rows[0], "entry_ready_admitted_by_update014", None) is True:
        raise PassiveUnarmedD3Block("PASSIVE_MUST_NEVER_ADMIT_ENTRY")
    if (
        tuple(session.initial_steps) != live.INITIAL_VISIBLE_STEPS
        or tuple(session.final_steps) != live.FINAL_VISIBLE_STEPS
    ):
        raise PassiveUnarmedD3Block("STAGED_PACKET_VISIBILITY_DRIFT")

    # Check the frozen formal post-D3 controls. A current geometry.TEST
    # alone cannot change a no-separation passive interaction into ACTIVE.
    result_d3 = formal_adapter._d3_rebuild(bar.symbol)
    snapshot_ids = {s.candidate_id for s in snapshots}
    for ev in v6._event_rows(result_d3):
        if ev.candidate_id not in snapshot_ids:
            continue
        frozen_break = getattr(ev.break_state, "value", ev.break_state)
        is_authorized_nonconsumable_armed_control = (
            ev.candidate_id in (new_arm_candidate_ids | prequalification_candidate_ids)
            and ev.control is InteractionControl.ARMED
            and frozen_break == "NONE"
        )
        if (
            (ev.control is not InteractionControl.UNARMED and not is_authorized_nonconsumable_armed_control)
            or ev.started_at is not None
            or ev.terminal
            or ev.attempted_wrong_side_acceptance
            or frozen_break not in inert_break_states
        ):
            raise PassiveUnarmedD3Block("NONCONSUMABLE_FORMAL_INTERACTION_ESCALATION")

    if runtime.export_state() != before:
        raise PassiveUnarmedD3Block("WORKING_PRESTATE_MUTATED")
    next_snapshots = dict(runtime.state.next_snapshots)
    if rows[0].next_bar_snapshot is not None:
        next_snapshots[rows[0].symbol] = rows[0].next_bar_snapshot
    completed = dict(runtime.state.completed)
    produced = v6.RawV6CutoffResult(
        mode=(
            "FULL_LIVE_NONCONSUMABLE_PREQUALIFICATION_D3_ONLY"
            if prequalification_candidate_ids
            else (
                "FULL_LIVE_NONCONSUMABLE_NEW_ARM_D3_ONLY"
                if new_arm_candidate_ids
                else "FULL_LIVE_PASSIVE_UNARMED_NO_SEPARATION_D3_ONLY"
            )
        ),
        engine_result=result,
        trend_episode_id=trend.episode_id,
        relation=None,
        prebar_snapshot_count=len(snapshots),
        final_packet_digest=assembler.digest(packet),
        persistent_state_committed=True,
        provenance={
            "binding_id": "FULL_LIVE_PASSIVE_UNARMED_NO_SEPARATION_D3_V1",
            "frozen_b3_source": "PASSIVE_NEW_ARM_OR_PREQUALIFICATION_NO_RETURN",
            "new_arm_count": str(len(new_arm_candidate_ids)),
            "prequalification_count": str(len(prequalification_candidate_ids)),
            "b4_action": "NONE",
            "d4_authority": "NONE",
            "new_strategy_science": "false",
            "trading": "FORBIDDEN",
        },
    )
    completed[f"{bar.symbol}:{bar.close_time}"] = (
        live.digest(bar), produced
    )
    runtime.state = v6.RawV6State(
        adapter_state=formal_adapter.export_state(),
        ledger_events=formal_ledger.snapshot(),
        next_snapshots=next_snapshots,
        assembler_state=runtime.state.assembler_state,
        lineage_state=runtime.state.lineage_state,
        candidate_state=candidate_rt.export_state(),
        b3_state=b3_rt.export_state(),
        b5_state=runtime.state.b5_state,
        platform_state=runtime.state.platform_state,
        minor_history=v6._append_pivots(
            runtime.state.minor_history, tuple(raw_cache.d2.update_005_minor)
        ),
        intermediate_history=v6._append_pivots(
            runtime.state.intermediate_history,
            tuple(raw_cache.d2.update_005_intermediate)
        ),
        completed=completed,
        last_cutoff=bar.close_time,
    )
    return produced
