from __future__ import annotations

import os
from dataclasses import dataclass
from decimal import Decimal

from operational_parameter_snapshot_v1 import load_operational_parameters


@dataclass(frozen=True)
class FullLivePolicyV1:
    leverage: int = 1
    notional_per_new_position_usdt: Decimal = Decimal("0")
    theta_stop: Decimal = Decimal("0")
    multiple_symbols_allowed: bool = True
    same_symbol_pyramiding: bool = False
    one_initial_entry_per_opportunity: bool = True
    stop_widening_allowed: bool = False

    @classmethod
    def from_env(cls) -> "FullLivePolicyV1":
        leverage = int(os.environ.get("TAC_LIVE_LEVERAGE", "1"))
        if leverage != 1:
            raise RuntimeError("TAC_FULL_LIVE_V1_REQUIRES_INITIAL_1X_LEVERAGE")

        raw_notional = os.environ.get("TAC_LIVE_NOTIONAL_USDT")
        if raw_notional is None:
            raise RuntimeError("TAC_LIVE_NOTIONAL_USDT_REQUIRED")
        notional = Decimal(raw_notional)
        if notional <= 0:
            raise RuntimeError("LIVE_NOTIONAL_MUST_BE_POSITIVE")

        params = load_operational_parameters()
        theta = params["theta_stop"]
        if theta <= 0:
            raise RuntimeError("THETA_STOP_MUST_BE_POSITIVE")

        return cls(
            leverage=leverage,
            notional_per_new_position_usdt=notional,
            theta_stop=theta,
        )


def initial_hard_stop(
    *,
    direction: str,
    risk_anchor_price: Decimal,
    atr_at_risk_reference: Decimal,
    theta_stop: Decimal,
) -> Decimal:
    if atr_at_risk_reference <= 0 or theta_stop <= 0:
        raise ValueError("HARD_STOP_INPUT_MUST_BE_POSITIVE")
    d = direction.upper()
    if d == "LONG":
        return risk_anchor_price - theta_stop * atr_at_risk_reference
    if d == "SHORT":
        return risk_anchor_price + theta_stop * atr_at_risk_reference
    raise ValueError("UNSUPPORTED_DIRECTION:" + direction)


def protective_stop_can_move(
    *,
    direction: str,
    current_stop: Decimal,
    proposed_stop: Decimal,
) -> bool:
    d = direction.upper()
    if d == "LONG":
        return proposed_stop > current_stop
    if d == "SHORT":
        return proposed_stop < current_stop
    raise ValueError("UNSUPPORTED_DIRECTION:" + direction)
