from __future__ import annotations

from dataclasses import dataclass
import json
from typing import Mapping, Sequence

from d2_to_b4_d4_causal_evidence_producers_v1 import (
    ClosedPriceObservation,
    EvidenceState,
    LineageContext,
    LocalTrendControlRegainRequest,
    produce_local_trend_control_regain,
    projection_to_info_value,
)
from strategy_rc1.d2_market_state.types import (
    PivotType,
    StructuralLayer,
    StructuralPivot,
    TrendDirection,
)
from strategy_rc1.d6_position_execution.types import (
    ProtectivePivotEvidence,
    StrategyPositionSnapshot,
)
from strategy_rc1.runtime_guards.information_state import InfoValue


class FullLiveD6ProtectivePivotEvidenceBlock(RuntimeError):
    pass


@dataclass(frozen=True)
class D6ProtectivePivotProjectionV1:
    evidence: ProtectivePivotEvidence
    state: str
    reason: str
    fixed_reference_pivot_id: str | None
    candidate_protective_pivot_id: str | None
    local_regain_confirmation_cutoff: int | None
    provenance: Mapping[str, str]


def _adverse(direction: TrendDirection) -> PivotType:
    if direction is TrendDirection.LONG:
        return PivotType.LOW
    if direction is TrendDirection.SHORT:
        return PivotType.HIGH
    raise FullLiveD6ProtectivePivotEvidenceBlock(
        "POSITION_DIRECTION_NOT_LONG_SHORT"
    )


def _by_id(
    rows: Sequence[StructuralPivot],
) -> dict[str, StructuralPivot]:
    out: dict[str, StructuralPivot] = {}
    for pivot in rows:
        old = out.get(pivot.pivot_id)
        if old is not None and old != pivot:
            raise FullLiveD6ProtectivePivotEvidenceBlock(
                "DIVERGENT_DUPLICATE_MINOR_PIVOT:"
                + pivot.pivot_id
            )
        out[pivot.pivot_id] = pivot
    return out


def _validate_reference(
    *,
    pivot: StructuralPivot,
    position: StrategyPositionSnapshot,
) -> None:
    entry = position.entry
    if (
        pivot.symbol != entry.symbol
        or pivot.timeframe_ms != 15 * 60 * 1000
        or pivot.layer is not StructuralLayer.MINOR
        or pivot.pivot_type is not _adverse(entry.direction)
        or pivot.canonical_segment_id
        != entry.canonical_segment_id
    ):
        raise FullLiveD6ProtectivePivotEvidenceBlock(
            "FIXED_PROTECTIVE_REFERENCE_LINEAGE_DRIFT"
        )
    if not pivot.provenance:
        raise FullLiveD6ProtectivePivotEvidenceBlock(
            "FIXED_PROTECTIVE_REFERENCE_PROVENANCE_REQUIRED"
        )


def _fixed_reference(
    *,
    position: StrategyPositionSnapshot,
    minor_by_id: Mapping[str, StructuralPivot],
) -> StructuralPivot | None:
    current = position.latest_qualified_protective_pivot
    if current is not None:
        _validate_reference(
            pivot=current,
            position=position,
        )
        durable = minor_by_id.get(current.pivot_id)
        if durable is None or durable != current:
            raise FullLiveD6ProtectivePivotEvidenceBlock(
                "CURRENT_PROTECTIVE_REFERENCE_NOT_IN_D2_HISTORY"
            )
        return current

    entry = position.entry
    if entry.risk_anchor_layer is not StructuralLayer.MINOR:
        return None
    pivot = minor_by_id.get(entry.risk_anchor_pivot_id)
    if pivot is None:
        raise FullLiveD6ProtectivePivotEvidenceBlock(
            "ENTRY_MINOR_RISK_ANCHOR_NOT_IN_D2_HISTORY"
        )
    _validate_reference(
        pivot=pivot,
        position=position,
    )
    frozen_checks = {
        "price": (
            pivot.extreme_price,
            entry.risk_anchor_price,
        ),
        "scale": (
            pivot.scale_at_extreme,
            entry.risk_anchor_scale,
        ),
        "confirmed_at": (
            pivot.confirmed_at,
            entry.risk_anchor_confirmed_at,
        ),
        "timeframe_ms": (
            pivot.timeframe_ms,
            entry.risk_anchor_timeframe_ms,
        ),
    }
    for name, (actual, expected) in frozen_checks.items():
        if actual != expected:
            raise FullLiveD6ProtectivePivotEvidenceBlock(
                "ENTRY_RISK_ANCHOR_D2_HISTORY_DRIFT:" + name
            )
    return pivot


def _candidate_from_projection(
    *,
    projection,
    reference: StructuralPivot,
    by_id: Mapping[str, StructuralPivot],
) -> StructuralPivot | None:
    raw = projection.provenance.get("source_pivot_ids")
    if not raw:
        return None
    try:
        ids = tuple(str(x) for x in json.loads(raw))
    except Exception as exc:
        raise FullLiveD6ProtectivePivotEvidenceBlock(
            "LOCAL_REGAIN_SOURCE_PIVOT_IDS_INVALID"
        ) from exc
    if len(ids) < 3:
        return None
    if ids[0] != reference.pivot_id:
        raise FullLiveD6ProtectivePivotEvidenceBlock(
            "LOCAL_REGAIN_REFERENCE_SOURCE_DRIFT"
        )
    candidate = by_id.get(ids[-1])
    if candidate is None:
        raise FullLiveD6ProtectivePivotEvidenceBlock(
            "LOCAL_REGAIN_CANDIDATE_NOT_IN_D2_HISTORY"
        )
    return candidate


def produce_d6_protective_pivot_evidence(
    *,
    position: StrategyPositionSnapshot,
    information_cutoff: int,
    current_canonical_segment_id: str | None,
    confirmed_minor_pivots: Sequence[StructuralPivot],
    closed_prices: Sequence[ClosedPriceObservation],
    theta_progress,
    trend_thesis_intact: InfoValue[bool],
) -> D6ProtectivePivotProjectionV1:
    if not isinstance(position, StrategyPositionSnapshot):
        raise FullLiveD6ProtectivePivotEvidenceBlock(
            "STRATEGY_POSITION_SNAPSHOT_REQUIRED"
        )
    entry = position.entry
    by_id = _by_id(tuple(confirmed_minor_pivots))
    reference = _fixed_reference(
        position=position,
        minor_by_id=by_id,
    )
    if reference is None:
        evidence = ProtectivePivotEvidence(
            adverse_minor_pivot=None,
            material_favorable_post_entry_progress=(
                InfoValue.unknown()
            ),
            trade_thesis_intact=InfoValue.unknown(),
            trend_thesis_intact=trend_thesis_intact,
            local_trend_control_regained=InfoValue.unknown(),
            provenance={
                "authority": (
                    "TAC_FULL_LIVE_D6_PROTECTIVE_PIVOT_"
                    "EVIDENCE_V1"
                ),
                "reason": (
                    "ENTRY_RISK_ANCHOR_NOT_MINOR_"
                    "NO_FIXED_MINOR_REFERENCE"
                ),
            },
        )
        return D6ProtectivePivotProjectionV1(
            evidence=evidence,
            state="UNKNOWN",
            reason="NO_FROZEN_MINOR_REFERENCE",
            fixed_reference_pivot_id=None,
            candidate_protective_pivot_id=None,
            local_regain_confirmation_cutoff=None,
            provenance={"selector_added": "false"},
        )

    continuity_known = current_canonical_segment_id is not None
    continuity_intact = (
        continuity_known
        and current_canonical_segment_id
        == entry.canonical_segment_id
    )
    ctx = LineageContext(
        symbol=entry.symbol,
        target_trend_episode_id=entry.trend_episode_id,
        direction=entry.direction,
        information_cutoff=information_cutoff,
        canonical_segment_id=entry.canonical_segment_id,
        source_evidence_refs=(
            "D6Position:" + position.position_id,
            "FixedProtectiveReference:" + reference.pivot_id,
        ),
        continuity_known=continuity_known,
        continuity_intact=continuity_intact,
        same_cutoff_order_proven=True,
    )
    result = produce_local_trend_control_regain(
        LocalTrendControlRegainRequest(
            context=ctx,
            pivots=tuple(confirmed_minor_pivots),
            adverse_reference_pivot_id=reference.pivot_id,
            theta_progress=theta_progress,
            closed_prices=tuple(closed_prices),
        )
    )
    consumer = result.consumer_evidence
    candidate = _candidate_from_projection(
        projection=result,
        reference=reference,
        by_id=by_id,
    )

    confirmation = (
        None
        if consumer is None
        else int(consumer.confirmation_cutoff)
    )
    if (
        confirmation is not None
        and confirmation <= entry.entry_ready_cutoff
    ):
        evidence = ProtectivePivotEvidence(
            adverse_minor_pivot=None,
            material_favorable_post_entry_progress=(
                InfoValue.unknown()
            ),
            trade_thesis_intact=InfoValue.unknown(),
            trend_thesis_intact=trend_thesis_intact,
            local_trend_control_regained=InfoValue.unknown(),
            provenance={
                "authority": (
                    "TAC_FULL_LIVE_D6_PROTECTIVE_PIVOT_"
                    "EVIDENCE_V1"
                ),
                "reason": (
                    "PRE_ENTRY_LOCAL_REGAIN_NOT_REUSABLE_FOR_D6"
                ),
            },
        )
        return D6ProtectivePivotProjectionV1(
            evidence=evidence,
            state="UNKNOWN",
            reason="PRE_ENTRY_LOCAL_REGAIN_IGNORED",
            fixed_reference_pivot_id=reference.pivot_id,
            candidate_protective_pivot_id=None,
            local_regain_confirmation_cutoff=confirmation,
            provenance={"post_entry_required": "true"},
        )

    if consumer is None:
        material = InfoValue.unknown()
        trade_intact = InfoValue.unknown()
    else:
        material = (
            consumer.material_original_direction_closed_price_recovery
        )
        trade_intact = (
            consumer.countertrend_progression_failed
        )

    local_regain = projection_to_info_value(result)
    evidence = ProtectivePivotEvidence(
        adverse_minor_pivot=(
            candidate
            if result.state in (
                EvidenceState.TRUE,
                EvidenceState.FALSE,
            )
            else None
        ),
        material_favorable_post_entry_progress=material,
        trade_thesis_intact=trade_intact,
        trend_thesis_intact=trend_thesis_intact,
        local_trend_control_regained=local_regain,
        provenance={
            "authority": (
                "TAC_FULL_LIVE_D6_PROTECTIVE_PIVOT_"
                "EVIDENCE_V1"
            ),
            "source_producer": result.producer,
            "source_reason": result.reason,
            "fixed_reference_pivot_id": reference.pivot_id,
            "post_entry_required": "true",
            "new_numeric_threshold": "false",
            "new_selector": "false",
        },
    )
    return D6ProtectivePivotProjectionV1(
        evidence=evidence,
        state=result.state.value,
        reason=result.reason,
        fixed_reference_pivot_id=reference.pivot_id,
        candidate_protective_pivot_id=(
            None if candidate is None else candidate.pivot_id
        ),
        local_regain_confirmation_cutoff=confirmation,
        provenance={
            "frozen_local_regain_semantic_reused": "true",
            "post_entry_causality_enforced": "true",
            "selector_added": "false",
            "ranking_added": "false",
        },
    )


def invariants() -> Mapping[str, object]:
    return {
        "fixed_reference": (
            "CURRENT_QUALIFIED_PROTECTIVE_PIVOT_"
            "ELSE_ENTRY_MINOR_RISK_ANCHOR"
        ),
        "local_regain_semantic": (
            "D2_TO_B4_D4_CAUSAL_EVIDENCE_PRODUCER_V1"
        ),
        "post_entry_confirmation_required": True,
        "intermediate_entry_anchor_without_minor_reference": (
            "UNKNOWN"
        ),
        "new_numeric_threshold": False,
        "new_selector": False,
        "ranking_added": False,
        "orders": 0,
        "fills": 0,
        "execution_intents": 0,
        "trading_activated": False,
    }


__all__ = [
    "D6ProtectivePivotProjectionV1",
    "FullLiveD6ProtectivePivotEvidenceBlock",
    "produce_d6_protective_pivot_evidence",
    "invariants",
]
