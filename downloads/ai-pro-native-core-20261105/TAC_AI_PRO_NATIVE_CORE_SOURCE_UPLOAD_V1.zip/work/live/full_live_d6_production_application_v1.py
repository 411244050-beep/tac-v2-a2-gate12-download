from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping

from full_live_d6_production_cutoff_input_v1 import (
    D6ProductionCutoffInputV1,
    build_d6_production_cutoff_input,
)
from strategy_rc1.d6_position_execution.engine import update_010
from strategy_rc1.d6_position_execution.types import StrategyPositionSnapshot


class FullLiveD6ProductionApplicationBlock(RuntimeError):
    pass


@dataclass(frozen=True)
class PreparedD6PositionCutoffV1:
    symbol: str
    position_id: str
    information_cutoff: int
    position_before: StrategyPositionSnapshot
    projection: D6ProductionCutoffInputV1
    preflight_view: Any


@dataclass(frozen=True)
class D6ProductionApplicationBatchV1:
    information_cutoff: int
    prepared: tuple[PreparedD6PositionCutoffV1, ...]
    application_results: tuple[Any, ...]
    provenance: Mapping[str, str]


def _symbol_results(candidate: Any) -> dict[str, Any]:
    authoritative = getattr(candidate, "authoritative_batch_result", None)
    rows = tuple(getattr(authoritative, "symbol_results", ()))
    out: dict[str, Any] = {}
    for row in rows:
        symbol = str(getattr(row, "symbol", "") or "")
        if not symbol:
            raise FullLiveD6ProductionApplicationBlock(
                "AUTHORITATIVE_SYMBOL_RESULT_SYMBOL_REQUIRED"
            )
        if symbol in out:
            raise FullLiveD6ProductionApplicationBlock(
                "AUTHORITATIVE_SYMBOL_RESULT_DUPLICATE:" + symbol
            )
        out[symbol] = row
    return out


def _exchange_reader(runtime: Any, exchange_reader: Any | None) -> Any:
    if exchange_reader is not None:
        return exchange_reader
    executor = getattr(runtime, "executor", None)
    reader = getattr(executor, "binance", None)
    if reader is None:
        raise FullLiveD6ProductionApplicationBlock(
            "BINANCE_READONLY_EXCHANGE_READER_REQUIRED"
        )
    return reader


def prepare_active_d6_cutoff_batch(
    *,
    runtime: Any,
    candidate: Any,
    exchange_reader: Any | None = None,
) -> tuple[PreparedD6PositionCutoffV1, ...]:
    store = getattr(runtime, "store", None)
    ledger = getattr(runtime, "ledger", None)
    if store is None or not hasattr(store, "active_positions"):
        raise FullLiveD6ProductionApplicationBlock(
            "AUTHORITATIVE_D6_POSITION_STORE_REQUIRED"
        )
    if ledger is None or not hasattr(ledger, "read_all"):
        raise FullLiveD6ProductionApplicationBlock(
            "TRADE_LEDGER_REQUIRED"
        )

    cutoff = int(getattr(candidate, "cutoff", -1))
    final_rawv6_state = getattr(candidate, "final_rawv6_state", None)
    if cutoff <= 0 or not isinstance(final_rawv6_state, str):
        raise FullLiveD6ProductionApplicationBlock(
            "COLLECTOR_CANDIDATE_CUTOFF_OR_RAWV6_STATE_INVALID"
        )

    positions = tuple(store.active_positions())
    if not positions:
        return ()

    by_symbol = _symbol_results(candidate)
    reader = _exchange_reader(runtime, exchange_reader)
    for name in ("position_snapshot", "open_orders", "algo_open_orders"):
        if not callable(getattr(reader, name, None)):
            raise FullLiveD6ProductionApplicationBlock(
                "EXCHANGE_READER_METHOD_REQUIRED:" + name
            )

    # Acquire all exchange reads before any D6 mutation/exchange application.
    # Algo open orders are account-wide in the current Binance adapter and are
    # intentionally read exactly once per cutoff.
    try:
        algo_orders = reader.algo_open_orders()
    except Exception as exc:
        raise FullLiveD6ProductionApplicationBlock(
            "D6_ALGO_OPEN_ORDER_READ_FAILED:"
            + exc.__class__.__name__
            + ":"
            + str(exc)
        ) from exc

    ledger_rows = tuple(ledger.read_all())
    observations: dict[str, tuple[Any, Any]] = {}
    for position in positions:
        if not isinstance(position, StrategyPositionSnapshot):
            raise FullLiveD6ProductionApplicationBlock(
                "ACTIVE_POSITION_TYPED_SNAPSHOT_REQUIRED"
            )
        symbol = position.entry.symbol
        if symbol in observations:
            raise FullLiveD6ProductionApplicationBlock(
                "MULTIPLE_ACTIVE_POSITIONS_SAME_SYMBOL:" + symbol
            )
        if symbol not in by_symbol:
            raise FullLiveD6ProductionApplicationBlock(
                "ACTIVE_POSITION_SYMBOL_MISSING_FROM_CURRENT_BATCH:" + symbol
            )
        row = by_symbol[symbol]
        if int(getattr(row, "information_cutoff", -1)) != cutoff:
            raise FullLiveD6ProductionApplicationBlock(
                "ACTIVE_POSITION_SYMBOL_RESULT_CUTOFF_DRIFT:" + symbol
            )
        try:
            position_snapshot = reader.position_snapshot(symbol)
            standard_orders = reader.open_orders(symbol)
        except Exception as exc:
            raise FullLiveD6ProductionApplicationBlock(
                "D6_EXCHANGE_READ_FAILED:"
                + symbol
                + ":"
                + exc.__class__.__name__
                + ":"
                + str(exc)
            ) from exc
        observations[symbol] = (
            position_snapshot,
            (standard_orders, algo_orders),
        )

    prepared: list[PreparedD6PositionCutoffV1] = []
    for position in positions:
        symbol = position.entry.symbol
        position_snapshot, open_orders = observations[symbol]
        projection = build_d6_production_cutoff_input(
            symbol_result=by_symbol[symbol],
            final_rawv6_state=final_rawv6_state,
            position=position,
            exchange_position_snapshot=position_snapshot,
            exchange_open_orders=open_orders,
            ledger_rows=ledger_rows,
        )
        inp = projection.strategy.cutoff_input
        if inp.position != position:
            raise FullLiveD6ProductionApplicationBlock(
                "D6_INPUT_POSITION_DRIFT:" + symbol
            )
        if inp.information_cutoff != cutoff:
            raise FullLiveD6ProductionApplicationBlock(
                "D6_INPUT_CUTOFF_DRIFT:" + symbol
            )
        try:
            view = update_010(inp)
        except Exception as exc:
            raise FullLiveD6ProductionApplicationBlock(
                "D6_PURE_UPDATE010_PREFLIGHT_FAILED:"
                + symbol
                + ":"
                + exc.__class__.__name__
                + ":"
                + str(exc)
            ) from exc
        if str(getattr(view, "position_id", "")) != position.position_id:
            raise FullLiveD6ProductionApplicationBlock(
                "D6_PREFLIGHT_POSITION_ID_DRIFT:" + symbol
            )
        if int(getattr(view, "information_cutoff", -1)) != cutoff:
            raise FullLiveD6ProductionApplicationBlock(
                "D6_PREFLIGHT_CUTOFF_DRIFT:" + symbol
            )
        prepared.append(
            PreparedD6PositionCutoffV1(
                symbol=symbol,
                position_id=position.position_id,
                information_cutoff=cutoff,
                position_before=position,
                projection=projection,
                preflight_view=view,
            )
        )

    return tuple(prepared)


def apply_active_d6_cutoff_batch(
    *,
    runtime: Any,
    candidate: Any,
    exchange_reader: Any | None = None,
) -> D6ProductionApplicationBatchV1:
    prepared = prepare_active_d6_cutoff_batch(
        runtime=runtime,
        candidate=candidate,
        exchange_reader=exchange_reader,
    )
    cutoff = int(getattr(candidate, "cutoff", -1))

    # Recheck the complete active-position set immediately before the first
    # application. No pure input/composition error may cause a partial D6
    # application across symbols.
    store = getattr(runtime, "store", None)
    current = tuple(store.active_positions())
    expected = tuple(row.position_before for row in prepared)
    if current != expected:
        raise FullLiveD6ProductionApplicationBlock(
            "ACTIVE_POSITION_SET_CHANGED_AFTER_D6_PREFLIGHT"
        )

    apply = getattr(runtime, "apply_d6_cutoff", None)
    if not callable(apply):
        raise FullLiveD6ProductionApplicationBlock(
            "RUNTIME_APPLY_D6_CUTOFF_REQUIRED"
        )

    results: list[Any] = []
    for row in prepared:
        # This is the first mutation/exchange-capable point. All symbols have
        # already passed exchange-read, typed composition, and pure UPDATE-010
        # validation. Any failure here stops the batch immediately.
        result = apply(
            inp=row.projection.strategy.cutoff_input,
        )
        results.append(result)

    return D6ProductionApplicationBatchV1(
        information_cutoff=cutoff,
        prepared=prepared,
        application_results=tuple(results),
        provenance={
            "binding": "TAC_FULL_LIVE_D6_PRODUCTION_APPLICATION_V1",
            "two_phase_compose_before_apply": "true",
            "all_active_positions_require_current_cutoff_symbol_result": "true",
            "all_exchange_reads_before_first_application": "true",
            "pure_update010_preflight_before_first_application": "true",
            "selector_added": "false",
            "ranking_added": "false",
            "historical_backfill": "false",
        },
    )


def invariants() -> Mapping[str, object]:
    return {
        "active_position_source": "AUTHORITATIVE_D6_POSITION_STORE",
        "strategy_source": "CURRENT_PROSPECTIVE_COLLECTOR_BATCH_CANDIDATE",
        "rawv6_source": "CURRENT_PROSPECTIVE_FINAL_RAWV6_STATE",
        "exchange_position_observation": "READ_ONLY_BEFORE_APPLICATION",
        "exchange_open_order_observation": "READ_ONLY_BEFORE_APPLICATION",
        "two_phase_compose_before_apply": True,
        "pure_update010_preflight": True,
        "historical_outcome_read": False,
        "pnl_read": False,
        "new_selector": False,
        "ranking_added": False,
        "orders_created_by_preparation": 0,
        "execution_intents_created_by_preparation": 0,
    }


__all__ = [
    "D6ProductionApplicationBatchV1",
    "FullLiveD6ProductionApplicationBlock",
    "PreparedD6PositionCutoffV1",
    "apply_active_d6_cutoff_batch",
    "invariants",
    "prepare_active_d6_cutoff_batch",
]
