from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
import json
from typing import Any, Mapping

from strategy_rc1.d2_market_state.types import (
    PivotType,
    StructuralLayer,
    StructuralPivot,
    TrendDirection,
)
from strategy_rc1.d6_position_execution.engine import D6CutoffInput
from strategy_rc1.d6_position_execution.parameters import (
    D6ParameterView,
    d6_parameter_view,
)
from strategy_rc1.d6_position_execution.types import (
    ExitCandidateEvidence,
    HardProtectionEvidence,
    ProtectivePivotEvidence,
    StrategyPositionSnapshot,
    TrendEpisodeEndCause,
    TrendEpisodeEndEvidence,
)
from strategy_rc1.parameter_snapshot import current_partial_parameter_snapshot
from strategy_rc1.runtime_guards.information_state import InfoValue


class FullLiveD6StrategyEvidenceBindingBlock(RuntimeError):
    pass


@dataclass(frozen=True)
class D6StrategyEvidenceBindingV1:
    cutoff_input: D6CutoffInput
    canonical_continuity_state: str
    protected_intermediate_structure_state: str
    trend_episode_end_cause: str
    new_adverse_pivot_id: str | None
    provenance: Mapping[str, str]


def _state_text(value: Any) -> str:
    return str(getattr(value, "value", value))


def _stage(symbol_result: Any, step: str) -> Any:
    rows = [
        row
        for row in tuple(getattr(symbol_result, "stages", ()))
        if _state_text(getattr(row, "step", None)) == step
    ]
    if len(rows) != 1:
        raise FullLiveD6StrategyEvidenceBindingBlock(
            "STAGE_CARDINALITY:" + step
        )
    row = rows[0]
    if _state_text(getattr(row, "state", None)) not in ("PASS", "N/A"):
        raise FullLiveD6StrategyEvidenceBindingBlock(
            "STAGE_NOT_PASS_OR_NA:" + step
        )
    return row


def _decode(value: Any) -> Any:
    if isinstance(value, list):
        return [_decode(x) for x in value]
    if not isinstance(value, dict):
        return value
    if set(value) == {"__fraction__"}:
        raw = value["__fraction__"]
        if not isinstance(raw, list) or len(raw) != 2:
            raise FullLiveD6StrategyEvidenceBindingBlock(
                "FROZEN_FRACTION_ENCODING_INVALID"
            )
        return Fraction(int(raw[0]), int(raw[1]))
    return {str(k): _decode(v) for k, v in value.items()}


def _payload(stage: Any) -> Any:
    raw = getattr(stage, "payload_json", None)
    if not isinstance(raw, str):
        raise FullLiveD6StrategyEvidenceBindingBlock(
            "STAGE_PAYLOAD_JSON_REQUIRED"
        )
    try:
        return _decode(json.loads(raw))
    except FullLiveD6StrategyEvidenceBindingBlock:
        raise
    except Exception as exc:
        raise FullLiveD6StrategyEvidenceBindingBlock(
            "STAGE_PAYLOAD_DECODE_FAILED:"
            + exc.__class__.__name__
            + ":"
            + str(exc)
        ) from exc


def _mapping(value: Any, label: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise FullLiveD6StrategyEvidenceBindingBlock(
            label + "_MAPPING_REQUIRED"
        )
    return value


def _pivot_from_payload(value: Any, label: str) -> StructuralPivot:
    row = _mapping(value, label)
    try:
        pivot = StructuralPivot(
            pivot_id=str(row["pivot_id"]),
            symbol=str(row["symbol"]),
            timeframe_ms=int(row["timeframe_ms"]),
            layer=StructuralLayer(str(row["layer"])),
            pivot_type=PivotType(str(row["pivot_type"])),
            extreme_price=row["extreme_price"],
            extreme_first_time=int(row["extreme_first_time"]),
            extreme_last_time=int(row["extreme_last_time"]),
            confirmed_at=int(row["confirmed_at"]),
            scale_at_extreme=row["scale_at_extreme"],
            canonical_segment_id=str(row["canonical_segment_id"]),
            source_pivot_ids=tuple(
                str(x) for x in row.get("source_pivot_ids", ())
            ),
            provenance={
                str(k): str(v)
                for k, v in _mapping(
                    row.get("provenance", {}),
                    label + "_PROVENANCE",
                ).items()
            },
        )
    except FullLiveD6StrategyEvidenceBindingBlock:
        raise
    except Exception as exc:
        raise FullLiveD6StrategyEvidenceBindingBlock(
            label
            + "_CONSTRUCTION_FAILED:"
            + exc.__class__.__name__
            + ":"
            + str(exc)
        ) from exc
    if not pivot.pivot_id or not pivot.symbol:
        raise FullLiveD6StrategyEvidenceBindingBlock(
            label + "_IDENTITY_REQUIRED"
        )
    return pivot


def _current_new_adverse_minor(
    *,
    update005: Mapping[str, Any],
    position: StrategyPositionSnapshot,
    information_cutoff: int,
    current_segment: str | None,
) -> StructuralPivot | None:
    entry = position.entry
    adverse = (
        PivotType.LOW
        if entry.direction is TrendDirection.LONG
        else PivotType.HIGH
    )
    rows = []
    raw_minor = update005.get("minor", [])
    if not isinstance(raw_minor, list):
        raise FullLiveD6StrategyEvidenceBindingBlock(
            "UPDATE005_MINOR_LIST_REQUIRED"
        )
    for i, raw in enumerate(raw_minor):
        pivot = _pivot_from_payload(
            raw,
            "UPDATE005_MINOR_" + str(i),
        )
        if pivot.symbol != entry.symbol:
            continue
        if pivot.timeframe_ms != 15 * 60 * 1000:
            continue
        if pivot.layer is not StructuralLayer.MINOR:
            continue
        if pivot.pivot_type is not adverse:
            continue
        if pivot.confirmed_at != information_cutoff:
            continue
        if current_segment is None:
            continue
        if pivot.canonical_segment_id != current_segment:
            continue
        rows.append(pivot)
    if len(rows) > 1:
        raise FullLiveD6StrategyEvidenceBindingBlock(
            "MULTIPLE_NEW_ADVERSE_MINOR_PIVOTS_SAME_CUTOFF"
        )
    return rows[0] if rows else None


def _trend_and_structure_evidence(
    *,
    trend: Mapping[str, Any],
    position: StrategyPositionSnapshot,
    continuity: InfoValue[bool],
) -> tuple[
    InfoValue[bool],
    TrendEpisodeEndEvidence,
    InfoValue[bool],
]:
    entry = position.entry
    current_episode = trend.get("episode_id")
    terminal_episode = trend.get("terminal_episode_id")
    current_direction = str(trend.get("direction", ""))

    if continuity.value is False:
        return (
            InfoValue.unknown(),
            TrendEpisodeEndEvidence(
                ended=InfoValue.na(),
                cause=TrendEpisodeEndCause.GAP,
                provenance={
                    "authority": "CANONICAL_SEGMENT_DISCONTINUITY",
                },
            ),
            InfoValue.unknown(),
        )

    if terminal_episode == entry.trend_episode_id:
        return (
            InfoValue.known(True),
            TrendEpisodeEndEvidence(
                ended=InfoValue.known(True),
                cause=TrendEpisodeEndCause.STRUCTURAL_FAILURE,
                provenance={
                    "authority": "D2_TREND_EPISODE_TERMINAL_ID",
                    "terminal_episode_id": str(terminal_episode),
                },
            ),
            InfoValue.known(False),
        )

    if (
        current_episode == entry.trend_episode_id
        and current_direction == entry.direction.value
    ):
        return (
            InfoValue.known(False),
            TrendEpisodeEndEvidence(
                ended=InfoValue.known(False),
                cause=TrendEpisodeEndCause.NONE,
                provenance={
                    "authority": "D2_ACTIVE_TREND_EPISODE_ID",
                    "episode_id": str(current_episode),
                },
            ),
            InfoValue.known(True),
        )

    return (
        InfoValue.unknown(),
        TrendEpisodeEndEvidence(
            ended=InfoValue.unknown(),
            cause=TrendEpisodeEndCause.UNKNOWN,
            provenance={
                "authority": "D2_TREND_EPISODE_RELATION_UNRESOLVED",
                "current_episode_id": str(current_episode),
                "terminal_episode_id": str(terminal_episode),
            },
        ),
        InfoValue.unknown(),
    )


def build_d6_strategy_cutoff_input(
    *,
    symbol_result: Any,
    position: StrategyPositionSnapshot,
    hard_protection: HardProtectionEvidence,
    protective_pivot_evidence: ProtectivePivotEvidence | None = None,
    exit_candidate_evidence: ExitCandidateEvidence | None = None,
    parameter_view: D6ParameterView | None = None,
) -> D6StrategyEvidenceBindingV1:
    if not isinstance(position, StrategyPositionSnapshot):
        raise FullLiveD6StrategyEvidenceBindingBlock(
            "STRATEGY_POSITION_SNAPSHOT_REQUIRED"
        )
    if not isinstance(hard_protection, HardProtectionEvidence):
        raise FullLiveD6StrategyEvidenceBindingBlock(
            "TYPED_HARD_PROTECTION_EVIDENCE_REQUIRED"
        )

    symbol = str(getattr(symbol_result, "symbol", ""))
    cutoff = int(getattr(symbol_result, "information_cutoff", -1))
    if symbol != position.entry.symbol or cutoff <= 0:
        raise FullLiveD6StrategyEvidenceBindingBlock(
            "D6_SUBJECT_OR_CUTOFF_DRIFT"
        )

    u001 = _stage(symbol_result, "UPDATE-001")
    u005 = _mapping(
        _payload(_stage(symbol_result, "UPDATE-005")),
        "UPDATE005",
    )
    trend = _mapping(
        _payload(_stage(symbol_result, "UPDATE-006")),
        "UPDATE006",
    )

    current_segment = getattr(
        u001,
        "canonical_segment_id",
        None,
    )
    if current_segment is None:
        continuity = InfoValue.unknown()
        continuity_state = "UNKNOWN"
    else:
        continuity = InfoValue.known(
            str(current_segment)
            == position.entry.canonical_segment_id
        )
        continuity_state = (
            "KNOWN_TRUE"
            if continuity.value
            else "KNOWN_FALSE"
        )

    (
        protected_failed,
        trend_end,
        trend_thesis_intact,
    ) = _trend_and_structure_evidence(
        trend=trend,
        position=position,
        continuity=continuity,
    )

    new_adverse = _current_new_adverse_minor(
        update005=u005,
        position=position,
        information_cutoff=cutoff,
        current_segment=(
            None
            if current_segment is None
            else str(current_segment)
        ),
    )

    if protective_pivot_evidence is None:
        protective = ProtectivePivotEvidence(
            adverse_minor_pivot=new_adverse,
            material_favorable_post_entry_progress=InfoValue.unknown(),
            trade_thesis_intact=InfoValue.unknown(),
            trend_thesis_intact=trend_thesis_intact,
            local_trend_control_regained=InfoValue.unknown(),
            provenance={
                "authority": (
                    "TAC_FULL_LIVE_D6_STRATEGY_EVIDENCE_BINDING_V1"
                ),
                "protective_progress_authority": (
                    "UNRESOLVED_NO_FALSE_COERCION"
                ),
                "local_control_regain_authority": (
                    "UNRESOLVED_NO_FALSE_COERCION"
                ),
            },
        )
    else:
        if not isinstance(
            protective_pivot_evidence,
            ProtectivePivotEvidence,
        ):
            raise FullLiveD6StrategyEvidenceBindingBlock(
                "TYPED_PROTECTIVE_PIVOT_EVIDENCE_REQUIRED"
            )
        protective = protective_pivot_evidence
        if protective.trend_thesis_intact != trend_thesis_intact:
            raise FullLiveD6StrategyEvidenceBindingBlock(
                "PROTECTIVE_EVIDENCE_TREND_THESIS_DRIFT"
            )
        provenance = dict(protective.provenance or {})
        if not provenance.get("authority"):
            raise FullLiveD6StrategyEvidenceBindingBlock(
                "PROTECTIVE_EVIDENCE_AUTHORITY_REQUIRED"
            )
        candidate = protective.adverse_minor_pivot
        if candidate is not None:
            expected_adverse = (
                PivotType.LOW
                if position.entry.direction is TrendDirection.LONG
                else PivotType.HIGH
            )
            if (
                candidate.symbol != position.entry.symbol
                or candidate.timeframe_ms != 15 * 60 * 1000
                or candidate.layer is not StructuralLayer.MINOR
                or candidate.pivot_type is not expected_adverse
                or candidate.canonical_segment_id
                != position.entry.canonical_segment_id
            ):
                raise FullLiveD6StrategyEvidenceBindingBlock(
                    "PROTECTIVE_EVIDENCE_PIVOT_LINEAGE_DRIFT"
                )
            if (
                candidate.confirmed_at > cutoff
                or candidate.confirmed_at
                <= position.entry.entry_ready_cutoff
            ):
                raise FullLiveD6StrategyEvidenceBindingBlock(
                    "PROTECTIVE_EVIDENCE_PIVOT_CAUSALITY_DRIFT"
                )

    exits = (
        exit_candidate_evidence
        if exit_candidate_evidence is not None
        else ExitCandidateEvidence(
            management_anchor_true_break=InfoValue.unknown(),
            entry_risk_anchor_wrong_side_close=InfoValue.unknown(),
        )
    )
    if not isinstance(exits, ExitCandidateEvidence):
        raise FullLiveD6StrategyEvidenceBindingBlock(
            "TYPED_EXIT_CANDIDATE_EVIDENCE_REQUIRED"
        )

    params = (
        parameter_view
        if parameter_view is not None
        else d6_parameter_view(
            current_partial_parameter_snapshot()
        )
    )
    if not isinstance(params, D6ParameterView):
        raise FullLiveD6StrategyEvidenceBindingBlock(
            "TYPED_D6_PARAMETER_VIEW_REQUIRED"
        )

    inp = D6CutoffInput(
        information_cutoff=cutoff,
        position=position,
        protective_pivot_evidence=protective,
        new_adverse_pivot=new_adverse,
        protected_intermediate_structure_failed=protected_failed,
        supporting_trend_episode_end=trend_end,
        canonical_continuity_intact=continuity,
        hard_protection=hard_protection,
        exit_candidate_evidence=exits,
        parameters=params,
    )
    protected_state = (
        "KNOWN_TRUE"
        if protected_failed.value is True
        else "KNOWN_FALSE"
        if protected_failed.value is False
        else protected_failed.kind.value
    )
    return D6StrategyEvidenceBindingV1(
        cutoff_input=inp,
        canonical_continuity_state=continuity_state,
        protected_intermediate_structure_state=protected_state,
        trend_episode_end_cause=trend_end.cause.value,
        new_adverse_pivot_id=(
            None if new_adverse is None else new_adverse.pivot_id
        ),
        provenance={
            "strategy_source": (
                "UPDATE001_UPDATE005_UPDATE006"
            ),
            "hard_protection_source": (
                hard_protection.evidence_source
            ),
            "unknown_not_coerced_false": "true",
            "selector_added": "false",
            "ranking_added": "false",
        },
    )


def invariants() -> Mapping[str, object]:
    return {
        "strategy_sources": (
            "UPDATE-001",
            "UPDATE-005",
            "UPDATE-006",
        ),
        "new_adverse_pivot_scope": (
            "NEW_CURRENT_CUTOFF_MINOR_ADVERSE_ONLY"
        ),
        "canonical_gap_maps_to_degraded_protective_input": True,
        "hard_protection_requires_typed_external_evidence": True,
        "missing_protective_progress_evidence": (
            "UNKNOWN_NOT_FALSE"
        ),
        "typed_protective_evidence_override": True,
        "protective_evidence_subject_lineage_rechecked": True,
        "protective_evidence_post_entry_causality_rechecked": True,
        "missing_exit_candidate_evidence": "UNKNOWN_NOT_FALSE",
        "selector_added": False,
        "ranking_added": False,
        "orders": 0,
        "fills": 0,
        "execution_intents": 0,
        "trading_activated": False,
    }


__all__ = [
    "D6StrategyEvidenceBindingV1",
    "FullLiveD6StrategyEvidenceBindingBlock",
    "build_d6_strategy_cutoff_input",
    "invariants",
]
