from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping

from d6_live_bridge_v1 import D6LiveBridgeBlock, run_update_010


class D6ContinuationGuardBlock(RuntimeError):
    pass


@dataclass(frozen=True)
class D6ContinuationGuardResultV1:
    update_result: Any
    position_before: Any
    mode_text: str
    new_risk_blocked: bool
    structural_reference_advanced: bool
    numeric_stop_unchanged: bool


def _text(value: Any) -> str:
    raw = getattr(value, "value", value)
    return str(raw)


def _mode_text_from_view(view: Any) -> str:
    return _text(getattr(view, "position_mode", None))


def _confirmed_at(pivot: Any) -> Any:
    if pivot is None:
        return None
    return getattr(pivot, "confirmed_at", None)


def _qualified_pivot_from_view(view: Any) -> Any:
    qualified = getattr(view, "qualified_protective_pivot", None)
    if qualified is None:
        return None
    return getattr(qualified, "pivot", None)


def _info_value_has_known_payload(value: Any) -> bool:
    if value is None:
        return False

    kind = _text(getattr(value, "kind", None)).upper()
    payload = getattr(value, "value", None)

    # InfoValue KNOWN is the only state allowed to carry a usable value.
    if "KNOWN" in kind:
        return payload is not None

    # A plain/non-InfoValue numeric object would itself constitute numeric
    # authority leaking out of UPDATE-010.
    if not hasattr(value, "kind"):
        return True

    return False


def _assert_no_numeric_candidate_stop(view: Any) -> None:
    qualified = getattr(view, "qualified_protective_pivot", None)
    if qualified is None:
        return

    numeric = getattr(qualified, "numeric_candidate_stop", None)
    if _info_value_has_known_payload(numeric):
        raise D6ContinuationGuardBlock(
            "UPDATE010_NUMERIC_CANDIDATE_STOP_FORBIDDEN_WHILE_THETA_LOCKED"
        )


def _assert_parameter_view_locked(parameter_view: Any) -> None:
    state = _text(getattr(parameter_view, "theta_stop_state", None))
    if "LOCKED" not in state:
        raise D6ContinuationGuardBlock(
            "D6_THETA_STOP_STATE_NOT_LOCKED:" + state
        )

    exact = getattr(parameter_view, "theta_stop_exact_value", None)
    if exact is not None:
        raise D6ContinuationGuardBlock(
            "D6_THETA_STOP_NUMERIC_VALUE_FORBIDDEN"
        )

    if bool(
        getattr(
            parameter_view,
            "complete_strategy_parameter_snapshot",
            False,
        )
    ):
        raise D6ContinuationGuardBlock(
            "D6_COMPLETE_PARAMETER_SNAPSHOT_UNEXPECTED"
        )

    if bool(getattr(parameter_view, "runtime_usable", False)):
        raise D6ContinuationGuardBlock(
            "D6_RUNTIME_USABLE_UNEXPECTED"
        )


def run_structural_only_update_010(
    *,
    update_010_callable: Any,
    kwargs: Mapping[str, Any],
    position_before: Any,
    parameter_view: Any,
) -> D6ContinuationGuardResultV1:
    """Run frozen UPDATE-010 without manufacturing numeric stop authority.

    D6CutoffView is a decision view, not a replacement StrategyPositionSnapshot.
    While theta_stop is LOCKED, UPDATE-010 may advance the structural protective
    reference and change the decision mode, but it may not emit a usable numeric
    candidate stop.  This bridge performs no exchange I/O and does not translate
    the live operational initial-stop parameter into D6 authority.
    """

    _assert_parameter_view_locked(parameter_view)

    before_id = str(getattr(position_before, "position_id", "") or "")
    if not before_id:
        raise D6ContinuationGuardBlock("POSITION_ID_REQUIRED")

    before_mode = _text(getattr(position_before, "mode", None))
    if before_mode == "CLOSED":
        raise D6ContinuationGuardBlock(
            "CLOSED_POSITION_CANNOT_ENTER_UPDATE010"
        )

    before_pivot = getattr(
        position_before,
        "latest_qualified_protective_pivot",
        None,
    )

    try:
        result = run_update_010(
            update_010_callable=update_010_callable,
            kwargs=kwargs,
        )
    except D6LiveBridgeBlock:
        raise

    result_id = str(getattr(result, "position_id", "") or "")
    if result_id != before_id:
        raise D6ContinuationGuardBlock(
            "UPDATE010_POSITION_ID_DRIFT:"
            + before_id
            + ":"
            + result_id
        )

    _assert_no_numeric_candidate_stop(result)

    after_pivot = _qualified_pivot_from_view(result)
    before_confirmed = _confirmed_at(before_pivot)
    after_confirmed = _confirmed_at(after_pivot)

    structural_advanced = False
    if before_confirmed is None and after_confirmed is not None:
        structural_advanced = True
    elif (
        before_confirmed is not None
        and after_confirmed is not None
    ):
        if after_confirmed < before_confirmed:
            raise D6ContinuationGuardBlock(
                "UPDATE010_PROTECTIVE_REFERENCE_REGRESSION"
            )
        structural_advanced = after_confirmed > before_confirmed

    mode = _mode_text_from_view(result)
    blocked = bool(getattr(result, "new_risk_blocked", False))

    if mode == "DEGRADED_PROTECTIVE" and not blocked:
        raise D6ContinuationGuardBlock(
            "DEGRADED_PROTECTIVE_MUST_BLOCK_NEW_RISK"
        )
    if mode != "DEGRADED_PROTECTIVE" and blocked:
        raise D6ContinuationGuardBlock(
            "NEW_RISK_BLOCKED_MODE_DRIFT:" + mode
        )

    return D6ContinuationGuardResultV1(
        update_result=result,
        position_before=position_before,
        mode_text=mode,
        new_risk_blocked=blocked,
        structural_reference_advanced=structural_advanced,
        numeric_stop_unchanged=True,
    )


__all__ = [
    "D6ContinuationGuardBlock",
    "D6ContinuationGuardResultV1",
    "run_structural_only_update_010",
]
