from __future__ import annotations

"""Build same-cutoff full-live D5 evidence from one prepared 528-symbol row.

This module is a recovery/binding surface only.  It consumes:
- frozen UPDATE-011 D4 output,
- the prepared symbol's post-cutoff durable Raw-V6 state,
- the final D3/D4 evidence packet,
- the same Strategy observer-bar Close,
and reuses already-frozen D5 mechanism/risk-source producers.

It does not create D4 observations, select a mechanism, invent risk policy,
or touch execution.
"""

from fractions import Fraction
from pathlib import Path
import sys
from typing import Any, Mapping

from strategy_rc1.d4_opportunity.types import OpportunityMechanism
from strategy_rc1.runtime_guards.information_state import InfoValue

REPO_ROOT = Path(__file__).resolve().parents[2]
PROVISIONAL_ROOT = REPO_ROOT / "provisional_shadow_v1"
WORK_SRC = REPO_ROOT / "work" / "src"
for root in (PROVISIONAL_ROOT, WORK_SRC):
    if str(root) not in sys.path:
        sys.path.insert(0, str(root))

from multisymbol_impl import transactional_batch_staging_v1 as staging

import d4_market_event_lineage_production_binding_v2 as lineage_prod
import platform_failed_reexpansion_event_and_state_production_binding_v1 as platform_prod

from full_live_d5_batch_injection_v1 import D5InjectionBuildResultV1
from full_live_d5_deep_adverse_defense_v1 import (
    produce_deep_adverse_defense_authority,
)
from full_live_d5_operational_policy_v1 import build_operational_input_set
from full_live_d5_platform_adverse_defense_v1 import (
    produce_platform_adverse_defense_authority,
)
from full_live_d5_source_authority_builder_v1 import (
    D5PreparedSourceAuthorityV1,
    build_d5_from_explicit_source,
)


rawv6 = staging.rawv6


class FullLiveD5PreparedRowBuilderBlock(RuntimeError):
    pass


class FullLiveD5PreparedRowBuilderConflict(
    FullLiveD5PreparedRowBuilderBlock
):
    pass


def _canonical_continuity(
    *,
    runtime: Any,
    symbol: str,
    d4_view: Any,
    information_cutoff: int,
) -> InfoValue[bool]:
    opportunity = getattr(d4_view, "opportunity", None)
    if opportunity is None:
        return InfoValue.unknown()

    projector = lineage_prod.D4MarketEventLineageProductionProjectorV2.restore_state(
        runtime.state.lineage_state
    )
    ledger = projector.ledger_for(
        symbol,
        opportunity.trend_episode_id,
        opportunity.direction,
    )
    if ledger is None:
        return InfoValue.unknown()

    last = ledger.get("last_evaluated_cutoff")
    if last is None:
        return InfoValue.unknown()
    last = int(last)
    if last > information_cutoff:
        raise FullLiveD5PreparedRowBuilderConflict(
            "D4_LINEAGE_LEDGER_FROM_FUTURE"
        )
    if last < information_cutoff:
        return InfoValue.unknown()

    intact = ledger.get("coverage_intact")
    if not isinstance(intact, bool):
        raise FullLiveD5PreparedRowBuilderConflict(
            "D4_LINEAGE_COVERAGE_INTACT_NOT_BOOLEAN"
        )
    return InfoValue.known(intact)


def _current_segment(runtime: Any, symbol: str) -> str | None:
    segment = getattr(
        runtime._adapter()._state(symbol),
        "last_canonical_segment_id",
        None,
    )
    if segment is None:
        return None
    segment = str(segment)
    return segment or None


def _theta_progress() -> Fraction:
    snapshot = rawv6.minimal.current_partial_parameter_snapshot()
    params = rawv6.frozen.frozen_d3_parameters(snapshot)
    value = getattr(params, "theta_progress", None)
    if not isinstance(value, Fraction) or value <= 0:
        raise FullLiveD5PreparedRowBuilderConflict(
            "FROZEN_THETA_PROGRESS_AUTHORITY_DRIFT"
        )
    return value


def _fbr_recovery_projection(
    *,
    final_packet: Any,
    evidence: Any,
) -> Any | None:
    event = getattr(evidence, "interaction", None)
    if event is None:
        return None
    snapshot_id = getattr(event, "provenance", {}).get("snapshot_id")
    if not snapshot_id:
        return None

    d3 = getattr(final_packet, "d3", None)
    scoped = getattr(d3, "snapshot_evidence", None)
    if not isinstance(scoped, Mapping):
        return None
    row = scoped.get(str(snapshot_id))
    if row is None:
        return None
    return getattr(row, "correct_side_recovery", None)


def _platform_authority(
    *,
    runtime: Any,
    evidence: Any,
    events: tuple[Any, ...],
    cutoff: int,
    continuity: InfoValue[bool],
) -> Any | None:
    platform = getattr(evidence, "platform", None)
    trend_episode_id = getattr(
        evidence,
        "target_trend_episode_id",
        None,
    )
    if platform is None or not trend_episode_id:
        return None

    rt = platform_prod.PlatformFailedReexpansionProductionRuntimeV1.restore_state(
        dict(runtime.state.platform_state)
    )
    memory = rt._memory.get(str(trend_episode_id))
    if memory is None:
        return None

    complete = (
        InfoValue.known(True)
        if continuity.value is True
        and int(runtime.state.last_cutoff) >= int(platform.confirmed_at or 0)
        else InfoValue.unknown()
    )
    projection = produce_platform_adverse_defense_authority(
        platform_memory=memory,
        events=events,
        all_minor=tuple(runtime.state.minor_history),
        information_cutoff=cutoff,
        history_complete_through_platform_confirmation=complete,
    )
    return projection.authority if projection.state == "BOUND" else None


def _deep_authority(
    *,
    runtime: Any,
    evidence: Any,
    symbol: str,
    segment: str,
    cutoff: int,
    continuity: InfoValue[bool],
) -> Any | None:
    complete = (
        InfoValue.known(True)
        if continuity.value is True
        and int(runtime.state.last_cutoff) >= cutoff
        else InfoValue.unknown()
    )
    projection = produce_deep_adverse_defense_authority(
        deep_evidence=evidence,
        symbol=symbol,
        canonical_segment_id=segment,
        confirmed_minor_pivots=tuple(runtime.state.minor_history),
        information_cutoff=cutoff,
        history_complete_through_confirmation=complete,
    )
    return projection.authority if projection.state == "BOUND" else None


def build_prepared_row_d5_packet(
    *,
    ctx: Any,
    d4_view: Any,
    prepared_row: Any,
    final_packet: Any,
) -> D5InjectionBuildResultV1:
    candidate = getattr(d4_view, "confirmation_candidate", None)
    if candidate is None:
        return D5InjectionBuildResultV1(
            state="NOT_APPLICABLE",
            d5_packet=None,
            reason="NO_SAME_CUTOFF_B7A_CONFIRMATION",
        )

    cutoff = int(getattr(d4_view, "information_cutoff", -1))
    if cutoff < 0 or int(prepared_row.cutoff) != cutoff:
        raise FullLiveD5PreparedRowBuilderConflict(
            "PREPARED_ROW_D4_CUTOFF_MISMATCH"
        )
    if candidate.confirmation_cutoff != cutoff:
        raise FullLiveD5PreparedRowBuilderConflict(
            "B7A_NOT_SAME_CUTOFF"
        )

    symbol = str(ctx.symbol_input.symbol)
    if symbol != str(prepared_row.symbol):
        raise FullLiveD5PreparedRowBuilderConflict(
            "PREPARED_ROW_SYMBOL_MISMATCH"
        )

    runtime = rawv6.LiveRuntimeRawAuthorityOrchestrationV6.restore_state(
        prepared_row.poststate_raw
    )
    if int(runtime.state.last_cutoff) < cutoff:
        return D5InjectionBuildResultV1(
            state="BLOCKED",
            d5_packet=None,
            reason="PREPARED_POSTSTATE_NOT_COMPLETE_THROUGH_CUTOFF",
        )

    segment = _current_segment(runtime, symbol)
    if segment is None:
        return D5InjectionBuildResultV1(
            state="BLOCKED",
            d5_packet=None,
            reason="CURRENT_CANONICAL_SEGMENT_AUTHORITY_MISSING",
        )

    continuity = _canonical_continuity(
        runtime=runtime,
        symbol=symbol,
        d4_view=d4_view,
        information_cutoff=cutoff,
    )
    if continuity.value is not True:
        return D5InjectionBuildResultV1(
            state="BLOCKED",
            d5_packet=None,
            reason="CANONICAL_CONTINUITY_NOT_AUTHORITATIVE_TRUE",
            provenance={
                "continuity_kind": continuity.kind.value,
                "known_false_not_coerced": "true",
            },
        )

    d4_packet = getattr(final_packet, "d4", None)
    if d4_packet is None:
        raise FullLiveD5PreparedRowBuilderConflict(
            "FINAL_D4_PACKET_MISSING_FOR_B7A"
        )

    mechanism = candidate.mechanism
    kwargs: dict[str, Any] = {
        "mechanism": mechanism,
        "canonical_segment_id": segment,
        "canonical_continuity_intact": continuity,
        "theta_progress": _theta_progress(),
        "rawv6_state": runtime.state,
        "provenance": {
            "builder": "FULL_LIVE_D5_PREPARED_ROW_BUILDER_V1",
            "transaction_id": str(ctx.transaction_id),
        },
    }

    if mechanism is OpportunityMechanism.NORMAL_RETEST_CONTINUATION:
        evidence = getattr(d4_packet, "normal_retest", None)
        if evidence is None:
            raise FullLiveD5PreparedRowBuilderConflict(
                "PRIMARY_NORMAL_WITHOUT_FINAL_D4_EVIDENCE"
            )
        kwargs["normal_retest_evidence"] = evidence

    elif mechanism is OpportunityMechanism.FALSE_BREAK_RECLAIM:
        evidence = getattr(d4_packet, "false_break_reclaim", None)
        if evidence is None:
            raise FullLiveD5PreparedRowBuilderConflict(
                "PRIMARY_FBR_WITHOUT_FINAL_D4_EVIDENCE"
            )
        recovery = _fbr_recovery_projection(
            final_packet=final_packet,
            evidence=evidence,
        )
        if recovery is None:
            return D5InjectionBuildResultV1(
                state="BLOCKED",
                d5_packet=None,
                reason="FBR_TYPED_CORRECT_SIDE_RECOVERY_SIDECAR_MISSING",
            )
        kwargs["false_break_evidence"] = evidence
        kwargs["correct_side_recovery_projection"] = recovery

    elif mechanism is OpportunityMechanism.PLATFORM_REEXPANSION:
        evidence = getattr(d4_packet, "platform_reexpansion", None)
        if evidence is None:
            raise FullLiveD5PreparedRowBuilderConflict(
                "PRIMARY_PLATFORM_WITHOUT_FINAL_D4_EVIDENCE"
            )
        d3 = runtime._adapter()._d3_rebuild(symbol)
        authority = _platform_authority(
            runtime=runtime,
            evidence=evidence,
            events=tuple(rawv6._event_rows(d3)),
            cutoff=cutoff,
            continuity=continuity,
        )
        if authority is None:
            return D5InjectionBuildResultV1(
                state="BLOCKED",
                d5_packet=None,
                reason="PLATFORM_ADVERSE_DEFENSE_AUTHORITY_NOT_BOUND",
            )
        kwargs["explicit_adverse_defense"] = authority

    elif mechanism is OpportunityMechanism.DEEP_STRUCTURE_TAKEOVER:
        evidence = getattr(d4_packet, "deep_takeover", None)
        if evidence is None:
            raise FullLiveD5PreparedRowBuilderConflict(
                "PRIMARY_DEEP_WITHOUT_FINAL_D4_EVIDENCE"
            )
        authority = _deep_authority(
            runtime=runtime,
            evidence=evidence,
            symbol=symbol,
            segment=segment,
            cutoff=cutoff,
            continuity=continuity,
        )
        if authority is None:
            return D5InjectionBuildResultV1(
                state="BLOCKED",
                d5_packet=None,
                reason="DEEP_ADVERSE_DEFENSE_AUTHORITY_NOT_BOUND",
            )
        kwargs["explicit_adverse_defense"] = authority

    else:
        return D5InjectionBuildResultV1(
            state="NOT_APPLICABLE",
            d5_packet=None,
            reason="NONEXECUTABLE_OR_UNSUPPORTED_D4_MECHANISM",
        )

    close = getattr(ctx.symbol_input.observer_bar, "close", None)
    if not isinstance(close, Fraction) or close <= 0:
        raise FullLiveD5PreparedRowBuilderConflict(
            "STRATEGY_BAR_CLOSE_NOT_POSITIVE_EXACT_FRACTION"
        )

    return build_d5_from_explicit_source(
        source=D5PreparedSourceAuthorityV1(**kwargs),
        d4_view=d4_view,
        strategy_entry_reference_price=close,
        operational_inputs=build_operational_input_set(),
    )


def invariants() -> Mapping[str, Any]:
    return {
        "primary_mechanism_selected_here": False,
        "same_cutoff_close_is_entry_reference": True,
        "canonical_continuity_from_lineage_coverage_ledger": True,
        "segment_id_alone_proves_continuity": False,
        "fbr_recovery_from_exact_snapshot_sidecar": True,
        "true_break_reconstruction_for_fbr": False,
        "platform_source_from_durable_platform_memory": True,
        "deep_source_from_final_d4_regain_provenance": True,
        "operational_policy_values_selected_here": False,
        "selector_added": False,
        "ranking_added": False,
        "threshold_added": False,
        "trading_activated": False,
    }
