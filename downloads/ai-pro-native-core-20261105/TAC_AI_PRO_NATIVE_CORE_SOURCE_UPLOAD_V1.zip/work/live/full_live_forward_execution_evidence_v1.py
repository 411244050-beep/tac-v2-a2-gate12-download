from __future__ import annotations
from dataclasses import dataclass
from decimal import Decimal
from typing import Iterable,Mapping
from full_live_prospective_execution_evidence_v1 import ProspectiveExecutionEvidenceV1

class ForwardExecutionEvidenceBlock(RuntimeError): pass

class ForwardExecutionEvidenceAccumulatorV1:
    def __init__(self,*,collector_started_at_ms:int,frozen_symbols:Iterable[str]):
        if not isinstance(collector_started_at_ms,int) or collector_started_at_ms<=0: raise ForwardExecutionEvidenceBlock("START_REQUIRED")
        self.start=collector_started_at_ms; self.symbols=frozenset(frozen_symbols); self.rows=[]
        if not self.symbols: raise ForwardExecutionEvidenceBlock("UNIVERSE_REQUIRED")
    def add(self,e:ProspectiveExecutionEvidenceV1)->None:
        if not isinstance(e,ProspectiveExecutionEvidenceV1): raise ForwardExecutionEvidenceBlock("TYPED_EVIDENCE_REQUIRED")
        if e.observed_at_ms<self.start: raise ForwardExecutionEvidenceBlock("PRESTART_FORBIDDEN")
        if e.symbol not in self.symbols: raise ForwardExecutionEvidenceBlock("OUTSIDE_FROZEN_UNIVERSE")
        if not e.entry_ready_id: raise ForwardExecutionEvidenceBlock("ENTRY_READY_REQUIRED")
        if any(x.evidence_id==e.evidence_id for x in self.rows): raise ForwardExecutionEvidenceBlock("DUPLICATE_EVIDENCE")
        self.rows.append(e)
    def report(self)->Mapping[str,object]:
        spreads=sorted(Decimal(x.spread_bps) for x in self.rows)
        impacts=sorted(Decimal(x.impact_from_best_bps) for x in self.rows if x.impact_from_best_bps is not None)
        def pct(a,p):
            if not a:return None
            return str(a[min(len(a)-1,(len(a)-1)*p//100)])
        return {"status":"FORWARD_ENTRY_READY_EXECUTION_EVIDENCE_ONLY","collector_started_at_ms":self.start,
          "observations":len(self.rows),"symbols":len({x.symbol for x in self.rows}),
          "fully_fillable":sum(x.fully_fillable for x in self.rows),
          "spread_bps":{k:pct(spreads,p) for k,p in (("p50",50),("p90",90),("p95",95),("p99",99),("max",100))},
          "impact_bps":{k:pct(impacts,p) for k,p in (("p50",50),("p90",90),("p95",95),("p99",99),("max",100))},
          "threshold_selected":False,"historical_backfill":False,"outcome_read":False,"pnl_read":False}

def invariants():
    return {"entry_ready_evidence_required":True,"prospective_only":True,"threshold_owned":False,
      "historical_backfill":False,"outcome_read":False,"pnl_read":False,"orders":0,"fills":0,"execution_intents":0,"trading_activated":False}
