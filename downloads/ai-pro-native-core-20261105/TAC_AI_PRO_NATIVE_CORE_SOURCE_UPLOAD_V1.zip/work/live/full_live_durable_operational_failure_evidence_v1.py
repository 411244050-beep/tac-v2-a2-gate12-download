from __future__ import annotations
import json,os
from dataclasses import asdict
from pathlib import Path
from full_live_kill_switch_measurement_v1 import OperationalFailureEventV1,measure_failure_counts
class DurableOperationalFailureEvidenceBlock(RuntimeError): pass
class DurableOperationalFailureEvidenceV1:
 def __init__(self,*,path:Path,collector_started_at_ms:int):
  if not isinstance(collector_started_at_ms,int) or collector_started_at_ms<=0: raise DurableOperationalFailureEvidenceBlock("START_REQUIRED")
  self.path=Path(path); self.start=collector_started_at_ms; self.rows=[]; self.ids=set(); self._restore()
 def _restore(self):
  if not self.path.exists(): return
  try:
   for n,line in enumerate(self.path.read_text().splitlines(),1):
    raw=json.loads(line)
    if set(raw)!={"event_id","occurred_at_ms","category"}: raise DurableOperationalFailureEvidenceBlock("ROW_SCHEMA_MISMATCH")
    e=OperationalFailureEventV1(**raw)
    if e.occurred_at_ms<self.start: raise DurableOperationalFailureEvidenceBlock("PRESTART_FORBIDDEN")
    if e.event_id in self.ids: raise DurableOperationalFailureEvidenceBlock("DUPLICATE_EVENT")
    measure_failure_counts([e],since_ms=self.start,through_ms=e.occurred_at_ms)
    self.rows.append(e); self.ids.add(e.event_id)
  except DurableOperationalFailureEvidenceBlock: raise
  except Exception as exc: raise DurableOperationalFailureEvidenceBlock("RESTORE_FAILED") from exc
 def append(self,e:OperationalFailureEventV1):
  if not isinstance(e,OperationalFailureEventV1): raise DurableOperationalFailureEvidenceBlock("TYPED_EVENT_REQUIRED")
  if e.occurred_at_ms<self.start: raise DurableOperationalFailureEvidenceBlock("PRESTART_FORBIDDEN")
  if e.event_id in self.ids:return "IDEMPOTENT_REPLAY"
  measure_failure_counts([e],since_ms=self.start,through_ms=e.occurred_at_ms)
  self.path.parent.mkdir(parents=True,exist_ok=True); fd=os.open(self.path,os.O_WRONLY|os.O_CREAT|os.O_APPEND,0o600)
  with os.fdopen(fd,"a") as f:f.write(json.dumps(asdict(e),sort_keys=True,separators=(",",":"))+"\n");f.flush();os.fsync(f.fileno())
  self.rows.append(e);self.ids.add(e.event_id);return "COMMITTED"
 def report(self,*,through_ms:int):
  c=measure_failure_counts(self.rows,since_ms=self.start,through_ms=through_ms)
  return {"status":"FORWARD_OPERATIONAL_FAILURE_EVIDENCE_ONLY","collector_started_at_ms":self.start,"events":len(self.rows),"counts":c,"numeric_trigger_selected":False,"window_selected":False,"historical_backfill":False,"outcome_read":False,"pnl_read":False}
def invariants():return {"prospective_only":True,"restart_restore":True,"numeric_trigger_owned":False,"window_owned":False,"orders":0,"fills":0,"execution_intents":0,"trading_activated":False}
