from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from typing import Any, Iterable, Mapping, Sequence

from d2_to_b4_d4_causal_evidence_producers_v1 import (
    ClosedPriceObservation,
)
from full_live_d6_hard_protection_evidence_v1 import (
    D6HardProtectionProjectionV1,
    produce_hard_protection_evidence,
)
from full_live_d6_protective_pivot_evidence_v1 import (
    D6ProtectivePivotProjectionV1,
    produce_d6_protective_pivot_evidence,
)
from full_live_d6_strategy_evidence_binding_v1 import (
    D6StrategyEvidenceBindingV1,
    build_d6_strategy_cutoff_input,
)
from multisymbol_impl import transactional_batch_staging_v1 as staging
from strategy_rc1.d2_market_state.types import StructuralPivot
from strategy_rc1.d6_position_execution.parameters import (
    D6ParameterView,
    d6_parameter_view,
)
from strategy_rc1.d6_position_execution.types import (
    ExitCandidateEvidence,
    StrategyPositionSnapshot,
)
from strategy_rc1.parameter_snapshot import (
    current_partial_parameter_snapshot,
)
from strategy_rc1.runtime_guards.information_state import InfoValue


rawv6 = staging.rawv6


class FullLiveD6CutoffComposerBlock(RuntimeError):
    pass


@dataclass(frozen=True)
class FullLiveD6CutoffCompositionV1:
    strategy_binding: D6StrategyEvidenceBindingV1
    hard_protection: D6HardProtectionProjectionV1
    protective_pivot: D6ProtectivePivotProjectionV1
    exit_candidate_evidence: ExitCandidateEvidence
    confirmed_minor_pivot_count: int
    closed_price_count: int
    provenance: Mapping[str, str]


def _state_text(value: Any) -> str:
    return str(getattr(value, "value", value))


def _stage(symbol_result: Any, step: str) -> Any:
    rows = [
        row
        for row in tuple(getattr(symbol_result, "stages", ()))
        if _state_text(getattr(row, "step", None)) == step
    ]
    if len(rows) != 1:
        raise FullLiveD6CutoffComposerBlock(
            "STAGE_CARDINALITY:" + step
        )
    row = rows[0]
    if _state_text(getattr(row, "state", None)) not in ("PASS", "N/A"):
        raise FullLiveD6CutoffComposerBlock(
            "STAGE_NOT_PASS_OR_NA:" + step
        )
    return row


def _current_segment(symbol_result: Any) -> str | None:
    value = getattr(
        _stage(symbol_result, "UPDATE-001"),
        "canonical_segment_id",
        None,
    )
    if value is None:
        return None
    value = str(value)
    return value if value else None


def _restore_minor_history(
    final_rawv6_state: str,
) -> tuple[StructuralPivot, ...]:
    try:
        runtime = rawv6.LiveRuntimeRawAuthorityOrchestrationV6.restore_state(
            final_rawv6_state
        )
    except Exception as exc:
        raise FullLiveD6CutoffComposerBlock(
            "FINAL_RAWV6_STATE_RESTORE_FAILED:"
            + exc.__class__.__name__
            + ":"
            + str(exc)
        ) from exc

    rows = tuple(runtime.state.minor_history)
    if any(not isinstance(x, StructuralPivot) for x in rows):
        raise FullLiveD6CutoffComposerBlock(
            "RAWV6_MINOR_HISTORY_SCHEMA_DRIFT"
        )
    ids: dict[str, StructuralPivot] = {}
    for pivot in rows:
        old = ids.get(pivot.pivot_id)
        if old is not None and old != pivot:
            raise FullLiveD6CutoffComposerBlock(
                "DIVERGENT_DUPLICATE_MINOR_PIVOT:"
                + pivot.pivot_id
            )
        ids[pivot.pivot_id] = pivot
    return rows


def _closed_prices(
    *,
    canonical_records: Sequence[Any],
    information_cutoff: int,
    canonical_segment_id: str | None,
) -> tuple[ClosedPriceObservation, ...]:
    if canonical_segment_id is None:
        return ()

    seen: dict[int, Fraction] = {}
    for record in canonical_records:
        bar = getattr(record, "bar", None)
        segment = getattr(
            record,
            "canonical_segment_id",
            None,
        )
        if bar is None:
            raise FullLiveD6CutoffComposerBlock(
                "D1_CANONICAL_RECORD_BAR_MISSING"
            )
        close_time = getattr(bar, "close_time", None)
        close = getattr(bar, "close", None)
        if close_time is None or close is None:
            raise FullLiveD6CutoffComposerBlock(
                "D1_CANONICAL_RECORD_CLOSE_MISSING"
            )
        cutoff = int(close_time)
        if cutoff > information_cutoff:
            raise FullLiveD6CutoffComposerBlock(
                "D1_FUTURE_CANONICAL_RECORD"
            )
        if str(segment) != canonical_segment_id:
            continue
        value = Fraction(close)
        old = seen.get(cutoff)
        if old is not None and old != value:
            raise FullLiveD6CutoffComposerBlock(
                "DIVERGENT_CLOSE_AT_CUTOFF:" + str(cutoff)
            )
        seen[cutoff] = value

    rows = tuple(
        ClosedPriceObservation(
            information_cutoff=cutoff,
            close=close,
            provenance={
                "source": "D1_CANONICAL_RECORD",
                "canonical_segment_id": canonical_segment_id,
            },
        )
        for cutoff, close in sorted(seen.items())
    )
    if (
        not rows
        or rows[-1].information_cutoff
        != information_cutoff
    ):
        raise FullLiveD6CutoffComposerBlock(
            "D1_CANONICAL_CLOSE_HISTORY_NOT_COMPLETE_THROUGH_CUTOFF"
        )
    return rows


def _default_exit_candidate_evidence() -> ExitCandidateEvidence:
    # Frozen D6 makes this surface non-terminal. Until a frozen production
    # producer exists, preserve epistemic state instead of manufacturing
    # negative evidence.
    return ExitCandidateEvidence(
        management_anchor_true_break=InfoValue.unknown(),
        entry_risk_anchor_wrong_side_close=InfoValue.unknown(),
    )


def compose_full_live_d6_cutoff(
    *,
    symbol_result: Any,
    position: StrategyPositionSnapshot,
    final_rawv6_state: str,
    canonical_records: Sequence[Any],
    exchange_position_snapshot: Any,
    exchange_open_orders: Any,
    ledger_rows: Iterable[Mapping[str, Any]],
    exit_candidate_evidence: ExitCandidateEvidence | None = None,
    parameter_view: D6ParameterView | None = None,
) -> FullLiveD6CutoffCompositionV1:
    if not isinstance(position, StrategyPositionSnapshot):
        raise FullLiveD6CutoffComposerBlock(
            "STRATEGY_POSITION_SNAPSHOT_REQUIRED"
        )

    symbol = str(getattr(symbol_result, "symbol", ""))
    cutoff = int(
        getattr(symbol_result, "information_cutoff", -1)
    )
    if symbol != position.entry.symbol or cutoff <= 0:
        raise FullLiveD6CutoffComposerBlock(
            "D6_COMPOSER_SUBJECT_OR_CUTOFF_DRIFT"
        )

    params = (
        parameter_view
        if parameter_view is not None
        else d6_parameter_view(
            current_partial_parameter_snapshot()
        )
    )
    if not isinstance(params, D6ParameterView):
        raise FullLiveD6CutoffComposerBlock(
            "TYPED_D6_PARAMETER_VIEW_REQUIRED"
        )

    hard = produce_hard_protection_evidence(
        position=position,
        information_cutoff=cutoff,
        exchange_position_snapshot=exchange_position_snapshot,
        exchange_open_orders=exchange_open_orders,
        ledger_rows=tuple(ledger_rows),
    )

    exits = (
        exit_candidate_evidence
        if exit_candidate_evidence is not None
        else _default_exit_candidate_evidence()
    )
    if not isinstance(exits, ExitCandidateEvidence):
        raise FullLiveD6CutoffComposerBlock(
            "TYPED_EXIT_CANDIDATE_EVIDENCE_REQUIRED"
        )

    # First pass resolves frozen strategy continuity/trend evidence.  No D6
    # state mutation or exchange write occurs here.
    baseline = build_d6_strategy_cutoff_input(
        symbol_result=symbol_result,
        position=position,
        hard_protection=hard.evidence,
        exit_candidate_evidence=exits,
        parameter_view=params,
    )

    segment = _current_segment(symbol_result)
    minor_history = _restore_minor_history(
        final_rawv6_state
    )
    closes = _closed_prices(
        canonical_records=canonical_records,
        information_cutoff=cutoff,
        canonical_segment_id=segment,
    )

    protective = produce_d6_protective_pivot_evidence(
        position=position,
        information_cutoff=cutoff,
        current_canonical_segment_id=segment,
        confirmed_minor_pivots=minor_history,
        closed_prices=closes,
        theta_progress=params.theta_progress,
        trend_thesis_intact=(
            baseline.cutoff_input
            .protective_pivot_evidence
            .trend_thesis_intact
        ),
    )

    final = build_d6_strategy_cutoff_input(
        symbol_result=symbol_result,
        position=position,
        hard_protection=hard.evidence,
        protective_pivot_evidence=protective.evidence,
        exit_candidate_evidence=exits,
        parameter_view=params,
    )

    if final.cutoff_input.position != position:
        raise FullLiveD6CutoffComposerBlock(
            "D6_COMPOSED_POSITION_DRIFT"
        )
    if (
        final.cutoff_input.information_cutoff
        != cutoff
    ):
        raise FullLiveD6CutoffComposerBlock(
            "D6_COMPOSED_CUTOFF_DRIFT"
        )
    if (
        final.cutoff_input.hard_protection
        != hard.evidence
    ):
        raise FullLiveD6CutoffComposerBlock(
            "D6_HARD_PROTECTION_COMPOSITION_DRIFT"
        )
    if (
        final.cutoff_input.protective_pivot_evidence
        != protective.evidence
    ):
        raise FullLiveD6CutoffComposerBlock(
            "D6_PROTECTIVE_PIVOT_COMPOSITION_DRIFT"
        )

    return FullLiveD6CutoffCompositionV1(
        strategy_binding=final,
        hard_protection=hard,
        protective_pivot=protective,
        exit_candidate_evidence=exits,
        confirmed_minor_pivot_count=len(minor_history),
        closed_price_count=len(closes),
        provenance={
            "composer": "FULL_LIVE_D6_CUTOFF_COMPOSER_V1",
            "strategy_sources": "UPDATE001_UPDATE005_UPDATE006",
            "minor_history_source": "FINAL_RAWV6_STATE",
            "closed_price_source": "D1_CANONICAL_RECORDS",
            "hard_protection_source": hard.evidence.evidence_source,
            "exit_candidate_default": (
                "UNKNOWN_NOT_FALSE"
                if exit_candidate_evidence is None
                else "TYPED_OVERRIDE"
            ),
            "selector_added": "false",
            "ranking_added": "false",
            "numeric_threshold_added": "false",
        },
    )


def invariants() -> Mapping[str, object]:
    return {
        "strategy_cutoff_sources": (
            "UPDATE-001",
            "UPDATE-005",
            "UPDATE-006",
        ),
        "minor_history_source": "FINAL_RAWV6_STATE",
        "closed_price_source": "D1_CANONICAL_RECORDS",
        "hard_protection_source": "READ_ONLY_EXCHANGE_PLUS_DURABLE_LEDGER",
        "protective_pivot_semantic": (
            "FROZEN_LOCAL_TREND_CONTROL_REGAIN"
        ),
        "missing_exit_candidate_evidence": "UNKNOWN_NOT_FALSE",
        "exit_candidate_can_trigger_exit": False,
        "selector_added": False,
        "ranking_added": False,
        "numeric_threshold_added": False,
        "orders": 0,
        "fills": 0,
        "execution_intents": 0,
        "trading_activated": False,
    }


__all__ = [
    "FullLiveD6CutoffComposerBlock",
    "FullLiveD6CutoffCompositionV1",
    "compose_full_live_d6_cutoff",
    "invariants",
]
