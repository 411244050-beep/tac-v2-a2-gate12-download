from __future__ import annotations

import hashlib
from dataclasses import dataclass
from typing import Any, Iterable, Mapping

from d6_snapshot_envelope_v1 import (
    decode_d6_position_snapshot,
    encode_d6_position_snapshot,
)
from strategy_rc1.d6_position_execution.types import StrategyPositionSnapshot
from trade_ledger_v1 import LedgerEvent


class D6SnapshotLedgerBlock(RuntimeError):
    pass


@dataclass(frozen=True)
class D6SnapshotLedgerRecoveryV1:
    snapshot: StrategyPositionSnapshot
    snapshot_event_id: str
    snapshot_event_time_ms: int
    envelope_sha256: str


def build_d6_snapshot_ledger_event(
    *,
    snapshot: StrategyPositionSnapshot,
    entry_ready_id: str,
    event_time_ms: int | None = None,
) -> LedgerEvent:
    if not isinstance(snapshot, StrategyPositionSnapshot):
        raise D6SnapshotLedgerBlock(
            "STRATEGY_POSITION_SNAPSHOT_REQUIRED"
        )
    if not entry_ready_id:
        raise D6SnapshotLedgerBlock("ENTRY_READY_ID_REQUIRED")

    snapshot_entry_ready_id = str(
        getattr(getattr(snapshot, "entry", None), "entry_ready_id", "") or ""
    )
    if snapshot_entry_ready_id != entry_ready_id:
        raise D6SnapshotLedgerBlock(
            "SNAPSHOT_ENTRY_READY_ID_DRIFT:"
            + snapshot_entry_ready_id
            + "!="
            + entry_ready_id
        )

    symbol = str(
        getattr(getattr(snapshot, "entry", None), "symbol", "") or ""
    )
    if not symbol:
        raise D6SnapshotLedgerBlock("SNAPSHOT_SYMBOL_REQUIRED")

    position_id = str(getattr(snapshot, "position_id", "") or "")
    if not position_id:
        raise D6SnapshotLedgerBlock("SNAPSHOT_POSITION_ID_REQUIRED")

    envelope_bytes = encode_d6_position_snapshot(snapshot)
    envelope_text = envelope_bytes.decode("utf-8")
    envelope_sha256 = hashlib.sha256(envelope_bytes).hexdigest()

    return LedgerEvent.build(
        "D6_POSITION_SNAPSHOT",
        symbol=symbol,
        event_time_ms=event_time_ms,
        data={
            "position_id": position_id,
            "entry_ready_id": entry_ready_id,
            "snapshot_envelope": envelope_text,
            "snapshot_envelope_sha256": envelope_sha256,
        },
    )


def recover_d6_snapshot_from_ledger(
    *,
    ledger_rows: Iterable[Mapping[str, Any]],
    symbol: str,
    position_id: str,
    entry_ready_id: str,
) -> D6SnapshotLedgerRecoveryV1:
    if not symbol or not position_id or not entry_ready_id:
        raise D6SnapshotLedgerBlock(
            "RECOVERY_IDENTITY_REQUIRED"
        )

    matches: list[Mapping[str, Any]] = []
    for row in ledger_rows:
        if row.get("event_type") != "D6_POSITION_SNAPSHOT":
            continue
        if str(row.get("symbol", "")) != symbol:
            continue
        data = row.get("data") or {}
        if str(data.get("position_id", "")) != position_id:
            continue
        if str(data.get("entry_ready_id", "")) != entry_ready_id:
            continue
        matches.append(row)

    if not matches:
        raise D6SnapshotLedgerBlock(
            "D6_POSITION_SNAPSHOT_NOT_FOUND"
        )

    row = matches[-1]
    data = row.get("data")
    if not isinstance(data, Mapping):
        raise D6SnapshotLedgerBlock(
            "D6_POSITION_SNAPSHOT_DATA_INVALID"
        )

    expected_fields = {
        "position_id",
        "entry_ready_id",
        "snapshot_envelope",
        "snapshot_envelope_sha256",
    }
    if set(data) != expected_fields:
        raise D6SnapshotLedgerBlock(
            "D6_POSITION_SNAPSHOT_FIELD_DRIFT"
        )

    envelope_text = data.get("snapshot_envelope")
    envelope_sha256 = str(
        data.get("snapshot_envelope_sha256", "")
    )
    if not isinstance(envelope_text, str) or not envelope_text:
        raise D6SnapshotLedgerBlock(
            "D6_POSITION_SNAPSHOT_ENVELOPE_REQUIRED"
        )
    if len(envelope_sha256) != 64:
        raise D6SnapshotLedgerBlock(
            "D6_POSITION_SNAPSHOT_SHA256_INVALID"
        )

    actual_sha256 = hashlib.sha256(
        envelope_text.encode("utf-8")
    ).hexdigest()
    if actual_sha256 != envelope_sha256:
        raise D6SnapshotLedgerBlock(
            "D6_POSITION_SNAPSHOT_OUTER_DIGEST_MISMATCH"
        )

    try:
        snapshot = decode_d6_position_snapshot(envelope_text)
    except Exception as exc:
        raise D6SnapshotLedgerBlock(
            "D6_POSITION_SNAPSHOT_DECODE_FAILED:"
            + exc.__class__.__name__
            + ":"
            + str(exc)
        ) from exc

    if str(getattr(snapshot, "position_id", "") or "") != position_id:
        raise D6SnapshotLedgerBlock(
            "D6_POSITION_SNAPSHOT_POSITION_ID_DRIFT"
        )

    entry = getattr(snapshot, "entry", None)
    if str(getattr(entry, "entry_ready_id", "") or "") != entry_ready_id:
        raise D6SnapshotLedgerBlock(
            "D6_POSITION_SNAPSHOT_ENTRY_READY_ID_DRIFT"
        )
    if str(getattr(entry, "symbol", "") or "") != symbol:
        raise D6SnapshotLedgerBlock(
            "D6_POSITION_SNAPSHOT_SYMBOL_DRIFT"
        )

    event_id = str(row.get("event_id", "") or "")
    if not event_id:
        raise D6SnapshotLedgerBlock(
            "D6_POSITION_SNAPSHOT_EVENT_ID_REQUIRED"
        )

    try:
        event_time_ms = int(row.get("event_time_ms"))
    except Exception as exc:
        raise D6SnapshotLedgerBlock(
            "D6_POSITION_SNAPSHOT_EVENT_TIME_INVALID"
        ) from exc

    return D6SnapshotLedgerRecoveryV1(
        snapshot=snapshot,
        snapshot_event_id=event_id,
        snapshot_event_time_ms=event_time_ms,
        envelope_sha256=envelope_sha256,
    )


__all__ = [
    "D6SnapshotLedgerBlock",
    "D6SnapshotLedgerRecoveryV1",
    "build_d6_snapshot_ledger_event",
    "recover_d6_snapshot_from_ledger",
]
