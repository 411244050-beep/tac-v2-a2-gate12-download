from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from decimal import Decimal
import json
from typing import Any, Mapping

from full_live_executor_v1 import AdmittedTacSignalV1
from full_live_final_entry_observation_authority_v1 import (
    extract_from_authoritative_symbol_result,
)
from full_live_position_coordinator_v1 import D6ActivationInputsV1
from multisymbol_impl import transactional_batch_staging_v1 as staging
from strategy_rc1.d2_market_state.types import StructuralPivot, TrendDirection
from strategy_rc1.d5_risk.types import DecisionState
from strategy_rc1.d6_position_execution.position import (
    position_id_from_entry_ready,
)
from strategy_rc1.d6_position_execution.types import (
    PositionMode,
    PositionProvenanceClass,
)
from strategy_rc1.runtime_guards.information_state import InfoValue


rawv6 = staging.rawv6


class AuthoritativeEntryActivationBindingBlock(RuntimeError):
    pass


@dataclass(frozen=True)
class AuthoritativeEntryActivationBindingV1:
    symbol: str
    transaction_id: str
    information_cutoff: int
    entry_ready_id: str
    per_unit_structural_risk: Fraction
    numeric_hard_stop: Fraction
    signal: AdmittedTacSignalV1
    activation: D6ActivationInputsV1


def _state_text(value: Any) -> str:
    return str(getattr(value, "value", value))


def _stage(sr: Any, step: str) -> Any:
    rows = [
        row
        for row in tuple(getattr(sr, "stages", ()))
        if _state_text(getattr(row, "step", None)) == step
    ]
    if len(rows) != 1:
        raise AuthoritativeEntryActivationBindingBlock(
            "STAGE_CARDINALITY:" + step
        )
    row = rows[0]
    if _state_text(getattr(row, "state", None)) != "PASS":
        raise AuthoritativeEntryActivationBindingBlock(
            "STAGE_NOT_PASS:" + step
        )
    return row


def _decode_frozen_payload(value: Any) -> Any:
    if isinstance(value, list):
        return [_decode_frozen_payload(x) for x in value]
    if not isinstance(value, dict):
        return value
    if set(value) == {"__fraction__"}:
        raw = value["__fraction__"]
        if not isinstance(raw, list) or len(raw) != 2:
            raise AuthoritativeEntryActivationBindingBlock(
                "FROZEN_FRACTION_ENCODING_INVALID"
            )
        return Fraction(int(raw[0]), int(raw[1]))
    return {str(k): _decode_frozen_payload(v) for k, v in value.items()}


def _decoded_payload(stage: Any) -> Any:
    raw = getattr(stage, "payload_json", None)
    if not isinstance(raw, str):
        raise AuthoritativeEntryActivationBindingBlock(
            "STAGE_PAYLOAD_JSON_REQUIRED"
        )
    try:
        return _decode_frozen_payload(json.loads(raw))
    except AuthoritativeEntryActivationBindingBlock:
        raise
    except Exception as exc:
        raise AuthoritativeEntryActivationBindingBlock(
            "STAGE_FROZEN_PAYLOAD_DECODE_FAILED:"
            + exc.__class__.__name__
            + ":"
            + str(exc)
        ) from exc


def _known_fraction(value: Any, label: str) -> Fraction:
    if not isinstance(value, Mapping):
        raise AuthoritativeEntryActivationBindingBlock(
            label + "_INFO_MAPPING_REQUIRED"
        )
    if str(value.get("kind")) != "KNOWN":
        raise AuthoritativeEntryActivationBindingBlock(label + "_NOT_KNOWN")
    out = value.get("value")
    if not isinstance(out, Fraction) or out <= 0:
        raise AuthoritativeEntryActivationBindingBlock(
            label + "_NOT_POSITIVE_FRACTION"
        )
    return out


def _fraction_to_exact_decimal(value: Fraction, label: str) -> Decimal:
    out = Decimal(value.numerator) / Decimal(value.denominator)
    if Fraction(out) != value:
        raise AuthoritativeEntryActivationBindingBlock(
            label + "_NOT_EXACT_DECIMAL"
        )
    return out


def _require_mapping(value: Any, label: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping):
        raise AuthoritativeEntryActivationBindingBlock(
            label + "_MAPPING_REQUIRED"
        )
    return value


def _decision_state(value: Any, label: str) -> str:
    row = _require_mapping(value, label)
    state = str(row.get("state", ""))
    if not state:
        raise AuthoritativeEntryActivationBindingBlock(
            label + "_STATE_REQUIRED"
        )
    return state


def _find_risk_anchor_pivot(
    *,
    final_rawv6_state: str,
    pivot_id: str,
) -> StructuralPivot:
    runtime = rawv6.LiveRuntimeRawAuthorityOrchestrationV6.restore_state(
        final_rawv6_state
    )
    rows = tuple(runtime.state.minor_history) + tuple(
        runtime.state.intermediate_history
    )
    matches = [
        row
        for row in rows
        if isinstance(row, StructuralPivot) and row.pivot_id == pivot_id
    ]
    if len(matches) != 1:
        raise AuthoritativeEntryActivationBindingBlock(
            "RISK_ANCHOR_PIVOT_CARDINALITY:" + pivot_id
        )
    return matches[0]


def build_authoritative_entry_activation_binding(
    *,
    symbol_result: Any,
    final_rawv6_state: str,
) -> AuthoritativeEntryActivationBindingV1:
    authority = extract_from_authoritative_symbol_result(symbol_result)

    u11 = _decoded_payload(_stage(symbol_result, "UPDATE-011"))
    u12 = _decoded_payload(_stage(symbol_result, "UPDATE-012"))
    u13 = _decoded_payload(_stage(symbol_result, "UPDATE-013"))
    _stage(symbol_result, "UPDATE-014")

    u11 = _require_mapping(u11, "UPDATE011_PAYLOAD")
    d4 = _require_mapping(u11.get("view"), "UPDATE011_D4_VIEW")
    risk = _require_mapping(
        _require_mapping(
            u12,
            "UPDATE012_PAYLOAD",
        ).get("risk_feasibility"),
        "UPDATE012_RISK_FEASIBILITY",
    )
    u13 = _require_mapping(u13, "UPDATE013_ENTRY_READY")

    cutoff = int(getattr(symbol_result, "information_cutoff"))
    symbol = str(getattr(symbol_result, "symbol", ""))
    tx = str(getattr(symbol_result, "transaction_id", ""))
    if (
        not symbol
        or not tx
        or cutoff != authority.information_cutoff
        or symbol != authority.symbol
    ):
        raise AuthoritativeEntryActivationBindingBlock(
            "AUTHORITATIVE_SUBJECT_DRIFT"
        )

    if (
        int(d4.get("information_cutoff", -1)) != cutoff
        or int(risk.get("information_cutoff", -1)) != cutoff
    ):
        raise AuthoritativeEntryActivationBindingBlock("CUTOFF_DRIFT")
    if int(u13.get("information_cutoff", -1)) != cutoff:
        raise AuthoritativeEntryActivationBindingBlock(
            "ENTRY_READY_CUTOFF_DRIFT"
        )
    if str(u13.get("entry_ready_id", "")) != authority.entry_ready_ref:
        raise AuthoritativeEntryActivationBindingBlock(
            "ENTRY_READY_ID_DRIFT"
        )
    if u13.get("semantic_entry_ready_emitted") is not True:
        raise AuthoritativeEntryActivationBindingBlock(
            "ENTRY_READY_NOT_EMITTED"
        )
    if _decision_state(
        u13.get("decision"),
        "ENTRY_READY_DECISION",
    ) != "PASS":
        raise AuthoritativeEntryActivationBindingBlock(
            "ENTRY_READY_NOT_PASS"
        )
    if _decision_state(
        risk.get("decision"),
        "RISK_DECISION",
    ) != "PASS":
        raise AuthoritativeEntryActivationBindingBlock(
            "RISK_FEASIBILITY_NOT_PASS"
        )
    direction = str(risk.get("direction", ""))
    if direction != authority.direction:
        raise AuthoritativeEntryActivationBindingBlock("DIRECTION_DRIFT")

    opportunity = _require_mapping(
        d4.get("opportunity"),
        "D4_OPPORTUNITY",
    )
    candidate = _require_mapping(
        d4.get("confirmation_candidate"),
        "D4_CONFIRMATION_CANDIDATE",
    )
    opportunity_id = str(opportunity.get("opportunity_id", ""))
    candidate_id = str(candidate.get("candidate_id", ""))
    if opportunity_id != str(risk.get("opportunity_id", "")):
        raise AuthoritativeEntryActivationBindingBlock(
            "OPPORTUNITY_ID_DRIFT"
        )
    if candidate_id != str(
        risk.get("confirmation_candidate_id", "")
    ):
        raise AuthoritativeEntryActivationBindingBlock(
            "CONFIRMATION_CANDIDATE_ID_DRIFT"
        )
    if str(candidate.get("opportunity_id", "")) != opportunity_id:
        raise AuthoritativeEntryActivationBindingBlock(
            "D4_CANDIDATE_OPPORTUNITY_DRIFT"
        )
    if str(candidate.get("direction", "")) != direction:
        raise AuthoritativeEntryActivationBindingBlock(
            "D4_CANDIDATE_DIRECTION_DRIFT"
        )

    anchor = _require_mapping(
        risk.get("risk_anchor"),
        "RISK_ANCHOR",
    )
    if str(anchor.get("opportunity_id", "")) != opportunity_id:
        raise AuthoritativeEntryActivationBindingBlock(
            "RISK_ANCHOR_OPPORTUNITY_DRIFT"
        )
    if str(
        anchor.get("confirmation_candidate_id", "")
    ) != candidate_id:
        raise AuthoritativeEntryActivationBindingBlock(
            "RISK_ANCHOR_CANDIDATE_DRIFT"
        )
    pivot_id = str(anchor.get("pivot_id", ""))
    pivot = _find_risk_anchor_pivot(
        final_rawv6_state=final_rawv6_state,
        pivot_id=pivot_id,
    )
    if (
        pivot.layer.value != str(anchor.get("layer", ""))
        or pivot.pivot_type.value != str(anchor.get("pivot_type", ""))
        or pivot.extreme_price != anchor.get("price")
        or pivot.confirmed_at != int(anchor.get("confirmed_at", -1))
        or pivot.canonical_segment_id
        != str(anchor.get("canonical_segment_id", ""))
        or pivot.scale_at_extreme
        != anchor.get("source_scale_at_extreme")
    ):
        raise AuthoritativeEntryActivationBindingBlock(
            "RISK_ANCHOR_PIVOT_DRIFT"
        )

    entry_reference = _known_fraction(
        risk.get("strategy_entry_reference_price"),
        "STRATEGY_ENTRY_REFERENCE_PRICE",
    )
    per_unit = _known_fraction(
        risk.get("per_unit_structural_risk"),
        "PER_UNIT_STRUCTURAL_RISK",
    )
    hard = _require_mapping(
        risk.get("hard_stop"),
        "INITIAL_HARD_STOP",
    )
    hard_state = _decision_state(
        hard.get("decision"),
        "INITIAL_HARD_STOP_DECISION",
    )
    if hard_state != "PASS":
        raise AuthoritativeEntryActivationBindingBlock(
            "INITIAL_HARD_STOP_NOT_PASS"
        )
    numeric_stop = hard.get("numeric_stop_price")
    if not isinstance(numeric_stop, Fraction) or numeric_stop <= 0:
        raise AuthoritativeEntryActivationBindingBlock(
            "INITIAL_HARD_STOP_NUMERIC_REQUIRED"
        )
    if abs(entry_reference - numeric_stop) != per_unit:
        raise AuthoritativeEntryActivationBindingBlock(
            "PER_UNIT_STRUCTURAL_RISK_NUMERIC_STOP_DRIFT"
        )

    fields = {
        "provenance_class": (
            PositionProvenanceClass.AUTHORITATIVE_STRATEGY
        ),
        "entry_ready_id": authority.entry_ready_ref,
        "entry_ready_cutoff": cutoff,
        "symbol": symbol,
        "direction": TrendDirection(direction),
        "trend_episode_id": str(
            opportunity.get("trend_episode_id", "")
        ),
        "opportunity_id": opportunity_id,
        "market_event_id": str(
            opportunity.get("market_event_id", "")
        ),
        "entry_boundary_unit_id": opportunity.get(
            "entry_boundary_unit_id"
        ),
        "risk_anchor_id": str(anchor.get("risk_anchor_id", "")),
        "risk_anchor_pivot_id": pivot.pivot_id,
        "risk_anchor_layer": pivot.layer,
        "risk_anchor_price": pivot.extreme_price,
        "risk_anchor_scale": pivot.scale_at_extreme,
        "risk_anchor_confirmed_at": pivot.confirmed_at,
        "risk_anchor_timeframe_ms": pivot.timeframe_ms,
        "canonical_segment_id": pivot.canonical_segment_id,
        "strategy_entry_reference_price": entry_reference,
        "initial_hard_stop_state": DecisionState(hard_state),
        "initial_hard_stop_numeric": numeric_stop,
    }

    provenance = {
        "binding": (
            "TAC_FULL_LIVE_AUTHORITATIVE_ENTRY_"
            "ACTIVATION_BINDING_V1"
        ),
        "transaction_id": tx,
        "update011_output_digest": str(
            getattr(
                _stage(symbol_result, "UPDATE-011"),
                "output_digest",
                "",
            )
        ),
        "update012_output_digest": str(
            getattr(
                _stage(symbol_result, "UPDATE-012"),
                "output_digest",
                "",
            )
        ),
        "update013_output_digest": str(
            getattr(
                _stage(symbol_result, "UPDATE-013"),
                "output_digest",
                "",
            )
        ),
        "update014_output_digest": authority.update014_output_digest,
    }

    signal = AdmittedTacSignalV1(
        symbol=symbol,
        direction=authority.direction,
        cutoff=cutoff,
        opportunity_id=opportunity_id,
        entry_ready_id=authority.entry_ready_ref,
        entry_ready_admitted_by_update014=True,
        risk_anchor_price=_fraction_to_exact_decimal(
            pivot.extreme_price,
            "RISK_ANCHOR_PRICE",
        ),
        atr_at_risk_reference=_fraction_to_exact_decimal(
            pivot.scale_at_extreme,
            "ATR_AT_RISK_REFERENCE",
        ),
        risk_gate_result="PASS",
        entry_ready_state="PASS",
    )
    activation = D6ActivationInputsV1(
        position_id=position_id_from_entry_ready(
            authority.entry_ready_ref,
            opportunity_id,
            symbol,
        ),
        frozen_entry_fields=fields,
        mode=PositionMode.ACTIVE,
        latest_qualified_protective_pivot=None,
        current_protective_stop=InfoValue.unknown(),
        observer_label=None,
        provenance=provenance,
    )

    return AuthoritativeEntryActivationBindingV1(
        symbol=symbol,
        transaction_id=tx,
        information_cutoff=cutoff,
        entry_ready_id=authority.entry_ready_ref,
        per_unit_structural_risk=per_unit,
        numeric_hard_stop=numeric_stop,
        signal=signal,
        activation=activation,
    )


def invariants() -> Mapping[str, object]:
    return {
        "source": (
            "AUTHORITATIVE_UPDATE011_012_013_014_PLUS_"
            "FINAL_RAWV6_RISK_ANCHOR"
        ),
        "update014_required": True,
        "risk_feasibility_pass_required": True,
        "entry_ready_pass_required": True,
        "numeric_hard_stop_from_full_live_update012": True,
        "per_unit_structural_risk_exact_numeric_distance": True,
        "d6_position_id_deterministic_from_entry_ready": True,
        "d6_initial_mode": "ACTIVE",
        "synthetic_protective_pivot_injected": False,
        "numeric_d6_trailing_added": False,
        "selector_added": False,
        "ranking_added": False,
        "orders": 0,
        "fills": 0,
        "execution_intents": 0,
        "trading_activated": False,
    }


__all__ = [
    "AuthoritativeEntryActivationBindingBlock",
    "AuthoritativeEntryActivationBindingV1",
    "build_authoritative_entry_activation_binding",
    "invariants",
]
