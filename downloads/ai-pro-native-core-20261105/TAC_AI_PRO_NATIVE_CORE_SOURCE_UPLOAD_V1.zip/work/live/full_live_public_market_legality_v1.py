from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
from typing import Any, Callable, Mapping

from binance_usdm_exchange_info_measurement_v1 import (
    BinanceUSDMSymbolFactsV1,
    parse_usdm_symbol_facts,
)
from binance_usdm_market_entry_legality_v1 import (
    USDMarketEntryLegalityV1,
    measure_market_entry_legality,
)


BASE_URL = "https://fapi.binance.com"
EXCHANGE_INFO_PATH = "/fapi/v1/exchangeInfo"
TICKER_PRICE_PATH = "/fapi/v1/ticker/price"


class FullLivePublicMarketLegalityBlock(RuntimeError):
    pass


@dataclass(frozen=True)
class PublicMarketEntryLegalityObservationV1:
    symbol: str
    information_cutoff: int
    observed_at_ms: int
    reference_price: Decimal
    symbol_facts: BinanceUSDMSymbolFactsV1
    legality: USDMarketEntryLegalityV1
    exchange_info_source: str
    ticker_source: str


def _positive_decimal(value: Any, label: str) -> Decimal:
    try:
        out = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise FullLivePublicMarketLegalityBlock(
            "INVALID_DECIMAL:" + label
        ) from exc
    if not out.is_finite() or out <= 0:
        raise FullLivePublicMarketLegalityBlock(
            "NONPOSITIVE_DECIMAL:" + label
        )
    return out


def _ticker_price(raw: Any, symbol: str) -> Decimal:
    target = symbol.upper()
    rows = raw if isinstance(raw, list) else [raw]
    matches = [
        row
        for row in rows
        if isinstance(row, Mapping)
        and str(row.get("symbol", "")).upper() == target
        and row.get("price") is not None
    ]
    if len(matches) != 1:
        raise FullLivePublicMarketLegalityBlock(
            "TICKER_SYMBOL_NOT_UNIQUE:" + target
        )
    return _positive_decimal(matches[0]["price"], "ticker_price")


def build_public_market_entry_legality_observation(
    *,
    symbol: str,
    intended_quote_notional: Any,
    information_cutoff: int,
    observed_at_ms: int,
    raw_exchange_info: Mapping[str, Any],
    raw_ticker: Any,
) -> PublicMarketEntryLegalityObservationV1:
    if not symbol:
        raise FullLivePublicMarketLegalityBlock("SYMBOL_REQUIRED")
    if (
        not isinstance(information_cutoff, int)
        or information_cutoff <= 0
        or not isinstance(observed_at_ms, int)
        or observed_at_ms < information_cutoff
    ):
        raise FullLivePublicMarketLegalityBlock(
            "PROSPECTIVE_OBSERVATION_TIME_INVALID"
        )

    facts = parse_usdm_symbol_facts(
        raw_exchange_info=raw_exchange_info,
        symbol=symbol,
    )
    price = _ticker_price(raw_ticker, symbol)
    legality = measure_market_entry_legality(
        facts=facts,
        requested_quote_notional=intended_quote_notional,
        reference_price=price,
    )
    if legality.reference_price != price:
        raise FullLivePublicMarketLegalityBlock(
            "LEGALITY_REFERENCE_PRICE_DRIFT"
        )

    return PublicMarketEntryLegalityObservationV1(
        symbol=symbol.upper(),
        information_cutoff=information_cutoff,
        observed_at_ms=observed_at_ms,
        reference_price=price,
        symbol_facts=facts,
        legality=legality,
        exchange_info_source=(
            "BINANCE_USDM_PUBLIC_EXCHANGE_INFO_REST_CURRENT_V1"
        ),
        ticker_source=(
            "BINANCE_USDM_PUBLIC_SYMBOL_PRICE_TICKER_REST_CURRENT_V1"
        ),
    )


def acquire_public_market_entry_legality_observation(
    *,
    symbol: str,
    intended_quote_notional: Any,
    information_cutoff: int,
    public_get: Callable[..., Any],
    clock_ms: Callable[[], int],
) -> PublicMarketEntryLegalityObservationV1:
    if not callable(public_get) or not callable(clock_ms):
        raise FullLivePublicMarketLegalityBlock(
            "INJECTED_PUBLIC_GET_AND_CLOCK_REQUIRED"
        )
    exchange_info = public_get(
        BASE_URL + EXCHANGE_INFO_PATH,
        params={},
    )
    ticker = public_get(
        BASE_URL + TICKER_PRICE_PATH,
        params={"symbol": symbol.upper()},
    )
    observed_at_ms = int(clock_ms())
    return build_public_market_entry_legality_observation(
        symbol=symbol,
        intended_quote_notional=intended_quote_notional,
        information_cutoff=information_cutoff,
        observed_at_ms=observed_at_ms,
        raw_exchange_info=exchange_info,
        raw_ticker=ticker,
    )


def invariants() -> Mapping[str, object]:
    return {
        "public_read_only": True,
        "credentials_required": False,
        "exchange_info_server_time_authoritative": False,
        "listing_age_selector_added": False,
        "policy_threshold_owned": False,
        "reference_price_source": (
            "BINANCE_USDM_PUBLIC_SYMBOL_PRICE_TICKER_REST_CURRENT_V1"
        ),
        "orders": 0,
        "fills": 0,
        "execution_intents": 0,
        "trading_activated": False,
    }


__all__ = [
    "FullLivePublicMarketLegalityBlock",
    "PublicMarketEntryLegalityObservationV1",
    "acquire_public_market_entry_legality_observation",
    "build_public_market_entry_legality_observation",
    "invariants",
]
