from __future__ import annotations

from dataclasses import dataclass, field
from fractions import Fraction
from types import MappingProxyType
from typing import Any, Mapping, Sequence

from strategy_rc1.d2_market_state.progress import same_type_progress
from strategy_rc1.d2_market_state.types import (
    PivotType,
    ProgressRelation,
    StructuralLayer,
    StructuralPivot,
    TrendDirection,
)
from strategy_rc1.runtime_guards.information_state import InfoKind, InfoValue


class FullLiveD5RiskAnchorValidityBlock(RuntimeError):
    pass


@dataclass(frozen=True)
class RiskAnchorValidityAuthorityV1:
    risk_anchor_not_invalidated: InfoValue[bool]
    reason: str
    risk_anchor_pivot_id: str
    invalidating_pivot_id: str | None
    compared_pivot_ids: tuple[str, ...]
    information_cutoff: int
    provenance: Mapping[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "provenance",
            MappingProxyType(dict(self.provenance)),
        )


def _nonknown_result(
    *,
    anchor: StructuralPivot,
    cutoff: int,
    value: InfoValue[bool],
    reason: str,
) -> RiskAnchorValidityAuthorityV1:
    if value.kind is InfoKind.ERROR:
        out = InfoValue.error(value.error_ref or reason)
    else:
        # NONE/N/A/UNKNOWN cannot prove a required pre-entry risk predicate.
        out = InfoValue.unknown()
    return RiskAnchorValidityAuthorityV1(
        risk_anchor_not_invalidated=out,
        reason=reason,
        risk_anchor_pivot_id=anchor.pivot_id,
        invalidating_pivot_id=None,
        compared_pivot_ids=(),
        information_cutoff=cutoff,
        provenance={
            "source_truth": "D2_CONFIRMED_PRICE_STRUCTURE",
            "unknown_not_coerced": "true",
        },
    )


def produce_risk_anchor_validity_authority(
    *,
    risk_anchor_pivot: StructuralPivot,
    direction: TrendDirection,
    information_cutoff: int,
    pivot_history: Sequence[StructuralPivot],
    history_complete_through_cutoff: InfoValue[bool],
    canonical_continuity_intact: InfoValue[bool],
    theta_progress: Fraction,
) -> RiskAnchorValidityAuthorityV1:
    """Produce the pre-entry Risk-Anchor validity authority.

    This is the same structural invalidation predicate used by frozen D6
    ENTRY_THESIS_FAILURE: a causally later adverse pivot on the corresponding
    structure layer invalidates the anchor only when same_type_progress reaches
    material adverse progress using theta_progress.  A wrong-side close alone
    is never sufficient.

    The function never treats missing history as evidence of validity.
    """

    anchor = risk_anchor_pivot
    if information_cutoff < 0:
        raise FullLiveD5RiskAnchorValidityBlock(
            "INFORMATION_CUTOFF_NEGATIVE"
        )
    if theta_progress <= 0:
        raise FullLiveD5RiskAnchorValidityBlock(
            "THETA_PROGRESS_MUST_BE_POSITIVE"
        )
    if direction not in (TrendDirection.LONG, TrendDirection.SHORT):
        raise FullLiveD5RiskAnchorValidityBlock(
            "RISK_ANCHOR_VALIDITY_DIRECTION_NOT_LONG_OR_SHORT"
        )
    if anchor.confirmed_at > information_cutoff:
        return RiskAnchorValidityAuthorityV1(
            risk_anchor_not_invalidated=InfoValue.error(
                "FUTURE_CONFIRMED_RISK_ANCHOR_FORBIDDEN"
            ),
            reason="FUTURE_CONFIRMED_RISK_ANCHOR_FORBIDDEN",
            risk_anchor_pivot_id=anchor.pivot_id,
            invalidating_pivot_id=None,
            compared_pivot_ids=(),
            information_cutoff=information_cutoff,
            provenance={"source_truth": "D2_CONFIRMED_PRICE_STRUCTURE"},
        )

    expected = (
        PivotType.LOW
        if direction is TrendDirection.LONG
        else PivotType.HIGH
    )
    if anchor.pivot_type is not expected:
        raise FullLiveD5RiskAnchorValidityBlock(
            "RISK_ANCHOR_NOT_ADVERSE_PIVOT_TYPE"
        )
    if not anchor.provenance:
        raise FullLiveD5RiskAnchorValidityBlock(
            "RISK_ANCHOR_PIVOT_PROVENANCE_MISSING"
        )

    if canonical_continuity_intact.kind is not InfoKind.KNOWN:
        return _nonknown_result(
            anchor=anchor,
            cutoff=information_cutoff,
            value=canonical_continuity_intact,
            reason=(
                "CANONICAL_CONTINUITY_"
                + canonical_continuity_intact.kind.value.replace("/", "_")
            ),
        )
    if canonical_continuity_intact.value is not True:
        return RiskAnchorValidityAuthorityV1(
            risk_anchor_not_invalidated=InfoValue.unknown(),
            reason="CANONICAL_CONTINUITY_NOT_INTACT_VALIDITY_UNKNOWN",
            risk_anchor_pivot_id=anchor.pivot_id,
            invalidating_pivot_id=None,
            compared_pivot_ids=(),
            information_cutoff=information_cutoff,
            provenance={
                "source_truth": "D2_CONFIRMED_PRICE_STRUCTURE",
                "gap_not_market_failure": "true",
            },
        )

    if history_complete_through_cutoff.kind is not InfoKind.KNOWN:
        return _nonknown_result(
            anchor=anchor,
            cutoff=information_cutoff,
            value=history_complete_through_cutoff,
            reason=(
                "PIVOT_HISTORY_COMPLETENESS_"
                + history_complete_through_cutoff.kind.value.replace("/", "_")
            ),
        )
    if history_complete_through_cutoff.value is not True:
        return RiskAnchorValidityAuthorityV1(
            risk_anchor_not_invalidated=InfoValue.unknown(),
            reason="PIVOT_HISTORY_NOT_COMPLETE_THROUGH_CUTOFF",
            risk_anchor_pivot_id=anchor.pivot_id,
            invalidating_pivot_id=None,
            compared_pivot_ids=(),
            information_cutoff=information_cutoff,
            provenance={
                "source_truth": "D2_CONFIRMED_PRICE_STRUCTURE",
                "absence_not_treated_as_validity": "true",
            },
        )

    by_id: dict[str, StructuralPivot] = {}
    for pivot in pivot_history:
        old = by_id.get(pivot.pivot_id)
        if old is not None and old != pivot:
            raise FullLiveD5RiskAnchorValidityBlock(
                "DIVERGENT_DUPLICATE_PIVOT_ID:" + pivot.pivot_id
            )
        by_id[pivot.pivot_id] = pivot

    comparable = []
    future_ignored = 0
    for pivot in by_id.values():
        if (
            pivot.symbol != anchor.symbol
            or pivot.timeframe_ms != anchor.timeframe_ms
            or pivot.layer is not anchor.layer
            or pivot.pivot_type is not anchor.pivot_type
        ):
            continue
        if pivot.confirmed_at > information_cutoff:
            future_ignored += 1
            continue
        if pivot.confirmed_at <= anchor.confirmed_at:
            continue
        if pivot.canonical_segment_id != anchor.canonical_segment_id:
            return RiskAnchorValidityAuthorityV1(
                risk_anchor_not_invalidated=InfoValue.error(
                    "CANONICAL_CONTINUITY_AUTHORITY_CONFLICT"
                ),
                reason="CANONICAL_CONTINUITY_AUTHORITY_CONFLICT",
                risk_anchor_pivot_id=anchor.pivot_id,
                invalidating_pivot_id=None,
                compared_pivot_ids=tuple(
                    p.pivot_id
                    for p in sorted(
                        comparable,
                        key=lambda x: (x.confirmed_at, x.pivot_id),
                    )
                ),
                information_cutoff=information_cutoff,
                provenance={
                    "source_truth": "D2_CONFIRMED_PRICE_STRUCTURE",
                    "conflicting_pivot_id": pivot.pivot_id,
                },
            )
        if not pivot.provenance:
            return RiskAnchorValidityAuthorityV1(
                risk_anchor_not_invalidated=InfoValue.error(
                    "COMPARABLE_PIVOT_PROVENANCE_MISSING"
                ),
                reason="COMPARABLE_PIVOT_PROVENANCE_MISSING",
                risk_anchor_pivot_id=anchor.pivot_id,
                invalidating_pivot_id=None,
                compared_pivot_ids=(),
                information_cutoff=information_cutoff,
                provenance={"pivot_id": pivot.pivot_id},
            )
        comparable.append(pivot)

    ordered = tuple(
        sorted(comparable, key=lambda x: (x.confirmed_at, x.pivot_id))
    )
    compared: list[str] = []
    adverse_relation = (
        ProgressRelation.MATERIAL_ADVANCE_DOWN
        if direction is TrendDirection.LONG
        else ProgressRelation.MATERIAL_ADVANCE_UP
    )
    for pivot in ordered:
        try:
            relation = same_type_progress(
                anchor,
                pivot,
                theta_progress,
            )
        except ValueError as exc:
            return RiskAnchorValidityAuthorityV1(
                risk_anchor_not_invalidated=InfoValue.error(
                    "RISK_ANCHOR_VALIDITY_PROGRESS_COMPARISON_FAILED"
                ),
                reason="RISK_ANCHOR_VALIDITY_PROGRESS_COMPARISON_FAILED",
                risk_anchor_pivot_id=anchor.pivot_id,
                invalidating_pivot_id=None,
                compared_pivot_ids=tuple(compared),
                information_cutoff=information_cutoff,
                provenance={
                    "error": str(exc),
                    "source_truth": "D2_CONFIRMED_PRICE_STRUCTURE",
                },
            )
        compared.append(pivot.pivot_id)
        if relation is adverse_relation:
            return RiskAnchorValidityAuthorityV1(
                risk_anchor_not_invalidated=InfoValue.known(False),
                reason="RISK_ANCHOR_MATERIAL_ADVERSE_PROGRESS_CONFIRMED",
                risk_anchor_pivot_id=anchor.pivot_id,
                invalidating_pivot_id=pivot.pivot_id,
                compared_pivot_ids=tuple(compared),
                information_cutoff=information_cutoff,
                provenance={
                    "progress_relation": relation.value,
                    "theta_progress": str(theta_progress),
                    "source_truth": "D2_CONFIRMED_PRICE_STRUCTURE",
                    "same_predicate_as_frozen_d6_entry_thesis_failure": "true",
                },
            )

    return RiskAnchorValidityAuthorityV1(
        risk_anchor_not_invalidated=InfoValue.known(True),
        reason="NO_MATERIAL_ADVERSE_PIVOT_BEYOND_RISK_ANCHOR",
        risk_anchor_pivot_id=anchor.pivot_id,
        invalidating_pivot_id=None,
        compared_pivot_ids=tuple(compared),
        information_cutoff=information_cutoff,
        provenance={
            "theta_progress": str(theta_progress),
            "history_complete_through_cutoff": "true",
            "canonical_continuity_intact": "true",
            "future_pivots_ignored": str(future_ignored),
            "source_truth": "D2_CONFIRMED_PRICE_STRUCTURE",
            "same_predicate_as_frozen_d6_entry_thesis_failure": "true",
        },
    )


def produce_from_rawv6_state(
    *,
    rawv6_state: Any,
    risk_anchor_pivot: StructuralPivot,
    direction: TrendDirection,
    information_cutoff: int,
    canonical_continuity_intact: InfoValue[bool],
    theta_progress: Fraction,
) -> RiskAnchorValidityAuthorityV1:
    """Bind the producer to Raw V6's durable complete D2 pivot history.

    Raw V6 persists MINOR and INTERMEDIATE history.  MAJOR is deliberately
    unsupported here rather than guessed from a shallower/deeper stream.
    """

    last_cutoff = getattr(rawv6_state, "last_cutoff", None)
    if last_cutoff is None or int(last_cutoff) < information_cutoff:
        return RiskAnchorValidityAuthorityV1(
            risk_anchor_not_invalidated=InfoValue.unknown(),
            reason="RAWV6_HISTORY_NOT_COMPLETE_THROUGH_REQUESTED_CUTOFF",
            risk_anchor_pivot_id=risk_anchor_pivot.pivot_id,
            invalidating_pivot_id=None,
            compared_pivot_ids=(),
            information_cutoff=information_cutoff,
            provenance={
                "rawv6_last_cutoff": (
                    "NONE" if last_cutoff is None else str(last_cutoff)
                ),
                "absence_not_treated_as_validity": "true",
                "source_truth": "RAW_V6_DURABLE_D2_HISTORY",
            },
        )

    if risk_anchor_pivot.layer is StructuralLayer.MINOR:
        history = tuple(getattr(rawv6_state, "minor_history", ()))
    elif risk_anchor_pivot.layer is StructuralLayer.INTERMEDIATE:
        history = tuple(getattr(rawv6_state, "intermediate_history", ()))
    else:
        return RiskAnchorValidityAuthorityV1(
            risk_anchor_not_invalidated=InfoValue.unknown(),
            reason="RAWV6_MAJOR_PIVOT_HISTORY_AUTHORITY_UNAVAILABLE",
            risk_anchor_pivot_id=risk_anchor_pivot.pivot_id,
            invalidating_pivot_id=None,
            compared_pivot_ids=(),
            information_cutoff=information_cutoff,
            provenance={
                "no_layer_substitution": "true",
                "source_truth": "RAW_V6_DURABLE_D2_HISTORY",
            },
        )

    return produce_risk_anchor_validity_authority(
        risk_anchor_pivot=risk_anchor_pivot,
        direction=direction,
        information_cutoff=information_cutoff,
        pivot_history=history,
        history_complete_through_cutoff=InfoValue.known(True),
        canonical_continuity_intact=canonical_continuity_intact,
        theta_progress=theta_progress,
    )
