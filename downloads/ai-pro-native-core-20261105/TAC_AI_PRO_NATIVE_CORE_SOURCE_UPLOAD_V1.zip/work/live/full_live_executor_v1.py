from __future__ import annotations

import subprocess
import time
from dataclasses import dataclass
from decimal import Decimal, ROUND_DOWN, ROUND_UP
from typing import Any

from binance_execution_adapter_v1 import (
    BinanceCliExecutionAdapterV1,
    BinanceExecutionError,
    EntryRequest,
    _parse_json_stdout,
    entry_client_order_id,
    hard_stop_client_algo_id,
)
from execution_uncertainty_latch_v1 import (
    ExecutionUncertaintyLatchBlock,
    ExecutionUncertaintyLatchV1,
    resolve_execution_uncertainty_latch_path,
)
from full_live_policy_v1 import FullLivePolicyV1, initial_hard_stop
from trade_ledger_v1 import LedgerEvent, TradeLedgerV1


class FullLiveExecutionBlock(RuntimeError):
    pass


@dataclass(frozen=True)
class AdmittedTacSignalV1:
    symbol: str
    direction: str
    cutoff: int
    opportunity_id: str
    entry_ready_id: str
    entry_ready_admitted_by_update014: bool
    risk_anchor_price: Decimal
    atr_at_risk_reference: Decimal
    risk_gate_result: str | None = None
    entry_ready_state: str | None = None

    def __post_init__(self) -> None:
        if not self.entry_ready_admitted_by_update014:
            raise FullLiveExecutionBlock("UPDATE014_NOT_ADMITTED")
        if self.direction.upper() not in ("LONG", "SHORT"):
            raise FullLiveExecutionBlock("DIRECTION_NOT_LONG_OR_SHORT")
        if not self.symbol or not self.opportunity_id or not self.entry_ready_id:
            raise FullLiveExecutionBlock("SIGNAL_IDENTITY_INCOMPLETE")
        if self.risk_anchor_price <= 0 or self.atr_at_risk_reference <= 0:
            raise FullLiveExecutionBlock("RISK_REFERENCE_INCOMPLETE")


def _cli_readonly(args: list[str]) -> Any:
    p = subprocess.run(
        ["binance-cli", *args],
        text=True,
        capture_output=True,
        check=False,
    )
    if p.returncode != 0:
        detail = (p.stderr or p.stdout or "")[-3000:]
        raise FullLiveExecutionBlock(
            "BINANCE_READ_FAILURE:" + str(p.returncode) + ":" + detail
        )
    return _parse_json_stdout(p.stdout)


def _walk_dicts(value: Any):
    if isinstance(value, dict):
        yield value
        for v in value.values():
            yield from _walk_dicts(v)
    elif isinstance(value, list):
        for v in value:
            yield from _walk_dicts(v)


def _position_qty(snapshot: Any, *, symbol: str, direction: str) -> Decimal:
    wanted_side = direction.upper()
    for row in _walk_dicts(snapshot):
        if str(row.get("symbol", "")) != symbol:
            continue
        if str(row.get("positionSide", "")).upper() != wanted_side:
            continue
        raw = row.get("positionAmt")
        if raw is None:
            continue
        try:
            return abs(Decimal(str(raw)))
        except Exception:
            continue
    return Decimal("0")


def _entry_price(snapshot: Any, *, symbol: str, direction: str) -> Decimal | None:
    wanted_side = direction.upper()
    for row in _walk_dicts(snapshot):
        if str(row.get("symbol", "")) != symbol:
            continue
        if str(row.get("positionSide", "")).upper() != wanted_side:
            continue
        raw = row.get("entryPrice")
        if raw is None:
            continue
        try:
            value = Decimal(str(raw))
        except Exception:
            continue
        return value if value > 0 else None
    return None


def _filled_market_result_evidence(
    result: Any,
    *,
    symbol: str,
    direction: str,
    entry_ready_id: str,
) -> tuple[Decimal, Decimal | None, dict[str, Any]] | None:
    expected_client_id = entry_client_order_id(entry_ready_id)
    expected_position_side = direction.upper()
    matches: list[tuple[Decimal, Decimal | None, dict[str, Any]]] = []

    for row in _walk_dicts(result):
        if str(row.get("symbol", "")) != symbol:
            continue
        if str(row.get("clientOrderId", "")) != expected_client_id:
            continue

        position_side = str(row.get("positionSide", "")).upper()
        if position_side and position_side != expected_position_side:
            continue

        order_type = str(row.get("type", "")).upper()
        if order_type and order_type != "MARKET":
            continue

        if str(row.get("status", "")).upper() != "FILLED":
            continue

        raw_qty = row.get("executedQty")
        if raw_qty is None:
            continue
        try:
            qty = abs(Decimal(str(raw_qty)))
        except Exception:
            continue
        if qty <= 0:
            continue

        avg_price: Decimal | None = None
        raw_avg = row.get("avgPrice")
        if raw_avg is not None:
            try:
                candidate = Decimal(str(raw_avg))
                if candidate > 0:
                    avg_price = candidate
            except Exception:
                pass

        matches.append((qty, avg_price, dict(row)))

    if len(matches) > 1:
        raise FullLiveExecutionBlock(
            "AMBIGUOUS_FILLED_MARKET_RESULT_ROWS:"
            + symbol
            + ":"
            + expected_client_id
        )
    return matches[0] if matches else None


def _find_symbol_info(exchange_info: Any, symbol: str) -> dict[str, Any]:
    for row in _walk_dicts(exchange_info):
        if row.get("symbol") == symbol and isinstance(row.get("filters"), list):
            return row
    raise FullLiveExecutionBlock("SYMBOL_EXCHANGE_INFO_NOT_FOUND:" + symbol)


def _filter(symbol_info: dict[str, Any], name: str) -> dict[str, Any] | None:
    for row in symbol_info.get("filters", []):
        if row.get("filterType") == name:
            return row
    return None


def _floor_step(value: Decimal, step: Decimal) -> Decimal:
    if step <= 0:
        raise FullLiveExecutionBlock("INVALID_STEP_SIZE")
    units = (value / step).to_integral_value(rounding=ROUND_DOWN)
    return units * step


def _round_stop(value: Decimal, tick: Decimal, direction: str) -> Decimal:
    if tick <= 0:
        raise FullLiveExecutionBlock("INVALID_TICK_SIZE")
    # Tick alignment must never widen the Strategy-authorized raw stop.
    # LONG protection rounds upward (closer to entry); SHORT rounds downward.
    d = direction.upper()
    if d == "LONG":
        rounding = ROUND_UP
    elif d == "SHORT":
        rounding = ROUND_DOWN
    else:
        raise FullLiveExecutionBlock("UNSUPPORTED_DIRECTION:" + direction)
    units = (value / tick).to_integral_value(rounding=rounding)
    return units * tick

def _open_symbol_position_sides(snapshot: Any, *, symbol: str) -> tuple[str, ...]:
    sides: set[str] = set()
    for row in _walk_dicts(snapshot):
        if str(row.get("symbol", "")) != symbol:
            continue
        raw = row.get("positionAmt")
        if raw is None:
            continue
        try:
            qty = abs(Decimal(str(raw)))
        except Exception:
            continue
        if qty <= 0:
            continue
        side = str(row.get("positionSide", "") or "UNKNOWN").upper()
        sides.add(side)
    return tuple(sorted(sides))


def _symbol_open_order_count(snapshot: Any, *, symbol: str) -> int:
    count = 0
    identity_keys = {
        "orderId",
        "clientOrderId",
        "algoId",
        "clientAlgoId",
    }
    for row in _walk_dicts(snapshot):
        if str(row.get("symbol", "")) != symbol:
            continue
        if any(row.get(key) not in (None, "") for key in identity_keys):
            count += 1
    return count


class FullLiveExecutorV1:
    def __init__(
        self,
        *,
        ledger: TradeLedgerV1,
        policy: FullLivePolicyV1 | None = None,
        execution_uncertainty_latch: ExecutionUncertaintyLatchV1 | None = None,
    ) -> None:
        self.ledger = ledger
        self.policy = policy or FullLivePolicyV1.from_env()
        self.binance = BinanceCliExecutionAdapterV1(ledger)
        self.execution_uncertainty_latch = (
            execution_uncertainty_latch
            if execution_uncertainty_latch is not None
            else ExecutionUncertaintyLatchV1(
                resolve_execution_uncertainty_latch_path(ledger)
            )
        )

    def _append_best_effort(self, event: LedgerEvent) -> bool:
        try:
            self.ledger.append(event)
            return True
        except Exception:
            return False

    def _already_consumed(self, entry_ready_id: str) -> bool:
        for event in self.ledger.read_all():
            data = event.get("data") or {}
            if (
                event.get("event_type") in ("SIGNAL_ADMITTED", "POSITION_OPENED")
                and data.get("entry_ready_id") == entry_ready_id
            ):
                return True
        return False

    def _latch_ambiguous_market_entry(
        self,
        *,
        signal: AdmittedTacSignalV1,
        detail: str | None = None,
    ) -> None:
        ambiguity_reason = "FATAL_AMBIGUOUS_MARKET_ENTRY_EXECUTION_STATE"
        try:
            latch_state = self.execution_uncertainty_latch.latch(
                reason=ambiguity_reason,
                symbol=signal.symbol,
                entry_ready_id=signal.entry_ready_id,
                client_order_id=entry_client_order_id(signal.entry_ready_id),
            )
        except Exception as latch_exc:
            self._append_best_effort(LedgerEvent.build(
                "EXECUTION_ERROR",
                symbol=signal.symbol,
                data={
                    "reason": "FATAL_EXECUTION_UNCERTAINTY_LATCH_PERSISTENCE_FAILURE",
                    "entry_ready_id": signal.entry_ready_id,
                    "detail": str(latch_exc)[:1200],
                    "market_submission_detail": None if detail is None else detail[:1200],
                },
            ))
            raise FullLiveExecutionBlock(
                "FATAL_EXECUTION_UNCERTAINTY_LATCH_PERSISTENCE_FAILURE:"
                + str(latch_exc)
            ) from latch_exc
        self._append_best_effort(LedgerEvent.build(
            "EXECUTION_ERROR",
            symbol=signal.symbol,
            data={
                "reason": ambiguity_reason,
                "entry_ready_id": signal.entry_ready_id,
                "client_order_id": latch_state.client_order_id,
                "latch_payload_sha256": latch_state.payload_sha256,
                "position_snapshot_confirmed": False,
                "market_result_filled_confirmed": False,
                "market_submission_detail": None if detail is None else detail[:1200],
            },
        ))
        raise FullLiveExecutionBlock(ambiguity_reason)

    def _market_metadata(
        self,
        symbol: str,
    ) -> tuple[Decimal, Decimal, Decimal, Decimal, Decimal, Decimal, str]:
        price_response = _cli_readonly([
            "futures-usds",
            "symbol-price-ticker",
            "--symbol", symbol,
        ])
        price: Decimal | None = None
        for row in _walk_dicts(price_response):
            if row.get("symbol") == symbol and row.get("price") is not None:
                price = Decimal(str(row["price"]))
                break
        if price is None or price <= 0:
            raise FullLiveExecutionBlock("MARK_PRICE_UNAVAILABLE:" + symbol)

        exchange_info = _cli_readonly([
            "futures-usds",
            "exchange-information",
        ])
        info = _find_symbol_info(exchange_info, symbol)

        lot = _filter(info, "MARKET_LOT_SIZE") or _filter(info, "LOT_SIZE")
        price_filter = _filter(info, "PRICE_FILTER")
        min_notional_filter = _filter(info, "MIN_NOTIONAL")
        if lot is None or price_filter is None or min_notional_filter is None:
            raise FullLiveExecutionBlock("EXCHANGE_FILTERS_INCOMPLETE:" + symbol)

        step = Decimal(str(lot.get("stepSize", "0")))
        min_qty = Decimal(str(lot.get("minQty", "0")))
        max_qty = Decimal(str(lot.get("maxQty", "0")))
        tick = Decimal(str(price_filter.get("tickSize", "0")))
        min_notional = Decimal(str(min_notional_filter.get("notional", "0")))
        status = str(info.get("status", ""))

        if step <= 0 or min_qty < 0 or max_qty <= 0 or tick <= 0 or min_notional < 0:
            raise FullLiveExecutionBlock("EXCHANGE_FILTER_VALUES_INVALID:" + symbol)
        return price, step, min_qty, max_qty, tick, min_notional, status

    def _confirmed_position(
        self,
        *,
        symbol: str,
        direction: str,
        attempts: int = 6,
    ) -> tuple[Decimal, Decimal | None, Any]:
        last = None
        for _ in range(attempts):
            last = self.binance.position_snapshot(symbol)
            qty = _position_qty(last, symbol=symbol, direction=direction)
            if qty > 0:
                return qty, _entry_price(last, symbol=symbol, direction=direction), last
            time.sleep(0.5)
        return Decimal("0"), None, last

    def _confirmed_flat(
        self,
        *,
        symbol: str,
        direction: str,
        attempts: int = 6,
    ) -> tuple[bool, Any]:
        last = None
        for _ in range(attempts):
            last = self.binance.position_snapshot(symbol)
            if _position_qty(last, symbol=symbol, direction=direction) <= 0:
                return True, last
            time.sleep(0.5)
        return False, last

    def execute_entry(
        self,
        signal: AdmittedTacSignalV1,
        *,
        authorized_quantity: Decimal | None = None,
        authorized_raw_hard_stop: Decimal | None = None,
    ) -> dict[str, Any]:
        # Global uncertainty is checked before any exchange read or write.
        try:
            self.execution_uncertainty_latch.assert_new_risk_allowed()
        except ExecutionUncertaintyLatchBlock as exc:
            raise FullLiveExecutionBlock(
                "GLOBAL_EXECUTION_UNCERTAINTY_BLOCK:"
                + str(exc)
            ) from exc

        self.binance._require_live_enabled()

        if self._already_consumed(signal.entry_ready_id):
            return {
                "status": "IDEMPOTENT_ALREADY_CONSUMED",
                "entry_ready_id": signal.entry_ready_id,
            }

        before = self.binance.position_snapshot(signal.symbol)
        open_sides = _open_symbol_position_sides(
            before,
            symbol=signal.symbol,
        )
        if open_sides:
            raise FullLiveExecutionBlock(
                "SAME_SYMBOL_ANY_SIDE_POSITION_ALREADY_OPEN:"
                + signal.symbol
                + ":"
                + ",".join(open_sides)
            )

        standard_open_orders = self.binance.open_orders(signal.symbol)
        if _symbol_open_order_count(
            standard_open_orders,
            symbol=signal.symbol,
        ):
            raise FullLiveExecutionBlock(
                "SAME_SYMBOL_STANDARD_OPEN_ORDER_ALREADY_PRESENT:"
                + signal.symbol
            )

        algo_open_orders = self.binance.algo_open_orders()
        if _symbol_open_order_count(
            algo_open_orders,
            symbol=signal.symbol,
        ):
            raise FullLiveExecutionBlock(
                "SAME_SYMBOL_ALGO_OPEN_ORDER_ALREADY_PRESENT:"
                + signal.symbol
            )

        market_price, step, min_qty, max_qty, tick, min_notional, status = self._market_metadata(signal.symbol)
        if status != "TRADING":
            raise FullLiveExecutionBlock("SYMBOL_NOT_TRADING:" + signal.symbol)
        computed_quantity = _floor_step(
            self.policy.notional_per_new_position_usdt / market_price,
            step,
        )
        if authorized_quantity is None:
            quantity = computed_quantity
        else:
            if (
                not isinstance(authorized_quantity, Decimal)
                or not authorized_quantity.is_finite()
                or authorized_quantity <= 0
            ):
                raise FullLiveExecutionBlock(
                    "AUTHORIZED_QUANTITY_INVALID:" + signal.symbol
                )
            if authorized_quantity != computed_quantity:
                raise FullLiveExecutionBlock(
                    "AUTHORIZED_QUANTITY_CURRENT_MARKET_DRIFT:"
                    + signal.symbol
                )
            quantity = authorized_quantity
        if quantity < min_qty or quantity <= 0:
            raise FullLiveExecutionBlock(
                "POSITION_SIZE_BELOW_MARKET_MINIMUM:" + signal.symbol
            )
        if quantity > max_qty:
            raise FullLiveExecutionBlock(
                "POSITION_SIZE_ABOVE_MARKET_MAXIMUM:" + signal.symbol
            )
        if quantity * market_price < min_notional:
            raise FullLiveExecutionBlock(
                "POSITION_NOTIONAL_BELOW_EXCHANGE_MINIMUM:" + signal.symbol
            )

        raw_stop = initial_hard_stop(
            direction=signal.direction,
            risk_anchor_price=signal.risk_anchor_price,
            atr_at_risk_reference=signal.atr_at_risk_reference,
            theta_stop=self.policy.theta_stop,
        )
        if authorized_raw_hard_stop is not None:
            if (
                not isinstance(authorized_raw_hard_stop, Decimal)
                or not authorized_raw_hard_stop.is_finite()
                or authorized_raw_hard_stop <= 0
            ):
                raise FullLiveExecutionBlock(
                    "AUTHORIZED_RAW_HARD_STOP_INVALID"
                )
            if raw_stop != authorized_raw_hard_stop:
                raise FullLiveExecutionBlock(
                    "AUTHORIZED_RAW_HARD_STOP_DRIFT"
                )
        stop_price = _round_stop(raw_stop, tick, signal.direction)
        if stop_price <= 0:
            raise FullLiveExecutionBlock("HARD_STOP_NONPOSITIVE")

        request = EntryRequest(
            symbol=signal.symbol,
            direction=signal.direction,
            quantity=quantity,
            opportunity_id=signal.opportunity_id,
            entry_ready_id=signal.entry_ready_id,
            cutoff=signal.cutoff,
            hard_stop_price=stop_price,
        )

        # Durable single-consumption boundary.  This event must be committed
        # before the first exchange write.  Once present, the entry_ready_id is
        # permanently consumed even if a later safety path reverses the
        # position.  A persistence failure therefore forbids market submission.
        signal_admitted_event = LedgerEvent.build(
            "SIGNAL_ADMITTED",
            symbol=signal.symbol,
            data={
                "direction": signal.direction.upper(),
                "opportunity_id": signal.opportunity_id,
                "entry_ready_id": signal.entry_ready_id,
                "cutoff": signal.cutoff,
                "quantity": str(quantity),
                "market_reference_price": str(market_price),
                "authorized_raw_hard_stop": str(raw_stop),
                "exchange_hard_stop_price": str(stop_price),
                "client_order_id": entry_client_order_id(
                    signal.entry_ready_id
                ),
                "update014_admitted": True,
            },
        )
        try:
            self.ledger.append(signal_admitted_event)
        except Exception as exc:
            raise FullLiveExecutionBlock(
                "SIGNAL_ADMITTED_DURABILITY_FAILURE_BEFORE_EXCHANGE_WRITE:"
                + exc.__class__.__name__
                + ":"
                + str(exc)
            ) from exc

        entry_result: Any = None
        market_submission_error: Exception | None = None
        try:
            entry_result = self.binance.place_market_entry(request)
        except Exception as exc:
            # A CLI/network failure does not prove that the exchange rejected
            # the deterministic client-order request. Resolve by observation;
            # if no position can be confirmed, latch global uncertainty.
            market_submission_error = exc

        actual_qty, entry_price, snapshot = self._confirmed_position(
            symbol=signal.symbol,
            direction=signal.direction,
        )
        execution_confirmation_source = "POSITION_SNAPSHOT"
        filled_order_result_evidence: dict[str, Any] | None = None

        if actual_qty <= 0:
            filled = (
                None
                if entry_result is None
                else _filled_market_result_evidence(
                    entry_result,
                    symbol=signal.symbol,
                    direction=signal.direction,
                    entry_ready_id=signal.entry_ready_id,
                )
            )
            if filled is None:
                self._latch_ambiguous_market_entry(
                    signal=signal,
                    detail=(
                        None
                        if market_submission_error is None
                        else str(market_submission_error)
                    ),
                )
            actual_qty, entry_price, filled_order_result_evidence = filled
            execution_confirmation_source = "MARKET_RESULT_FILLED"

        fill_event = LedgerEvent.build(
            "FILL",
            symbol=signal.symbol,
            data={
                "kind": "ENTRY_CONFIRMED_POSITION",
                "direction": signal.direction,
                "quantity": str(actual_qty),
                "entry_price": None if entry_price is None else str(entry_price),
                "opportunity_id": signal.opportunity_id,
                "entry_ready_id": signal.entry_ready_id,
                "entry_order_response": entry_result,
                "market_submission_error": (
                    None
                    if market_submission_error is None
                    else str(market_submission_error)[:1200]
                ),
                "execution_confirmation_source": (
                    execution_confirmation_source
                ),
                "filled_order_result_evidence": (
                    filled_order_result_evidence
                ),
                "confirmed_position_snapshot": snapshot,
            },
        )

        actual_request = EntryRequest(
            symbol=request.symbol,
            direction=request.direction,
            quantity=actual_qty,
            opportunity_id=request.opportunity_id,
            entry_ready_id=request.entry_ready_id,
            cutoff=request.cutoff,
            hard_stop_price=request.hard_stop_price,
        )

        # Protect the confirmed exchange position before any required
        # post-entry durability write.  Audit persistence must never delay
        # installation of the exchange-side hard stop.
        try:
            stop_result = self.binance.place_full_position_hard_stop(
                actual_request
            )
        except Exception as stop_exc:
            # Safety action first.  Diagnostic persistence is best-effort.
            try:
                self.execute_strategy_exit(
                    symbol=signal.symbol,
                    direction=signal.direction,
                    reason="FAIL_CLOSED_NO_INITIAL_HARD_STOP",
                    reference_id=signal.entry_ready_id,
                )
            except Exception as close_exc:
                self._append_best_effort(LedgerEvent.build(
                    "EXECUTION_ERROR",
                    symbol=signal.symbol,
                    data={
                        "reason": (
                            "FATAL_OPEN_POSITION_WITHOUT_CONFIRMED_HARD_STOP"
                        ),
                        "entry_ready_id": signal.entry_ready_id,
                        "detail": str(stop_exc)[:900],
                        "close_detail": str(close_exc)[:900],
                    },
                ))
                raise FullLiveExecutionBlock(
                    "FATAL_OPEN_POSITION_WITHOUT_CONFIRMED_HARD_STOP:"
                    + str(close_exc)
                ) from stop_exc

            self._append_best_effort(fill_event)
            self._append_best_effort(LedgerEvent.build(
                "EXECUTION_ERROR",
                symbol=signal.symbol,
                data={
                    "reason": "INITIAL_HARD_STOP_PLACEMENT_FAILED",
                    "entry_ready_id": signal.entry_ready_id,
                    "detail": str(stop_exc)[:1000],
                    "exchange_position_reversed": True,
                },
            ))
            raise FullLiveExecutionBlock(
                "ENTRY_REVERSED_BECAUSE_INITIAL_HARD_STOP_FAILED"
            ) from stop_exc

        position_opened_event = LedgerEvent.build(
            "POSITION_OPENED",
            symbol=signal.symbol,
            data={
                "direction": signal.direction,
                "quantity": str(actual_qty),
                "entry_price": None if entry_price is None else str(entry_price),
                "opportunity_id": signal.opportunity_id,
                "entry_ready_id": signal.entry_ready_id,
                "cutoff": signal.cutoff,
                "risk_gate_result": signal.risk_gate_result,
                "entry_ready_state": signal.entry_ready_state,
                "theta_stop": str(self.policy.theta_stop),
                "hard_stop_price": str(stop_price),
                "execution_evidence_id": fill_event.event_id,
                "opened_real_time": fill_event.event_time_ms,
                "execution_confirmation_source": (
                    execution_confirmation_source
                ),
                "position_snapshot": snapshot,
                "stop_response": stop_result,
            },
        )

        try:
            self.ledger.append(fill_event)
            self.ledger.append(position_opened_event)
        except Exception as durability_exc:
            # The exchange position is protected, but the authoritative live
            # ledger is incomplete.  Do not continue into D6 activation.
            # Close first and clear the exchange-side algo stop via the normal
            # strategy-exit path; diagnostics remain best-effort.
            try:
                close_result = self.execute_strategy_exit(
                    symbol=signal.symbol,
                    direction=signal.direction,
                    reason="FAIL_CLOSED_EXECUTION_DURABILITY_FAILURE",
                    reference_id=signal.entry_ready_id,
                )
            except Exception as close_exc:
                self._append_best_effort(LedgerEvent.build(
                    "EXECUTION_ERROR",
                    symbol=signal.symbol,
                    data={
                        "reason": (
                            "FATAL_EXECUTION_DURABILITY_FAILURE_WITH_"
                            "OPEN_EXCHANGE_POSITION"
                        ),
                        "entry_ready_id": signal.entry_ready_id,
                        "detail": str(durability_exc)[:900],
                        "close_detail": str(close_exc)[:900],
                    },
                ))
                raise FullLiveExecutionBlock(
                    "FATAL_EXECUTION_DURABILITY_FAILURE_WITH_OPEN_"
                    "EXCHANGE_POSITION:"
                    + str(close_exc)
                ) from durability_exc

            self._append_best_effort(LedgerEvent.build(
                "EXECUTION_ERROR",
                symbol=signal.symbol,
                data={
                    "reason": "EXECUTION_DURABILITY_FAILURE",
                    "entry_ready_id": signal.entry_ready_id,
                    "detail": str(durability_exc)[:1000],
                    "exchange_position_reversed": True,
                    "close_status": (
                        close_result.get("status")
                        if isinstance(close_result, dict)
                        else None
                    ),
                },
            ))
            raise FullLiveExecutionBlock(
                "ENTRY_REVERSED_BECAUSE_EXECUTION_DURABILITY_FAILED"
            ) from durability_exc

        return {
            "status": "POSITION_OPENED_WITH_HARD_PROTECTION",
            "symbol": signal.symbol,
            "direction": signal.direction,
            "quantity": str(actual_qty),
            "entry_price": None if entry_price is None else str(entry_price),
            "hard_stop_price": str(stop_price),
            "entry_ready_id": signal.entry_ready_id,
            "execution_evidence_id": fill_event.event_id,
            "opened_real_time": fill_event.event_time_ms,
            "execution_confirmation_source": (
                execution_confirmation_source
            ),
        }

    def _cleanup_exact_tac_hard_stop(
        self,
        *,
        symbol: str,
        direction: str,
        reference_id: str,
        reason: str,
    ) -> None:
        # Determine the owner from durable entry lineage, not a symbol-level
        # guess. The fallback is only for a safety reversal before
        # POSITION_OPENED was committed, using the matching SIGNAL_ADMITTED.
        ledger_rows = self.ledger.read_all()
        opened = [
            row for row in ledger_rows
            if row.get("event_type") == "POSITION_OPENED"
            and row.get("symbol") == symbol
            and isinstance(row.get("data"), dict)
            and str(row["data"].get("direction", "")).upper()
                == direction.upper()
        ]
        admitted = [
            row for row in ledger_rows
            if row.get("event_type") == "SIGNAL_ADMITTED"
            and row.get("symbol") == symbol
            and isinstance(row.get("data"), dict)
            and str(row["data"].get("direction", "")).upper()
                == direction.upper()
        ]
        entry_id = None
        if opened:
            entry_id = str(opened[-1]["data"].get("entry_ready_id") or "")
        elif reason.startswith("FAIL_CLOSED_") and admitted:
            last = admitted[-1]
            if str(last["data"].get("entry_ready_id")) == reference_id:
                entry_id = reference_id
        if not entry_id:
            raise FullLiveExecutionBlock(
                "EXACT_TAC_HARD_STOP_OWNERSHIP_UNPROVEN:" + symbol
            )
        client_id = hard_stop_client_algo_id(entry_id)
        raw = self.binance.algo_open_orders()
        if isinstance(raw, dict):
            if "data" in raw:
                raw = raw["data"]
            elif "orders" in raw:
                raw = raw["orders"]
            elif "clientAlgoId" in raw and "symbol" in raw:
                raw = [raw]
            else:
                raise FullLiveExecutionBlock(
                    "ALGO_OPEN_ORDER_READ_UNRECOGNIZED:" + symbol
                )
        if not isinstance(raw, (list, tuple)) or not all(
            isinstance(row, dict) for row in raw
        ):
            raise FullLiveExecutionBlock(
                "ALGO_OPEN_ORDER_READ_UNRECOGNIZED:" + symbol
            )
        hits = [
            row for row in _walk_dicts(raw)
            if str(row.get("clientAlgoId", "")) == client_id
        ]
        if len(hits) > 1:
            raise FullLiveExecutionBlock(
                "DUPLICATE_TAC_STOP_CLIENT_ID:" + symbol
            )
        if not hits:
            return
        order = hits[0]
        expected_side = "SELL" if direction.upper() == "LONG" else "BUY"
        if (
            str(order.get("symbol", "")) != symbol
            or str(order.get("positionSide", "")).upper()
                != direction.upper()
            or str(order.get("side", "")).upper() != expected_side
            or str(order.get("orderType", "")).upper() != "STOP_MARKET"
            or str(order.get("closePosition", "")).lower()
                not in ("true", "1")
        ):
            raise FullLiveExecutionBlock(
                "OWNED_TAC_STOP_ATTRIBUTES_DRIFT:" + symbol
            )
        self.binance.cancel_algo_order_by_client_id(client_id)

    def execute_strategy_exit(
        self,
        *,
        symbol: str,
        direction: str,
        reason: str,
        reference_id: str,
    ) -> dict[str, Any]:
        self.binance._require_live_enabled()
        snapshot = self.binance.position_snapshot(symbol)
        qty = _position_qty(snapshot, symbol=symbol, direction=direction)
        if qty <= 0:
            try:
                self._cleanup_exact_tac_hard_stop(
                    symbol=symbol,
                    direction=direction,
                    reference_id=reference_id,
                    reason=reason,
                )
            except Exception as exc:
                self._append_best_effort(LedgerEvent.build(
                    "EXECUTION_ERROR",
                    symbol=symbol,
                    data={
                        "reason": (
                            "ALREADY_FLAT_ALGO_ORDER_CLEANUP_UNCERTAIN"
                        ),
                        "reference_id": reference_id,
                        "detail": str(exc)[:1000],
                    },
                ))
                raise FullLiveExecutionBlock(
                    "ALREADY_FLAT_BUT_ALGO_ORDER_CLEANUP_UNCERTAIN:"
                    + symbol
                ) from exc
            self._append_best_effort(LedgerEvent.build(
                "POSITION_CLOSED",
                symbol=symbol,
                data={
                    "direction": direction,
                    "quantity": "0",
                    "reason": reason,
                    "reference_id": reference_id,
                    "close_response": None,
                    "close_submission_error": None,
                    "confirmed_flat_snapshot": snapshot,
                    "already_flat_before_close_request": True,
                },
            ))
            return {
                "status": "POSITION_CLOSED_ALREADY_FLAT",
                "symbol": symbol,
                "direction": direction,
                "quantity": "0",
                "reason": reason,
                "execution_confirmation_source": (
                    "POSITION_SNAPSHOT_ALREADY_FLAT"
                ),
                "close_submission_error": None,
            }

        result: Any = None
        submission_error: Exception | None = None
        try:
            result = self.binance.close_position_market(
                symbol=symbol,
                direction=direction,
                quantity=qty,
                reason=reason,
                reference_id=reference_id,
            )
        except Exception as exc:
            # Submission failure is ambiguous: the deterministic market close
            # may still have reached the exchange. Resolve only from the
            # authoritative position snapshot, and never remove hard protection
            # until the target hedge-side position is confirmed flat.
            submission_error = exc

        try:
            flat, flat_snapshot = self._confirmed_flat(
                symbol=symbol,
                direction=direction,
            )
        except Exception as exc:
            self._append_best_effort(LedgerEvent.build(
                "EXECUTION_ERROR",
                symbol=symbol,
                data={
                    "reason": "EXIT_FLAT_CONFIRMATION_READ_FAILED",
                    "reference_id": reference_id,
                    "close_submission_detail": (
                        None if submission_error is None else str(submission_error)[:1000]
                    ),
                    "detail": str(exc)[:1000],
                    "hard_protection_preserved": True,
                },
            ))
            raise FullLiveExecutionBlock(
                "EXIT_FLAT_CONFIRMATION_UNAVAILABLE_HARD_PROTECTION_PRESERVED:"
                + symbol
            ) from exc

        if not flat:
            self._append_best_effort(LedgerEvent.build(
                "EXECUTION_ERROR",
                symbol=symbol,
                data={
                    "reason": "EXIT_POSITION_NOT_CONFIRMED_FLAT",
                    "reference_id": reference_id,
                    "close_submission_detail": (
                        None if submission_error is None else str(submission_error)[:1000]
                    ),
                    "close_response": result,
                    "position_snapshot": flat_snapshot,
                    "hard_protection_preserved": True,
                },
            ))
            raise FullLiveExecutionBlock(
                "EXIT_POSITION_NOT_CONFIRMED_FLAT_HARD_PROTECTION_PRESERVED:"
                + symbol
            )

        try:
            self._cleanup_exact_tac_hard_stop(
                symbol=symbol,
                direction=direction,
                reference_id=reference_id,
                reason=reason,
            )
        except Exception as exc:
            self._append_best_effort(LedgerEvent.build(
                "EXECUTION_ERROR",
                symbol=symbol,
                data={
                    "reason": "STALE_ALGO_ORDER_CANCEL_FAILED_AFTER_EXIT",
                    "reference_id": reference_id,
                    "detail": str(exc)[:1000],
                },
            ))
            raise FullLiveExecutionBlock(
                "EXIT_CLOSED_POSITION_BUT_ALGO_ORDER_CLEANUP_UNCERTAIN:"
                + symbol
            ) from exc

        self._append_best_effort(LedgerEvent.build(
            "POSITION_CLOSED",
            symbol=symbol,
            data={
                "direction": direction,
                "quantity": str(qty),
                "reason": reason,
                "reference_id": reference_id,
                "close_response": result,
                "close_submission_error": (
                    None if submission_error is None else str(submission_error)[:1200]
                ),
                "confirmed_flat_snapshot": flat_snapshot,
            },
        ))
        return {
            "status": "POSITION_CLOSED",
            "symbol": symbol,
            "direction": direction,
            "quantity": str(qty),
            "reason": reason,
            "execution_confirmation_source": "POSITION_SNAPSHOT_FLAT",
            "close_submission_error": (
                None if submission_error is None else str(submission_error)[:1200]
            ),
        }
