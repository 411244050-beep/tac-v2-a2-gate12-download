from __future__ import annotations

import hashlib
import json
import os
import pathlib
import time
from dataclasses import dataclass
from typing import Any


SCHEMA = "TAC_EXECUTION_UNCERTAINTY_LATCH_V1"
DEFAULT_FILENAME = "execution_uncertainty_latch_v1.json"


class ExecutionUncertaintyLatchBlock(RuntimeError):
    pass


def _canonical_json(value: Any) -> str:
    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    )


@dataclass(frozen=True)
class ExecutionUncertaintyLatchStateV1:
    reason: str
    symbol: str
    entry_ready_id: str
    client_order_id: str
    latched_at_ms: int
    payload_sha256: str


class ExecutionUncertaintyLatchV1:
    def __init__(self, path: str | os.PathLike[str]) -> None:
        self.path = pathlib.Path(path)

    def _encode(
        self,
        *,
        reason: str,
        symbol: str,
        entry_ready_id: str,
        client_order_id: str,
        latched_at_ms: int,
    ) -> bytes:
        payload = {
            "schema": SCHEMA,
            "latched": True,
            "reason": reason,
            "symbol": symbol,
            "entry_ready_id": entry_ready_id,
            "client_order_id": client_order_id,
            "latched_at_ms": int(latched_at_ms),
        }
        digest = hashlib.sha256(
            _canonical_json(payload).encode("utf-8")
        ).hexdigest()
        envelope = {
            **payload,
            "payload_sha256": digest,
        }
        return (
            _canonical_json(envelope) + "\n"
        ).encode("utf-8")

    def latch(
        self,
        *,
        reason: str,
        symbol: str,
        entry_ready_id: str,
        client_order_id: str,
        latched_at_ms: int | None = None,
    ) -> ExecutionUncertaintyLatchStateV1:
        if not reason:
            raise ExecutionUncertaintyLatchBlock("LATCH_REASON_REQUIRED")
        if not symbol:
            raise ExecutionUncertaintyLatchBlock("LATCH_SYMBOL_REQUIRED")
        if not entry_ready_id:
            raise ExecutionUncertaintyLatchBlock(
                "LATCH_ENTRY_READY_ID_REQUIRED"
            )
        if not client_order_id:
            raise ExecutionUncertaintyLatchBlock(
                "LATCH_CLIENT_ORDER_ID_REQUIRED"
            )

        # Preserve the first unresolved execution ambiguity.  A later event
        # must never erase the original reconciliation starting point.
        existing = self.read()
        if existing is not None:
            return existing

        ts = int(
            time.time_ns() // 1_000_000
            if latched_at_ms is None
            else latched_at_ms
        )
        raw = self._encode(
            reason=reason,
            symbol=symbol,
            entry_ready_id=entry_ready_id,
            client_order_id=client_order_id,
            latched_at_ms=ts,
        )

        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_name(
            self.path.name + ".tmp." + str(os.getpid())
        )

        fd = os.open(
            tmp,
            os.O_WRONLY | os.O_CREAT | os.O_TRUNC,
            0o600,
        )
        try:
            with os.fdopen(fd, "wb") as fh:
                fh.write(raw)
                fh.flush()
                os.fsync(fh.fileno())
            os.replace(tmp, self.path)

            dir_fd = os.open(
                self.path.parent,
                os.O_RDONLY,
            )
            try:
                os.fsync(dir_fd)
            finally:
                os.close(dir_fd)
        except Exception as exc:
            try:
                tmp.unlink(missing_ok=True)
            except Exception:
                pass
            raise ExecutionUncertaintyLatchBlock(
                "EXECUTION_UNCERTAINTY_LATCH_PERSISTENCE_FAILED:"
                + exc.__class__.__name__
                + ":"
                + str(exc)
            ) from exc

        state = self.read()
        if state is None:
            raise ExecutionUncertaintyLatchBlock(
                "EXECUTION_UNCERTAINTY_LATCH_PERSISTENCE_NOT_VISIBLE"
            )
        return state

    def read(self) -> ExecutionUncertaintyLatchStateV1 | None:
        if not self.path.exists():
            return None

        try:
            raw = self.path.read_text(encoding="utf-8")
            item = json.loads(raw)
        except Exception as exc:
            raise ExecutionUncertaintyLatchBlock(
                "EXECUTION_UNCERTAINTY_LATCH_CORRUPT:"
                + exc.__class__.__name__
            ) from exc

        expected = {
            "schema",
            "latched",
            "reason",
            "symbol",
            "entry_ready_id",
            "client_order_id",
            "latched_at_ms",
            "payload_sha256",
        }
        if not isinstance(item, dict) or set(item) != expected:
            raise ExecutionUncertaintyLatchBlock(
                "EXECUTION_UNCERTAINTY_LATCH_FIELD_DRIFT"
            )
        if item.get("schema") != SCHEMA:
            raise ExecutionUncertaintyLatchBlock(
                "EXECUTION_UNCERTAINTY_LATCH_SCHEMA_DRIFT"
            )
        if item.get("latched") is not True:
            raise ExecutionUncertaintyLatchBlock(
                "EXECUTION_UNCERTAINTY_LATCH_STATE_INVALID"
            )

        payload = {
            key: item[key]
            for key in (
                "schema",
                "latched",
                "reason",
                "symbol",
                "entry_ready_id",
                "client_order_id",
                "latched_at_ms",
            )
        }
        actual = hashlib.sha256(
            _canonical_json(payload).encode("utf-8")
        ).hexdigest()
        expected_digest = str(item.get("payload_sha256", ""))
        if actual != expected_digest:
            raise ExecutionUncertaintyLatchBlock(
                "EXECUTION_UNCERTAINTY_LATCH_DIGEST_MISMATCH"
            )

        reason = str(item.get("reason", ""))
        symbol = str(item.get("symbol", ""))
        entry_ready_id = str(item.get("entry_ready_id", ""))
        client_order_id = str(item.get("client_order_id", ""))
        try:
            latched_at_ms = int(item.get("latched_at_ms"))
        except Exception as exc:
            raise ExecutionUncertaintyLatchBlock(
                "EXECUTION_UNCERTAINTY_LATCH_TIME_INVALID"
            ) from exc

        if not all(
            (reason, symbol, entry_ready_id, client_order_id)
        ):
            raise ExecutionUncertaintyLatchBlock(
                "EXECUTION_UNCERTAINTY_LATCH_IDENTITY_INCOMPLETE"
            )

        return ExecutionUncertaintyLatchStateV1(
            reason=reason,
            symbol=symbol,
            entry_ready_id=entry_ready_id,
            client_order_id=client_order_id,
            latched_at_ms=latched_at_ms,
            payload_sha256=expected_digest,
        )

    def assert_new_risk_allowed(self) -> None:
        state = self.read()
        if state is None:
            return
        raise ExecutionUncertaintyLatchBlock(
            "GLOBAL_EXECUTION_UNCERTAINTY_LATCHED:"
            + state.reason
            + ":"
            + state.symbol
            + ":"
            + state.entry_ready_id
        )


def resolve_execution_uncertainty_latch_path(
    ledger: Any,
) -> pathlib.Path:
    seen: set[int] = set()
    current = ledger
    while current is not None and id(current) not in seen:
        seen.add(id(current))
        raw_path = getattr(current, "path", None)
        if raw_path is not None:
            path = pathlib.Path(raw_path)
            return path.parent / DEFAULT_FILENAME
        current = getattr(current, "inner", None)

    raise ExecutionUncertaintyLatchBlock(
        "EXECUTION_UNCERTAINTY_LATCH_STORAGE_UNAVAILABLE"
    )


__all__ = [
    "SCHEMA",
    "DEFAULT_FILENAME",
    "ExecutionUncertaintyLatchBlock",
    "ExecutionUncertaintyLatchStateV1",
    "ExecutionUncertaintyLatchV1",
    "resolve_execution_uncertainty_latch_path",
]
