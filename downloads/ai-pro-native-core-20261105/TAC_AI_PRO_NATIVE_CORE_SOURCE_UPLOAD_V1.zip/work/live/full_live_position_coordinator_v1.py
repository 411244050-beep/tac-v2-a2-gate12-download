from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping

from d6_activation_persistence_v1 import (
    persist_d6_activation_snapshot_first,
)
from d6_position_store_v1 import AuthoritativeD6PositionStoreV1
from d6_live_bridge_v1 import (
    D6LiveBridgeBlock,
    activate_authoritative_position,
    build_frozen_entry_provenance,
    close_authoritative_position,
    register_authoritative_position,
)
from full_live_executor_v1 import (
    AdmittedTacSignalV1,
    FullLiveExecutorV1,
)
from strategy_rc1.d6_position_execution.position import StrategyPositionRegistry
from trade_ledger_v1 import LedgerEvent, TradeLedgerV1


class FullLivePositionActivationBlock(RuntimeError):
    pass


@dataclass(frozen=True)
class D6ActivationInputsV1:
    """Opaque Strategy-owned values required to activate a real D6 position.

    Enum/dataclass values are supplied by the existing TAC runtime. This live
    layer does not convert strings into Strategy enums and does not invent IDs.
    """

    position_id: str
    frozen_entry_fields: Mapping[str, Any]
    mode: Any
    latest_qualified_protective_pivot: Any
    current_protective_stop: Any
    observer_label: Any = None
    provenance: Mapping[str, str] | None = None


def _assert_entry_identity_matches_signal(
    signal: AdmittedTacSignalV1,
    fields: Mapping[str, Any],
    *,
    hard_stop_price: str,
) -> None:
    checks = {
        "entry_ready_id": signal.entry_ready_id,
        "entry_ready_cutoff": signal.cutoff,
        "symbol": signal.symbol,
        "opportunity_id": signal.opportunity_id,
    }
    for name, expected in checks.items():
        if fields.get(name) != expected:
            raise FullLivePositionActivationBlock(
                "D6_ENTRY_IDENTITY_DRIFT:"
                + name
                + ":"
                + repr(fields.get(name))
                + "!="
                + repr(expected)
            )

    direction = fields.get("direction")
    direction_text = getattr(direction, "value", direction)
    if str(direction_text).upper() != signal.direction.upper():
        raise FullLivePositionActivationBlock("D6_DIRECTION_DRIFT")

    numeric_stop = fields.get("initial_hard_stop_numeric")

    # Exchange hard protection and D6 scientific numeric-stop authority are
    # separate contracts.  execute_entry() has already established exchange
    # hard protection before this function runs.  Current D6 governance may
    # legitimately carry no authorized numeric stop at all.
    #
    # If D6 eventually carries an authorized numeric initial stop, preserve
    # the existing cross-check against the exchange-side protection.
    if numeric_stop is not None and str(numeric_stop) != str(hard_stop_price):
        try:
            if float(numeric_stop) != float(hard_stop_price):
                raise FullLivePositionActivationBlock(
                    "D6_HARD_STOP_PRICE_DRIFT"
                )
        except (TypeError, ValueError):
            raise FullLivePositionActivationBlock(
                "D6_HARD_STOP_PRICE_DRIFT"
            )


class FullLivePositionCoordinatorV1:
    def __init__(
        self,
        *,
        executor: FullLiveExecutorV1,
        registry: StrategyPositionRegistry | AuthoritativeD6PositionStoreV1,
        ledger: TradeLedgerV1,
    ) -> None:
        self.executor = executor
        self.registry = (
            registry
            if isinstance(registry, AuthoritativeD6PositionStoreV1)
            else AuthoritativeD6PositionStoreV1(registry)
        )
        self.ledger = ledger

    def execute_and_activate(
        self,
        *,
        signal: AdmittedTacSignalV1,
        activation: D6ActivationInputsV1,
        authorized_quantity: Any = None,
        authorized_raw_hard_stop: Any = None,
    ) -> Any:
        if (
            authorized_quantity is None
            and authorized_raw_hard_stop is None
        ):
            exchange = self.executor.execute_entry(signal)
        else:
            exchange = self.executor.execute_entry(
                signal,
                authorized_quantity=authorized_quantity,
                authorized_raw_hard_stop=authorized_raw_hard_stop,
            )

        if exchange.get("status") != "POSITION_OPENED_WITH_HARD_PROTECTION":
            return exchange

        try:
            _assert_entry_identity_matches_signal(
                signal,
                activation.frozen_entry_fields,
                hard_stop_price=str(exchange["hard_stop_price"]),
            )

            entry = build_frozen_entry_provenance(
                fields_from_tac=activation.frozen_entry_fields,
                provenance=activation.provenance,
            )

            position = activate_authoritative_position(
                position_id=activation.position_id,
                entry=entry,
                execution_evidence_id=str(exchange["execution_evidence_id"]),
                opened_real_time=exchange["opened_real_time"],
                mode=activation.mode,
                latest_qualified_protective_pivot=(
                    activation.latest_qualified_protective_pivot
                ),
                current_protective_stop=activation.current_protective_stop,
                observer_label=activation.observer_label,
                provenance=activation.provenance,
            )

            # Persist the complete typed snapshot before marking D6 activated.
            # Only after both durable events exist do we install the position
            # into the in-memory registry.
            persist_d6_activation_snapshot_first(
                ledger=self.ledger,
                snapshot=position,
                entry_ready_id=signal.entry_ready_id,
                opportunity_id=signal.opportunity_id,
                execution_evidence_id=str(
                    exchange["execution_evidence_id"]
                ),
                opened_real_time=exchange["opened_real_time"],
                hard_stop_price=str(exchange["hard_stop_price"]),
            )

            register_authoritative_position(
                registry=self.registry,
                position=position,
            )

        except Exception as activation_exc:
            # Safety action must not depend on another ledger write succeeding.
            # Reverse the exchange position first, then record diagnostics on a
            # best-effort basis.
            try:
                self.executor.execute_strategy_exit(
                    symbol=signal.symbol,
                    direction=signal.direction,
                    reason="FAIL_CLOSED_D6_ACTIVATION_FAILURE",
                    reference_id=signal.entry_ready_id,
                )
            except Exception as close_exc:
                try:
                    self.ledger.append(LedgerEvent.build(
                        "EXECUTION_ERROR",
                        symbol=signal.symbol,
                        data={
                            "reason": (
                                "FATAL_D6_ACTIVATION_FAILURE_WITH_"
                                "OPEN_EXCHANGE_POSITION"
                            ),
                            "entry_ready_id": signal.entry_ready_id,
                            "detail": str(activation_exc)[:1200],
                            "close_detail": str(close_exc)[:1200],
                        },
                    ))
                except Exception:
                    pass
                raise FullLivePositionActivationBlock(
                    "FATAL_D6_ACTIVATION_FAILURE_WITH_OPEN_EXCHANGE_POSITION:"
                    + str(close_exc)
                ) from activation_exc

            try:
                self.ledger.append(LedgerEvent.build(
                    "EXECUTION_ERROR",
                    symbol=signal.symbol,
                    data={
                        "reason": "D6_REAL_POSITION_ACTIVATION_FAILED",
                        "entry_ready_id": signal.entry_ready_id,
                        "detail": str(activation_exc)[:1500],
                        "exchange_position_reversed": True,
                    },
                ))
            except Exception:
                pass

            raise FullLivePositionActivationBlock(
                "EXCHANGE_POSITION_REVERSED_AFTER_D6_ACTIVATION_FAILURE"
            ) from activation_exc

        return position

    def close_after_d6_exit(
        self,
        *,
        position_id: str,
        symbol: str,
        direction: str,
        exit_id: str,
        primary_reason: str,
    ) -> Any:
        """Exchange close first; freeze D6 CLOSED only after close request succeeds."""
        result = self.executor.execute_strategy_exit(
            symbol=symbol,
            direction=direction,
            reason=primary_reason,
            reference_id=exit_id,
        )

        closed = close_authoritative_position(
            registry=self.registry,
            position_id=position_id,
            exit_id=exit_id,
        )

        self.ledger.append(LedgerEvent.build(
            "D6_POSITION_CLOSED",
            symbol=symbol,
            data={
                "position_id": position_id,
                "exit_id": exit_id,
                "primary_reason": primary_reason,
                "exchange_result": result,
            },
        ))
        return closed
