from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from fractions import Fraction
from typing import Mapping

from full_live_authoritative_entry_activation_binding_v1 import (
    AuthoritativeEntryActivationBindingV1,
)
from full_live_execution_feasibility_enforcement_v1 import (
    ExecutionFeasibilityEnforcementV1,
    enforce_authorized_execution_slots,
)
from full_live_prospective_execution_evidence_v1 import (
    ProspectiveExecutionEvidenceV1,
    validate_prospective_execution_evidence,
)
from full_live_public_market_legality_v1 import (
    PublicMarketEntryLegalityObservationV1,
)
from full_live_remaining_d5_policy_enforcement_v1 import (
    OperationalCandidateV1,
)


class FullLiveProductionOperationalCandidateBlock(RuntimeError):
    pass


@dataclass(frozen=True)
class ProductionOperationalCandidateProjectionV1:
    candidate: OperationalCandidateV1
    execution_enforcement: ExecutionFeasibilityEnforcementV1
    legality_observation: PublicMarketEntryLegalityObservationV1
    provenance: Mapping[str, str]


def _fraction_to_exact_decimal(
    value: Fraction,
    label: str,
) -> Decimal:
    if not isinstance(value, Fraction):
        raise FullLiveProductionOperationalCandidateBlock(
            label + "_FRACTION_REQUIRED"
        )
    out = Decimal(value.numerator) / Decimal(value.denominator)
    if Fraction(out) != value:
        raise FullLiveProductionOperationalCandidateBlock(
            label + "_NOT_EXACT_DECIMAL"
        )
    return out


def build_production_operational_candidate(
    *,
    binding: AuthoritativeEntryActivationBindingV1,
    execution_evidence: ProspectiveExecutionEvidenceV1,
    legality_observation: PublicMarketEntryLegalityObservationV1,
) -> ProductionOperationalCandidateProjectionV1:
    if not isinstance(
        binding,
        AuthoritativeEntryActivationBindingV1,
    ):
        raise FullLiveProductionOperationalCandidateBlock(
            "AUTHORITATIVE_ENTRY_ACTIVATION_BINDING_REQUIRED"
        )
    evidence = validate_prospective_execution_evidence(
        execution_evidence
    )
    if not isinstance(
        legality_observation,
        PublicMarketEntryLegalityObservationV1,
    ):
        raise FullLiveProductionOperationalCandidateBlock(
            "PUBLIC_MARKET_LEGALITY_OBSERVATION_REQUIRED"
        )

    subject = (
        evidence.symbol,
        evidence.direction.upper(),
        evidence.entry_ready_id,
        evidence.information_cutoff,
    )
    expected = (
        binding.symbol,
        binding.signal.direction.upper(),
        binding.entry_ready_id,
        binding.information_cutoff,
    )
    if subject != expected:
        raise FullLiveProductionOperationalCandidateBlock(
            "EXECUTION_EVIDENCE_SUBJECT_DRIFT"
        )
    legality_subject = (
        legality_observation.symbol,
        legality_observation.information_cutoff,
    )
    if legality_subject != (
        binding.symbol,
        binding.information_cutoff,
    ):
        raise FullLiveProductionOperationalCandidateBlock(
            "LEGALITY_OBSERVATION_SUBJECT_DRIFT"
        )
    if legality_observation.observed_at_ms < evidence.observed_at_ms:
        raise FullLiveProductionOperationalCandidateBlock(
            "LEGALITY_OBSERVATION_PRECEDES_EXECUTION_EVIDENCE"
        )

    enforcement = enforce_authorized_execution_slots(
        evidence=evidence,
        legality=legality_observation.legality,
    )

    per_unit = _fraction_to_exact_decimal(
        binding.per_unit_structural_risk,
        "PER_UNIT_STRUCTURAL_RISK",
    )
    hard_stop = _fraction_to_exact_decimal(
        binding.numeric_hard_stop,
        "NUMERIC_HARD_STOP",
    )
    quantity = legality_observation.legality.rounded_quantity
    if quantity <= 0:
        raise FullLiveProductionOperationalCandidateBlock(
            "AUTHORIZED_QUANTITY_NONPOSITIVE"
        )
    risk_quote = quantity * per_unit
    if risk_quote <= 0:
        raise FullLiveProductionOperationalCandidateBlock(
            "STRUCTURAL_RISK_NONPOSITIVE"
        )

    candidate = OperationalCandidateV1(
        symbol=binding.symbol,
        direction=binding.signal.direction.upper(),
        entry_ready_id=binding.entry_ready_id,
        transaction_id=binding.transaction_id,
        information_cutoff=binding.information_cutoff,
        authorized_quantity=quantity,
        per_unit_structural_risk=per_unit,
        numeric_hard_stop=hard_stop,
        structural_risk_quote=risk_quote,
        legality=legality_observation.legality,
        execution_enforcement=enforcement,
    )
    return ProductionOperationalCandidateProjectionV1(
        candidate=candidate,
        execution_enforcement=enforcement,
        legality_observation=legality_observation,
        provenance={
            "binding": (
                "TAC_FULL_LIVE_PRODUCTION_OPERATIONAL_CANDIDATE_V1"
            ),
            "strategy_authority": (
                "AUTHORITATIVE_UPDATE011_012_013_014"
            ),
            "execution_evidence": evidence.evidence_id,
            "legality_source": (
                legality_observation.ticker_source
            ),
            "structural_risk_formula": (
                "authorized_quantity*per_unit_structural_risk"
            ),
            "capital_snapshot_used_here": "false",
            "selector_added": "false",
            "ranking_added": "false",
        },
    )


def invariants() -> Mapping[str, object]:
    return {
        "update014_required_upstream": True,
        "prospective_execution_evidence_required": True,
        "current_exchange_legality_required": True,
        "capital_policy_owned": False,
        "risk_formula": (
            "authorized_quantity*per_unit_structural_risk"
        ),
        "selector_added": False,
        "ranking_added": False,
        "orders": 0,
        "fills": 0,
        "execution_intents": 0,
        "trading_activated": False,
    }


__all__ = [
    "FullLiveProductionOperationalCandidateBlock",
    "ProductionOperationalCandidateProjectionV1",
    "build_production_operational_candidate",
    "invariants",
]
