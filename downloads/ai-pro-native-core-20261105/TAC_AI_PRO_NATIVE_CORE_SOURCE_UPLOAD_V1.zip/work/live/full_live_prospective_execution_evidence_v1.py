from __future__ import annotations
from dataclasses import asdict,dataclass
import hashlib,json
from typing import Mapping
from binance_usdm_public_depth_snapshot_v1 import BinanceUSDMPublicDepthSnapshotV1
from full_live_execution_feasibility_measurement_v1 import ExecutionFeasibilityMeasurementV1

class ExecutionEvidenceBlock(RuntimeError): pass

@dataclass(frozen=True)
class ProspectiveExecutionEvidenceV1:
    evidence_id:str
    symbol:str
    direction:str
    entry_ready_id:str
    information_cutoff:int
    observed_at_ms:int
    clock_authority:str
    depth_source:str
    depth_last_update_id:int
    depth_message_output_time_ms:int
    depth_transaction_time_ms:int
    intended_quote_notional:str
    spread_bps:str
    impact_from_best_bps:str|None
    fully_fillable:bool

def _payload(e:ProspectiveExecutionEvidenceV1)->dict[str,object]:
    return {
      "symbol":e.symbol,"direction":e.direction,"entry_ready_id":e.entry_ready_id,
      "information_cutoff":e.information_cutoff,"observed_at_ms":e.observed_at_ms,"clock_authority":e.clock_authority,
      "depth_source":e.depth_source,"depth_last_update_id":e.depth_last_update_id,
      "depth_message_output_time_ms":e.depth_message_output_time_ms,"depth_transaction_time_ms":e.depth_transaction_time_ms,
      "intended_quote_notional":e.intended_quote_notional,"spread_bps":e.spread_bps,
      "impact_from_best_bps":e.impact_from_best_bps,"fully_fillable":e.fully_fillable,
    }

def validate_prospective_execution_evidence(e:ProspectiveExecutionEvidenceV1)->ProspectiveExecutionEvidenceV1:
    if not isinstance(e,ProspectiveExecutionEvidenceV1): raise ExecutionEvidenceBlock("TYPED_EVIDENCE_REQUIRED")
    if not e.symbol or not e.entry_ready_id or not e.clock_authority or not e.depth_source:
        raise ExecutionEvidenceBlock("PROVENANCE_REQUIRED")
    if e.direction not in ("LONG","SHORT"): raise ExecutionEvidenceBlock("DIRECTION_INVALID")
    if not isinstance(e.information_cutoff,int) or e.information_cutoff<0:
        raise ExecutionEvidenceBlock("INFORMATION_CUTOFF_INVALID")
    if not isinstance(e.observed_at_ms,int) or e.observed_at_ms<e.information_cutoff:
        raise ExecutionEvidenceBlock("OBSERVATION_PRECEDES_INFORMATION_CUTOFF")
    if not isinstance(e.depth_last_update_id,int) or e.depth_last_update_id<0:
        raise ExecutionEvidenceBlock("DEPTH_UPDATE_ID_INVALID")
    if not isinstance(e.depth_message_output_time_ms,int) or e.depth_message_output_time_ms<=0:
        raise ExecutionEvidenceBlock("DEPTH_MESSAGE_TIME_INVALID")
    if not isinstance(e.depth_transaction_time_ms,int) or e.depth_transaction_time_ms<=0:
        raise ExecutionEvidenceBlock("DEPTH_TRANSACTION_TIME_INVALID")
    if e.depth_transaction_time_ms>e.depth_message_output_time_ms:
        raise ExecutionEvidenceBlock("DEPTH_TIME_ORDER_INVALID")
    if e.depth_transaction_time_ms<e.information_cutoff:
        raise ExecutionEvidenceBlock("DEPTH_TRANSACTION_PRECEDES_INFORMATION_CUTOFF")
    expected="EXECUTION_EVIDENCE_SHA256:"+hashlib.sha256(
        json.dumps(_payload(e),sort_keys=True,separators=(",",":")).encode()
    ).hexdigest()
    if e.evidence_id!=expected: raise ExecutionEvidenceBlock("EVIDENCE_DIGEST_MISMATCH")
    return e

def build_prospective_execution_evidence(*,entry_ready_id:str,information_cutoff:int,observed_at_ms:int,
    collector_started_at_ms:int,clock_authority:str,depth:BinanceUSDMPublicDepthSnapshotV1,
    measurement:ExecutionFeasibilityMeasurementV1)->ProspectiveExecutionEvidenceV1:
    if not entry_ready_id or not clock_authority: raise ExecutionEvidenceBlock("PROVENANCE_REQUIRED")
    if information_cutoff<0 or collector_started_at_ms<=0 or observed_at_ms<collector_started_at_ms:
        raise ExecutionEvidenceBlock("PROSPECTIVE_TIME_INVALID")
    if observed_at_ms<information_cutoff: raise ExecutionEvidenceBlock("OBSERVATION_PRECEDES_INFORMATION_CUTOFF")
    if depth.symbol!=measurement.symbol: raise ExecutionEvidenceBlock("SYMBOL_DRIFT")
    if depth.transaction_time_ms<information_cutoff:
        raise ExecutionEvidenceBlock("DEPTH_TRANSACTION_PRECEDES_INFORMATION_CUTOFF")
    payload={"symbol":measurement.symbol,"direction":measurement.direction,"entry_ready_id":entry_ready_id,
      "information_cutoff":information_cutoff,"observed_at_ms":observed_at_ms,"clock_authority":clock_authority,
      "depth_source":depth.source,"depth_last_update_id":depth.last_update_id,
      "depth_message_output_time_ms":depth.message_output_time_ms,"depth_transaction_time_ms":depth.transaction_time_ms,
      "intended_quote_notional":str(measurement.intended_quote_notional),"spread_bps":str(measurement.spread_bps),
      "impact_from_best_bps":None if measurement.impact_from_best_bps is None else str(measurement.impact_from_best_bps),
      "fully_fillable":measurement.fully_fillable}
    eid="EXECUTION_EVIDENCE_SHA256:"+hashlib.sha256(json.dumps(payload,sort_keys=True,separators=(",",":")).encode()).hexdigest()
    return validate_prospective_execution_evidence(ProspectiveExecutionEvidenceV1(evidence_id=eid,**payload))

def invariants()->Mapping[str,object]:
    return {"prospective_only":True,"depth_update_id_bound":True,"depth_exchange_times_bound":True,"clock_authority_required":True,"observation_not_before_information_cutoff":True,"depth_transaction_not_before_information_cutoff":True,"digest_revalidated":True,
      "policy_threshold_owned":False,"historical_backfill":False,"outcome_read":False,"pnl_read":False,
      "orders":0,"fills":0,"execution_intents":0,"trading_activated":False}
