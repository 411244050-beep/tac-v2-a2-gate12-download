from __future__ import annotations

from pathlib import Path
import sys

REPO_ROOT = Path(__file__).resolve().parents[2]
PROVISIONAL_DIR = REPO_ROOT / "provisional_shadow_v1"
if str(PROVISIONAL_DIR) not in sys.path:
    sys.path.insert(0, str(PROVISIONAL_DIR))

"""Pure B4 projection for a durable pre-bar Interaction surface."""

from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Any, Mapping

from strategy_rc1.d3_boundary_intelligence.types import (
    InteractionControl,
    InteractionEvent,
)

import d2_to_b4_d4_causal_evidence_producers_v1 as b4prod

from full_live_active_d4_causal_time_authority_v1 import (
    derive_active_b4_causal_time_authority,
)


class FullLiveActiveB4Block(RuntimeError):
    pass


class FullLiveActiveB4Conflict(FullLiveActiveB4Block):
    pass


@dataclass(frozen=True)
class ActiveB4ProjectionV1:
    structural_acceptance: Any
    correct_side_recovery: Any
    provenance: Mapping[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "provenance",
            MappingProxyType(dict(self.provenance)),
        )


def project_active_b4(
    *,
    symbol: str,
    trend_episode_id: str,
    direction: Any,
    information_cutoff: int,
    canonical_segment_id: str,
    event: InteractionEvent,
    geometry: Any,
    current_close: Any,
    minor_history: tuple[Any, ...],
    canonical_records: tuple[Any, ...],
    theta_progress: Any,
) -> ActiveB4ProjectionV1:
    if event.target_trend_episode_id != trend_episode_id:
        raise FullLiveActiveB4Conflict(
            "B4_EVENT_TREND_EPISODE_MISMATCH"
        )
    if event.target_direction is not direction:
        raise FullLiveActiveB4Conflict(
            "B4_EVENT_DIRECTION_MISMATCH"
        )
    if event.control not in (
        InteractionControl.ARMED,
        InteractionControl.INTERACTION_ACTIVE,
    ):
        # RESOLVED rows carry immutable historical truth but do not need fresh
        # B4 production; return explicit non-consumer projections.
        if event.control is InteractionControl.RESOLVED:
            ctx = b4prod.LineageContext(
                symbol=symbol,
                target_trend_episode_id=trend_episode_id,
                direction=direction,
                information_cutoff=information_cutoff,
                canonical_segment_id=canonical_segment_id,
                interaction_event_id=event.event_id,
                source_evidence_refs=(
                    "InteractionEvent:" + event.event_id,
                    "B4:RESOLVED_NO_FRESH_PROJECTION",
                ),
                continuity_known=True,
                continuity_intact=True,
                same_cutoff_order_proven=True,
            )
            sa = b4prod._result(
                "B4_STRUCTURAL_ACCEPTANCE_D2_PROJECTION_V1",
                b4prod.EvidenceState.FALSE,
                "INTERACTION_ALREADY_RESOLVED",
                ctx,
            )
            cr = b4prod._result(
                "B4_CORRECT_SIDE_RECOVERY_D2_PROJECTION_V1",
                b4prod.EvidenceState.FALSE,
                "INTERACTION_ALREADY_RESOLVED",
                ctx,
            )
            return ActiveB4ProjectionV1(
                structural_acceptance=sa,
                correct_side_recovery=cr,
                provenance={"resolved_no_fresh_b4": "true"},
            )
        raise FullLiveActiveB4Block(
            "B4_UNSUPPORTED_INTERACTION_CONTROL:"
            + str(getattr(event.control, "value", event.control))
        )

    timing = derive_active_b4_causal_time_authority(
        event=event,
        direction=direction,
        information_cutoff=information_cutoff,
        canonical_segment_id=canonical_segment_id,
        canonical_records=canonical_records,
    )
    ctx = b4prod.LineageContext(
        symbol=symbol,
        target_trend_episode_id=trend_episode_id,
        direction=direction,
        information_cutoff=information_cutoff,
        canonical_segment_id=canonical_segment_id,
        interaction_event_id=event.event_id,
        source_evidence_refs=(
            "InteractionEvent:" + event.event_id,
            "D1CanonicalArmingCutoff:" + str(timing.arming_cutoff),
        ),
        continuity_known=True,
        continuity_intact=True,
        same_cutoff_order_proven=True,
    )
    sa = b4prod.produce_structural_acceptance(
        b4prod.StructuralAcceptanceRequest(
            context=ctx,
            interaction=event,
            pivots=minor_history,
            separation_origin_open_time=timing.arming_open_time,
            separation_cutoff=timing.arming_cutoff,
            theta_progress=theta_progress,
            prior_reclaim_cutoffs=timing.reclaim_cutoffs,
        )
    )
    if sa.state is b4prod.EvidenceState.CONFLICT:
        raise FullLiveActiveB4Conflict(
            "STRUCTURAL_ACCEPTANCE_CONFLICT:" + sa.reason
        )

    if (
        event.attempted_wrong_side_acceptance
        and timing.first_wrong_side_attempt_cutoff is None
    ):
        raise FullLiveActiveB4Conflict(
            "ATTEMPT_STATE_WITHOUT_CAUSAL_ATTEMPT_CUTOFF"
        )

    # Before the first attempted wrong-side close, CorrectSideRecovery is
    # scientifically UNKNOWN by definition.  We still call the frozen
    # producer with the arming origin/cutoff because it exits on the explicit
    # event.attempted flag before consuming the attempt interval.
    attempt_open = (
        timing.arming_open_time
        if timing.first_wrong_side_attempt_open_time is None
        else timing.first_wrong_side_attempt_open_time
    )
    attempt_cutoff = (
        timing.arming_cutoff
        if timing.first_wrong_side_attempt_cutoff is None
        else timing.first_wrong_side_attempt_cutoff
    )
    cr = b4prod.produce_correct_side_recovery(
        b4prod.CorrectSideRecoveryRequest(
            context=ctx,
            interaction=event,
            pivots=minor_history,
            attempt_origin_open_time=attempt_open,
            attempt_cutoff=attempt_cutoff,
            evaluating_close=current_close,
        )
    )
    if cr.state is b4prod.EvidenceState.CONFLICT:
        raise FullLiveActiveB4Conflict(
            "CORRECT_SIDE_RECOVERY_CONFLICT:" + cr.reason
        )

    return ActiveB4ProjectionV1(
        structural_acceptance=sa,
        correct_side_recovery=cr,
        provenance={
            "producer": "FULL_LIVE_ACTIVE_B4_PROJECTION_V1",
            "arming_cutoff": str(timing.arming_cutoff),
            "first_attempt_cutoff": (
                "NONE"
                if timing.first_wrong_side_attempt_cutoff is None
                else str(timing.first_wrong_side_attempt_cutoff)
            ),
            "reclaim_count": str(len(timing.reclaim_cutoffs)),
            "new_threshold_added": "false",
            "fixed_window_added": "false",
        },
    )


def invariants() -> Mapping[str, Any]:
    return {
        "break_classification_owned_here": False,
        "frozen_structural_acceptance_reused": True,
        "frozen_correct_side_recovery_reused": True,
        "attempt_cutoff_from_causal_time_authority": True,
        "reclaim_history_from_canonical_closes": True,
        "current_canonical_bar_close_passed_explicitly": True,
        "normalized_geometry_used_to_reconstruct_close": False,
        "new_threshold_added": False,
        "fixed_window_added": False,
        "trading_activated": False,
    }
