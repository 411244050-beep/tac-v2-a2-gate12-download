from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import Any, Iterable, Mapping

from full_live_restart_reconciliation_v1 import (
    RestartReconciliationBlock,
    _exchange_qty,
    _open_hard_stop_present,
)
from strategy_rc1.d6_position_execution.types import (
    HardProtectionEvidence,
    StrategyPositionSnapshot,
)
from strategy_rc1.runtime_guards.information_state import InfoValue


class FullLiveD6HardProtectionEvidenceBlock(RuntimeError):
    pass


@dataclass(frozen=True)
class D6HardProtectionProjectionV1:
    evidence: HardProtectionEvidence
    exchange_quantity: Decimal
    hard_stop_present: bool
    status: str
    provenance: Mapping[str, str]


def _matching_trigger_event(
    rows: Iterable[Mapping[str, Any]],
    *,
    position: StrategyPositionSnapshot,
    information_cutoff: int,
) -> Mapping[str, Any] | None:
    entry = position.entry
    matches = []
    for row in rows:
        if row.get("event_type") != "HARD_PROTECTION_TRIGGERED":
            continue
        if str(row.get("symbol", "")) != entry.symbol:
            continue
        event_time = int(row.get("event_time_ms", 0) or 0)
        if event_time <= 0 or event_time > information_cutoff:
            continue
        data = row.get("data")
        if not isinstance(data, Mapping):
            raise FullLiveD6HardProtectionEvidenceBlock(
                "HARD_PROTECTION_TRIGGER_DATA_MAPPING_REQUIRED"
            )
        if str(data.get("position_id", "")) != position.position_id:
            continue
        if (
            str(data.get("entry_ready_id", ""))
            != entry.entry_ready_id
        ):
            continue
        matches.append(row)
    if len(matches) > 1:
        raise FullLiveD6HardProtectionEvidenceBlock(
            "MULTIPLE_HARD_PROTECTION_TRIGGER_EVENTS_FOR_POSITION"
        )
    return matches[0] if matches else None


def produce_hard_protection_evidence(
    *,
    position: StrategyPositionSnapshot,
    information_cutoff: int,
    exchange_position_snapshot: Any,
    exchange_open_orders: Any,
    ledger_rows: Iterable[Mapping[str, Any]],
) -> D6HardProtectionProjectionV1:
    if not isinstance(position, StrategyPositionSnapshot):
        raise FullLiveD6HardProtectionEvidenceBlock(
            "STRATEGY_POSITION_SNAPSHOT_REQUIRED"
        )
    if information_cutoff <= 0:
        raise FullLiveD6HardProtectionEvidenceBlock(
            "INFORMATION_CUTOFF_INVALID"
        )

    entry = position.entry
    direction = entry.direction.value
    try:
        qty = _exchange_qty(
            exchange_position_snapshot,
            symbol=entry.symbol,
            direction=direction,
        )
    except RestartReconciliationBlock as exc:
        raise FullLiveD6HardProtectionEvidenceBlock(
            "EXCHANGE_POSITION_OBSERVATION_INVALID:" + str(exc)
        ) from exc

    trigger = _matching_trigger_event(
        tuple(ledger_rows),
        position=position,
        information_cutoff=information_cutoff,
    )

    if qty > 0:
        if trigger is not None:
            raise FullLiveD6HardProtectionEvidenceBlock(
                "HARD_PROTECTION_TRIGGER_EVENT_WITH_OPEN_EXCHANGE_POSITION"
            )
        matching_opened = [
            row for row in tuple(ledger_rows)
            if row.get("event_type") == "POSITION_OPENED"
            and row.get("symbol") == entry.symbol
            and isinstance(row.get("data"), Mapping)
            and row["data"].get("entry_ready_id") == entry.entry_ready_id
        ]
        if not matching_opened:
            raise FullLiveD6HardProtectionEvidenceBlock(
                "D6_ACTIVE_POSITION_DURABLE_OPENED_RISK_REQUIRED"
            )
        try:
            stop_price = Decimal(
                str(matching_opened[-1]["data"]["hard_stop_price"])
            )
        except Exception as exc:
            raise FullLiveD6HardProtectionEvidenceBlock(
                "D6_ACTIVE_POSITION_DURABLE_STOP_PRICE_INVALID"
            ) from exc
        if not stop_price.is_finite() or stop_price <= 0:
            raise FullLiveD6HardProtectionEvidenceBlock(
                "D6_ACTIVE_POSITION_DURABLE_STOP_PRICE_INVALID"
            )
        try:
            present = _open_hard_stop_present(
                exchange_open_orders,
                symbol=entry.symbol,
                direction=direction,
                entry_ready_id=entry.entry_ready_id,
                expected_stop_price=stop_price,
            )
        except RestartReconciliationBlock as exc:
            raise FullLiveD6HardProtectionEvidenceBlock(
                "EXCHANGE_HARD_STOP_OBSERVATION_INVALID:" + str(exc)
            ) from exc
        if not present:
            raise FullLiveD6HardProtectionEvidenceBlock(
                "ACTIVE_POSITION_WITHOUT_UNIQUE_EXCHANGE_HARD_STOP"
            )
        evidence = HardProtectionEvidence(
            triggered=InfoValue.known(False),
            execution_event_id=None,
            real_event_time=None,
            evidence_source=(
                "BINANCE_POSITION_OPEN_PLUS_UNIQUE_FULL_POSITION_STOP_V1"
            ),
        )
        return D6HardProtectionProjectionV1(
            evidence=evidence,
            exchange_quantity=qty,
            hard_stop_present=True,
            status="OPEN_POSITION_HARD_PROTECTION_CONFIRMED_NOT_TRIGGERED",
            provenance={
                "exchange_position_open": "true",
                "unique_full_position_hard_stop": "true",
                "absence_of_trigger_inferred_from_ledger_only": "false",
            },
        )

    if trigger is None:
        raise FullLiveD6HardProtectionEvidenceBlock(
            "ACTIVE_D6_POSITION_MISSING_ON_EXCHANGE_WITHOUT_"
            "HARD_PROTECTION_TRIGGER_EVIDENCE"
        )

    event_id = str(trigger.get("event_id", ""))
    event_time = int(trigger.get("event_time_ms", 0))
    if not event_id or event_time <= 0:
        raise FullLiveD6HardProtectionEvidenceBlock(
            "HARD_PROTECTION_TRIGGER_EVENT_ID_OR_TIME_INVALID"
        )
    evidence = HardProtectionEvidence(
        triggered=InfoValue.known(True),
        execution_event_id=event_id,
        real_event_time=event_time,
        evidence_source="DURABLE_HARD_PROTECTION_TRIGGER_LEDGER_V1",
    )
    return D6HardProtectionProjectionV1(
        evidence=evidence,
        exchange_quantity=Decimal("0"),
        hard_stop_present=False,
        status="HARD_PROTECTION_TRIGGER_CONFIRMED",
        provenance={
            "exchange_position_open": "false",
            "trigger_event_id": event_id,
            "manual_or_external_close_guessed_as_stop": "false",
        },
    )


def invariants() -> Mapping[str, object]:
    return {
        "open_position_requires_unique_exchange_hard_stop": True,
        "open_position_plus_stop_means_triggered_false": True,
        "missing_exchange_position_without_trigger_event": "FAIL_CLOSED",
        "manual_or_external_close_guessed_as_hard_stop": False,
        "orders": 0,
        "fills": 0,
        "execution_intents": 0,
        "trading_activated": False,
    }


__all__ = [
    "D6HardProtectionProjectionV1",
    "FullLiveD6HardProtectionEvidenceBlock",
    "produce_hard_protection_evidence",
    "invariants",
]
