from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import Any, Iterable, Mapping

from binance_execution_adapter_v1 import hard_stop_client_algo_id


class RestartReconciliationBlock(RuntimeError):
    pass


@dataclass(frozen=True)
class RestartPositionViewV1:
    symbol: str
    direction: str
    quantity: Decimal
    entry_ready_id: str | None
    position_id: str | None
    hard_stop_present: bool
    ledger_position_open: bool
    ledger_d6_active: bool
    exchange_position_open: bool
    status: str
    new_risk_blocked: bool


def _walk_dicts(value: Any):
    if isinstance(value, Mapping):
        yield value
        for child in value.values():
            yield from _walk_dicts(child)
    elif isinstance(value, (list, tuple)):
        for child in value:
            yield from _walk_dicts(child)


def _exchange_qty(
    exchange_position_snapshot: Any,
    *,
    symbol: str,
    direction: str,
) -> Decimal:
    wanted = direction.upper()
    found: list[Decimal] = []
    for row in _walk_dicts(exchange_position_snapshot):
        if str(row.get("symbol", "")) != symbol:
            continue
        if str(row.get("positionSide", "")).upper() != wanted:
            continue
        raw = row.get("positionAmt")
        if raw is None:
            continue
        try:
            qty = abs(Decimal(str(raw)))
        except Exception as exc:
            raise RestartReconciliationBlock(
                "EXCHANGE_POSITION_QTY_INVALID:" + symbol
            ) from exc
        found.append(qty)

    if len(found) > 1:
        nonzero = [x for x in found if x > 0]
        if len(nonzero) > 1:
            raise RestartReconciliationBlock(
                "AMBIGUOUS_EXCHANGE_POSITION_ROWS:" + symbol
            )
        if nonzero:
            return nonzero[0]
    return found[0] if found else Decimal("0")


def _open_hard_stop_present(
    exchange_open_orders: Any,
    *,
    symbol: str,
    direction: str,
    entry_ready_id: str,
    expected_stop_price: Decimal,
) -> bool:
    """Require the exact live TAC stop, never a same-side substitute."""
    client_id = hard_stop_client_algo_id(entry_ready_id)
    wanted_side = "SELL" if direction == "LONG" else "BUY"
    matches = []
    for row in _walk_dicts(exchange_open_orders):
        if "clientAlgoId" not in row:
            continue
        if str(row.get("clientAlgoId", "")) == client_id:
            matches.append(row)
    if len(matches) != 1:
        return False
    row = matches[0]
    try:
        stop = Decimal(str(row.get("triggerPrice")))
    except Exception:
        return False
    return (
        str(row.get("symbol", "")) == symbol
        and str(row.get("positionSide", "")).upper() == direction
        and str(row.get("side", "")).upper() == wanted_side
        and str(row.get("orderType", "")).upper() == "STOP_MARKET"
        and str(row.get("algoType", "")).upper() == "CONDITIONAL"
        and str(row.get("algoStatus", "")).upper() == "NEW"
        and str(row.get("workingType", "")).upper() == "MARK_PRICE"
        and str(row.get("closePosition", "")).lower() in {"true", "1"}
        and str(row.get("priceProtect", "")).lower() in {"true", "1"}
        and stop.is_finite()
        and stop == expected_stop_price
    )


def _symbol_events(
    ledger_rows: Iterable[Mapping[str, Any]],
    symbol: str,
) -> tuple[Mapping[str, Any], ...]:
    return tuple(
        row
        for row in ledger_rows
        if str(row.get("symbol", "")) == symbol
    )


def _latest_event(
    rows: Iterable[Mapping[str, Any]],
    event_type: str,
) -> Mapping[str, Any] | None:
    found = [
        row
        for row in rows
        if str(row.get("event_type", "")) == event_type
    ]
    if not found:
        return None
    return found[-1]


def reconcile_restart_position_v1(
    *,
    symbol: str,
    direction: str,
    ledger_rows: Iterable[Mapping[str, Any]],
    exchange_position_snapshot: Any,
    exchange_open_orders: Any,
) -> RestartPositionViewV1:
    if not symbol:
        raise RestartReconciliationBlock("SYMBOL_REQUIRED")
    direction = direction.upper()
    if direction not in ("LONG", "SHORT"):
        raise RestartReconciliationBlock(
            "DIRECTION_NOT_LONG_OR_SHORT:" + direction
        )

    rows = _symbol_events(tuple(ledger_rows), symbol)

    position_opened = _latest_event(rows, "POSITION_OPENED")
    d6_activated = _latest_event(rows, "D6_POSITION_ACTIVATED")
    d6_closed = _latest_event(rows, "D6_POSITION_CLOSED")
    position_closed = _latest_event(rows, "POSITION_CLOSED")

    ledger_position_open = position_opened is not None
    ledger_d6_active = d6_activated is not None

    # A later close event closes the corresponding ledger-side state.
    if position_closed is not None and position_opened is not None:
        if int(position_closed.get("event_time_ms", 0)) >= int(
            position_opened.get("event_time_ms", 0)
        ):
            ledger_position_open = False

    if d6_closed is not None and d6_activated is not None:
        if int(d6_closed.get("event_time_ms", 0)) >= int(
            d6_activated.get("event_time_ms", 0)
        ):
            ledger_d6_active = False

    qty = _exchange_qty(
        exchange_position_snapshot,
        symbol=symbol,
        direction=direction,
    )
    exchange_position_open = qty > 0
    entry_ready_id = None
    opened_data = None
    if position_opened is not None:
        opened_data = position_opened.get("data")
        if isinstance(opened_data, Mapping):
            entry_ready_id = str(
                opened_data.get("entry_ready_id") or ""
            ) or None

    hard_stop_present = False
    if exchange_position_open and entry_ready_id and opened_data is not None:
        try:
            stop_price = Decimal(str(opened_data.get("hard_stop_price")))
        except Exception:
            stop_price = Decimal("NaN")
        if stop_price.is_finite() and stop_price > 0:
            hard_stop_present = _open_hard_stop_present(
                exchange_open_orders,
                symbol=symbol,
                direction=direction,
                entry_ready_id=entry_ready_id,
                expected_stop_price=stop_price,
            )

    position_id = None
    if d6_activated is not None:
        position_id = str(
            (d6_activated.get("data") or {}).get("position_id") or ""
        ) or None

    if not exchange_position_open and not ledger_position_open and not ledger_d6_active:
        status = "CLEAN_NO_POSITION"
        blocked = False
    elif exchange_position_open and not ledger_position_open:
        status = "BLOCK_EXCHANGE_ONLY_POSITION"
        blocked = True
    elif ledger_position_open and not exchange_position_open:
        status = "BLOCK_LEDGER_POSITION_MISSING_ON_EXCHANGE"
        blocked = True
    elif ledger_position_open and not ledger_d6_active:
        status = "BLOCK_D6_ACTIVATION_MISSING"
        blocked = True
    elif ledger_d6_active and not exchange_position_open:
        status = "BLOCK_D6_ACTIVE_WITHOUT_EXCHANGE_POSITION"
        blocked = True
    elif exchange_position_open and not hard_stop_present:
        status = "BLOCK_OPEN_POSITION_WITHOUT_HARD_PROTECTION"
        blocked = True
    elif not entry_ready_id or not position_id:
        status = "BLOCK_RESTART_LINEAGE_INCOMPLETE"
        blocked = True
    else:
        # Exchange/ledger protection agrees, but the current ledger does not
        # yet carry enough typed state to reconstruct StrategyPositionSnapshot.
        status = "MATCHED_REQUIRES_D6_SNAPSHOT_RECONSTRUCTION"
        blocked = True

    return RestartPositionViewV1(
        symbol=symbol,
        direction=direction,
        quantity=qty,
        entry_ready_id=entry_ready_id,
        position_id=position_id,
        hard_stop_present=hard_stop_present,
        ledger_position_open=ledger_position_open,
        ledger_d6_active=ledger_d6_active,
        exchange_position_open=exchange_position_open,
        status=status,
        new_risk_blocked=blocked,
    )


__all__ = [
    "RestartReconciliationBlock",
    "RestartPositionViewV1",
    "reconcile_restart_position_v1",
]
