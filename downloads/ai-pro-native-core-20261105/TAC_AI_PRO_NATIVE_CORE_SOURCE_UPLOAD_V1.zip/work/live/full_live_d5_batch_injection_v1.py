from __future__ import annotations

"""Full-live D5 post-UPDATE-011 packet injection surface.

This module deliberately does not change frozen D4/D5 semantics and does not
produce any strategy signal itself.  It solves only the orchestration problem
that same-cutoff D5 authority cannot be known before frozen UPDATE-011 has
materialized D4/B7-A into the adapter transaction cache.

UPDATE-011 therefore consumes the existing final D3/D4 packet unchanged.
Only after UPDATE-011 returns is a caller-supplied D5 builder allowed to
construct a D5EvidencePacket from the now-authoritative same-cutoff D4 view.
UPDATE-012/013 then consume the augmented packet. UPDATE-014 remains outside
this session and remains the final admission authority.
"""

from dataclasses import dataclass, field
from pathlib import Path
import sys
from types import MappingProxyType
from typing import Any, Callable, Mapping


REPO_ROOT = Path(__file__).resolve().parents[2]
WORK_SRC = REPO_ROOT / "work" / "src"
if str(WORK_SRC) not in sys.path:
    sys.path.insert(0, str(WORK_SRC))

from multisymbol_impl import transactional_batch_composition_v1 as batch


class FullLiveD5BatchInjectionBlock(RuntimeError):
    pass


class FullLiveD5BatchInjectionConflict(FullLiveD5BatchInjectionBlock):
    pass


@dataclass(frozen=True)
class D5InjectionBuildResultV1:
    state: str
    d5_packet: Any | None
    reason: str
    provenance: Mapping[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "provenance",
            MappingProxyType(
                {str(k): str(v) for k, v in self.provenance.items()}
            ),
        )
        if self.state == "BUILT" and self.d5_packet is None:
            raise ValueError("BUILT_REQUIRES_D5_PACKET")
        if self.state != "BUILT" and self.d5_packet is not None:
            raise ValueError("NONBUILT_MAY_NOT_CARRY_D5_PACKET")


D5Builder = Callable[..., D5InjectionBuildResultV1]


def _packet_with_d5(base_packet: Any, d5_packet: Any) -> Any:
    frozen = batch.frozen
    if not isinstance(base_packet, frozen.CutoffEvidencePacket):
        raise FullLiveD5BatchInjectionConflict(
            "FINAL_PACKET_SCHEMA_DRIFT"
        )
    return frozen.CutoffEvidencePacket(
        d3=base_packet.d3,
        d4=base_packet.d4,
        d5=d5_packet,
        d6=getattr(base_packet, "d6", None),
    )


class FullLiveD5BatchPacketSessionV1(
    batch.BatchPreassembledPacketSession
):
    """Inject D5 only after frozen UPDATE-011 has produced same-cutoff D4.

    The base batch session's immutable packet authorities remain unchanged.
    This wrapper holds the post-UPDATE-011 augmented packet only in the
    transaction-local session.  No prepared-row poststate or durable Raw V6
    state is rewritten.
    """

    def __init__(
        self,
        adapter: Any,
        prepared_rows: Any,
        *,
        d5_builder: D5Builder,
    ) -> None:
        rows = tuple(prepared_rows)
        super().__init__(adapter, rows)
        if not callable(d5_builder):
            raise FullLiveD5BatchInjectionBlock(
                "D5_BUILDER_NOT_CALLABLE"
            )
        self._d5_builder = d5_builder
        self._rows_by_key = MappingProxyType(
            {
                (str(row.symbol), str(row.transaction_id)): row
                for row in rows
            }
        )
        if len(self._rows_by_key) != len(rows):
            raise FullLiveD5BatchInjectionConflict(
                "DUPLICATE_PREPARED_ROW_IDENTITY"
            )
        self._post_update011_packets: dict[str, Any] = {}
        self._build_results: dict[str, D5InjectionBuildResultV1] = {}

    def _row_for(self, ctx: Any) -> Any:
        key = (
            str(ctx.symbol_input.symbol),
            str(ctx.transaction_id),
        )
        row = self._rows_by_key.get(key)
        if row is None:
            raise FullLiveD5BatchInjectionBlock(
                "PREPARED_ROW_MISSING:"
                + key[0]
                + ":"
                + key[1]
            )
        return row

    def _cache_d4(self, ctx: Any) -> Any:
        cache = getattr(self.adapter, "tx_cache", {}).get(
            ctx.transaction_id
        )
        if cache is None:
            cache_fn = getattr(self.adapter, "_cache", None)
            if callable(cache_fn):
                cache = cache_fn(ctx.transaction_id)
        if cache is None:
            raise FullLiveD5BatchInjectionBlock(
                "UPDATE011_TRANSACTION_CACHE_MISSING"
            )
        d4 = getattr(cache, "d4", None)
        if d4 is None:
            raise FullLiveD5BatchInjectionBlock(
                "UPDATE011_D4_CACHE_MISSING"
            )
        return d4

    def _after_update011(
        self,
        ctx: Any,
        authority: Any,
    ) -> None:
        d4_view = self._cache_d4(ctx)
        candidate = getattr(d4_view, "confirmation_candidate", None)
        if candidate is None:
            # D5 is not meaningful without a same-cutoff B7-A candidate.
            self._post_update011_packets[ctx.transaction_id] = (
                authority.final_packet
            )
            self._build_results[ctx.transaction_id] = (
                D5InjectionBuildResultV1(
                    state="NOT_APPLICABLE",
                    d5_packet=None,
                    reason="NO_SAME_CUTOFF_B7A_CONFIRMATION",
                    provenance={
                        "update011_recomputed": "false",
                        "d5_injected": "false",
                    },
                )
            )
            return

        row = self._row_for(ctx)
        built = self._d5_builder(
            ctx=ctx,
            d4_view=d4_view,
            prepared_row=row,
            final_packet=authority.final_packet,
        )
        if not isinstance(built, D5InjectionBuildResultV1):
            raise FullLiveD5BatchInjectionConflict(
                "D5_BUILDER_RESULT_SCHEMA"
            )
        self._build_results[ctx.transaction_id] = built
        if built.state != "BUILT" or built.d5_packet is None:
            raise FullLiveD5BatchInjectionBlock(
                "D5_REQUIRED_FOR_B7A_BUT_NOT_BUILT:"
                + built.state
                + ":"
                + built.reason
            )
        self._post_update011_packets[ctx.transaction_id] = (
            _packet_with_d5(
                authority.final_packet,
                built.d5_packet,
            )
        )

    def _invoke_exact_frozen_v6_step(self, step: Any, ctx: Any) -> Any:
        """Match frozen RawV6 _PreassembledPacketSession dispatch byte-for-byte.

        The frozen initial packet is intentionally replaced by the authorized
        final D3/D4 packet at UPDATE-011; the adapter's general-purpose
        _make_adapter caches one evidence digest per transaction and therefore
        cannot be used in this staged two-packet execution path.

        Retain the original stage owner ledger entry and exact _uNNN function,
        never skip, rewrite or suppress frozen stage results.
        """
        if ctx.step is not step:
            raise FullLiveD5BatchInjectionConflict("STAGE_CONTEXT_MISMATCH")
        self.adapter.owner_execution_ledger.append(
            (ctx.transaction_id, step.value, batch.frozen.EXPECTED_OWNER[step].value)
        )
        return getattr(self.adapter, f"_u{int(step.value[-3:]):03d}")(ctx)

    def adapter_for(self, step: Any):
        def run(ctx: Any) -> Any:
            if ctx.step is not step:
                raise FullLiveD5BatchInjectionConflict(
                    "STAGE_CONTEXT_MISMATCH"
                )

            authority = self._authority_for(ctx)
            step_name = step.value

            if step_name in batch.INITIAL_VISIBLE_STEPS:
                packet = authority.initial_packet
                self.initial_steps.setdefault(
                    ctx.transaction_id, []
                ).append(step_name)
                self.adapter.set_evidence(
                    ctx.symbol_input.symbol,
                    ctx.symbol_input.observer_bar.open_time,
                    packet,
                )
                return self._invoke_exact_frozen_v6_step(step, ctx)

            if step_name not in batch.FINAL_VISIBLE_STEPS:
                raise FullLiveD5BatchInjectionConflict(
                    "UNKNOWN_PACKET_VISIBILITY_STEP:" + step_name
                )

            self.final_steps.setdefault(
                ctx.transaction_id, []
            ).append(step_name)

            if step_name == "UPDATE-011":
                # Frozen D4 sees the exact pre-existing final D3/D4 packet.
                packet = authority.final_packet
                self.adapter.set_evidence(
                    ctx.symbol_input.symbol,
                    ctx.symbol_input.observer_bar.open_time,
                    packet,
                )
                result = self._invoke_exact_frozen_v6_step(step, ctx)
                # Genesis / no-active-D4 is a legitimate UPDATE-011 outcome.
                # D5 is meaningful only when UPDATE-011 materialized D4 state.
                cache = getattr(self.adapter, "tx_cache", {}).get(ctx.transaction_id)
                if cache is None:
                    cache_fn = getattr(self.adapter, "_cache", None)
                    if callable(cache_fn):
                        cache = cache_fn(ctx.transaction_id)
                d4 = getattr(cache, "d4", None) if cache is not None else None
                if d4 is None:
                    self._post_update011_packets[ctx.transaction_id] = authority.final_packet
                    self._build_results[ctx.transaction_id] = D5InjectionBuildResultV1(
                        state="NOT_APPLICABLE",
                        d5_packet=None,
                        reason="UPDATE011_NO_D4_NO_D5",
                        provenance={"update011_recomputed":"false","d5_injected":"false"},
                    )
                else:
                    self._after_update011(ctx, authority)
                return result

            if step_name in ("UPDATE-012", "UPDATE-013"):
                packet = self._post_update011_packets.get(
                    ctx.transaction_id
                )
                if packet is None:
                    raise FullLiveD5BatchInjectionBlock(
                        "POST_UPDATE011_PACKET_MISSING:"
                        + ctx.transaction_id
                    )
                self.adapter.set_evidence(
                    ctx.symbol_input.symbol,
                    ctx.symbol_input.observer_bar.open_time,
                    packet,
                )
                return self._invoke_exact_frozen_v6_step(step, ctx)

            # Current batch FINAL_VISIBLE_STEPS are UPDATE-011..013 only.
            raise FullLiveD5BatchInjectionConflict(
                "UNEXPECTED_FINAL_STEP:" + step_name
            )

        return run

    @property
    def build_results(
        self,
    ) -> Mapping[str, D5InjectionBuildResultV1]:
        return MappingProxyType(dict(self._build_results))


def invariants() -> dict[str, Any]:
    return {
        "update011_uses_original_final_packet": True,
        "d4_recomputed": False,
        "d5_build_after_update011": True,
        "update012_013_use_post_update011_d5_packet": True,
        "update014_authority_changed": False,
        "prepared_row_poststate_mutated": False,
        "raw_v6_durable_state_mutated": False,
        "selector_added": False,
        "ranking_added": False,
        "threshold_added": False,
        "trading_activated": False,
    }
