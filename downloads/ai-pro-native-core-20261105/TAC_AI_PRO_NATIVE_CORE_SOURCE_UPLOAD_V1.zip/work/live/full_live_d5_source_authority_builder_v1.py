from __future__ import annotations

"""Mechanism source authority -> post-UPDATE-011 D5 packet builder.

This is deliberately a consumer of explicit upstream authority, not a producer
of missing active-D4 science.  It is ready for a future generic active-D4
binding while failing closed today if that upstream sidecar is absent.
"""

from dataclasses import dataclass, field
from fractions import Fraction
import json
from types import MappingProxyType
from typing import Any, Mapping

from strategy_rc1.d2_market_state.types import (
    PivotType,
    StructuralPivot,
    TrendDirection,
)
from strategy_rc1.d4_opportunity.types import OpportunityMechanism
from strategy_rc1.runtime_guards.information_state import InfoKind, InfoValue

from full_live_d5_batch_injection_v1 import D5InjectionBuildResultV1
from full_live_d5_deep_adverse_defense_v1 import (
    DeepAdverseDefenseProjectionV1,
)
from full_live_d5_mechanism_source_binding_v1 import (
    ExplicitAdverseDefensePivotAuthorityV1,
    bind_explicit_adverse_defense_risk_source,
    bind_false_break_risk_source,
    bind_normal_retest_risk_source,
)
from full_live_d5_packet_authority_v1 import (
    D5PacketAuthorityV1,
    build_frozen_d5_evidence_packet,
)
from full_live_d5_risk_anchor_validity_v1 import (
    produce_from_rawv6_state,
)


class FullLiveD5SourceAuthorityBuilderBlock(RuntimeError):
    pass


@dataclass(frozen=True)
class D5PreparedSourceAuthorityV1:
    """Explicit upstream sidecar for one same-cutoff B7-A candidate.

    Platform and Deep carry an already-frozen one-pivot authority. Normal and
    FBR carry the exact upstream evidence needed by their previously validated
    binders.  This dataclass intentionally contains no fallback selectors.
    """

    mechanism: OpportunityMechanism
    canonical_segment_id: str
    canonical_continuity_intact: InfoValue[bool]
    theta_progress: Fraction
    rawv6_state: Any
    normal_retest_evidence: Any | None = None
    false_break_evidence: Any | None = None
    correct_side_recovery_projection: Any | None = None
    explicit_adverse_defense: ExplicitAdverseDefensePivotAuthorityV1 | None = None
    provenance: Mapping[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "provenance",
            MappingProxyType(
                {str(k): str(v) for k, v in self.provenance.items()}
            ),
        )
        if not self.canonical_segment_id:
            raise ValueError("D5_SOURCE_CANONICAL_SEGMENT_REQUIRED")
        if self.theta_progress <= 0:
            raise ValueError("D5_SOURCE_THETA_PROGRESS_MUST_BE_POSITIVE")


def _adverse_type(direction: TrendDirection) -> PivotType:
    if direction is TrendDirection.LONG:
        return PivotType.LOW
    if direction is TrendDirection.SHORT:
        return PivotType.HIGH
    raise FullLiveD5SourceAuthorityBuilderBlock(
        "D5_SOURCE_DIRECTION_NOT_LONG_OR_SHORT"
    )


def _minor_index(rawv6_state: Any) -> dict[str, StructuralPivot]:
    rows = tuple(getattr(rawv6_state, "minor_history", ()))
    out: dict[str, StructuralPivot] = {}
    for pivot in rows:
        if not isinstance(pivot, StructuralPivot):
            raise FullLiveD5SourceAuthorityBuilderBlock(
                "RAWV6_MINOR_HISTORY_SCHEMA"
            )
        old = out.get(pivot.pivot_id)
        if old is not None and old != pivot:
            raise FullLiveD5SourceAuthorityBuilderBlock(
                "DIVERGENT_MINOR_PIVOT:" + pivot.pivot_id
            )
        out[pivot.pivot_id] = pivot
    return out


def _normal_selected_pivot(
    evidence: Any,
    *,
    direction: TrendDirection,
    rawv6_state: Any,
) -> StructuralPivot:
    regain = getattr(evidence, "local_control_regain", None)
    if regain is None:
        raise FullLiveD5SourceAuthorityBuilderBlock(
            "NORMAL_LOCAL_CONTROL_REGAIN_REQUIRED"
        )
    raw = getattr(regain, "provenance", {}).get("source_pivot_ids")
    if not raw:
        raise FullLiveD5SourceAuthorityBuilderBlock(
            "NORMAL_SOURCE_PIVOT_IDS_MISSING"
        )
    try:
        decoded = json.loads(raw)
    except Exception as exc:
        raise FullLiveD5SourceAuthorityBuilderBlock(
            "NORMAL_SOURCE_PIVOT_IDS_INVALID_JSON"
        ) from exc
    if not isinstance(decoded, list) or not decoded:
        raise FullLiveD5SourceAuthorityBuilderBlock(
            "NORMAL_SOURCE_PIVOT_IDS_EMPTY"
        )
    ids = tuple(str(x) for x in decoded)
    if len(set(ids)) != len(ids):
        raise FullLiveD5SourceAuthorityBuilderBlock(
            "NORMAL_SOURCE_PIVOT_IDS_DUPLICATE"
        )
    by_id = _minor_index(rawv6_state)
    missing = tuple(x for x in ids if x not in by_id)
    if missing:
        raise FullLiveD5SourceAuthorityBuilderBlock(
            "NORMAL_SOURCE_PIVOT_HISTORY_MISSING:" + ",".join(missing)
        )
    adverse = tuple(
        by_id[x]
        for x in ids
        if by_id[x].pivot_type is _adverse_type(direction)
    )
    if not adverse:
        raise FullLiveD5SourceAuthorityBuilderBlock(
            "NORMAL_ADVERSE_SOURCE_EMPTY"
        )
    return (
        min(adverse, key=lambda p: p.extreme_price)
        if direction is TrendDirection.LONG
        else max(adverse, key=lambda p: p.extreme_price)
    )


def _false_break_selected_pivot(
    projection: Any,
    *,
    rawv6_state: Any,
) -> StructuralPivot:
    if (
        getattr(projection, "producer", None)
        != "B4_CORRECT_SIDE_RECOVERY_D2_PROJECTION_V1"
    ):
        raise FullLiveD5SourceAuthorityBuilderBlock(
            "FBR_RECOVERY_PRODUCER_MISMATCH"
        )
    if getattr(getattr(projection, "state", None), "value", None) != "TRUE":
        raise FullLiveD5SourceAuthorityBuilderBlock(
            "FBR_RECOVERY_NOT_TRUE"
        )
    recovery = getattr(projection, "consumer_evidence", None)
    turning_id = getattr(recovery, "turning_pivot_id", None)
    if not turning_id:
        raise FullLiveD5SourceAuthorityBuilderBlock(
            "FBR_TURNING_PIVOT_ID_MISSING"
        )
    pivot = _minor_index(rawv6_state).get(str(turning_id))
    if pivot is None:
        raise FullLiveD5SourceAuthorityBuilderBlock(
            "FBR_TURNING_PIVOT_HISTORY_MISSING:" + str(turning_id)
        )
    return pivot


def _selected_source_pivot(
    source: D5PreparedSourceAuthorityV1,
    d4_view: Any,
) -> StructuralPivot:
    candidate = getattr(d4_view, "confirmation_candidate", None)
    if candidate is None:
        raise FullLiveD5SourceAuthorityBuilderBlock(
            "CURRENT_B7A_REQUIRED"
        )
    if candidate.mechanism is not source.mechanism:
        raise FullLiveD5SourceAuthorityBuilderBlock(
            "SOURCE_MECHANISM_B7A_MISMATCH"
        )
    direction = candidate.direction

    if source.mechanism is OpportunityMechanism.NORMAL_RETEST_CONTINUATION:
        if source.normal_retest_evidence is None:
            raise FullLiveD5SourceAuthorityBuilderBlock(
                "NORMAL_SOURCE_EVIDENCE_MISSING"
            )
        return _normal_selected_pivot(
            source.normal_retest_evidence,
            direction=direction,
            rawv6_state=source.rawv6_state,
        )

    if source.mechanism is OpportunityMechanism.FALSE_BREAK_RECLAIM:
        if (
            source.false_break_evidence is None
            or source.correct_side_recovery_projection is None
        ):
            raise FullLiveD5SourceAuthorityBuilderBlock(
                "FBR_TYPED_SOURCE_SIDECAR_MISSING"
            )
        return _false_break_selected_pivot(
            source.correct_side_recovery_projection,
            rawv6_state=source.rawv6_state,
        )

    if source.mechanism in (
        OpportunityMechanism.PLATFORM_REEXPANSION,
        OpportunityMechanism.DEEP_STRUCTURE_TAKEOVER,
    ):
        explicit = source.explicit_adverse_defense
        if explicit is None:
            raise FullLiveD5SourceAuthorityBuilderBlock(
                "EXPLICIT_ADVERSE_DEFENSE_SIDECAR_MISSING"
            )
        if explicit.mechanism is not source.mechanism:
            raise FullLiveD5SourceAuthorityBuilderBlock(
                "EXPLICIT_ADVERSE_DEFENSE_MECHANISM_MISMATCH"
            )
        return explicit.pivot

    raise FullLiveD5SourceAuthorityBuilderBlock(
        "UNSUPPORTED_EXECUTABLE_MECHANISM:"
        + source.mechanism.value
    )


def _bind_risk_evidence(
    source: D5PreparedSourceAuthorityV1,
    d4_view: Any,
    validity: InfoValue[bool],
) -> Any:
    history = tuple(getattr(source.rawv6_state, "minor_history", ()))

    if source.mechanism is OpportunityMechanism.NORMAL_RETEST_CONTINUATION:
        result = bind_normal_retest_risk_source(
            d4_view=d4_view,
            normal_retest_evidence=source.normal_retest_evidence,
            confirmed_minor_pivots=history,
            canonical_segment_id=source.canonical_segment_id,
            risk_anchor_not_invalidated=validity,
        )
    elif source.mechanism is OpportunityMechanism.FALSE_BREAK_RECLAIM:
        result = bind_false_break_risk_source(
            d4_view=d4_view,
            false_break_evidence=source.false_break_evidence,
            correct_side_recovery_projection=(
                source.correct_side_recovery_projection
            ),
            confirmed_minor_pivots=history,
            canonical_segment_id=source.canonical_segment_id,
            risk_anchor_not_invalidated=validity,
        )
    elif source.mechanism in (
        OpportunityMechanism.PLATFORM_REEXPANSION,
        OpportunityMechanism.DEEP_STRUCTURE_TAKEOVER,
    ):
        result = bind_explicit_adverse_defense_risk_source(
            d4_view=d4_view,
            source_authority=source.explicit_adverse_defense,
            canonical_segment_id=source.canonical_segment_id,
            risk_anchor_not_invalidated=validity,
        )
    else:
        raise FullLiveD5SourceAuthorityBuilderBlock(
            "UNSUPPORTED_EXECUTABLE_MECHANISM:"
            + source.mechanism.value
        )

    if result.status != "BOUND" or result.risk_evidence is None:
        raise FullLiveD5SourceAuthorityBuilderBlock(
            "MECHANISM_RISK_EVIDENCE_NOT_BOUND:"
            + result.status
            + ":"
            + result.reason
        )
    return result.risk_evidence


def build_d5_from_explicit_source(
    *,
    source: D5PreparedSourceAuthorityV1,
    d4_view: Any,
    strategy_entry_reference_price: Fraction,
    operational_inputs: Any,
) -> D5InjectionBuildResultV1:
    cutoff = int(getattr(d4_view, "information_cutoff", -1))
    candidate = getattr(d4_view, "confirmation_candidate", None)
    if candidate is None:
        return D5InjectionBuildResultV1(
            state="NOT_APPLICABLE",
            d5_packet=None,
            reason="NO_SAME_CUTOFF_B7A_CONFIRMATION",
        )
    if candidate.confirmation_cutoff != cutoff:
        raise FullLiveD5SourceAuthorityBuilderBlock(
            "STALE_B7A_FOR_D5_SOURCE"
        )

    pivot = _selected_source_pivot(source, d4_view)
    validity_result = produce_from_rawv6_state(
        rawv6_state=source.rawv6_state,
        risk_anchor_pivot=pivot,
        direction=candidate.direction,
        information_cutoff=cutoff,
        canonical_continuity_intact=(
            source.canonical_continuity_intact
        ),
        theta_progress=source.theta_progress,
    )
    validity = validity_result.risk_anchor_not_invalidated
    if validity.kind is not InfoKind.KNOWN:
        return D5InjectionBuildResultV1(
            state="BLOCKED",
            d5_packet=None,
            reason=(
                "RISK_ANCHOR_VALIDITY_NOT_KNOWN:"
                + validity_result.reason
            ),
            provenance={
                "risk_anchor_pivot_id": pivot.pivot_id,
                "unknown_not_coerced": "true",
            },
        )

    risk_evidence = _bind_risk_evidence(
        source,
        d4_view,
        validity,
    )
    packet = build_frozen_d5_evidence_packet(
        D5PacketAuthorityV1(
            information_cutoff=cutoff,
            direction=candidate.direction,
            canonical_segment_id=source.canonical_segment_id,
            risk_evidence=risk_evidence,
            risk_anchor_pivot=pivot,
            strategy_entry_reference_price=(
                strategy_entry_reference_price
            ),
            canonical_continuity_intact=(
                source.canonical_continuity_intact
            ),
            risk_anchor_not_invalidated=validity,
            operational_inputs=operational_inputs,
            provenance={
                "builder": "FULL_LIVE_D5_SOURCE_AUTHORITY_BUILDER_V1",
                **dict(source.provenance),
            },
        )
    )
    return D5InjectionBuildResultV1(
        state="BUILT",
        d5_packet=packet,
        reason="D5_PACKET_BUILT_FROM_EXPLICIT_SOURCE_AUTHORITY",
        provenance={
            "mechanism": source.mechanism.value,
            "risk_anchor_pivot_id": pivot.pivot_id,
            "operational_inputs_may_remain_unresolved": "true",
        },
    )


def invariants() -> Mapping[str, Any]:
    return {
        "active_d4_science_produced_here": False,
        "fbr_correct_side_recovery_reconstructed_from_true_break": False,
        "fbr_explicit_typed_sidecar_required": True,
        "platform_deep_exact_authority_required": True,
        "risk_anchor_validity_computed_before_packet": True,
        "unknown_validity_coerced_to_true": False,
        "operational_policy_values_selected_here": False,
        "selector_added": False,
        "ranking_added": False,
        "threshold_added": False,
        "trading_activated": False,
    }
