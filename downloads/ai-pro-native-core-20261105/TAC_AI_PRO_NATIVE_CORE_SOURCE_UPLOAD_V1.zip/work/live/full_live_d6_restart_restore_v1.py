from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable, Mapping

from d6_position_store_v1 import AuthoritativeD6PositionStoreV1
from d6_live_bridge_v1 import (
    active_authoritative_position,
    register_authoritative_position,
)
from d6_continuation_persistence_v1 import (
    D6CommittedSnapshotRecoveryV1,
    D6ContinuationPersistenceBlock,
    recover_latest_committed_d6_snapshot,
)
from full_live_restart_reconciliation_v1 import (
    RestartPositionViewV1,
    reconcile_restart_position_v1,
)
from strategy_rc1.d6_position_execution.position import StrategyPositionRegistry
from strategy_rc1.d6_position_execution.types import StrategyPositionSnapshot


class D6RestartRestoreBlock(RuntimeError):
    pass


@dataclass(frozen=True)
class D6RestartRestoreResultV1:
    snapshot: StrategyPositionSnapshot
    recovery: D6CommittedSnapshotRecoveryV1
    activation_event_id: str
    activation_event_time_ms: int
    reconciliation_before: RestartPositionViewV1
    status: str
    restart_new_risk_blocked: bool


def _text(value: Any) -> str:
    raw = getattr(value, "value", value)
    return str(raw)


def _latest_activation(
    rows: Iterable[Mapping[str, Any]],
    *,
    symbol: str,
) -> Mapping[str, Any]:
    matches = [
        row
        for row in rows
        if row.get("event_type") == "D6_POSITION_ACTIVATED"
        and str(row.get("symbol", "")) == symbol
    ]
    if not matches:
        raise D6RestartRestoreBlock(
            "D6_POSITION_ACTIVATION_EVENT_NOT_FOUND"
        )
    return matches[-1]


def _validate_activation_snapshot_reference(
    rows: tuple[Mapping[str, Any], ...],
    *,
    activation: Mapping[str, Any],
    reconciliation: RestartPositionViewV1,
    symbol: str,
) -> str:
    data = activation.get("data")
    if not isinstance(data, Mapping):
        raise D6RestartRestoreBlock(
            "D6_POSITION_ACTIVATION_DATA_INVALID"
        )

    snapshot_event_id = str(
        data.get("snapshot_event_id", "") or ""
    )
    if not snapshot_event_id:
        raise D6RestartRestoreBlock(
            "D6_POSITION_ACTIVATION_SNAPSHOT_EVENT_ID_REQUIRED"
        )

    matches = [
        row
        for row in rows
        if row.get("event_type") == "D6_POSITION_SNAPSHOT"
        and str(row.get("event_id", "")) == snapshot_event_id
    ]
    if len(matches) != 1:
        raise D6RestartRestoreBlock(
            "D6_RESTART_ACTIVATION_LINK_DRIFT:snapshot_event_id"
        )

    snapshot_row = matches[0]
    if str(snapshot_row.get("symbol", "")) != symbol:
        raise D6RestartRestoreBlock(
            "D6_RESTART_ACTIVATION_LINK_DRIFT:snapshot_symbol"
        )

    snapshot_data = snapshot_row.get("data")
    if not isinstance(snapshot_data, Mapping):
        raise D6RestartRestoreBlock(
            "D6_RESTART_ACTIVATION_LINK_DRIFT:snapshot_data"
        )

    if str(snapshot_data.get("position_id", "")) != str(
        reconciliation.position_id or ""
    ):
        raise D6RestartRestoreBlock(
            "D6_RESTART_ACTIVATION_LINK_DRIFT:position_id"
        )
    if str(snapshot_data.get("entry_ready_id", "")) != str(
        reconciliation.entry_ready_id or ""
    ):
        raise D6RestartRestoreBlock(
            "D6_RESTART_ACTIVATION_LINK_DRIFT:entry_ready_id"
        )

    return snapshot_event_id


def _validate_activation_link(
    *,
    activation: Mapping[str, Any],
    recovery: D6CommittedSnapshotRecoveryV1,
    reconciliation: RestartPositionViewV1,
    symbol: str,
    direction: str,
) -> tuple[str, int]:
    data = activation.get("data")
    if not isinstance(data, Mapping):
        raise D6RestartRestoreBlock(
            "D6_POSITION_ACTIVATION_DATA_INVALID"
        )

    required = {
        "position_id",
        "entry_ready_id",
        "opportunity_id",
        "execution_evidence_id",
        "opened_real_time",
        "hard_stop_price",
        "snapshot_event_id",
    }
    missing = sorted(required - set(data))
    if missing:
        raise D6RestartRestoreBlock(
            "D6_POSITION_ACTIVATION_FIELDS_MISSING:"
            + ",".join(missing)
        )

    checks = {
        "position_id": (
            str(data.get("position_id", "")),
            str(reconciliation.position_id or ""),
        ),
        "entry_ready_id": (
            str(data.get("entry_ready_id", "")),
            str(reconciliation.entry_ready_id or ""),
        ),
        "snapshot_event_id": (
            str(data.get("snapshot_event_id", "")),
            recovery.initial_snapshot_event_id,
        ),
    }
    for name, (actual, expected) in checks.items():
        if not actual or actual != expected:
            raise D6RestartRestoreBlock(
                "D6_RESTART_ACTIVATION_LINK_DRIFT:"
                + name
                + ":"
                + repr(actual)
                + "!="
                + repr(expected)
            )

    snapshot = recovery.snapshot
    entry = getattr(snapshot, "entry", None)

    snapshot_checks = {
        "position_id": (
            str(getattr(snapshot, "position_id", "") or ""),
            str(reconciliation.position_id or ""),
        ),
        "entry_ready_id": (
            str(getattr(entry, "entry_ready_id", "") or ""),
            str(reconciliation.entry_ready_id or ""),
        ),
        "symbol": (
            str(getattr(entry, "symbol", "") or ""),
            symbol,
        ),
        "direction": (
            _text(getattr(entry, "direction", "")).upper(),
            direction.upper(),
        ),
        "opportunity_id": (
            str(getattr(entry, "opportunity_id", "") or ""),
            str(data.get("opportunity_id", "")),
        ),
        "execution_evidence_id": (
            str(
                getattr(
                    snapshot,
                    "opened_from_execution_evidence_id",
                    "",
                )
                or ""
            ),
            str(data.get("execution_evidence_id", "")),
        ),
    }
    for name, (actual, expected) in snapshot_checks.items():
        if not actual or actual != expected:
            raise D6RestartRestoreBlock(
                "D6_RESTART_SNAPSHOT_IDENTITY_DRIFT:"
                + name
                + ":"
                + repr(actual)
                + "!="
                + repr(expected)
            )

    if (
        getattr(snapshot, "opened_real_time", None)
        != data.get("opened_real_time")
    ):
        raise D6RestartRestoreBlock(
            "D6_RESTART_OPENED_REAL_TIME_DRIFT"
        )

    if getattr(snapshot, "closed_exit_id", None) is not None:
        raise D6RestartRestoreBlock(
            "D6_RESTART_CLOSED_SNAPSHOT_FORBIDDEN"
        )

    activation_event_id = str(
        activation.get("event_id", "") or ""
    )
    if not activation_event_id:
        raise D6RestartRestoreBlock(
            "D6_POSITION_ACTIVATION_EVENT_ID_REQUIRED"
        )

    try:
        activation_time = int(activation.get("event_time_ms"))
    except Exception as exc:
        raise D6RestartRestoreBlock(
            "D6_POSITION_ACTIVATION_EVENT_TIME_INVALID"
        ) from exc

    if recovery.initial_snapshot_event_time_ms > activation_time:
        raise D6RestartRestoreBlock(
            "D6_INITIAL_SNAPSHOT_MUST_PRECEDE_ACTIVATION"
        )

    return activation_event_id, activation_time


def restore_authoritative_d6_position_after_restart(
    *,
    registry: StrategyPositionRegistry | AuthoritativeD6PositionStoreV1,
    ledger_rows: Iterable[Mapping[str, Any]],
    symbol: str,
    direction: str,
    exchange_position_snapshot: Any,
    exchange_open_orders: Any,
) -> D6RestartRestoreResultV1:
    rows = tuple(ledger_rows)

    reconciliation = reconcile_restart_position_v1(
        symbol=symbol,
        direction=direction,
        ledger_rows=rows,
        exchange_position_snapshot=exchange_position_snapshot,
        exchange_open_orders=exchange_open_orders,
    )
    if (
        reconciliation.status
        != "MATCHED_REQUIRES_D6_SNAPSHOT_RECONSTRUCTION"
    ):
        raise D6RestartRestoreBlock(
            "RESTART_STATE_NOT_RESTORABLE:"
            + reconciliation.status
        )

    if (
        not reconciliation.position_id
        or not reconciliation.entry_ready_id
    ):
        raise D6RestartRestoreBlock(
            "RESTART_RECONCILIATION_IDENTITY_INCOMPLETE"
        )

    existing = active_authoritative_position(
        registry=registry,
        symbol=symbol,
    )
    if existing is not None:
        raise D6RestartRestoreBlock(
            "D6_REGISTRY_ALREADY_ACTIVE_FOR_SYMBOL:" + symbol
        )

    activation = _latest_activation(rows, symbol=symbol)
    initial_snapshot_event_id = _validate_activation_snapshot_reference(
        rows,
        activation=activation,
        reconciliation=reconciliation,
        symbol=symbol,
    )

    try:
        recovery = recover_latest_committed_d6_snapshot(
            ledger_rows=rows,
            symbol=symbol,
            position_id=reconciliation.position_id,
            entry_ready_id=reconciliation.entry_ready_id,
            initial_snapshot_event_id=initial_snapshot_event_id,
        )
    except D6ContinuationPersistenceBlock as exc:
        raise D6RestartRestoreBlock(
            "D6_RESTART_SNAPSHOT_RECOVERY_FAILED:"
            + str(exc)
        ) from exc

    activation_event_id, activation_event_time_ms = (
        _validate_activation_link(
            activation=activation,
            recovery=recovery,
            reconciliation=reconciliation,
            symbol=symbol,
            direction=direction,
        )
    )

    try:
        register_authoritative_position(
            registry=registry,
            position=recovery.snapshot,
        )
    except Exception as exc:
        raise D6RestartRestoreBlock(
            "D6_RESTART_REGISTRY_RESTORE_FAILED:"
            + exc.__class__.__name__
            + ":"
            + str(exc)
        ) from exc

    active = active_authoritative_position(
        registry=registry,
        symbol=symbol,
    )
    if active != recovery.snapshot:
        raise D6RestartRestoreBlock(
            "D6_RESTART_REGISTRY_ACTIVE_SNAPSHOT_DRIFT"
        )

    return D6RestartRestoreResultV1(
        snapshot=recovery.snapshot,
        recovery=recovery,
        activation_event_id=activation_event_id,
        activation_event_time_ms=activation_event_time_ms,
        reconciliation_before=reconciliation,
        status="RESTORED_AUTHORITATIVE_D6_POSITION",
        restart_new_risk_blocked=False,
    )


def restore_authoritative_d6_position_after_confirmed_hard_protection(
    *,
    registry: StrategyPositionRegistry | AuthoritativeD6PositionStoreV1,
    ledger_rows: Iterable[Mapping[str, Any]],
    symbol: str,
    direction: str,
    exchange_position_snapshot: Any,
    exchange_open_orders: Any,
    hard_protection_trigger_event_id: str,
) -> D6RestartRestoreResultV1:
    """Restore the committed D6 snapshot when exact hard protection closed exchange.

    This path never infers a stop trigger from a missing exchange position.
    A durable HARD_PROTECTION_TRIGGERED event created from exact exchange
    execution evidence is mandatory. New risk remains blocked until the next
    prospective UPDATE-010 consumes that evidence and closes D6.
    """
    rows = tuple(ledger_rows)
    reconciliation = reconcile_restart_position_v1(
        symbol=symbol,
        direction=direction,
        ledger_rows=rows,
        exchange_position_snapshot=exchange_position_snapshot,
        exchange_open_orders=exchange_open_orders,
    )
    if reconciliation.status != (
        "BLOCK_LEDGER_POSITION_MISSING_ON_EXCHANGE"
    ):
        raise D6RestartRestoreBlock(
            "HARD_PROTECTION_RESTORE_STATE_NOT_ELIGIBLE:"
            + reconciliation.status
        )
    if (
        not reconciliation.position_id
        or not reconciliation.entry_ready_id
    ):
        raise D6RestartRestoreBlock(
            "HARD_PROTECTION_RESTORE_LINEAGE_INCOMPLETE"
        )

    triggers = []
    for row in rows:
        if row.get("event_type") != "HARD_PROTECTION_TRIGGERED":
            continue
        if str(row.get("event_id", "")) != hard_protection_trigger_event_id:
            continue
        if str(row.get("symbol", "")) != symbol:
            continue
        data = row.get("data")
        if not isinstance(data, Mapping):
            raise D6RestartRestoreBlock(
                "HARD_PROTECTION_TRIGGER_DATA_INVALID"
            )
        if (
            str(data.get("position_id", ""))
            != reconciliation.position_id
            or str(data.get("entry_ready_id", ""))
            != reconciliation.entry_ready_id
        ):
            raise D6RestartRestoreBlock(
                "HARD_PROTECTION_TRIGGER_LINEAGE_DRIFT"
            )
        triggers.append(row)
    if len(triggers) != 1:
        raise D6RestartRestoreBlock(
            "HARD_PROTECTION_TRIGGER_EVENT_NOT_UNIQUE"
        )
    trigger = triggers[0]

    existing = active_authoritative_position(
        registry=registry,
        symbol=symbol,
    )
    if existing is not None:
        raise D6RestartRestoreBlock(
            "D6_REGISTRY_ALREADY_ACTIVE_FOR_SYMBOL:" + symbol
        )

    activation = _latest_activation(rows, symbol=symbol)
    initial_snapshot_event_id = _validate_activation_snapshot_reference(
        rows,
        activation=activation,
        reconciliation=reconciliation,
        symbol=symbol,
    )
    try:
        recovery = recover_latest_committed_d6_snapshot(
            ledger_rows=rows,
            symbol=symbol,
            position_id=reconciliation.position_id,
            entry_ready_id=reconciliation.entry_ready_id,
            initial_snapshot_event_id=initial_snapshot_event_id,
        )
    except D6ContinuationPersistenceBlock as exc:
        raise D6RestartRestoreBlock(
            "D6_HARD_PROTECTION_SNAPSHOT_RECOVERY_FAILED:"
            + str(exc)
        ) from exc

    activation_event_id, activation_event_time_ms = (
        _validate_activation_link(
            activation=activation,
            recovery=recovery,
            reconciliation=reconciliation,
            symbol=symbol,
            direction=direction,
        )
    )
    trigger_time = int(trigger.get("event_time_ms", 0) or 0)
    if trigger_time <= 0 or trigger_time < activation_event_time_ms:
        raise D6RestartRestoreBlock(
            "HARD_PROTECTION_TRIGGER_PRECEDES_D6_ACTIVATION"
        )

    try:
        register_authoritative_position(
            registry=registry,
            position=recovery.snapshot,
        )
    except Exception as exc:
        raise D6RestartRestoreBlock(
            "D6_HARD_PROTECTION_REGISTRY_RESTORE_FAILED:"
            + exc.__class__.__name__
            + ":"
            + str(exc)
        ) from exc

    active = active_authoritative_position(
        registry=registry,
        symbol=symbol,
    )
    if active != recovery.snapshot:
        raise D6RestartRestoreBlock(
            "D6_HARD_PROTECTION_RESTORE_ROUNDTRIP_DRIFT"
        )

    return D6RestartRestoreResultV1(
        snapshot=recovery.snapshot,
        recovery=recovery,
        activation_event_id=activation_event_id,
        activation_event_time_ms=activation_event_time_ms,
        reconciliation_before=reconciliation,
        status=(
            "RESTORED_PENDING_CONFIRMED_HARD_PROTECTION_D6_CLOSE"
        ),
        restart_new_risk_blocked=True,
    )


__all__ = [
    "D6RestartRestoreBlock",
    "D6RestartRestoreResultV1",
    "restore_authoritative_d6_position_after_restart",
    "restore_authoritative_d6_position_after_confirmed_hard_protection",
]
