from __future__ import annotations

from decimal import Decimal
from fractions import Fraction
from typing import Any, Mapping

from d6_position_store_v1 import AuthoritativeD6PositionStoreV1
from full_live_structural_risk_accounting_v1 import (
    PortfolioStructuralRiskV1,
    aggregate_portfolio_structural_risk,
    open_position_structural_risk,
)
from strategy_rc1.d6_position_execution.types import (
    StrategyPositionSnapshot,
)
from trade_ledger_v1 import TradeLedgerV1


class FullLivePortfolioStructuralRiskRuntimeBlock(RuntimeError):
    pass


def _exact_decimal(value: Any, label: str) -> Decimal:
    if not isinstance(value, Fraction):
        raise FullLivePortfolioStructuralRiskRuntimeBlock(
            label + "_FRACTION_REQUIRED"
        )
    out = Decimal(value.numerator) / Decimal(value.denominator)
    if Fraction(out) != value:
        raise FullLivePortfolioStructuralRiskRuntimeBlock(
            label + "_NOT_EXACT_DECIMAL"
        )
    return out


def _positive_decimal(value: Any, label: str) -> Decimal:
    try:
        out = Decimal(str(value))
    except Exception as exc:
        raise FullLivePortfolioStructuralRiskRuntimeBlock(
            label + "_DECIMAL_REQUIRED"
        ) from exc
    if not out.is_finite() or out <= 0:
        raise FullLivePortfolioStructuralRiskRuntimeBlock(
            label + "_POSITIVE_REQUIRED"
        )
    return out


def _matching_event(
    rows: tuple[Mapping[str, Any], ...],
    *,
    event_type: str,
    symbol: str,
    entry_ready_id: str,
    position_id: str | None = None,
) -> Mapping[str, Any]:
    matches: list[Mapping[str, Any]] = []
    for row in rows:
        if row.get("event_type") != event_type:
            continue
        if str(row.get("symbol") or "") != symbol:
            continue
        data = row.get("data")
        if not isinstance(data, Mapping):
            raise FullLivePortfolioStructuralRiskRuntimeBlock(
                event_type + "_DATA_MAPPING_REQUIRED"
            )
        if str(data.get("entry_ready_id") or "") != entry_ready_id:
            continue
        if position_id is not None and str(
            data.get("position_id") or ""
        ) != position_id:
            continue
        matches.append(row)
    if len(matches) != 1:
        raise FullLivePortfolioStructuralRiskRuntimeBlock(
            event_type
            + "_EVENT_CARDINALITY:"
            + symbol
            + ":"
            + entry_ready_id
            + ":"
            + str(len(matches))
        )
    return matches[0]


def _position_risk(
    *,
    position: StrategyPositionSnapshot,
    ledger_rows: tuple[Mapping[str, Any], ...],
):
    if not isinstance(position, StrategyPositionSnapshot):
        raise FullLivePortfolioStructuralRiskRuntimeBlock(
            "STRATEGY_POSITION_SNAPSHOT_REQUIRED"
        )
    entry = position.entry
    symbol = str(getattr(entry, "symbol", "") or "")
    entry_ready_id = str(
        getattr(entry, "entry_ready_id", "") or ""
    )
    position_id = str(
        getattr(position, "position_id", "") or ""
    )
    direction = str(
        getattr(getattr(entry, "direction", None), "value", "")
        or getattr(entry, "direction", "")
    ).upper()
    if (
        not symbol
        or not entry_ready_id
        or not position_id
        or direction not in ("LONG", "SHORT")
    ):
        raise FullLivePortfolioStructuralRiskRuntimeBlock(
            "ACTIVE_POSITION_IDENTITY_INCOMPLETE"
        )

    opened = _matching_event(
        ledger_rows,
        event_type="POSITION_OPENED",
        symbol=symbol,
        entry_ready_id=entry_ready_id,
    )
    activated = _matching_event(
        ledger_rows,
        event_type="D6_POSITION_ACTIVATED",
        symbol=symbol,
        entry_ready_id=entry_ready_id,
        position_id=position_id,
    )
    opened_data = opened["data"]
    activated_data = activated["data"]

    quantity = _positive_decimal(
        opened_data.get("quantity"),
        "POSITION_OPENED_QUANTITY",
    )
    strategy_entry = _exact_decimal(
        getattr(entry, "strategy_entry_reference_price", None),
        "STRATEGY_ENTRY_REFERENCE_PRICE",
    )
    raw_stop = _exact_decimal(
        getattr(entry, "initial_hard_stop_numeric", None),
        "INITIAL_HARD_STOP_NUMERIC",
    )
    actual_stop = _positive_decimal(
        opened_data.get("hard_stop_price"),
        "POSITION_OPENED_HARD_STOP_PRICE",
    )
    activation_stop = _positive_decimal(
        activated_data.get("hard_stop_price"),
        "D6_ACTIVATION_HARD_STOP_PRICE",
    )
    if actual_stop != activation_stop:
        raise FullLivePortfolioStructuralRiskRuntimeBlock(
            "OPENED_ACTIVATION_HARD_STOP_DRIFT"
        )

    # Exchange tick rounding is only allowed to make the stop safer than the
    # Strategy raw stop.  Structural-risk accounting remains conservative by
    # retaining the Strategy raw stop as the effective risk denominator.
    if direction == "LONG":
        if not (raw_stop <= actual_stop < strategy_entry):
            raise FullLivePortfolioStructuralRiskRuntimeBlock(
                "LONG_EXCHANGE_HARD_STOP_WIDENING_OR_INVALID"
            )
    else:
        if not (strategy_entry < actual_stop <= raw_stop):
            raise FullLivePortfolioStructuralRiskRuntimeBlock(
                "SHORT_EXCHANGE_HARD_STOP_WIDENING_OR_INVALID"
            )

    if str(opened_data.get("cutoff")) != str(
        getattr(entry, "entry_ready_cutoff", "")
    ):
        raise FullLivePortfolioStructuralRiskRuntimeBlock(
            "POSITION_OPENED_ENTRY_CUTOFF_DRIFT"
        )

    return open_position_structural_risk(
        symbol=symbol,
        direction=direction,
        quantity=quantity,
        strategy_entry_reference_price=strategy_entry,
        effective_hard_stop=raw_stop,
        hard_stop_authority=(
            "FROZEN_STRATEGY_INITIAL_HARD_STOP_CONSERVATIVE_"
            "NO_NUMERIC_D6_TRAILING_V1"
        ),
    )


def build_portfolio_structural_risk_from_runtime(
    *,
    store: AuthoritativeD6PositionStoreV1,
    ledger: TradeLedgerV1,
) -> PortfolioStructuralRiskV1:
    if not isinstance(store, AuthoritativeD6PositionStoreV1):
        raise FullLivePortfolioStructuralRiskRuntimeBlock(
            "AUTHORITATIVE_D6_POSITION_STORE_REQUIRED"
        )
    if not isinstance(ledger, TradeLedgerV1):
        raise FullLivePortfolioStructuralRiskRuntimeBlock(
            "TRADE_LEDGER_REQUIRED"
        )

    positions = store.active_positions()
    rows = tuple(ledger.read_all())
    risk_rows = tuple(
        _position_risk(
            position=position,
            ledger_rows=rows,
        )
        for position in positions
    )
    return aggregate_portfolio_structural_risk(risk_rows)


def invariants() -> Mapping[str, object]:
    return {
        "quantity_source": "DURABLE_POSITION_OPENED_CONFIRMED_QUANTITY",
        "strategy_entry_reference_source": (
            "FROZEN_ENTRY_PROVENANCE"
        ),
        "risk_stop_source": (
            "FROZEN_STRATEGY_INITIAL_HARD_STOP_CONSERVATIVE"
        ),
        "exchange_tick_rounding_may_widen_risk": False,
        "numeric_d6_trailing_releases_budget": False,
        "market_price_used": False,
        "unrealized_pnl_used": False,
        "live_equity_used": False,
        "selector_added": False,
        "ranking_added": False,
        "orders": 0,
        "fills": 0,
        "execution_intents": 0,
        "trading_activated": False,
    }


__all__ = [
    "FullLivePortfolioStructuralRiskRuntimeBlock",
    "build_portfolio_structural_risk_from_runtime",
    "invariants",
]
