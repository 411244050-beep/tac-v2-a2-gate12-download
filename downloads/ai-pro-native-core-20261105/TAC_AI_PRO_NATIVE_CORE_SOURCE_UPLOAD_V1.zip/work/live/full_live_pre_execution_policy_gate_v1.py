from __future__ import annotations

"""Pre-execution policy gate.

The legacy evaluate helper remains a mechanics-only surface. The
production-facing path is load_frozen_execution_feasibility_policy plus
evaluate_prospective_execution_evidence. It consumes only a post-UPDATE-014
prospective public-book observation and exchange-rule legality. It never
creates Strategy admission, ranking, orders, fills, or execution intent.
"""

from dataclasses import dataclass
from decimal import Decimal, InvalidOperation
import hashlib
import json
from pathlib import Path
from typing import Mapping, Any

from full_live_execution_feasibility_measurement_v1 import (
    ExecutionFeasibilityMeasurementV1,
)
from full_live_prospective_execution_evidence_v1 import (
    ProspectiveExecutionEvidenceV1,
    validate_prospective_execution_evidence,
)
from binance_usdm_market_entry_legality_v1 import USDMarketEntryLegalityV1


LIVE_DIR = Path(__file__).resolve().parent
DEFAULT_EXECUTION_FEASIBILITY_AUTHORITY_PATH = (
    LIVE_DIR / "full_live_execution_feasibility_policy_authority_v1.json"
)
AUTHORITY_SCHEMA = "TAC_FULL_LIVE_EXECUTION_FEASIBILITY_POLICY_AUTHORITY_V1"
FROZEN_STATUS = "FROZEN"


class PreExecutionPolicyBlock(RuntimeError):
    pass


@dataclass(frozen=True)
class ExecutionTolerancePolicyV1:
    max_spread_bps: Decimal
    max_impact_bps: Decimal
    min_fill_fraction: Decimal
    authority: str
    version: str


@dataclass(frozen=True)
class FrozenExecutionFeasibilityPolicyV1:
    intended_quote_notional: Decimal
    depth_source: str
    depth_limit: int
    rpi_liquidity_included: bool
    max_spread_bps: Decimal
    max_impact_bps: Decimal
    fully_fillable_required: bool
    measurement_cohort_policy: str
    execution_allowance_mode: str
    authority: str
    version: str
    authority_digest: str


def _positive_decimal(value: Any, label: str) -> Decimal:
    try:
        out = Decimal(str(value))
    except (InvalidOperation, ValueError, TypeError) as exc:
        raise PreExecutionPolicyBlock("INVALID_DECIMAL:" + label) from exc
    if not out.is_finite() or out <= 0:
        raise PreExecutionPolicyBlock("NONPOSITIVE_DECIMAL:" + label)
    return out


def _nonnegative_decimal(value: Any, label: str) -> Decimal:
    try:
        out = Decimal(str(value))
    except (InvalidOperation, ValueError, TypeError) as exc:
        raise PreExecutionPolicyBlock("INVALID_DECIMAL:" + label) from exc
    if not out.is_finite() or out < 0:
        raise PreExecutionPolicyBlock("NEGATIVE_DECIMAL:" + label)
    return out


def load_frozen_execution_feasibility_policy(
    path: Path = DEFAULT_EXECUTION_FEASIBILITY_AUTHORITY_PATH,
) -> FrozenExecutionFeasibilityPolicyV1:
    try:
        raw_bytes = Path(path).read_bytes()
        raw = json.loads(raw_bytes)
    except Exception as exc:
        raise PreExecutionPolicyBlock(
            "EXECUTION_FEASIBILITY_AUTHORITY_READ_FAILED"
        ) from exc
    if not isinstance(raw, dict):
        raise PreExecutionPolicyBlock(
            "EXECUTION_FEASIBILITY_AUTHORITY_NOT_OBJECT"
        )
    if raw.get("schema") != AUTHORITY_SCHEMA:
        raise PreExecutionPolicyBlock(
            "EXECUTION_FEASIBILITY_AUTHORITY_SCHEMA_DRIFT"
        )
    if raw.get("status") != FROZEN_STATUS:
        raise PreExecutionPolicyBlock(
            "EXECUTION_FEASIBILITY_AUTHORITY_NOT_FROZEN"
        )
    if raw.get("branch") != "tac-full-live-v1":
        raise PreExecutionPolicyBlock(
            "EXECUTION_FEASIBILITY_AUTHORITY_BRANCH_DRIFT"
        )
    authority = str(raw.get("authority") or "")
    version = str(raw.get("version") or "")
    if not authority or not version:
        raise PreExecutionPolicyBlock(
            "EXECUTION_FEASIBILITY_AUTHORITY_PROVENANCE_REQUIRED"
        )

    execution = raw.get("execution_feasibility")
    cohort = raw.get("measurement_cohort")
    allowance = raw.get("execution_allowance")
    activation = raw.get("activation")
    if not isinstance(execution, dict):
        raise PreExecutionPolicyBlock("EXECUTION_FEASIBILITY_POLICY_REQUIRED")
    if not isinstance(cohort, dict):
        raise PreExecutionPolicyBlock("MEASUREMENT_COHORT_POLICY_REQUIRED")
    if not isinstance(allowance, dict):
        raise PreExecutionPolicyBlock("EXECUTION_ALLOWANCE_POLICY_REQUIRED")
    if not isinstance(activation, dict):
        raise PreExecutionPolicyBlock("EXECUTION_ACTIVATION_POLICY_REQUIRED")

    if execution.get("market") != "BINANCE_USDM_FUTURES":
        raise PreExecutionPolicyBlock("EXECUTION_MARKET_DRIFT")
    if (
        execution.get("order_book_source")
        != "BINANCE_USDM_STANDARD_ORDER_BOOK_DEPTH_REST_V1"
    ):
        raise PreExecutionPolicyBlock("EXECUTION_DEPTH_SOURCE_DRIFT")
    if int(execution.get("depth_limit", 0)) != 100:
        raise PreExecutionPolicyBlock("EXECUTION_DEPTH_LIMIT_DRIFT")
    if execution.get("rpi_liquidity_included") is not False:
        raise PreExecutionPolicyBlock("EXECUTION_RPI_POLICY_DRIFT")
    if execution.get("fully_fillable_required") is not True:
        raise PreExecutionPolicyBlock("EXECUTION_FILLABILITY_POLICY_DRIFT")
    if execution.get("spread_impact_fillability_all_required") is not True:
        raise PreExecutionPolicyBlock("EXECUTION_COMBINED_GATE_REQUIRED")
    if execution.get("direction_policy") != "SYMMETRIC_LONG_SHORT_CAP":
        raise PreExecutionPolicyBlock("EXECUTION_DIRECTION_POLICY_DRIFT")
    if (
        cohort.get("policy")
        != "FROZEN_UNIVERSE_INTERSECT_TRADING_AT_CUTOFF"
    ):
        raise PreExecutionPolicyBlock("MEASUREMENT_COHORT_POLICY_DRIFT")
    if cohort.get("strategy_universe_changed") is not False:
        raise PreExecutionPolicyBlock("STRATEGY_UNIVERSE_MUTATION_FORBIDDEN")
    if allowance.get("mode") != "D5_FEASIBILITY_GATED_ONLY":
        raise PreExecutionPolicyBlock("EXECUTION_ALLOWANCE_MODE_DRIFT")
    if allowance.get("independent_numeric_allowance") is not None:
        raise PreExecutionPolicyBlock(
            "INDEPENDENT_EXECUTION_ALLOWANCE_FORBIDDEN"
        )
    if allowance.get("tolerance_override_allowed") is not False:
        raise PreExecutionPolicyBlock("EXECUTION_TOLERANCE_OVERRIDE_FORBIDDEN")
    if activation.get("TAC_LIVE_ENABLED") is not False:
        raise PreExecutionPolicyBlock("AUTHORITY_MUST_NOT_ENABLE_LIVE")
    if activation.get("real_trading_authorized") is not False:
        raise PreExecutionPolicyBlock("AUTHORITY_MUST_NOT_AUTHORIZE_TRADING")

    return FrozenExecutionFeasibilityPolicyV1(
        intended_quote_notional=_positive_decimal(
            execution.get("intended_quote_notional_usdt"),
            "intended_quote_notional_usdt",
        ),
        depth_source=str(execution["order_book_source"]),
        depth_limit=int(execution["depth_limit"]),
        rpi_liquidity_included=False,
        max_spread_bps=_positive_decimal(
            execution.get("max_spread_bps"),
            "max_spread_bps",
        ),
        max_impact_bps=_positive_decimal(
            execution.get("max_impact_from_best_bps"),
            "max_impact_from_best_bps",
        ),
        fully_fillable_required=True,
        measurement_cohort_policy=str(cohort["policy"]),
        execution_allowance_mode=str(allowance["mode"]),
        authority=authority,
        version=version,
        authority_digest="SHA256:" + hashlib.sha256(raw_bytes).hexdigest(),
    )


def evaluate(
    *,
    legality: USDMarketEntryLegalityV1,
    measurement: ExecutionFeasibilityMeasurementV1,
    policy: ExecutionTolerancePolicyV1 | None,
) -> Mapping[str, object]:
    """Legacy mechanics-only evaluation retained for compatibility."""

    if not legality.exchange_legal:
        return {"state": "FAIL", "reason": "EXCHANGE_RULE_LEGALITY_FAILED"}
    if policy is None:
        return {
            "state": "BLOCKED",
            "reason": "EXECUTION_TOLERANCE_POLICY_NOT_FROZEN",
        }
    if not policy.authority or not policy.version:
        raise PreExecutionPolicyBlock("POLICY_AUTHORITY_VERSION_REQUIRED")
    target = measurement.intended_quote_notional
    fill_fraction = measurement.executable_quote_notional / target
    impact = measurement.impact_from_best_bps
    passed = (
        measurement.spread_bps <= policy.max_spread_bps
        and impact is not None
        and impact <= policy.max_impact_bps
        and fill_fraction >= policy.min_fill_fraction
        and measurement.fully_fillable
    )
    return {
        "state": "PASS" if passed else "FAIL",
        "reason": (
            "EXECUTION_FEASIBLE"
            if passed
            else "EXECUTION_TOLERANCE_EXCEEDED"
        ),
        "fill_fraction": str(fill_fraction),
    }


def evaluate_prospective_execution_evidence(
    *,
    legality: USDMarketEntryLegalityV1,
    evidence: ProspectiveExecutionEvidenceV1,
    policy: FrozenExecutionFeasibilityPolicyV1,
) -> Mapping[str, object]:
    """Evaluate the frozen 80-USDT execution policy after UPDATE-014."""

    evidence = validate_prospective_execution_evidence(evidence)
    if not isinstance(legality, USDMarketEntryLegalityV1):
        raise PreExecutionPolicyBlock("TYPED_MARKET_ENTRY_LEGALITY_REQUIRED")
    if not isinstance(policy, FrozenExecutionFeasibilityPolicyV1):
        raise PreExecutionPolicyBlock(
            "TYPED_FROZEN_EXECUTION_FEASIBILITY_POLICY_REQUIRED"
        )

    evidence_notional = _positive_decimal(
        evidence.intended_quote_notional,
        "evidence_intended_quote_notional",
    )
    if evidence_notional != policy.intended_quote_notional:
        raise PreExecutionPolicyBlock(
            "EXECUTION_NOTIONAL_POLICY_DRIFT:"
            + str(evidence_notional)
            + "!="
            + str(policy.intended_quote_notional)
        )
    if legality.requested_quote_notional != policy.intended_quote_notional:
        raise PreExecutionPolicyBlock(
            "LEGALITY_NOTIONAL_POLICY_DRIFT"
        )
    if evidence.depth_source != policy.depth_source:
        raise PreExecutionPolicyBlock("EXECUTION_DEPTH_SOURCE_POLICY_DRIFT")

    spread = _positive_decimal(evidence.spread_bps, "spread_bps")
    impact = (
        None
        if evidence.impact_from_best_bps is None
        else _nonnegative_decimal(
            evidence.impact_from_best_bps,
            "impact_from_best_bps",
        )
    )

    spread_pass = spread <= policy.max_spread_bps
    impact_pass = (
        impact is not None and impact <= policy.max_impact_bps
    )
    fillability_pass = (
        evidence.fully_fillable
        if policy.fully_fillable_required
        else True
    )
    trading_status_pass = legality.status_trading

    feasibility_pass = all(
        (
            trading_status_pass,
            spread_pass,
            impact_pass,
            fillability_pass,
        )
    )
    exchange_legal_pass = legality.exchange_legal
    allowance_pass = (
        feasibility_pass
        and exchange_legal_pass
        and policy.execution_allowance_mode
        == "D5_FEASIBILITY_GATED_ONLY"
    )

    return {
        "state": "PASS" if feasibility_pass else "FAIL",
        "reason": (
            "EXECUTION_FEASIBILITY_POLICY_PASS"
            if feasibility_pass
            else "EXECUTION_FEASIBILITY_POLICY_FAIL"
        ),
        "execution_allowance_state": (
            "PASS" if allowance_pass else "FAIL"
        ),
        "execution_allowance_reason": (
            "D5_FEASIBILITY_GATED_ONLY_PASS"
            if allowance_pass
            else "D5_FEASIBILITY_GATED_ONLY_BLOCK"
        ),
        "checks": {
            "status_trading": trading_status_pass,
            "spread": spread_pass,
            "impact_from_best": impact_pass,
            "fully_fillable": fillability_pass,
            "exchange_legal": exchange_legal_pass,
        },
        "observed": {
            "intended_quote_notional": str(evidence_notional),
            "spread_bps": str(spread),
            "impact_from_best_bps": (
                None if impact is None else str(impact)
            ),
            "fully_fillable": bool(evidence.fully_fillable),
        },
        "limits": {
            "intended_quote_notional": str(
                policy.intended_quote_notional
            ),
            "max_spread_bps": str(policy.max_spread_bps),
            "max_impact_from_best_bps": str(policy.max_impact_bps),
            "fully_fillable_required": policy.fully_fillable_required,
        },
        "policy": {
            "authority": policy.authority,
            "version": policy.version,
            "authority_digest": policy.authority_digest,
            "measurement_cohort_policy": (
                policy.measurement_cohort_policy
            ),
            "execution_allowance_mode": (
                policy.execution_allowance_mode
            ),
        },
    }


def invariants() -> Mapping[str, object]:
    return {
        "status": "AUTHORIZED_POLICY_ENFORCEMENT_READY",
        "fully_fillable_required": True,
        "post_update014_only": True,
        "update014_semantics_changed": False,
        "non_trading_symbol_execution_feasibility_pass": False,
        "notional_must_exactly_match_frozen_policy": True,
        "policy_loaded_from_versioned_authority": True,
        "selector_added": False,
        "ranking_added": False,
        "orders": 0,
        "fills": 0,
        "execution_intents": 0,
        "trading_activated": False,
    }
