"""Execute original D4 update_011 four mechanisms against source-merged engine.

The inputs here are explicitly synthetic TYPED upstream examples; no claim
that native Binance produced D3 evidence or UPDATE014 entry authority.
"""
from __future__ import annotations
from dataclasses import replace
from fractions import Fraction
import importlib
import importlib.util
from pathlib import Path
import sys
import tempfile
import unittest
from types import SimpleNamespace

from build_original_d1_singlemodule import DEST, ORIGINALS,originals
from build_original_d1d2_singlemodule import D2_FILES
from build_original_d1d2d3_singlemodule import D3_FILES
from build_original_d1d2d3d4_singlemodule import D4_FILES,make

CUTOFF=1800000899999


class OriginalD4CutoffDifferential(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory()
        root=Path(cls.tmp.name)
        for name,data in originals(ORIGINALS+D2_FILES+D3_FILES+D4_FILES):
            p=root/"strategy_rc1"/name
            p.parent.mkdir(parents=True,exist_ok=True)
            p.write_bytes(data)
        sys.path.insert(0,str(root))
        cls.original=SimpleNamespace(
            engine=importlib.import_module("strategy_rc1.d4_opportunity.engine"),
            types=importlib.import_module("strategy_rc1.d4_opportunity.types"),
            mechs=importlib.import_module("strategy_rc1.d4_opportunity.mechanisms"),
            d4params=importlib.import_module("strategy_rc1.d4_opportunity.parameters"),
            d2types=importlib.import_module("strategy_rc1.d2_market_state.types"),
            d2trend=importlib.import_module("strategy_rc1.d2_market_state.trend"),
            d3types=importlib.import_module("strategy_rc1.d3_boundary_intelligence.types"),
            d3anchors=importlib.import_module("strategy_rc1.d3_boundary_intelligence.anchors"),
            d3interaction=importlib.import_module("strategy_rc1.d3_boundary_intelligence.interaction"),
            params=importlib.import_module("strategy_rc1.parameter_snapshot"),
            info=importlib.import_module("strategy_rc1.runtime_guards.information_state"),
            results=importlib.import_module("strategy_rc1.result_types"),
        )
        spec=importlib.util.spec_from_file_location(
            "tac_original_d1d2d3d4_allinone",DEST/"original_d1d2d3d4_singlemodule.py")
        cls.inline=importlib.util.module_from_spec(spec)
        sys.modules[spec.name]=cls.inline
        spec.loader.exec_module(cls.inline)

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def create_cutoff_input(self,lib,scenario):
        orig=lib is self.original
        m=lib
        t=m.types if orig else m
        mt=m.mechs if orig else m
        d2=m.d2types if orig else m
        d3=m.d3types if orig else m
        ia=m.d3interaction if orig else m
        anchors=m.d3anchors if orig else m
        info=m.info if orig else m
        param=m.params if orig else m
        d4p=m.d4params if orig else m
        trend_module=m.d2trend if orig else m
        engine=m.engine if orig else m
        direction=d2.TrendDirection.LONG
        episode_id="D2_ORIGINAL_EPISODE_TEST"
        base=trend_module.initial_trend_state()
        trend=replace(base,direction=direction,
                      episode_id=episode_id,
                      episode_start_cutoff=CUTOFF-3600000,
                      phase=d2.TrendPhase.EXPANSION,
                      integrity=d2.TrendIntegrity.HEALTHY)
        tpos=d2.TrendPositionResult(
            d2.TrendPosition.BALANCED,info.InfoValue.known(Fraction(0)),
            info.InfoValue.na(),info.InfoValue.na(),info.InfoValue.na())
        is_active=scenario not in ("none","watch")
        aid="A1"
        event=ia.initial_watch("CANDIDATE_D3_TEST",episode_id,direction)
        event=replace(
            event,control=d3.InteractionControl.RESOLVED,
            resolution=d3.InteractionResolution.RESOLVED_CORRECT_SIDE,
            break_state=d3.BreakState.FALSE_BREAK,
            started_at=CUTOFF-1800000,
            armed_at=CUTOFF-2700000,
            approach_lineage_started_at=CUTOFF-1800000,
            resolved_at=CUTOFF,
            event_reference_boundary=Fraction(100),
            event_reference_scale=Fraction(2),
            terminal=True,
        )
        ep=d3.AnchorEpisode(
            anchor_episode_id=aid,candidate_id="CANDIDATE_D3_TEST",
            target_trend_episode_id=episode_id,
            target_direction=direction,
            validity=d3.AnchorValidity.VALID,
            activity=d3.AnchorActivity.ACTIVE,
            started_at=CUTOFF-7200000,
            ended_at=None,
            interaction_event_ids=(event.event_id,),
            qualified_uses=(),
            terminal_true_break=False,
            dossier=anchors.empty_dossier(),
            provenance={"test":"synthetic D3 typed input, not market proof"},
        )
        unit=d3.EconomicBoundaryUnit(
            unit_id="D3_UNIT_TEST",anchor_episode_ids=(aid,),
            contact_zones=(),is_cluster=False,
        )
        params=d4p.frozen_d4_parameters(param.current_partial_parameter_snapshot())
        extras={}
        if scenario=="watch":
            extras["trend_establishment_watch"]=mt.TrendEstablishmentWatchEvidence(
                observed=True,setup_lineage=("D2_STARTED",),source_event_ids=())
        elif scenario=="false":
            extras["false_break_reclaim"]=mt.FalseBreakReclaimEvidence(
                interaction=event,setup_lineage=("D3_BREAK_FALSE",))
        elif scenario=="normal":
            rearmed=replace(event,control=d3.InteractionControl.INTERACTION_ACTIVE,
                break_state=d3.BreakState.NONE,resolved_at=None,terminal=False)
            extras["normal_retest"]=mt.NormalRetestEvidence(
                interaction=rearmed,qualifying_retest_or_probe=True,
                adverse_structural_reference_fixed=True,
                local_control_regain=None,
                setup_lineage=("D3_PROBE","D2_CONTROL_AWAIT"),
            )
        elif scenario=="platform":
            platform=d2.PlatformState(
                status=d2.PlatformStatus.PLATFORM_CONFIRMED,
                contributing_event_ids=("FRE1","FRE2"),
                trend_side_extremes=(Fraction(90),Fraction(99)),
                platform_cap_price=Fraction(100),
                platform_scale=Fraction(2),
                confirmed_at=CUTOFF-900000,
                cap_first_time=CUTOFF-3600000,
                cap_last_time=CUTOFF-1800000,
            )
            extras["platform_reexpansion"]=mt.PlatformReexpansionEvidence(
                platform=platform,current_close=Fraction(105),
                target_trend_episode_id=episode_id,
                direction=direction,
                setup_lineage=("D2_PLATFORM_CONFIRM",),
            )
        elif scenario=="deep":
            regain=t.LocalTrendControlRegainEvidence(
                direction=direction,adverse_reference_pivot_id="PIVOT_A",
                adverse_reference_confirmed_at=CUTOFF-3600000,
                recovery_pivot_id="PIVOT_B",
                recovery_pivot_confirmed_at=CUTOFF,
                countertrend_progression_failed=info.InfoValue.known(True),
                material_original_direction_closed_price_recovery=info.InfoValue.known(True),
                confirmation_cutoff=CUTOFF,
            )
            extras["deep_takeover"]=mt.DeepStructureTakeoverEvidence(
                shallow_operating_defense_no_longer_completes_setup=True,
                deeper_boundary_independent=True,
                deeper_interaction=event,
                local_control_regain=regain,
                role_transition=d3.RoleTransition.PROMOTION,
                promotion_confirmed_at=CUTOFF,
                setup_lineage=("D3_B5_PROMOTION","D2_REGAIN"),
            )
        return engine.D4CutoffInput(
            information_cutoff=CUTOFF,trend=trend,
            trend_position=tpos,opportunity_direction=direction,
            market_event_id="AUTHORITATIVE_SYNTHETIC_EVENT_TEST_ONLY",
            detector_evidence_ids=("DETECTOR_TEST",),
            critical_information_known=info.InfoValue.known(True),
            entry_boundary_unit=unit if is_active else None,
            anchor_episodes={aid:ep} if is_active else {},
            parameters=params,**extras
        )

    def compare_one(self,scenario):
        orig=self.original
        a=orig.engine.update_011(self.create_cutoff_input(orig,scenario))
        b=self.inline.update_011(self.create_cutoff_input(self.inline,scenario))
        left=orig.results.freeze_payload(a)
        right=self.inline.freeze_payload(b)
        self.assertEqual(left,right,scenario)
        self.assertEqual(right["update_step"],"UPDATE-011")
        # Original output deliberately carries provenance 'no_entry_ready':
        # its presence is evidence of non-admission, not a trade signal.
        self.assertNotIn("entry_ready",right)
        self.assertNotIn("entry_ready_id",right.get("confirmation_candidate") or {})
        if right.get("confirmation_candidate"):
            self.assertEqual(right["confirmation_candidate"]["provenance"]["no_entry_ready"],"true")
        return right

    def test_original_D4_none_and_watch_only(self):
        none=self.compare_one("none")
        self.assertIsNone(none["primary_observation"])
        self.assertIsNone(none["confirmation_candidate"])
        watch=self.compare_one("watch")
        self.assertEqual(watch["primary_observation"]["mechanism"],
                         "TREND_ESTABLISHMENT_WATCH_ONLY")
        self.assertIsNone(watch["confirmation_candidate"])

    def test_original_D4_all_four_mechanism_paths(self):
        for mechanism in ("normal","false","platform","deep"):
            with self.subTest(mechanism=mechanism):
                out=self.compare_one(mechanism)
                self.assertIsNotNone(out["primary_observation"])
                self.assertIsNotNone(out["opportunity"])
                self.assertEqual(out["market_eligibility"]["result"]["value"],True)
        self.assertIsNotNone(self.compare_one("false")["confirmation_candidate"])

    def test_original_D4_ast_unchanged(self):
        source,members=make()
        self.assertEqual(len(members),10)
        self.assertTrue(all(m["scientific_body_ast_unchanged"] for m in members))
        self.assertEqual(source,(DEST/"original_d1d2d3d4_singlemodule.py").read_text())
        self.assertIn("def update_011(inp: D4CutoffInput)",source)
        self.assertNotIn("def execute_order",source)


if __name__=="__main__":
    unittest.main()
