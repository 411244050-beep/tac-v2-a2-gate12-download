"""Source-preserving D1 single-module dependency closure, generated from SHA-pinned original 91 files.

NOT a full TAC strategy; consume only within a Binance AI Pro native D1-D6
assembly. No synthetic pivot logic. All original scientific function bodies
and numeric constants are unchanged; only module-relative imports removed.
"""
from __future__ import annotations
from dataclasses import dataclass
from enum import Enum
from fractions import Fraction
from typing import Any
class Direction(str,Enum):
 UP = 'UP'
 DOWN = 'DOWN'
 UNKNOWN = 'UNKNOWN'
class IntegritySeverity(str,Enum):
 INFO = 'INFO'
 BLOCK = 'BLOCK'
@dataclass(frozen=True)
class IntegrityIssue:
 code: str
 severity: IntegritySeverity
 detail: str
 open_time: int | None = None
Number = Fraction
def number_to_exact_dict(value: Fraction) -> dict[str,int]:
 return {'numerator': value.numerator,'denominator': value.denominator}
def freeze_payload(value: Any) -> Any:
 """Convert supported objects into deterministic JSON-safe primitives."""
 from dataclasses import asdict,is_dataclass
 if isinstance(value,Fraction):
  return {'__fraction__': [value.numerator,value.denominator]}
 if isinstance(value,Enum):
  return value.value
 if is_dataclass(value):
  return {k: freeze_payload(v) for k,v in asdict(value).items()}
 if isinstance(value,dict):
  return {str(k): freeze_payload(v) for k,v in sorted(value.items(),key=lambda kv: str(kv[0]))}
 if isinstance(value,(list,tuple)):
  return [freeze_payload(v) for v in value]
 if value is None or isinstance(value,(str,int,bool)):
  return value
 raise TypeError(f'Unsupported deterministic payload type: {type(value)!r}')
import hashlib
import json
from typing import Any
def canonical_json(value: Any) -> str:
 return json.dumps(freeze_payload(value),sort_keys=True,separators=(',',':'),ensure_ascii=False)
def deterministic_id(namespace: str,*parts: Any,length: int=32) -> str:
 if not namespace or not isinstance(namespace,str):
  raise ValueError('namespace must be a non-empty string')
 payload = canonical_json({'namespace': namespace,'parts': list(parts)})
 digest = hashlib.sha256(payload.encode('utf-8')).hexdigest()
 return f'{namespace}:{digest[:length]}'
from dataclasses import dataclass
from enum import Enum
from typing import Generic,TypeVar
T = TypeVar('T')
class InfoKind(str,Enum):
 KNOWN = 'KNOWN'
 NONE = 'NONE'
 UNKNOWN = 'UNKNOWN'
 NA = 'N/A'
 ERROR = 'ERROR'
@dataclass(frozen=True)
class InfoValue(Generic[T]):
 kind: InfoKind
 value: T | None = None
 error_ref: str | None = None
 def __post_init__(self) -> None:
  if self.kind is InfoKind.KNOWN:
   if self.value is None or self.error_ref is not None:
    raise ValueError('KNOWN requires a value and no error_ref')
  elif self.kind is InfoKind.ERROR:
   if self.error_ref is None or self.value is not None:
    raise ValueError('ERROR requires error_ref and no value')
  elif self.value is not None or self.error_ref is not None:
   raise ValueError(f'{self.kind.value} cannot carry value/error_ref')
 @classmethod
 def known(cls,value: T) -> 'InfoValue[T]':
  return cls(InfoKind.KNOWN,value=value)
 @classmethod
 def none(cls) -> 'InfoValue[T]':
  return cls(InfoKind.NONE)
 @classmethod
 def unknown(cls) -> 'InfoValue[T]':
  return cls(InfoKind.UNKNOWN)
 @classmethod
 def na(cls) -> 'InfoValue[T]':
  return cls(InfoKind.NA)
 @classmethod
 def error(cls,error_ref: str) -> 'InfoValue[T]':
  return cls(InfoKind.ERROR,error_ref=error_ref)
 def require_known(self) -> T:
  if self.kind is not InfoKind.KNOWN:
   raise ValueError(f'Value is {self.kind.value}, not KNOWN')
  return self.value
class DataIntegrityBlock(RuntimeError):
 """System-level integrity block; never a market Strategy failure."""
class ContinuityReset(RuntimeError):
 """Marker exception for callers that choose exception-based segment handling."""
from fractions import Fraction
from typing import Protocol
class OHLCBar(Protocol):
 open_time: int
 close_time: int
 open: Fraction
 high: Fraction
 low: Fraction
 close: Fraction
from dataclasses import dataclass
from decimal import Decimal
from fractions import Fraction
from typing import Iterable
TF_15M_MS = 15 * 60 * 1000
def parse_exact_number(value: str | int | Decimal | Fraction) -> Fraction:
 if isinstance(value,Fraction):
  return value
 if isinstance(value,bool):
  raise TypeError('bool is not a valid market number')
 if isinstance(value,int):
  return Fraction(value,1)
 if isinstance(value,Decimal):
  return Fraction(value)
 if isinstance(value,str):
  return Fraction(Decimal(value))
 if isinstance(value,float):
  raise TypeError('float market inputs are forbidden; provide exact decimal string/int/Decimal/Fraction')
 raise TypeError(f'Unsupported market number type: {type(value)!r}')
@dataclass(frozen=True)
class CanonicalBar:
 symbol: str
 open_time: int
 close_time: int
 open: Fraction
 high: Fraction
 low: Fraction
 close: Fraction
 base_volume: Fraction | None = None
 quote_volume: Fraction | None = None
 is_closed: bool = True
 @classmethod
 def from_values(cls,*,symbol: str,open_time: int,close_time: int,open: str | int | Decimal | Fraction,high: str | int | Decimal | Fraction,low: str | int | Decimal | Fraction,close: str | int | Decimal | Fraction,base_volume: str | int | Decimal | Fraction | None=None,quote_volume: str | int | Decimal | Fraction | None=None,is_closed: bool=True) -> 'CanonicalBar':
  return cls(symbol=symbol,open_time=open_time,close_time=close_time,open=parse_exact_number(open),high=parse_exact_number(high),low=parse_exact_number(low),close=parse_exact_number(close),base_volume=None if base_volume is None else parse_exact_number(base_volume),quote_volume=None if quote_volume is None else parse_exact_number(quote_volume),is_closed=is_closed)
@dataclass(frozen=True)
class CanonicalRecord:
 bar: CanonicalBar
 canonical_segment_id: str
@dataclass(frozen=True)
class CanonicalizationResult:
 records: tuple[CanonicalRecord,...]
 issues: tuple[IntegrityIssue,...]
 identical_duplicates_deduplicated: int
 @property
 def information_cutoff(self) -> int | None:
  return self.records[-1].bar.close_time if self.records else None
def _validate_bar(bar: CanonicalBar) -> None:
 if not bar.symbol:
  raise DataIntegrityBlock('EMPTY_SYMBOL')
 if not bar.is_closed:
  raise DataIntegrityBlock(f'OPEN_BAR_FORBIDDEN open_time={bar.open_time}')
 if bar.open_time % TF_15M_MS != 0:
  raise DataIntegrityBlock(f'OPEN_TIME_NOT_15M_ALIGNED open_time={bar.open_time}')
 if bar.close_time <= bar.open_time:
  raise DataIntegrityBlock(f'IMPOSSIBLE_CLOSE_TIME open_time={bar.open_time} close_time={bar.close_time}')
 if bar.high < max(bar.open,bar.close,bar.low):
  raise DataIntegrityBlock(f'INVALID_HIGH open_time={bar.open_time}')
 if bar.low > min(bar.open,bar.close,bar.high):
  raise DataIntegrityBlock(f'INVALID_LOW open_time={bar.open_time}')
 if bar.base_volume is not None and bar.base_volume < 0:
  raise DataIntegrityBlock(f'NEGATIVE_BASE_VOLUME open_time={bar.open_time}')
 if bar.quote_volume is not None and bar.quote_volume < 0:
  raise DataIntegrityBlock(f'NEGATIVE_QUOTE_VOLUME open_time={bar.open_time}')
def canonicalize_15m(bars: Iterable[CanonicalBar]) -> CanonicalizationResult:
 ordered = sorted(bars,key=lambda b: (b.open_time,b.close_time))
 if not ordered:
  return CanonicalizationResult((),(),0)
 by_open: dict[int,CanonicalBar] = {}
 dedup = 0
 for bar in ordered:
  _validate_bar(bar)
  prior = by_open.get(bar.open_time)
  if prior is None:
   by_open[bar.open_time] = bar
  elif prior == bar:
   dedup += 1
  else:
   raise DataIntegrityBlock(f'CONFLICTING_DUPLICATE open_time={bar.open_time}')
 unique = [by_open[k] for k in sorted(by_open)]
 symbols = {b.symbol for b in unique}
 if len(symbols) != 1:
  raise DataIntegrityBlock('MIXED_SYMBOL_INPUT')
 symbol = unique[0].symbol
 records: list[CanonicalRecord] = []
 issues: list[IntegrityIssue] = []
 segment_id: str | None = None
 prev_open: int | None = None
 for bar in unique:
  if prev_open is None or bar.open_time - prev_open != TF_15M_MS:
   if prev_open is not None:
    delta = bar.open_time - prev_open
    if delta <= 0:
     raise DataIntegrityBlock('NON_MONOTONIC_OPEN_TIME')
    issues.append(IntegrityIssue(code='DATA_GAP_NEW_CANONICAL_SEGMENT',severity=IntegritySeverity.BLOCK,detail=f'gap_ms={delta - TF_15M_MS}; no forward fill; recursive state must reset',open_time=bar.open_time))
   segment_id = deterministic_id('canonical_segment',symbol,bar.open_time)
  records.append(CanonicalRecord(bar=bar,canonical_segment_id=segment_id))
  prev_open = bar.open_time
 return CanonicalizationResult(tuple(records),tuple(issues),dedup)
from fractions import Fraction
class EMARecurrence:
 def __init__(self,period: int) -> None:
  if period <= 0:
   raise ValueError('EMA period must be positive')
  self.period = period
  self._segment_id: str | None = None
  self._seed: list[Fraction] = []
  self._ema: Fraction | None = None
  self._alpha = Fraction(2,period + 1)
 def reset(self) -> None:
  self._seed.clear()
  self._ema = None
 def update(self,close: Fraction,*,segment_id: str) -> InfoValue[Fraction]:
  if self._segment_id != segment_id:
   self._segment_id = segment_id
   self.reset()
  if self._ema is None:
   self._seed.append(close)
   if len(self._seed) < self.period:
    return InfoValue.na()
   if len(self._seed) == self.period:
    self._ema = sum(self._seed,Fraction(0,1)) / self.period
    return InfoValue.known(self._ema)
   raise AssertionError('EMA seed length invariant broken')
  self._ema = self._alpha * close + (1 - self._alpha) * self._ema
  return InfoValue.known(self._ema)
from fractions import Fraction
class ATR14Recurrence:
 period = 14
 def __init__(self) -> None:
  self._segment_id: str | None = None
  self._prev_close: Fraction | None = None
  self._trs: list[Fraction] = []
  self._atr: Fraction | None = None
 def reset(self) -> None:
  self._prev_close = None
  self._trs.clear()
  self._atr = None
 def update(self,bar: OHLCBar,*,segment_id: str) -> InfoValue[Fraction]:
  if self._segment_id != segment_id:
   self._segment_id = segment_id
   self.reset()
  if self._prev_close is None:
   tr = bar.high - bar.low
  else:
   tr = max(bar.high - bar.low,abs(bar.high - self._prev_close),abs(bar.low - self._prev_close))
  self._prev_close = bar.close
  if self._atr is None:
   self._trs.append(tr)
   if len(self._trs) < self.period:
    return InfoValue.na()
   if len(self._trs) == self.period:
    self._atr = sum(self._trs,Fraction(0,1)) / self.period
    return InfoValue.known(self._atr)
   raise AssertionError('ATR seed length invariant broken')
  self._atr = (self._atr * (self.period - 1) + tr) / self.period
  return InfoValue.known(self._atr)
from dataclasses import dataclass
from fractions import Fraction
ST_MULTIPLIER = Fraction(3,1)
@dataclass(frozen=True)
class SupertrendPoint:
 final_upper: InfoValue[Fraction]
 final_lower: InfoValue[Fraction]
 direction: Direction
 active_line: InfoValue[Fraction]
class SupertrendRecurrence:
 """RC1 + adopted post-RC1 exact final-band recurrence binding."""
 def __init__(self) -> None:
  self._segment_id: str | None = None
  self._prev_close: Fraction | None = None
  self._final_upper: Fraction | None = None
  self._final_lower: Fraction | None = None
  self._direction = Direction.UNKNOWN
 def reset(self) -> None:
  self._prev_close = None
  self._final_upper = None
  self._final_lower = None
  self._direction = Direction.UNKNOWN
 def update(self,bar: OHLCBar,atr14: InfoValue[Fraction],*,segment_id: str) -> SupertrendPoint:
  if self._segment_id != segment_id:
   self._segment_id = segment_id
   self.reset()
  if atr14.kind is not InfoKind.KNOWN:
   self._prev_close = bar.close
   return SupertrendPoint(final_upper=InfoValue.na(),final_lower=InfoValue.na(),direction=Direction.UNKNOWN,active_line=InfoValue.na())
  atr = atr14.require_known()
  hl2 = (bar.high + bar.low) / 2
  basic_upper = hl2 + ST_MULTIPLIER * atr
  basic_lower = hl2 - ST_MULTIPLIER * atr
  if self._final_upper is None or self._final_lower is None or self._prev_close is None:
   self._final_upper = basic_upper
   self._final_lower = basic_lower
   self._direction = Direction.UNKNOWN
   self._prev_close = bar.close
   return SupertrendPoint(final_upper=InfoValue.known(self._final_upper),final_lower=InfoValue.known(self._final_lower),direction=self._direction,active_line=InfoValue.na())
  prior_upper = self._final_upper
  prior_lower = self._final_lower
  prior_close = self._prev_close
  final_lower = basic_lower if basic_lower > prior_lower or prior_close < prior_lower else prior_lower
  final_upper = basic_upper if basic_upper < prior_upper or prior_close > prior_upper else prior_upper
  if bar.close > prior_upper:
   direction = Direction.UP
  elif bar.close < prior_lower:
   direction = Direction.DOWN
  else:
   direction = self._direction
  self._final_upper = final_upper
  self._final_lower = final_lower
  self._direction = direction
  self._prev_close = bar.close
  if direction is Direction.UP:
   active = InfoValue.known(final_lower)
  elif direction is Direction.DOWN:
   active = InfoValue.known(final_upper)
  else:
   active = InfoValue.na()
  return SupertrendPoint(final_upper=InfoValue.known(final_upper),final_lower=InfoValue.known(final_lower),direction=direction,active_line=active)
from collections import defaultdict
from dataclasses import dataclass
from fractions import Fraction
from typing import Iterable
@dataclass(frozen=True)
class HTFBar:
 symbol: str
 timeframe_ms: int
 open_time: int
 close_time: int
 open: Fraction
 high: Fraction
 low: Fraction
 close: Fraction
 base_volume: Fraction | None
 quote_volume: Fraction | None
 source_segment_id: str
def _sum_optional(values: list[Fraction | None]) -> Fraction | None:
 if any((v is None for v in values)):
  return None
 return sum((v for v in values if v is not None),Fraction(0,1))
def aggregate_completed_htf(records: Iterable[CanonicalRecord],*,timeframe_ms: int,information_cutoff: int) -> tuple[HTFBar,...]:
 if timeframe_ms not in (60 * 60 * 1000,4 * 60 * 60 * 1000):
  raise ValueError('Only causal 1H and 4H aggregation is authorized in WP1')
 required = timeframe_ms // TF_15M_MS
 buckets: dict[tuple[str,int],list[CanonicalRecord]] = defaultdict(list)
 for rec in records:
  bucket_start = rec.bar.open_time // timeframe_ms * timeframe_ms
  buckets[rec.canonical_segment_id,bucket_start].append(rec)
 out: list[HTFBar] = []
 for (segment_id,bucket_start),members in sorted(buckets.items(),key=lambda kv: kv[0][1]):
  members.sort(key=lambda r: r.bar.open_time)
  expected_opens = [bucket_start + i * TF_15M_MS for i in range(required)]
  actual_opens = [r.bar.open_time for r in members]
  if actual_opens != expected_opens:
   continue
  if len({r.canonical_segment_id for r in members}) != 1:
   continue
  close_time = members[-1].bar.close_time
  if close_time > information_cutoff:
   continue
  first,last = (members[0].bar,members[-1].bar)
  out.append(HTFBar(symbol=first.symbol,timeframe_ms=timeframe_ms,open_time=bucket_start,close_time=close_time,open=first.open,high=max((r.bar.high for r in members)),low=min((r.bar.low for r in members)),close=last.close,base_volume=_sum_optional([r.bar.base_volume for r in members]),quote_volume=_sum_optional([r.bar.quote_volume for r in members]),source_segment_id=segment_id))
 return tuple(out)
from dataclasses import dataclass
from enum import Enum
from types import MappingProxyType
from typing import Mapping
class ParameterState(str,Enum):
 FROZEN = 'FROZEN'
 OPEN = 'OPEN'
 LOCKED = 'LOCKED'
@dataclass(frozen=True)
class ParameterSlot:
 name: str
 state: ParameterState
 exact_value: str | None = None
 def __post_init__(self) -> None:
  if self.state is ParameterState.FROZEN and self.exact_value is None:
   raise ValueError(f'Frozen parameter {self.name} requires exact_value')
  if self.state is not ParameterState.FROZEN and self.exact_value is not None:
   raise ValueError(f'Unfrozen parameter {self.name} must not contain a value')
@dataclass(frozen=True)
class ParameterSnapshot:
 snapshot_id: str
 slots: Mapping[str,ParameterSlot]
 complete_strategy_parameter_snapshot: bool
 runtime_usable: bool
 source_status: str
 def __post_init__(self) -> None:
  object.__setattr__(self,'slots',MappingProxyType(dict(self.slots)))
 def slot(self,name: str) -> ParameterSlot:
  try:
   return self.slots[name]
  except KeyError as exc:
   raise KeyError(f'Parameter slot not declared: {name}') from exc
 @property
 def frozen_count(self) -> int:
  return sum((s.state is ParameterState.FROZEN for s in self.slots.values()))
PARTIAL_PARAMETER_SNAPSHOT_ID = 'R1_PARTIAL_RESEARCH_SNAPSHOT_PROGRESS_RATE_B3_ACCEPT_OVER_995E24FBAA216C62'
PARTIAL_PARAMETER_SNAPSHOT_DETERMINISTIC_SHA256 = 'a869a3a7758c0a4ff34ddfb5ae1c4e012e0600bbea6492cf12efa19a148ef5bb'
_FROZEN = {'theta_accept': '2.1313767840459202205981702405574439224871803906649207193085500','theta_approach': '1.197268280893772873697806561124554291191704011769349520546870','theta_overextension': '2.7703041968078565478295719882475244376661292176373236367284700','theta_progress': '1.27112707163488491529631027277968495738450','theta_rate': '0.17560145225927980894381212168524856466229325734699705827303000','theta_separation': '2.24912097135367169114306428916723600671864369102654007565280','theta_test': '0.5913466407600057877252533034649404155944065891655909831651470'}
def current_partial_parameter_snapshot() -> ParameterSnapshot:
 """Bind the durable partial snapshot, overlaid by newer current governance.

    The source V5 snapshot recorded theta_stop as OPEN at that historical point.
    Current v12 governance supersedes only its current-state display and locks
    theta_stop. No numerical value is created for the locked slot.
    """
 slots: dict[str,ParameterSlot] = {name: ParameterSlot(name=name,state=ParameterState.FROZEN,exact_value=value) for name,value in _FROZEN.items()}
 slots.update({'theta_minor': ParameterSlot('theta_minor',ParameterState.OPEN),'theta_intermediate': ParameterSlot('theta_intermediate',ParameterState.OPEN),'theta_major': ParameterSlot('theta_major',ParameterState.OPEN),'theta_stop': ParameterSlot('theta_stop',ParameterState.LOCKED)})
 return ParameterSnapshot(snapshot_id=PARTIAL_PARAMETER_SNAPSHOT_ID,slots=slots,complete_strategy_parameter_snapshot=False,runtime_usable=False,source_status='PARTIAL_RESEARCH_FREEZE_NOT_STRATEGY_USABLE_WITH_CURRENT_V12_THETA_STOP_LOCK_OVERLAY')
from dataclasses import dataclass
from decimal import Decimal
from fractions import Fraction
class StructuralParameterResolutionBlock(RuntimeError):
 pass
def _exact_fraction(value: str) -> Fraction:
 return Fraction(Decimal(value))
@dataclass(frozen=True)
class StructuralScaleParameters:
 theta_minor: Fraction
 theta_intermediate: Fraction
 theta_major: Fraction
 def __post_init__(self) -> None:
  if not 0 < self.theta_minor < self.theta_intermediate < self.theta_major:
   raise ValueError('RC1 requires 0 < theta_minor < theta_intermediate < theta_major')
@dataclass(frozen=True)
class FrozenD2Parameters:
 theta_progress: Fraction
 theta_rate: Fraction
 theta_overextension: Fraction
 def __post_init__(self) -> None:
  if self.theta_progress < 0:
   raise ValueError('theta_progress must be >= 0')
  if self.theta_rate < 0:
   raise ValueError('theta_rate must be >= 0')
  if self.theta_overextension <= 1:
   raise ValueError('theta_overextension must be > 1')
def require_structural_scale_parameters(snapshot: ParameterSnapshot) -> StructuralScaleParameters:
 names = ('theta_minor','theta_intermediate','theta_major')
 slots = [snapshot.slot(name) for name in names]
 unresolved = [slot.name for slot in slots if slot.state is not ParameterState.FROZEN]
 if unresolved:
  raise StructuralParameterResolutionBlock('WP2_STRUCTURAL_SCALE_PARAMETERS_UNRESOLVED: ' + ','.join(unresolved))
 return StructuralScaleParameters(*(_exact_fraction(slot.exact_value or '') for slot in slots))
def frozen_d2_parameters(snapshot: ParameterSnapshot) -> FrozenD2Parameters:
 values: list[Fraction] = []
 for name in ('theta_progress','theta_rate','theta_overextension'):
  slot = snapshot.slot(name)
  if slot.state is not ParameterState.FROZEN or slot.exact_value is None:
   raise StructuralParameterResolutionBlock(f'D2_FROZEN_PARAMETER_MISSING: {name}')
  values.append(_exact_fraction(slot.exact_value))
 return FrozenD2Parameters(*values)
from dataclasses import dataclass
from enum import Enum
from fractions import Fraction
from typing import Mapping
class StructuralLayer(str,Enum):
 MINOR = 'MINOR'
 INTERMEDIATE = 'INTERMEDIATE'
 MAJOR = 'MAJOR'
class PivotType(str,Enum):
 HIGH = 'HIGH'
 LOW = 'LOW'
class SearchMode(str,Enum):
 UNKNOWN = 'UNKNOWN'
 NEUTRAL = 'NEUTRAL'
 SEEK_HIGH = 'SEEK_HIGH'
 SEEK_LOW = 'SEEK_LOW'
class ProgressRelation(str,Enum):
 MATERIAL_ADVANCE_UP = 'MATERIAL_ADVANCE_UP'
 MATERIAL_ADVANCE_DOWN = 'MATERIAL_ADVANCE_DOWN'
 STRUCTURALLY_EQUIVALENT = 'STRUCTURALLY_EQUIVALENT'
class TrendDirection(str,Enum):
 LONG = 'LONG'
 SHORT = 'SHORT'
 NONE = 'NONE'
 UNKNOWN = 'UNKNOWN'
class TrendIntegrity(str,Enum):
 HEALTHY = 'HEALTHY'
 PRESSURED = 'PRESSURED'
 DETERIORATING = 'DETERIORATING'
 FAILED = 'FAILED'
class TrendPhase(str,Enum):
 UNKNOWN = 'UNKNOWN'
 NO_TREND = 'NO_TREND'
 EXPANSION = 'EXPANSION'
 ACCELERATION = 'ACCELERATION'
 DECELERATION = 'DECELERATION'
 PLATFORM_CANDIDATE = 'PLATFORM_CANDIDATE'
 PLATFORM_CONFIRMED = 'PLATFORM_CONFIRMED'
 REVERSAL_CANDIDATE = 'REVERSAL_CANDIDATE'
 STRUCTURAL_FAILURE = 'STRUCTURAL_FAILURE'
class TrendPosition(str,Enum):
 BALANCED = 'BALANCED'
 PULLBACK = 'PULLBACK'
 EXTENDED = 'EXTENDED'
 OVEREXTENDED = 'OVEREXTENDED'
 UNKNOWN = 'UNKNOWN'
 NA = 'N/A'
class PlatformStatus(str,Enum):
 NONE = 'NONE'
 PLATFORM_CANDIDATE = 'PLATFORM_CANDIDATE'
 PLATFORM_CONFIRMED = 'PLATFORM_CONFIRMED'
@dataclass(frozen=True)
class StructuralPivot:
 pivot_id: str
 symbol: str
 timeframe_ms: int
 layer: StructuralLayer
 pivot_type: PivotType
 extreme_price: Fraction
 extreme_first_time: int
 extreme_last_time: int
 confirmed_at: int
 scale_at_extreme: Fraction
 canonical_segment_id: str
 source_pivot_ids: tuple[str,...]
 provenance: Mapping[str,str]
 def __post_init__(self) -> None:
  if self.extreme_last_time < self.extreme_first_time:
   raise ValueError('extreme_last_time precedes extreme_first_time')
  if self.confirmed_at < self.extreme_last_time:
   raise ValueError('confirmed_at precedes extreme_last_time')
  if self.scale_at_extreme <= 0:
   raise ValueError('scale_at_extreme must be positive')
  if not self.canonical_segment_id:
   raise ValueError('canonical_segment_id is required')
@dataclass(frozen=True)
class LegMetrics:
 gross_displacement: Fraction
 normalized_displacement: Fraction
 directional_efficiency: InfoValue[Fraction]
 robust_normalized_slope: InfoValue[Fraction]
@dataclass(frozen=True)
class StructuralLeg:
 leg_id: str
 symbol: str
 timeframe_ms: int
 layer: StructuralLayer
 start_pivot_id: str
 end_pivot_id: str
 start_type: PivotType
 end_type: PivotType
 canonical_segment_id: str
 metrics: LegMetrics
@dataclass(frozen=True)
class EstablishmentEvidence:
 direction: TrendDirection
 newest_pivot_id: str
 sequence_pivot_ids: tuple[str,str,str,str]
 defended_opposite_pivot_id: str
 opposing_structural_cap_pivot_id: str
@dataclass(frozen=True)
class TrendEpisodeState:
 direction: TrendDirection
 episode_id: str | None
 episode_start_cutoff: int | None
 protected_pivot: StructuralPivot | None
 frontier_pivot: StructuralPivot | None
 phase: TrendPhase
 integrity: TrendIntegrity | None
 reversal_candidate_cap: StructuralPivot | None
 defended_pullback_after_pressure: bool
 prior_same_direction_edpr: InfoValue[Fraction]
 completed_trend_aligned_normalized_legs: tuple[Fraction,...]
 terminal_episode_id: str | None = None
@dataclass(frozen=True)
class TrendPositionResult:
 position: TrendPosition
 x: InfoValue[Fraction]
 episode_excursion: InfoValue[Fraction]
 episode_median_leg_length: InfoValue[Fraction]
 overextension_ratio: InfoValue[Fraction]
@dataclass(frozen=True)
class StructuralCorridor:
 lower: Fraction
 upper: Fraction
@dataclass(frozen=True)
class FailedReexpansionEvent:
 event_id: str
 symbol: str
 timeframe_ms: int
 direction: TrendDirection
 confirmation_cutoff: int
 trend_side_minor_extreme_price: Fraction
 trend_side_minor_extreme_first_time: int
 trend_side_minor_extreme_last_time: int
 protected_structure_intact: bool
 independent_from_prior: bool
 rearmed_from_prior: bool
@dataclass(frozen=True)
class PlatformState:
 status: PlatformStatus
 contributing_event_ids: tuple[str,...]
 trend_side_extremes: tuple[Fraction,...]
 platform_cap_price: Fraction | None
 platform_scale: Fraction | None
 confirmed_at: int | None
 cap_first_time: int | None
 cap_last_time: int | None
from fractions import Fraction
def same_type_progress(p0: StructuralPivot,p1: StructuralPivot,theta_progress: Fraction) -> ProgressRelation:
 if p0.pivot_type is not p1.pivot_type:
  raise ValueError('same_type_progress requires same pivot type')
 if p0.layer is not p1.layer:
  raise ValueError('same_type_progress requires same structural layer')
 if p0.symbol != p1.symbol or p0.timeframe_ms != p1.timeframe_ms:
  raise ValueError('same_type_progress requires same symbol/timeframe')
 if p0.canonical_segment_id != p1.canonical_segment_id:
  raise ValueError('cross-gap progress comparison is forbidden')
 if p1.confirmed_at <= p0.confirmed_at:
  raise ValueError('p1 must be causally later than p0')
 if p0.scale_at_extreme <= 0:
  raise ValueError('p0 scale_at_extreme must be positive')
 delta_n = (p1.extreme_price - p0.extreme_price) / p0.scale_at_extreme
 if delta_n > theta_progress:
  return ProgressRelation.MATERIAL_ADVANCE_UP
 if delta_n < -theta_progress:
  return ProgressRelation.MATERIAL_ADVANCE_DOWN
 return ProgressRelation.STRUCTURALLY_EQUIVALENT
def normalized_delta(p0: StructuralPivot,p1: StructuralPivot) -> Fraction:
 if p0.scale_at_extreme <= 0:
  raise ValueError('p0 scale_at_extreme must be positive')
 return (p1.extreme_price - p0.extreme_price) / p0.scale_at_extreme
from fractions import Fraction
from typing import Sequence
def latest_establishment_evidence(pivots: Sequence[StructuralPivot],*,theta_progress: Fraction) -> EstablishmentEvidence | None:
 """Evaluate only the latest complete alternating 4-pivot sequence ending at newest pivot."""
 if len(pivots) < 4:
  return None
 seq = tuple(pivots[-4:])
 if any((p.layer.value != 'INTERMEDIATE' for p in seq)):
  raise ValueError('Trend establishment consumes Intermediate pivots only')
 if len({p.canonical_segment_id for p in seq}) != 1:
  return None
 if not all((a.confirmed_at < b.confirmed_at for a,b in zip(seq,seq[1:]))):
  raise ValueError('Intermediate pivot stream must be causally ordered')
 types = tuple((p.pivot_type for p in seq))
 if types == (PivotType.LOW,PivotType.HIGH,PivotType.LOW,PivotType.HIGH):
  l0,h0,l1,h1 = seq
  high_progress = same_type_progress(h0,h1,theta_progress)
  low_progress = same_type_progress(l0,l1,theta_progress)
  if high_progress is ProgressRelation.MATERIAL_ADVANCE_UP and low_progress is not ProgressRelation.MATERIAL_ADVANCE_DOWN:
   return EstablishmentEvidence(direction=TrendDirection.LONG,newest_pivot_id=h1.pivot_id,sequence_pivot_ids=tuple((p.pivot_id for p in seq)),defended_opposite_pivot_id=l1.pivot_id,opposing_structural_cap_pivot_id=l1.pivot_id)
 if types == (PivotType.HIGH,PivotType.LOW,PivotType.HIGH,PivotType.LOW):
  h0,l0,h1,l1 = seq
  low_progress = same_type_progress(l0,l1,theta_progress)
  high_progress = same_type_progress(h0,h1,theta_progress)
  if low_progress is ProgressRelation.MATERIAL_ADVANCE_DOWN and high_progress is not ProgressRelation.MATERIAL_ADVANCE_UP:
   return EstablishmentEvidence(direction=TrendDirection.SHORT,newest_pivot_id=l1.pivot_id,sequence_pivot_ids=tuple((p.pivot_id for p in seq)),defended_opposite_pivot_id=h1.pivot_id,opposing_structural_cap_pivot_id=h1.pivot_id)
 return None
from dataclasses import dataclass
from fractions import Fraction
@dataclass
class _MinorCandidate:
 pivot_type: PivotType
 price: Fraction
 first_time: int
 last_time: int
 scale: Fraction
class MinorDirectionalChangeEngine:
 """RC1 Minor directional-change state machine.

    Only canonical OHLC is consumed. A confirmation close may confirm a prior
    candidate, but the same confirmation bar's opposite wick is deliberately
    not reused as the next candidate because intrabar ordering is unknowable.
    """
 def __init__(self,*,symbol: str,timeframe_ms: int,theta_minor: Fraction) -> None:
  if theta_minor <= 0:
   raise ValueError('theta_minor must be positive')
  self.symbol = symbol
  self.timeframe_ms = timeframe_ms
  self.theta = theta_minor
  self.segment_id: str | None = None
  self.mode = SearchMode.UNKNOWN
  self.seed_close: Fraction | None = None
  self.seed_scale: Fraction | None = None
  self.candidate: _MinorCandidate | None = None
  self._sequence = 0
 def _reset(self,segment_id: str) -> None:
  self.segment_id = segment_id
  self.mode = SearchMode.UNKNOWN
  self.seed_close = None
  self.seed_scale = None
  self.candidate = None
 def _pivot(self,c: _MinorCandidate,*,confirmed_at: int,confirming_open_time: int) -> StructuralPivot:
  self._sequence += 1
  pid = deterministic_id('pivot',self.symbol,self.timeframe_ms,StructuralLayer.MINOR.value,c.pivot_type.value,c.price,c.first_time,c.last_time,confirmed_at,self.segment_id,self._sequence)
  return StructuralPivot(pivot_id=pid,symbol=self.symbol,timeframe_ms=self.timeframe_ms,layer=StructuralLayer.MINOR,pivot_type=c.pivot_type,extreme_price=c.price,extreme_first_time=c.first_time,extreme_last_time=c.last_time,confirmed_at=confirmed_at,scale_at_extreme=c.scale,canonical_segment_id=self.segment_id or '',source_pivot_ids=(),provenance={'rule': 'MS-003..MS-008','confirming_bar_open_time': str(confirming_open_time),'ohlc_ordering': 'confirmation_close_may_confirm_prior_candidate; opposite_wick_not_reused_same_bar'})
 def update(self,bar: CanonicalBar,atr14: InfoValue[Fraction],*,canonical_segment_id: str) -> tuple[StructuralPivot,...]:
  if bar.symbol != self.symbol:
   raise ValueError('symbol mismatch')
  if self.segment_id != canonical_segment_id:
   self._reset(canonical_segment_id)
  if atr14.kind is not InfoKind.KNOWN:
   return ()
  scale = atr14.require_known()
  if scale <= 0:
   return ()
  if self.mode is SearchMode.UNKNOWN:
   self.seed_close = bar.close
   self.seed_scale = scale
   self.mode = SearchMode.NEUTRAL
   return ()
  if self.mode is SearchMode.NEUTRAL:
   assert self.seed_close is not None and self.seed_scale is not None
   threshold = self.theta * self.seed_scale
   up = bar.close - self.seed_close
   down = self.seed_close - bar.close
   if up >= threshold:
    self.mode = SearchMode.SEEK_HIGH
    self.candidate = _MinorCandidate(PivotType.HIGH,bar.high,bar.open_time,bar.open_time,scale)
   elif down >= threshold:
    self.mode = SearchMode.SEEK_LOW
    self.candidate = _MinorCandidate(PivotType.LOW,bar.low,bar.open_time,bar.open_time,scale)
   return ()
  if self.candidate is None:
   if self.mode is SearchMode.SEEK_HIGH:
    self.candidate = _MinorCandidate(PivotType.HIGH,bar.high,bar.open_time,bar.open_time,scale)
    return ()
   if self.mode is SearchMode.SEEK_LOW:
    self.candidate = _MinorCandidate(PivotType.LOW,bar.low,bar.open_time,bar.open_time,scale)
    return ()
   raise AssertionError(f'unexpected mode {self.mode}')
  prior = self.candidate
  if self.mode is SearchMode.SEEK_HIGH:
   if bar.high > prior.price:
    self.candidate = _MinorCandidate(PivotType.HIGH,bar.high,bar.open_time,bar.open_time,scale)
    return ()
   if bar.high == prior.price:
    self.candidate = _MinorCandidate(PivotType.HIGH,prior.price,prior.first_time,bar.open_time,prior.scale)
    return ()
   if bar.open_time > prior.last_time and prior.price - bar.close >= self.theta * prior.scale:
    pivot = self._pivot(prior,confirmed_at=bar.close_time,confirming_open_time=bar.open_time)
    self.mode = SearchMode.SEEK_LOW
    self.candidate = None
    return (pivot,)
   return ()
  if self.mode is SearchMode.SEEK_LOW:
   if bar.low < prior.price:
    self.candidate = _MinorCandidate(PivotType.LOW,bar.low,bar.open_time,bar.open_time,scale)
    return ()
   if bar.low == prior.price:
    self.candidate = _MinorCandidate(PivotType.LOW,prior.price,prior.first_time,bar.open_time,prior.scale)
    return ()
   if bar.open_time > prior.last_time and bar.close - prior.price >= self.theta * prior.scale:
    pivot = self._pivot(prior,confirmed_at=bar.close_time,confirming_open_time=bar.open_time)
    self.mode = SearchMode.SEEK_HIGH
    self.candidate = None
    return (pivot,)
   return ()
  raise AssertionError(f'unexpected mode {self.mode}')
@dataclass
class _HierarchyCandidate:
 source: StructuralPivot
class PivotStreamDirectionalChangeEngine:
 """Generic higher-layer directional change over confirmed lower-layer pivots."""
 def __init__(self,*,output_layer: StructuralLayer,theta: Fraction) -> None:
  if output_layer is StructuralLayer.MINOR:
   raise ValueError('Use MinorDirectionalChangeEngine for MINOR')
  if theta <= 0:
   raise ValueError('theta must be positive')
  self.output_layer = output_layer
  self.theta = theta
  self.segment_id: str | None = None
  self.mode = SearchMode.UNKNOWN
  self.seed: StructuralPivot | None = None
  self.candidate: _HierarchyCandidate | None = None
  self._sequence = 0
 @staticmethod
 def _expected_input_layer(output_layer: StructuralLayer) -> StructuralLayer:
  return StructuralLayer.MINOR if output_layer is StructuralLayer.INTERMEDIATE else StructuralLayer.INTERMEDIATE
 def _reset(self,segment_id: str) -> None:
  self.segment_id = segment_id
  self.mode = SearchMode.UNKNOWN
  self.seed = None
  self.candidate = None
 def _emit(self,candidate: StructuralPivot,confirmer: StructuralPivot) -> StructuralPivot:
  self._sequence += 1
  pid = deterministic_id('pivot',candidate.symbol,candidate.timeframe_ms,self.output_layer.value,candidate.pivot_type.value,candidate.extreme_price,candidate.extreme_first_time,candidate.extreme_last_time,confirmer.confirmed_at,candidate.canonical_segment_id,self._sequence)
  return StructuralPivot(pivot_id=pid,symbol=candidate.symbol,timeframe_ms=candidate.timeframe_ms,layer=self.output_layer,pivot_type=candidate.pivot_type,extreme_price=candidate.extreme_price,extreme_first_time=candidate.extreme_first_time,extreme_last_time=candidate.extreme_last_time,confirmed_at=confirmer.confirmed_at,scale_at_extreme=candidate.scale_at_extreme,canonical_segment_id=candidate.canonical_segment_id,source_pivot_ids=(candidate.pivot_id,confirmer.pivot_id),provenance={'rule': 'MS-012','method': 'directional_change_over_confirmed_lower_pivot_stream'})
 def update(self,pivot: StructuralPivot) -> tuple[StructuralPivot,...]:
  expected = self._expected_input_layer(self.output_layer)
  if pivot.layer is not expected:
   raise ValueError(f'{self.output_layer.value} requires {expected.value} input pivots')
  if self.segment_id != pivot.canonical_segment_id:
   self._reset(pivot.canonical_segment_id)
  if self.mode is SearchMode.UNKNOWN:
   self.seed = pivot
   self.mode = SearchMode.NEUTRAL
   return ()
  if self.mode is SearchMode.NEUTRAL:
   assert self.seed is not None
   if pivot.pivot_type is self.seed.pivot_type:
    if pivot.pivot_type is PivotType.HIGH and pivot.extreme_price >= self.seed.extreme_price:
     self.seed = pivot
    elif pivot.pivot_type is PivotType.LOW and pivot.extreme_price <= self.seed.extreme_price:
     self.seed = pivot
    return ()
   threshold = self.theta * self.seed.scale_at_extreme
   delta = pivot.extreme_price - self.seed.extreme_price
   if delta >= threshold:
    self.mode = SearchMode.SEEK_HIGH
    self.candidate = _HierarchyCandidate(pivot if pivot.pivot_type is PivotType.HIGH else self.seed)
   elif delta <= -threshold:
    self.mode = SearchMode.SEEK_LOW
    self.candidate = _HierarchyCandidate(pivot if pivot.pivot_type is PivotType.LOW else self.seed)
   return ()
  assert self.candidate is not None
  c = self.candidate.source
  if self.mode is SearchMode.SEEK_HIGH:
   if pivot.pivot_type is PivotType.LOW and c.extreme_price - pivot.extreme_price >= self.theta * c.scale_at_extreme:
    emitted = self._emit(c,pivot)
    self.mode = SearchMode.SEEK_LOW
    self.candidate = _HierarchyCandidate(pivot)
    return (emitted,)
   if pivot.pivot_type is PivotType.HIGH and pivot.extreme_price >= c.extreme_price:
    self.candidate = _HierarchyCandidate(pivot)
   return ()
  if self.mode is SearchMode.SEEK_LOW:
   if pivot.pivot_type is PivotType.HIGH and pivot.extreme_price - c.extreme_price >= self.theta * c.scale_at_extreme:
    emitted = self._emit(c,pivot)
    self.mode = SearchMode.SEEK_HIGH
    self.candidate = _HierarchyCandidate(pivot)
    return (emitted,)
   if pivot.pivot_type is PivotType.LOW and pivot.extreme_price <= c.extreme_price:
    self.candidate = _HierarchyCandidate(pivot)
   return ()
  raise AssertionError(f'unexpected mode {self.mode}')
from dataclasses import dataclass
from fractions import Fraction
@dataclass(frozen=True)
class HierarchyUpdate:
 minor: tuple[StructuralPivot,...]
 intermediate: tuple[StructuralPivot,...]
 major: tuple[StructuralPivot,...]
class StructuralHierarchyEngine:
 """One timeframe's Minor -> Intermediate -> Major RC1 hierarchy."""
 def __init__(self,*,symbol: str,timeframe_ms: int,params: StructuralScaleParameters) -> None:
  self.minor = MinorDirectionalChangeEngine(symbol=symbol,timeframe_ms=timeframe_ms,theta_minor=params.theta_minor)
  self.intermediate = PivotStreamDirectionalChangeEngine(output_layer=StructuralLayer.INTERMEDIATE,theta=params.theta_intermediate)
  self.major = PivotStreamDirectionalChangeEngine(output_layer=StructuralLayer.MAJOR,theta=params.theta_major)
  self._all_minor: list[StructuralPivot] = []
  self._all_intermediate: list[StructuralPivot] = []
  self._all_major: list[StructuralPivot] = []
 @property
 def all_minor(self) -> tuple[StructuralPivot,...]:
  return tuple(self._all_minor)
 @property
 def all_intermediate(self) -> tuple[StructuralPivot,...]:
  return tuple(self._all_intermediate)
 @property
 def all_major(self) -> tuple[StructuralPivot,...]:
  return tuple(self._all_major)
 def update_bar(self,bar: CanonicalBar,atr14: InfoValue[Fraction],*,canonical_segment_id: str) -> HierarchyUpdate:
  minors = self.minor.update(bar,atr14,canonical_segment_id=canonical_segment_id)
  inters: list[StructuralPivot] = []
  majors: list[StructuralPivot] = []
  for p in minors:
   self._all_minor.append(p)
   new_i = self.intermediate.update(p)
   for ip in new_i:
    self._all_intermediate.append(ip)
    inters.append(ip)
    new_m = self.major.update(ip)
    for mp in new_m:
     self._all_major.append(mp)
     majors.append(mp)
  return HierarchyUpdate(minors,tuple(inters),tuple(majors))
from dataclasses import dataclass
from fractions import Fraction
from statistics import median
from typing import Sequence
@dataclass(frozen=True)
class TimedClose:
 open_time: int
 close: Fraction
def _theil_sen_normalized_slope(closes: Sequence[TimedClose],*,timeframe_ms: int,scale_at_leg_start: Fraction) -> InfoValue[Fraction]:
 if len(closes) < 3:
  return InfoValue.na()
 if scale_at_leg_start <= 0:
  return InfoValue.error('NONPOSITIVE_LEG_START_SCALE')
 ordered = sorted(closes,key=lambda c: c.open_time)
 if len({c.open_time for c in ordered}) != len(ordered):
  return InfoValue.error('DUPLICATE_CLOSE_TIME_IN_LEG')
 slopes: list[Fraction] = []
 for i,left in enumerate(ordered[:-1]):
  for right in ordered[i + 1:]:
   delta_ms = right.open_time - left.open_time
   if delta_ms <= 0 or delta_ms % timeframe_ms != 0:
    return InfoValue.error('NONCANONICAL_ELAPSED_INTERVAL_IN_LEG')
   dx = Fraction(delta_ms,timeframe_ms)
   dy = (right.close - left.close) / scale_at_leg_start
   slopes.append(dy / dx)
 return InfoValue.known(median(slopes)) if slopes else InfoValue.na()
def build_structural_leg(start: StructuralPivot,end: StructuralPivot,*,close_path: Sequence[TimedClose]) -> StructuralLeg:
 if start.pivot_type is end.pivot_type:
  raise ValueError('Structural Leg requires adjacent opposite pivots')
 if start.layer is not end.layer:
  raise ValueError('Structural Leg requires same layer')
 if start.symbol != end.symbol or start.timeframe_ms != end.timeframe_ms:
  raise ValueError('Structural Leg requires same symbol/timeframe')
 if start.canonical_segment_id != end.canonical_segment_id:
  raise ValueError('Structural Leg cannot cross a canonical gap')
 if end.confirmed_at <= start.confirmed_at:
  raise ValueError('end pivot must be causally later')
 gross = abs(end.extreme_price - start.extreme_price)
 normalized = gross / start.scale_at_extreme
 if len(close_path) < 2:
  efficiency = InfoValue.na()
 else:
  ordered = sorted(close_path,key=lambda c: c.open_time)
  path = sum((abs(b.close - a.close) for a,b in zip(ordered,ordered[1:])))
  if path == 0:
   efficiency = InfoValue.na()
  else:
   efficiency = InfoValue.known(abs(ordered[-1].close - ordered[0].close) / path)
 slope = _theil_sen_normalized_slope(close_path,timeframe_ms=start.timeframe_ms,scale_at_leg_start=start.scale_at_extreme)
 metrics = LegMetrics(gross_displacement=gross,normalized_displacement=normalized,directional_efficiency=efficiency,robust_normalized_slope=slope)
 leg_id = deterministic_id('structural_leg',start.pivot_id,end.pivot_id,start.canonical_segment_id)
 return StructuralLeg(leg_id=leg_id,symbol=start.symbol,timeframe_ms=start.timeframe_ms,layer=start.layer,start_pivot_id=start.pivot_id,end_pivot_id=end.pivot_id,start_type=start.pivot_type,end_type=end.pivot_type,canonical_segment_id=start.canonical_segment_id,metrics=metrics)
def trend_aligned_edpr(leg: StructuralLeg,direction: TrendDirection) -> InfoValue[Fraction]:
 """B2 EDPR = TrendAlignedRobustSlope × DirectionalEfficiency."""
 slope = leg.metrics.robust_normalized_slope
 efficiency = leg.metrics.directional_efficiency
 if slope.kind.value != 'KNOWN' or efficiency.kind.value != 'KNOWN':
  return InfoValue.na()
 if direction is TrendDirection.LONG:
  aligned = slope.require_known()
 elif direction is TrendDirection.SHORT:
  aligned = -slope.require_known()
 else:
  return InfoValue.na()
 if aligned < 0:
  return InfoValue.error('LEG_NOT_TREND_ALIGNED')
 return InfoValue.known(aligned * efficiency.require_known())
from dataclasses import replace
from fractions import Fraction
from typing import Mapping,Sequence
def initial_trend_state() -> TrendEpisodeState:
 return TrendEpisodeState(direction=TrendDirection.UNKNOWN,episode_id=None,episode_start_cutoff=None,protected_pivot=None,frontier_pivot=None,phase=TrendPhase.UNKNOWN,integrity=None,reversal_candidate_cap=None,defended_pullback_after_pressure=False,prior_same_direction_edpr=InfoValue.na(),completed_trend_aligned_normalized_legs=())
def _by_id(pivots: Sequence[StructuralPivot]) -> dict[str,StructuralPivot]:
 return {p.pivot_id: p for p in pivots}
def _episode_from_establishment(evidence: EstablishmentEvidence,pivots: Sequence[StructuralPivot],*,leg_by_end_pivot: Mapping[str,StructuralLeg]) -> TrendEpisodeState:
 lookup = _by_id(pivots)
 newest = lookup[evidence.newest_pivot_id]
 protected = lookup[evidence.defended_opposite_pivot_id]
 episode_id = deterministic_id('trend_episode',newest.symbol,newest.timeframe_ms,evidence.direction.value,newest.confirmed_at,newest.pivot_id)
 leg = leg_by_end_pivot.get(newest.pivot_id)
 if leg is not None:
  lengths = (leg.metrics.normalized_displacement,)
  baseline = trend_aligned_edpr(leg,evidence.direction)
 else:
  lengths = ()
  baseline = InfoValue.na()
 return TrendEpisodeState(direction=evidence.direction,episode_id=episode_id,episode_start_cutoff=newest.confirmed_at,protected_pivot=protected,frontier_pivot=newest,phase=TrendPhase.EXPANSION,integrity=TrendIntegrity.HEALTHY,reversal_candidate_cap=None,defended_pullback_after_pressure=False,prior_same_direction_edpr=baseline,completed_trend_aligned_normalized_legs=lengths)
def _is_adverse(direction: TrendDirection,pivot: StructuralPivot) -> bool:
 return direction is TrendDirection.LONG and pivot.pivot_type is PivotType.LOW or (direction is TrendDirection.SHORT and pivot.pivot_type is PivotType.HIGH)
def _is_favorable(direction: TrendDirection,pivot: StructuralPivot) -> bool:
 return direction is TrendDirection.LONG and pivot.pivot_type is PivotType.HIGH or (direction is TrendDirection.SHORT and pivot.pivot_type is PivotType.LOW)
def _material_failure(direction: TrendDirection,protected: StructuralPivot,adverse: StructuralPivot,theta_progress: Fraction) -> bool:
 relation = same_type_progress(protected,adverse,theta_progress)
 return direction is TrendDirection.LONG and relation is ProgressRelation.MATERIAL_ADVANCE_DOWN or (direction is TrendDirection.SHORT and relation is ProgressRelation.MATERIAL_ADVANCE_UP)
def _inside_protected_zone(protected: StructuralPivot,adverse: StructuralPivot,theta_progress: Fraction) -> bool:
 return abs(normalized_delta(protected,adverse)) <= theta_progress
def _classify_edpr_phase(prior: InfoValue[Fraction],current: InfoValue[Fraction],theta_rate: Fraction) -> TrendPhase:
 if prior.kind is not InfoKind.KNOWN or current.kind is not InfoKind.KNOWN:
  return TrendPhase.EXPANSION
 delta = current.require_known() - prior.require_known()
 if delta > theta_rate:
  return TrendPhase.ACCELERATION
 if delta < -theta_rate:
  return TrendPhase.DECELERATION
 return TrendPhase.EXPANSION
def _opposite(direction: TrendDirection) -> TrendDirection:
 if direction is TrendDirection.LONG:
  return TrendDirection.SHORT
 if direction is TrendDirection.SHORT:
  return TrendDirection.LONG
 return TrendDirection.NONE
def _recovery_breaks_cap(direction: TrendDirection,cap: StructuralPivot,favorable: StructuralPivot,theta_progress: Fraction) -> bool:
 if cap.pivot_type is not favorable.pivot_type:
  return False
 rel = same_type_progress(cap,favorable,theta_progress)
 return direction is TrendDirection.LONG and rel is ProgressRelation.MATERIAL_ADVANCE_UP or (direction is TrendDirection.SHORT and rel is ProgressRelation.MATERIAL_ADVANCE_DOWN)
def on_new_intermediate_pivot(state: TrendEpisodeState,pivots: Sequence[StructuralPivot],*,theta_progress: Fraction,theta_rate: Fraction,leg_by_end_pivot: Mapping[str,StructuralLeg]) -> TrendEpisodeState:
 """UPDATE-006 event-driven D2 Trend transition on newest confirmed Intermediate pivot only."""
 if not pivots:
  return state
 newest = pivots[-1]
 if newest.layer.value != 'INTERMEDIATE':
  raise ValueError('Trend consumes Intermediate pivots only')
 if newest.confirmed_at != max((p.confirmed_at for p in pivots)):
  raise ValueError('newest pivot must be latest causal Intermediate event')
 evidence = latest_establishment_evidence(pivots,theta_progress=theta_progress)
 if state.direction not in (TrendDirection.LONG,TrendDirection.SHORT) or state.episode_id is None:
  if evidence is not None:
   return _episode_from_establishment(evidence,pivots,leg_by_end_pivot=leg_by_end_pivot)
  if len(pivots) >= 4:
   return replace(state,direction=TrendDirection.NONE,phase=TrendPhase.NO_TREND,integrity=None)
  return replace(state,direction=TrendDirection.UNKNOWN,phase=TrendPhase.UNKNOWN,integrity=None)
 direction = state.direction
 protected = state.protected_pivot
 if protected is None:
  raise ValueError('active Trend Episode requires Protected Intermediate Structure')
 if _is_adverse(direction,newest) and _material_failure(direction,protected,newest,theta_progress):
  terminal = state.episode_id
  if evidence is not None and evidence.direction is _opposite(direction):
   new_state = _episode_from_establishment(evidence,pivots,leg_by_end_pivot=leg_by_end_pivot)
   return replace(new_state,terminal_episode_id=terminal)
  return TrendEpisodeState(direction=TrendDirection.NONE,episode_id=None,episode_start_cutoff=None,protected_pivot=None,frontier_pivot=None,phase=TrendPhase.STRUCTURAL_FAILURE,integrity=TrendIntegrity.FAILED,reversal_candidate_cap=None,defended_pullback_after_pressure=False,prior_same_direction_edpr=InfoValue.na(),completed_trend_aligned_normalized_legs=(),terminal_episode_id=terminal)
 if evidence is not None and evidence.direction is _opposite(direction):
  lookup = _by_id(pivots)
  cap = lookup[evidence.defended_opposite_pivot_id]
  return replace(state,phase=TrendPhase.REVERSAL_CANDIDATE,integrity=TrendIntegrity.DETERIORATING,reversal_candidate_cap=cap,defended_pullback_after_pressure=False)
 if _is_adverse(direction,newest):
  pressured = _inside_protected_zone(protected,newest,theta_progress)
  if state.integrity is TrendIntegrity.PRESSURED:
   return replace(state,defended_pullback_after_pressure=True)
  if state.integrity is TrendIntegrity.DETERIORATING:
   return state
  if pressured:
   return replace(state,integrity=TrendIntegrity.PRESSURED,defended_pullback_after_pressure=False)
  return state
 if _is_favorable(direction,newest):
  prior_frontier = state.frontier_pivot
  state2 = replace(state,frontier_pivot=newest)
  if state.integrity is TrendIntegrity.DETERIORATING and state.reversal_candidate_cap is not None:
   if _recovery_breaks_cap(direction,state.reversal_candidate_cap,newest,theta_progress):
    leg = leg_by_end_pivot.get(newest.pivot_id)
    phase = _classify_edpr_phase(state.prior_same_direction_edpr,trend_aligned_edpr(leg,direction) if leg else InfoValue.na(),theta_rate)
    prior_edpr = trend_aligned_edpr(leg,direction) if leg is not None else state.prior_same_direction_edpr
    lengths = state.completed_trend_aligned_normalized_legs + ((leg.metrics.normalized_displacement,) if leg else ())
    return replace(state2,phase=phase,integrity=TrendIntegrity.PRESSURED,reversal_candidate_cap=None,defended_pullback_after_pressure=False,prior_same_direction_edpr=prior_edpr,completed_trend_aligned_normalized_legs=lengths)
   return state2
  material = False
  if prior_frontier is not None and prior_frontier.pivot_type is newest.pivot_type:
   rel = same_type_progress(prior_frontier,newest,theta_progress)
   material = direction is TrendDirection.LONG and rel is ProgressRelation.MATERIAL_ADVANCE_UP or (direction is TrendDirection.SHORT and rel is ProgressRelation.MATERIAL_ADVANCE_DOWN)
  if not material:
   return state2
  candidate = pivots[-2] if len(pivots) >= 2 and pivots[-2].pivot_type is not newest.pivot_type else None
  protected2 = protected
  if candidate is not None and candidate.pivot_type is protected.pivot_type:
   relp = same_type_progress(protected,candidate,theta_progress)
   if direction is TrendDirection.LONG and relp is ProgressRelation.MATERIAL_ADVANCE_UP:
    protected2 = candidate
   elif direction is TrendDirection.SHORT and relp is ProgressRelation.MATERIAL_ADVANCE_DOWN:
    protected2 = candidate
  leg = leg_by_end_pivot.get(newest.pivot_id)
  phase = _classify_edpr_phase(state.prior_same_direction_edpr,trend_aligned_edpr(leg,direction) if leg else InfoValue.na(),theta_rate)
  new_edpr = trend_aligned_edpr(leg,direction) if leg is not None else state.prior_same_direction_edpr
  lengths = state.completed_trend_aligned_normalized_legs + ((leg.metrics.normalized_displacement,) if leg else ())
  integrity = state.integrity
  defended = state.defended_pullback_after_pressure
  if integrity is TrendIntegrity.PRESSURED and defended:
   integrity = TrendIntegrity.HEALTHY
   defended = False
  return replace(state2,protected_pivot=protected2,phase=phase,integrity=integrity,defended_pullback_after_pressure=defended,prior_same_direction_edpr=new_edpr,completed_trend_aligned_normalized_legs=lengths)
 return state
from fractions import Fraction
from statistics import median
def protected_equivalence_zone(protected: StructuralPivot,theta_progress: Fraction) -> tuple[Fraction,Fraction]:
 half = theta_progress * protected.scale_at_extreme
 return (protected.extreme_price - half,protected.extreme_price + half)
def structural_corridor(*,direction: TrendDirection,protected: StructuralPivot | None,frontier: StructuralPivot | None,current_close: Fraction,theta_progress: Fraction) -> InfoValue[StructuralCorridor]:
 if direction not in (TrendDirection.LONG,TrendDirection.SHORT):
  return InfoValue.na()
 if protected is None or frontier is None:
  return InfoValue.unknown()
 low_zone,high_zone = protected_equivalence_zone(protected,theta_progress)
 if direction is TrendDirection.LONG:
  return InfoValue.known(StructuralCorridor(low_zone,max(current_close,frontier.extreme_price)))
 return InfoValue.known(StructuralCorridor(min(current_close,frontier.extreme_price),high_zone))
def classify_trend_position(*,direction: TrendDirection,current_close: Fraction,frontier: StructuralPivot | None,reset_pivot: StructuralPivot | None,theta_progress: Fraction,theta_overextension: Fraction,completed_trend_aligned_normalized_legs: tuple[Fraction,...]) -> TrendPositionResult:
 if direction not in (TrendDirection.LONG,TrendDirection.SHORT):
  return TrendPositionResult(TrendPosition.NA,InfoValue.na(),InfoValue.na(),InfoValue.na(),InfoValue.na())
 if frontier is None or frontier.scale_at_extreme <= 0:
  return TrendPositionResult(TrendPosition.UNKNOWN,InfoValue.unknown(),InfoValue.unknown(),InfoValue.unknown(),InfoValue.unknown())
 sign = Fraction(1) if direction is TrendDirection.LONG else Fraction(-1)
 x = sign * (current_close - frontier.extreme_price) / frontier.scale_at_extreme
 if abs(x) <= theta_progress:
  base = TrendPosition.BALANCED
 elif x < -theta_progress:
  base = TrendPosition.PULLBACK
 else:
  base = TrendPosition.EXTENDED
 if reset_pivot is None or reset_pivot.scale_at_extreme <= 0:
  return TrendPositionResult(base,InfoValue.known(x),InfoValue.unknown(),InfoValue.unknown(),InfoValue.unknown())
 l_t = sign * (current_close - reset_pivot.extreme_price) / reset_pivot.scale_at_extreme
 positive_legs = tuple((v for v in completed_trend_aligned_normalized_legs if v > 0))
 if not positive_legs:
  return TrendPositionResult(base,InfoValue.known(x),InfoValue.known(l_t),InfoValue.na(),InfoValue.na())
 m_episode = median(positive_legs)
 if m_episode <= 0:
  return TrendPositionResult(base,InfoValue.known(x),InfoValue.known(l_t),InfoValue.error('NONPOSITIVE_EPISODE_MEDIAN'),InfoValue.error('NONPOSITIVE_EPISODE_MEDIAN'))
 ratio = l_t / m_episode
 pos = TrendPosition.OVEREXTENDED if base is TrendPosition.EXTENDED and ratio > theta_overextension else base
 return TrendPositionResult(pos,InfoValue.known(x),InfoValue.known(l_t),InfoValue.known(m_episode),InfoValue.known(ratio))
"""Non-trading WP2 D2 reference skeleton.

Only D2-owned UPDATE-005, UPDATE-006 and UPDATE-009 semantics are represented.
Construction from the current durable partial ParameterSnapshot is expected to
fail because theta_minor/intermediate/major remain OPEN.
"""
from dataclasses import dataclass,field
from fractions import Fraction
from typing import Iterable
@dataclass
class _TimeframeState:
 symbol: str
 timeframe_ms: int
 structural_params: StructuralScaleParameters
 hierarchy: StructuralHierarchyEngine = field(init=False)
 segment_id: str | None = None
 intermediate: list[StructuralPivot] = field(default_factory=list)
 legs_by_end: dict[str,StructuralLeg] = field(default_factory=dict)
 closes: list[TimedClose] = field(default_factory=list)
 trend: TrendEpisodeState = field(default_factory=initial_trend_state)
 def __post_init__(self) -> None:
  self.hierarchy = StructuralHierarchyEngine(symbol=self.symbol,timeframe_ms=self.timeframe_ms,params=self.structural_params)
 def reset_for_segment(self,segment_id: str) -> None:
  self.segment_id = segment_id
  self.hierarchy = StructuralHierarchyEngine(symbol=self.symbol,timeframe_ms=self.timeframe_ms,params=self.structural_params)
  self.intermediate.clear()
  self.legs_by_end.clear()
  self.closes.clear()
  self.trend = initial_trend_state()
@dataclass(frozen=True)
class D2CutoffResult:
 information_cutoff: int
 update_005_minor: tuple[StructuralPivot,...]
 update_005_intermediate: tuple[StructuralPivot,...]
 update_005_major: tuple[StructuralPivot,...]
 update_006_trend: TrendEpisodeState
 update_009_trend_position: object
 update_009_structural_corridor: object
class D2ReferenceSkeleton:
 def __init__(self,*,symbol: str,structural_params: StructuralScaleParameters,frozen_params: FrozenD2Parameters) -> None:
  self.symbol = symbol
  self.structural_params = structural_params
  self.frozen_params = frozen_params
  self._tf: dict[int,_TimeframeState] = {}
 @classmethod
 def from_parameter_snapshot(cls,*,symbol: str,snapshot: ParameterSnapshot) -> 'D2ReferenceSkeleton':
  structural = require_structural_scale_parameters(snapshot)
  frozen = frozen_d2_parameters(snapshot)
  return cls(symbol=symbol,structural_params=structural,frozen_params=frozen)
 def _state(self,timeframe_ms: int) -> _TimeframeState:
  state = self._tf.get(timeframe_ms)
  if state is None:
   state = _TimeframeState(self.symbol,timeframe_ms,self.structural_params)
   self._tf[timeframe_ms] = state
  return state
 @staticmethod
 def _reset_pivot(state: _TimeframeState) -> StructuralPivot | None:
  if state.trend.direction is TrendDirection.LONG:
   lows = [p for p in state.intermediate if p.pivot_type is PivotType.LOW]
   return lows[-1] if lows else state.trend.protected_pivot
  if state.trend.direction is TrendDirection.SHORT:
   highs = [p for p in state.intermediate if p.pivot_type is PivotType.HIGH]
   return highs[-1] if highs else state.trend.protected_pivot
  return None
 def advance_source_bar(self,bar: CanonicalBar,atr14: InfoValue[Fraction],*,canonical_segment_id: str) -> D2CutoffResult:
  """Execute only D2's UPDATE-005 -> UPDATE-006 -> UPDATE-009 slice."""
  state = self._state(self._infer_timeframe(bar))
  if state.segment_id != canonical_segment_id:
   state.reset_for_segment(canonical_segment_id)
  state.closes.append(TimedClose(bar.open_time,bar.close))
  update = state.hierarchy.update_bar(bar,atr14,canonical_segment_id=canonical_segment_id)
  for ip in update.intermediate:
   if state.intermediate:
    prior = state.intermediate[-1]
    if prior.pivot_type is not ip.pivot_type and prior.canonical_segment_id == ip.canonical_segment_id:
     close_path = tuple((c for c in state.closes if prior.extreme_first_time <= c.open_time <= ip.extreme_last_time))
     try:
      state.legs_by_end[ip.pivot_id] = build_structural_leg(prior,ip,close_path=close_path)
     except ValueError:
      pass
   state.intermediate.append(ip)
   state.trend = on_new_intermediate_pivot(state.trend,state.intermediate,theta_progress=self.frozen_params.theta_progress,theta_rate=self.frozen_params.theta_rate,leg_by_end_pivot=state.legs_by_end)
  reset = self._reset_pivot(state)
  tpos = classify_trend_position(direction=state.trend.direction,current_close=bar.close,frontier=state.trend.frontier_pivot,reset_pivot=reset,theta_progress=self.frozen_params.theta_progress,theta_overextension=self.frozen_params.theta_overextension,completed_trend_aligned_normalized_legs=state.trend.completed_trend_aligned_normalized_legs)
  corridor = structural_corridor(direction=state.trend.direction,protected=state.trend.protected_pivot,frontier=state.trend.frontier_pivot,current_close=bar.close,theta_progress=self.frozen_params.theta_progress)
  return D2CutoffResult(information_cutoff=bar.close_time,update_005_minor=update.minor,update_005_intermediate=update.intermediate,update_005_major=update.major,update_006_trend=state.trend,update_009_trend_position=tpos,update_009_structural_corridor=corridor)
 @staticmethod
 def _infer_timeframe(bar: CanonicalBar) -> int:
  span = bar.close_time - bar.open_time
  candidates = (15 * 60 * 1000,60 * 60 * 1000,4 * 60 * 60 * 1000)
  for tf in candidates:
   if span in (tf,tf - 1):
    return tf
  raise ValueError(f'Unsupported D2 source timeframe span={span}')
