"""Source-preserving D1 single-module dependency closure, generated from SHA-pinned original 91 files.

NOT a full TAC strategy; consume only within a Binance AI Pro native D1-D6
assembly. No synthetic pivot logic. All original scientific function bodies
and numeric constants are unchanged; only module-relative imports removed.
"""
from __future__ import annotations
# --- ORIGINAL result_types.py ---
from dataclasses import dataclass
from enum import Enum
from fractions import Fraction
from typing import Any

class Direction(str, Enum):
    UP = 'UP'
    DOWN = 'DOWN'
    UNKNOWN = 'UNKNOWN'

class IntegritySeverity(str, Enum):
    INFO = 'INFO'
    BLOCK = 'BLOCK'

@dataclass(frozen=True)
class IntegrityIssue:
    code: str
    severity: IntegritySeverity
    detail: str
    open_time: int | None = None
Number = Fraction

def number_to_exact_dict(value: Fraction) -> dict[str, int]:
    return {'numerator': value.numerator, 'denominator': value.denominator}

def freeze_payload(value: Any) -> Any:
    """Convert supported objects into deterministic JSON-safe primitives."""
    from dataclasses import asdict, is_dataclass
    if isinstance(value, Fraction):
        return {'__fraction__': [value.numerator, value.denominator]}
    if isinstance(value, Enum):
        return value.value
    if is_dataclass(value):
        return {k: freeze_payload(v) for k, v in asdict(value).items()}
    if isinstance(value, dict):
        return {str(k): freeze_payload(v) for k, v in sorted(value.items(), key=lambda kv: str(kv[0]))}
    if isinstance(value, (list, tuple)):
        return [freeze_payload(v) for v in value]
    if value is None or isinstance(value, (str, int, bool)):
        return value
    raise TypeError(f'Unsupported deterministic payload type: {type(value)!r}')

# --- ORIGINAL ids.py ---
import hashlib
import json
from typing import Any

def canonical_json(value: Any) -> str:
    return json.dumps(freeze_payload(value), sort_keys=True, separators=(',', ':'), ensure_ascii=False)

def deterministic_id(namespace: str, *parts: Any, length: int=32) -> str:
    if not namespace or not isinstance(namespace, str):
        raise ValueError('namespace must be a non-empty string')
    payload = canonical_json({'namespace': namespace, 'parts': list(parts)})
    digest = hashlib.sha256(payload.encode('utf-8')).hexdigest()
    return f'{namespace}:{digest[:length]}'

# --- ORIGINAL runtime_guards/information_state.py ---
from dataclasses import dataclass
from enum import Enum
from typing import Generic, TypeVar
T = TypeVar('T')

class InfoKind(str, Enum):
    KNOWN = 'KNOWN'
    NONE = 'NONE'
    UNKNOWN = 'UNKNOWN'
    NA = 'N/A'
    ERROR = 'ERROR'

@dataclass(frozen=True)
class InfoValue(Generic[T]):
    kind: InfoKind
    value: T | None = None
    error_ref: str | None = None

    def __post_init__(self) -> None:
        if self.kind is InfoKind.KNOWN:
            if self.value is None or self.error_ref is not None:
                raise ValueError('KNOWN requires a value and no error_ref')
        elif self.kind is InfoKind.ERROR:
            if self.error_ref is None or self.value is not None:
                raise ValueError('ERROR requires error_ref and no value')
        elif self.value is not None or self.error_ref is not None:
            raise ValueError(f'{self.kind.value} cannot carry value/error_ref')

    @classmethod
    def known(cls, value: T) -> 'InfoValue[T]':
        return cls(InfoKind.KNOWN, value=value)

    @classmethod
    def none(cls) -> 'InfoValue[T]':
        return cls(InfoKind.NONE)

    @classmethod
    def unknown(cls) -> 'InfoValue[T]':
        return cls(InfoKind.UNKNOWN)

    @classmethod
    def na(cls) -> 'InfoValue[T]':
        return cls(InfoKind.NA)

    @classmethod
    def error(cls, error_ref: str) -> 'InfoValue[T]':
        return cls(InfoKind.ERROR, error_ref=error_ref)

    def require_known(self) -> T:
        if self.kind is not InfoKind.KNOWN:
            raise ValueError(f'Value is {self.kind.value}, not KNOWN')
        return self.value

# --- ORIGINAL runtime_guards/continuity_guard.py ---
class DataIntegrityBlock(RuntimeError):
    """System-level integrity block; never a market Strategy failure."""

class ContinuityReset(RuntimeError):
    """Marker exception for callers that choose exception-based segment handling."""

# --- ORIGINAL d1_data_math/ohlc_protocol.py ---
from fractions import Fraction
from typing import Protocol

class OHLCBar(Protocol):
    open_time: int
    close_time: int
    open: Fraction
    high: Fraction
    low: Fraction
    close: Fraction

# --- ORIGINAL d1_data_math/canonical.py ---
from dataclasses import dataclass
from decimal import Decimal
from fractions import Fraction
from typing import Iterable
TF_15M_MS = 15 * 60 * 1000

def parse_exact_number(value: str | int | Decimal | Fraction) -> Fraction:
    if isinstance(value, Fraction):
        return value
    if isinstance(value, bool):
        raise TypeError('bool is not a valid market number')
    if isinstance(value, int):
        return Fraction(value, 1)
    if isinstance(value, Decimal):
        return Fraction(value)
    if isinstance(value, str):
        return Fraction(Decimal(value))
    if isinstance(value, float):
        raise TypeError('float market inputs are forbidden; provide exact decimal string/int/Decimal/Fraction')
    raise TypeError(f'Unsupported market number type: {type(value)!r}')

@dataclass(frozen=True)
class CanonicalBar:
    symbol: str
    open_time: int
    close_time: int
    open: Fraction
    high: Fraction
    low: Fraction
    close: Fraction
    base_volume: Fraction | None = None
    quote_volume: Fraction | None = None
    is_closed: bool = True

    @classmethod
    def from_values(cls, *, symbol: str, open_time: int, close_time: int, open: str | int | Decimal | Fraction, high: str | int | Decimal | Fraction, low: str | int | Decimal | Fraction, close: str | int | Decimal | Fraction, base_volume: str | int | Decimal | Fraction | None=None, quote_volume: str | int | Decimal | Fraction | None=None, is_closed: bool=True) -> 'CanonicalBar':
        return cls(symbol=symbol, open_time=open_time, close_time=close_time, open=parse_exact_number(open), high=parse_exact_number(high), low=parse_exact_number(low), close=parse_exact_number(close), base_volume=None if base_volume is None else parse_exact_number(base_volume), quote_volume=None if quote_volume is None else parse_exact_number(quote_volume), is_closed=is_closed)

@dataclass(frozen=True)
class CanonicalRecord:
    bar: CanonicalBar
    canonical_segment_id: str

@dataclass(frozen=True)
class CanonicalizationResult:
    records: tuple[CanonicalRecord, ...]
    issues: tuple[IntegrityIssue, ...]
    identical_duplicates_deduplicated: int

    @property
    def information_cutoff(self) -> int | None:
        return self.records[-1].bar.close_time if self.records else None

def _validate_bar(bar: CanonicalBar) -> None:
    if not bar.symbol:
        raise DataIntegrityBlock('EMPTY_SYMBOL')
    if not bar.is_closed:
        raise DataIntegrityBlock(f'OPEN_BAR_FORBIDDEN open_time={bar.open_time}')
    if bar.open_time % TF_15M_MS != 0:
        raise DataIntegrityBlock(f'OPEN_TIME_NOT_15M_ALIGNED open_time={bar.open_time}')
    if bar.close_time <= bar.open_time:
        raise DataIntegrityBlock(f'IMPOSSIBLE_CLOSE_TIME open_time={bar.open_time} close_time={bar.close_time}')
    if bar.high < max(bar.open, bar.close, bar.low):
        raise DataIntegrityBlock(f'INVALID_HIGH open_time={bar.open_time}')
    if bar.low > min(bar.open, bar.close, bar.high):
        raise DataIntegrityBlock(f'INVALID_LOW open_time={bar.open_time}')
    if bar.base_volume is not None and bar.base_volume < 0:
        raise DataIntegrityBlock(f'NEGATIVE_BASE_VOLUME open_time={bar.open_time}')
    if bar.quote_volume is not None and bar.quote_volume < 0:
        raise DataIntegrityBlock(f'NEGATIVE_QUOTE_VOLUME open_time={bar.open_time}')

def canonicalize_15m(bars: Iterable[CanonicalBar]) -> CanonicalizationResult:
    ordered = sorted(bars, key=lambda b: (b.open_time, b.close_time))
    if not ordered:
        return CanonicalizationResult((), (), 0)
    by_open: dict[int, CanonicalBar] = {}
    dedup = 0
    for bar in ordered:
        _validate_bar(bar)
        prior = by_open.get(bar.open_time)
        if prior is None:
            by_open[bar.open_time] = bar
        elif prior == bar:
            dedup += 1
        else:
            raise DataIntegrityBlock(f'CONFLICTING_DUPLICATE open_time={bar.open_time}')
    unique = [by_open[k] for k in sorted(by_open)]
    symbols = {b.symbol for b in unique}
    if len(symbols) != 1:
        raise DataIntegrityBlock('MIXED_SYMBOL_INPUT')
    symbol = unique[0].symbol
    records: list[CanonicalRecord] = []
    issues: list[IntegrityIssue] = []
    segment_id: str | None = None
    prev_open: int | None = None
    for bar in unique:
        if prev_open is None or bar.open_time - prev_open != TF_15M_MS:
            if prev_open is not None:
                delta = bar.open_time - prev_open
                if delta <= 0:
                    raise DataIntegrityBlock('NON_MONOTONIC_OPEN_TIME')
                issues.append(IntegrityIssue(code='DATA_GAP_NEW_CANONICAL_SEGMENT', severity=IntegritySeverity.BLOCK, detail=f'gap_ms={delta - TF_15M_MS}; no forward fill; recursive state must reset', open_time=bar.open_time))
            segment_id = deterministic_id('canonical_segment', symbol, bar.open_time)
        records.append(CanonicalRecord(bar=bar, canonical_segment_id=segment_id))
        prev_open = bar.open_time
    return CanonicalizationResult(tuple(records), tuple(issues), dedup)

# --- ORIGINAL d1_data_math/ema.py ---
from fractions import Fraction

class EMARecurrence:

    def __init__(self, period: int) -> None:
        if period <= 0:
            raise ValueError('EMA period must be positive')
        self.period = period
        self._segment_id: str | None = None
        self._seed: list[Fraction] = []
        self._ema: Fraction | None = None
        self._alpha = Fraction(2, period + 1)

    def reset(self) -> None:
        self._seed.clear()
        self._ema = None

    def update(self, close: Fraction, *, segment_id: str) -> InfoValue[Fraction]:
        if self._segment_id != segment_id:
            self._segment_id = segment_id
            self.reset()
        if self._ema is None:
            self._seed.append(close)
            if len(self._seed) < self.period:
                return InfoValue.na()
            if len(self._seed) == self.period:
                self._ema = sum(self._seed, Fraction(0, 1)) / self.period
                return InfoValue.known(self._ema)
            raise AssertionError('EMA seed length invariant broken')
        self._ema = self._alpha * close + (1 - self._alpha) * self._ema
        return InfoValue.known(self._ema)

# --- ORIGINAL d1_data_math/atr.py ---
from fractions import Fraction

class ATR14Recurrence:
    period = 14

    def __init__(self) -> None:
        self._segment_id: str | None = None
        self._prev_close: Fraction | None = None
        self._trs: list[Fraction] = []
        self._atr: Fraction | None = None

    def reset(self) -> None:
        self._prev_close = None
        self._trs.clear()
        self._atr = None

    def update(self, bar: OHLCBar, *, segment_id: str) -> InfoValue[Fraction]:
        if self._segment_id != segment_id:
            self._segment_id = segment_id
            self.reset()
        if self._prev_close is None:
            tr = bar.high - bar.low
        else:
            tr = max(bar.high - bar.low, abs(bar.high - self._prev_close), abs(bar.low - self._prev_close))
        self._prev_close = bar.close
        if self._atr is None:
            self._trs.append(tr)
            if len(self._trs) < self.period:
                return InfoValue.na()
            if len(self._trs) == self.period:
                self._atr = sum(self._trs, Fraction(0, 1)) / self.period
                return InfoValue.known(self._atr)
            raise AssertionError('ATR seed length invariant broken')
        self._atr = (self._atr * (self.period - 1) + tr) / self.period
        return InfoValue.known(self._atr)

# --- ORIGINAL d1_data_math/supertrend.py ---
from dataclasses import dataclass
from fractions import Fraction
ST_MULTIPLIER = Fraction(3, 1)

@dataclass(frozen=True)
class SupertrendPoint:
    final_upper: InfoValue[Fraction]
    final_lower: InfoValue[Fraction]
    direction: Direction
    active_line: InfoValue[Fraction]

class SupertrendRecurrence:
    """RC1 + adopted post-RC1 exact final-band recurrence binding."""

    def __init__(self) -> None:
        self._segment_id: str | None = None
        self._prev_close: Fraction | None = None
        self._final_upper: Fraction | None = None
        self._final_lower: Fraction | None = None
        self._direction = Direction.UNKNOWN

    def reset(self) -> None:
        self._prev_close = None
        self._final_upper = None
        self._final_lower = None
        self._direction = Direction.UNKNOWN

    def update(self, bar: OHLCBar, atr14: InfoValue[Fraction], *, segment_id: str) -> SupertrendPoint:
        if self._segment_id != segment_id:
            self._segment_id = segment_id
            self.reset()
        if atr14.kind is not InfoKind.KNOWN:
            self._prev_close = bar.close
            return SupertrendPoint(final_upper=InfoValue.na(), final_lower=InfoValue.na(), direction=Direction.UNKNOWN, active_line=InfoValue.na())
        atr = atr14.require_known()
        hl2 = (bar.high + bar.low) / 2
        basic_upper = hl2 + ST_MULTIPLIER * atr
        basic_lower = hl2 - ST_MULTIPLIER * atr
        if self._final_upper is None or self._final_lower is None or self._prev_close is None:
            self._final_upper = basic_upper
            self._final_lower = basic_lower
            self._direction = Direction.UNKNOWN
            self._prev_close = bar.close
            return SupertrendPoint(final_upper=InfoValue.known(self._final_upper), final_lower=InfoValue.known(self._final_lower), direction=self._direction, active_line=InfoValue.na())
        prior_upper = self._final_upper
        prior_lower = self._final_lower
        prior_close = self._prev_close
        final_lower = basic_lower if basic_lower > prior_lower or prior_close < prior_lower else prior_lower
        final_upper = basic_upper if basic_upper < prior_upper or prior_close > prior_upper else prior_upper
        if bar.close > prior_upper:
            direction = Direction.UP
        elif bar.close < prior_lower:
            direction = Direction.DOWN
        else:
            direction = self._direction
        self._final_upper = final_upper
        self._final_lower = final_lower
        self._direction = direction
        self._prev_close = bar.close
        if direction is Direction.UP:
            active = InfoValue.known(final_lower)
        elif direction is Direction.DOWN:
            active = InfoValue.known(final_upper)
        else:
            active = InfoValue.na()
        return SupertrendPoint(final_upper=InfoValue.known(final_upper), final_lower=InfoValue.known(final_lower), direction=direction, active_line=active)

# --- ORIGINAL d1_data_math/htf_aggregation.py ---
from collections import defaultdict
from dataclasses import dataclass
from fractions import Fraction
from typing import Iterable

@dataclass(frozen=True)
class HTFBar:
    symbol: str
    timeframe_ms: int
    open_time: int
    close_time: int
    open: Fraction
    high: Fraction
    low: Fraction
    close: Fraction
    base_volume: Fraction | None
    quote_volume: Fraction | None
    source_segment_id: str

def _sum_optional(values: list[Fraction | None]) -> Fraction | None:
    if any((v is None for v in values)):
        return None
    return sum((v for v in values if v is not None), Fraction(0, 1))

def aggregate_completed_htf(records: Iterable[CanonicalRecord], *, timeframe_ms: int, information_cutoff: int) -> tuple[HTFBar, ...]:
    if timeframe_ms not in (60 * 60 * 1000, 4 * 60 * 60 * 1000):
        raise ValueError('Only causal 1H and 4H aggregation is authorized in WP1')
    required = timeframe_ms // TF_15M_MS
    buckets: dict[tuple[str, int], list[CanonicalRecord]] = defaultdict(list)
    for rec in records:
        bucket_start = rec.bar.open_time // timeframe_ms * timeframe_ms
        buckets[rec.canonical_segment_id, bucket_start].append(rec)
    out: list[HTFBar] = []
    for (segment_id, bucket_start), members in sorted(buckets.items(), key=lambda kv: kv[0][1]):
        members.sort(key=lambda r: r.bar.open_time)
        expected_opens = [bucket_start + i * TF_15M_MS for i in range(required)]
        actual_opens = [r.bar.open_time for r in members]
        if actual_opens != expected_opens:
            continue
        if len({r.canonical_segment_id for r in members}) != 1:
            continue
        close_time = members[-1].bar.close_time
        if close_time > information_cutoff:
            continue
        first, last = (members[0].bar, members[-1].bar)
        out.append(HTFBar(symbol=first.symbol, timeframe_ms=timeframe_ms, open_time=bucket_start, close_time=close_time, open=first.open, high=max((r.bar.high for r in members)), low=min((r.bar.low for r in members)), close=last.close, base_volume=_sum_optional([r.bar.base_volume for r in members]), quote_volume=_sum_optional([r.bar.quote_volume for r in members]), source_segment_id=segment_id))
    return tuple(out)

# --- ORIGINAL parameter_snapshot.py ---
from dataclasses import dataclass
from enum import Enum
from types import MappingProxyType
from typing import Mapping

class ParameterState(str, Enum):
    FROZEN = 'FROZEN'
    OPEN = 'OPEN'
    LOCKED = 'LOCKED'

@dataclass(frozen=True)
class ParameterSlot:
    name: str
    state: ParameterState
    exact_value: str | None = None

    def __post_init__(self) -> None:
        if self.state is ParameterState.FROZEN and self.exact_value is None:
            raise ValueError(f'Frozen parameter {self.name} requires exact_value')
        if self.state is not ParameterState.FROZEN and self.exact_value is not None:
            raise ValueError(f'Unfrozen parameter {self.name} must not contain a value')

@dataclass(frozen=True)
class ParameterSnapshot:
    snapshot_id: str
    slots: Mapping[str, ParameterSlot]
    complete_strategy_parameter_snapshot: bool
    runtime_usable: bool
    source_status: str

    def __post_init__(self) -> None:
        object.__setattr__(self, 'slots', MappingProxyType(dict(self.slots)))

    def slot(self, name: str) -> ParameterSlot:
        try:
            return self.slots[name]
        except KeyError as exc:
            raise KeyError(f'Parameter slot not declared: {name}') from exc

    @property
    def frozen_count(self) -> int:
        return sum((s.state is ParameterState.FROZEN for s in self.slots.values()))
PARTIAL_PARAMETER_SNAPSHOT_ID = 'R1_PARTIAL_RESEARCH_SNAPSHOT_PROGRESS_RATE_B3_ACCEPT_OVER_995E24FBAA216C62'
PARTIAL_PARAMETER_SNAPSHOT_DETERMINISTIC_SHA256 = 'a869a3a7758c0a4ff34ddfb5ae1c4e012e0600bbea6492cf12efa19a148ef5bb'
_FROZEN = {'theta_accept': '2.1313767840459202205981702405574439224871803906649207193085500', 'theta_approach': '1.197268280893772873697806561124554291191704011769349520546870', 'theta_overextension': '2.7703041968078565478295719882475244376661292176373236367284700', 'theta_progress': '1.27112707163488491529631027277968495738450', 'theta_rate': '0.17560145225927980894381212168524856466229325734699705827303000', 'theta_separation': '2.24912097135367169114306428916723600671864369102654007565280', 'theta_test': '0.5913466407600057877252533034649404155944065891655909831651470'}

def current_partial_parameter_snapshot() -> ParameterSnapshot:
    """Bind the durable partial snapshot, overlaid by newer current governance.

    The source V5 snapshot recorded theta_stop as OPEN at that historical point.
    Current v12 governance supersedes only its current-state display and locks
    theta_stop. No numerical value is created for the locked slot.
    """
    slots: dict[str, ParameterSlot] = {name: ParameterSlot(name=name, state=ParameterState.FROZEN, exact_value=value) for name, value in _FROZEN.items()}
    slots.update({'theta_minor': ParameterSlot('theta_minor', ParameterState.OPEN), 'theta_intermediate': ParameterSlot('theta_intermediate', ParameterState.OPEN), 'theta_major': ParameterSlot('theta_major', ParameterState.OPEN), 'theta_stop': ParameterSlot('theta_stop', ParameterState.LOCKED)})
    return ParameterSnapshot(snapshot_id=PARTIAL_PARAMETER_SNAPSHOT_ID, slots=slots, complete_strategy_parameter_snapshot=False, runtime_usable=False, source_status='PARTIAL_RESEARCH_FREEZE_NOT_STRATEGY_USABLE_WITH_CURRENT_V12_THETA_STOP_LOCK_OVERLAY')

# --- ORIGINAL d2_market_state/parameters.py ---
from dataclasses import dataclass
from decimal import Decimal
from fractions import Fraction

class StructuralParameterResolutionBlock(RuntimeError):
    pass

def _exact_fraction(value: str) -> Fraction:
    return Fraction(Decimal(value))

@dataclass(frozen=True)
class StructuralScaleParameters:
    theta_minor: Fraction
    theta_intermediate: Fraction
    theta_major: Fraction

    def __post_init__(self) -> None:
        if not 0 < self.theta_minor < self.theta_intermediate < self.theta_major:
            raise ValueError('RC1 requires 0 < theta_minor < theta_intermediate < theta_major')

@dataclass(frozen=True)
class FrozenD2Parameters:
    theta_progress: Fraction
    theta_rate: Fraction
    theta_overextension: Fraction

    def __post_init__(self) -> None:
        if self.theta_progress < 0:
            raise ValueError('theta_progress must be >= 0')
        if self.theta_rate < 0:
            raise ValueError('theta_rate must be >= 0')
        if self.theta_overextension <= 1:
            raise ValueError('theta_overextension must be > 1')

def require_structural_scale_parameters(snapshot: ParameterSnapshot) -> StructuralScaleParameters:
    names = ('theta_minor', 'theta_intermediate', 'theta_major')
    slots = [snapshot.slot(name) for name in names]
    unresolved = [slot.name for slot in slots if slot.state is not ParameterState.FROZEN]
    if unresolved:
        raise StructuralParameterResolutionBlock('WP2_STRUCTURAL_SCALE_PARAMETERS_UNRESOLVED: ' + ','.join(unresolved))
    return StructuralScaleParameters(*(_exact_fraction(slot.exact_value or '') for slot in slots))

def frozen_d2_parameters(snapshot: ParameterSnapshot) -> FrozenD2Parameters:
    values: list[Fraction] = []
    for name in ('theta_progress', 'theta_rate', 'theta_overextension'):
        slot = snapshot.slot(name)
        if slot.state is not ParameterState.FROZEN or slot.exact_value is None:
            raise StructuralParameterResolutionBlock(f'D2_FROZEN_PARAMETER_MISSING: {name}')
        values.append(_exact_fraction(slot.exact_value))
    return FrozenD2Parameters(*values)

# --- ORIGINAL d2_market_state/types.py ---
from dataclasses import dataclass
from enum import Enum
from fractions import Fraction
from typing import Mapping

class StructuralLayer(str, Enum):
    MINOR = 'MINOR'
    INTERMEDIATE = 'INTERMEDIATE'
    MAJOR = 'MAJOR'

class PivotType(str, Enum):
    HIGH = 'HIGH'
    LOW = 'LOW'

class SearchMode(str, Enum):
    UNKNOWN = 'UNKNOWN'
    NEUTRAL = 'NEUTRAL'
    SEEK_HIGH = 'SEEK_HIGH'
    SEEK_LOW = 'SEEK_LOW'

class ProgressRelation(str, Enum):
    MATERIAL_ADVANCE_UP = 'MATERIAL_ADVANCE_UP'
    MATERIAL_ADVANCE_DOWN = 'MATERIAL_ADVANCE_DOWN'
    STRUCTURALLY_EQUIVALENT = 'STRUCTURALLY_EQUIVALENT'

class TrendDirection(str, Enum):
    LONG = 'LONG'
    SHORT = 'SHORT'
    NONE = 'NONE'
    UNKNOWN = 'UNKNOWN'

class TrendIntegrity(str, Enum):
    HEALTHY = 'HEALTHY'
    PRESSURED = 'PRESSURED'
    DETERIORATING = 'DETERIORATING'
    FAILED = 'FAILED'

class TrendPhase(str, Enum):
    UNKNOWN = 'UNKNOWN'
    NO_TREND = 'NO_TREND'
    EXPANSION = 'EXPANSION'
    ACCELERATION = 'ACCELERATION'
    DECELERATION = 'DECELERATION'
    PLATFORM_CANDIDATE = 'PLATFORM_CANDIDATE'
    PLATFORM_CONFIRMED = 'PLATFORM_CONFIRMED'
    REVERSAL_CANDIDATE = 'REVERSAL_CANDIDATE'
    STRUCTURAL_FAILURE = 'STRUCTURAL_FAILURE'

class TrendPosition(str, Enum):
    BALANCED = 'BALANCED'
    PULLBACK = 'PULLBACK'
    EXTENDED = 'EXTENDED'
    OVEREXTENDED = 'OVEREXTENDED'
    UNKNOWN = 'UNKNOWN'
    NA = 'N/A'

class PlatformStatus(str, Enum):
    NONE = 'NONE'
    PLATFORM_CANDIDATE = 'PLATFORM_CANDIDATE'
    PLATFORM_CONFIRMED = 'PLATFORM_CONFIRMED'

@dataclass(frozen=True)
class StructuralPivot:
    pivot_id: str
    symbol: str
    timeframe_ms: int
    layer: StructuralLayer
    pivot_type: PivotType
    extreme_price: Fraction
    extreme_first_time: int
    extreme_last_time: int
    confirmed_at: int
    scale_at_extreme: Fraction
    canonical_segment_id: str
    source_pivot_ids: tuple[str, ...]
    provenance: Mapping[str, str]

    def __post_init__(self) -> None:
        if self.extreme_last_time < self.extreme_first_time:
            raise ValueError('extreme_last_time precedes extreme_first_time')
        if self.confirmed_at < self.extreme_last_time:
            raise ValueError('confirmed_at precedes extreme_last_time')
        if self.scale_at_extreme <= 0:
            raise ValueError('scale_at_extreme must be positive')
        if not self.canonical_segment_id:
            raise ValueError('canonical_segment_id is required')

@dataclass(frozen=True)
class LegMetrics:
    gross_displacement: Fraction
    normalized_displacement: Fraction
    directional_efficiency: InfoValue[Fraction]
    robust_normalized_slope: InfoValue[Fraction]

@dataclass(frozen=True)
class StructuralLeg:
    leg_id: str
    symbol: str
    timeframe_ms: int
    layer: StructuralLayer
    start_pivot_id: str
    end_pivot_id: str
    start_type: PivotType
    end_type: PivotType
    canonical_segment_id: str
    metrics: LegMetrics

@dataclass(frozen=True)
class EstablishmentEvidence:
    direction: TrendDirection
    newest_pivot_id: str
    sequence_pivot_ids: tuple[str, str, str, str]
    defended_opposite_pivot_id: str
    opposing_structural_cap_pivot_id: str

@dataclass(frozen=True)
class TrendEpisodeState:
    direction: TrendDirection
    episode_id: str | None
    episode_start_cutoff: int | None
    protected_pivot: StructuralPivot | None
    frontier_pivot: StructuralPivot | None
    phase: TrendPhase
    integrity: TrendIntegrity | None
    reversal_candidate_cap: StructuralPivot | None
    defended_pullback_after_pressure: bool
    prior_same_direction_edpr: InfoValue[Fraction]
    completed_trend_aligned_normalized_legs: tuple[Fraction, ...]
    terminal_episode_id: str | None = None

@dataclass(frozen=True)
class TrendPositionResult:
    position: TrendPosition
    x: InfoValue[Fraction]
    episode_excursion: InfoValue[Fraction]
    episode_median_leg_length: InfoValue[Fraction]
    overextension_ratio: InfoValue[Fraction]

@dataclass(frozen=True)
class StructuralCorridor:
    lower: Fraction
    upper: Fraction

@dataclass(frozen=True)
class FailedReexpansionEvent:
    event_id: str
    symbol: str
    timeframe_ms: int
    direction: TrendDirection
    confirmation_cutoff: int
    trend_side_minor_extreme_price: Fraction
    trend_side_minor_extreme_first_time: int
    trend_side_minor_extreme_last_time: int
    protected_structure_intact: bool
    independent_from_prior: bool
    rearmed_from_prior: bool

@dataclass(frozen=True)
class PlatformState:
    status: PlatformStatus
    contributing_event_ids: tuple[str, ...]
    trend_side_extremes: tuple[Fraction, ...]
    platform_cap_price: Fraction | None
    platform_scale: Fraction | None
    confirmed_at: int | None
    cap_first_time: int | None
    cap_last_time: int | None

# --- ORIGINAL d2_market_state/progress.py ---
from fractions import Fraction

def same_type_progress(p0: StructuralPivot, p1: StructuralPivot, theta_progress: Fraction) -> ProgressRelation:
    if p0.pivot_type is not p1.pivot_type:
        raise ValueError('same_type_progress requires same pivot type')
    if p0.layer is not p1.layer:
        raise ValueError('same_type_progress requires same structural layer')
    if p0.symbol != p1.symbol or p0.timeframe_ms != p1.timeframe_ms:
        raise ValueError('same_type_progress requires same symbol/timeframe')
    if p0.canonical_segment_id != p1.canonical_segment_id:
        raise ValueError('cross-gap progress comparison is forbidden')
    if p1.confirmed_at <= p0.confirmed_at:
        raise ValueError('p1 must be causally later than p0')
    if p0.scale_at_extreme <= 0:
        raise ValueError('p0 scale_at_extreme must be positive')
    delta_n = (p1.extreme_price - p0.extreme_price) / p0.scale_at_extreme
    if delta_n > theta_progress:
        return ProgressRelation.MATERIAL_ADVANCE_UP
    if delta_n < -theta_progress:
        return ProgressRelation.MATERIAL_ADVANCE_DOWN
    return ProgressRelation.STRUCTURALLY_EQUIVALENT

def normalized_delta(p0: StructuralPivot, p1: StructuralPivot) -> Fraction:
    if p0.scale_at_extreme <= 0:
        raise ValueError('p0 scale_at_extreme must be positive')
    return (p1.extreme_price - p0.extreme_price) / p0.scale_at_extreme

# --- ORIGINAL d2_market_state/establishment.py ---
from fractions import Fraction
from typing import Sequence

def latest_establishment_evidence(pivots: Sequence[StructuralPivot], *, theta_progress: Fraction) -> EstablishmentEvidence | None:
    """Evaluate only the latest complete alternating 4-pivot sequence ending at newest pivot."""
    if len(pivots) < 4:
        return None
    seq = tuple(pivots[-4:])
    if any((p.layer.value != 'INTERMEDIATE' for p in seq)):
        raise ValueError('Trend establishment consumes Intermediate pivots only')
    if len({p.canonical_segment_id for p in seq}) != 1:
        return None
    if not all((a.confirmed_at < b.confirmed_at for a, b in zip(seq, seq[1:]))):
        raise ValueError('Intermediate pivot stream must be causally ordered')
    types = tuple((p.pivot_type for p in seq))
    if types == (PivotType.LOW, PivotType.HIGH, PivotType.LOW, PivotType.HIGH):
        l0, h0, l1, h1 = seq
        high_progress = same_type_progress(h0, h1, theta_progress)
        low_progress = same_type_progress(l0, l1, theta_progress)
        if high_progress is ProgressRelation.MATERIAL_ADVANCE_UP and low_progress is not ProgressRelation.MATERIAL_ADVANCE_DOWN:
            return EstablishmentEvidence(direction=TrendDirection.LONG, newest_pivot_id=h1.pivot_id, sequence_pivot_ids=tuple((p.pivot_id for p in seq)), defended_opposite_pivot_id=l1.pivot_id, opposing_structural_cap_pivot_id=l1.pivot_id)
    if types == (PivotType.HIGH, PivotType.LOW, PivotType.HIGH, PivotType.LOW):
        h0, l0, h1, l1 = seq
        low_progress = same_type_progress(l0, l1, theta_progress)
        high_progress = same_type_progress(h0, h1, theta_progress)
        if low_progress is ProgressRelation.MATERIAL_ADVANCE_DOWN and high_progress is not ProgressRelation.MATERIAL_ADVANCE_UP:
            return EstablishmentEvidence(direction=TrendDirection.SHORT, newest_pivot_id=l1.pivot_id, sequence_pivot_ids=tuple((p.pivot_id for p in seq)), defended_opposite_pivot_id=h1.pivot_id, opposing_structural_cap_pivot_id=h1.pivot_id)
    return None

# --- ORIGINAL d2_market_state/pivots.py ---
from dataclasses import dataclass
from fractions import Fraction

@dataclass
class _MinorCandidate:
    pivot_type: PivotType
    price: Fraction
    first_time: int
    last_time: int
    scale: Fraction

class MinorDirectionalChangeEngine:
    """RC1 Minor directional-change state machine.

    Only canonical OHLC is consumed. A confirmation close may confirm a prior
    candidate, but the same confirmation bar's opposite wick is deliberately
    not reused as the next candidate because intrabar ordering is unknowable.
    """

    def __init__(self, *, symbol: str, timeframe_ms: int, theta_minor: Fraction) -> None:
        if theta_minor <= 0:
            raise ValueError('theta_minor must be positive')
        self.symbol = symbol
        self.timeframe_ms = timeframe_ms
        self.theta = theta_minor
        self.segment_id: str | None = None
        self.mode = SearchMode.UNKNOWN
        self.seed_close: Fraction | None = None
        self.seed_scale: Fraction | None = None
        self.candidate: _MinorCandidate | None = None
        self._sequence = 0

    def _reset(self, segment_id: str) -> None:
        self.segment_id = segment_id
        self.mode = SearchMode.UNKNOWN
        self.seed_close = None
        self.seed_scale = None
        self.candidate = None

    def _pivot(self, c: _MinorCandidate, *, confirmed_at: int, confirming_open_time: int) -> StructuralPivot:
        self._sequence += 1
        pid = deterministic_id('pivot', self.symbol, self.timeframe_ms, StructuralLayer.MINOR.value, c.pivot_type.value, c.price, c.first_time, c.last_time, confirmed_at, self.segment_id, self._sequence)
        return StructuralPivot(pivot_id=pid, symbol=self.symbol, timeframe_ms=self.timeframe_ms, layer=StructuralLayer.MINOR, pivot_type=c.pivot_type, extreme_price=c.price, extreme_first_time=c.first_time, extreme_last_time=c.last_time, confirmed_at=confirmed_at, scale_at_extreme=c.scale, canonical_segment_id=self.segment_id or '', source_pivot_ids=(), provenance={'rule': 'MS-003..MS-008', 'confirming_bar_open_time': str(confirming_open_time), 'ohlc_ordering': 'confirmation_close_may_confirm_prior_candidate; opposite_wick_not_reused_same_bar'})

    def update(self, bar: CanonicalBar, atr14: InfoValue[Fraction], *, canonical_segment_id: str) -> tuple[StructuralPivot, ...]:
        if bar.symbol != self.symbol:
            raise ValueError('symbol mismatch')
        if self.segment_id != canonical_segment_id:
            self._reset(canonical_segment_id)
        if atr14.kind is not InfoKind.KNOWN:
            return ()
        scale = atr14.require_known()
        if scale <= 0:
            return ()
        if self.mode is SearchMode.UNKNOWN:
            self.seed_close = bar.close
            self.seed_scale = scale
            self.mode = SearchMode.NEUTRAL
            return ()
        if self.mode is SearchMode.NEUTRAL:
            assert self.seed_close is not None and self.seed_scale is not None
            threshold = self.theta * self.seed_scale
            up = bar.close - self.seed_close
            down = self.seed_close - bar.close
            if up >= threshold:
                self.mode = SearchMode.SEEK_HIGH
                self.candidate = _MinorCandidate(PivotType.HIGH, bar.high, bar.open_time, bar.open_time, scale)
            elif down >= threshold:
                self.mode = SearchMode.SEEK_LOW
                self.candidate = _MinorCandidate(PivotType.LOW, bar.low, bar.open_time, bar.open_time, scale)
            return ()
        if self.candidate is None:
            if self.mode is SearchMode.SEEK_HIGH:
                self.candidate = _MinorCandidate(PivotType.HIGH, bar.high, bar.open_time, bar.open_time, scale)
                return ()
            if self.mode is SearchMode.SEEK_LOW:
                self.candidate = _MinorCandidate(PivotType.LOW, bar.low, bar.open_time, bar.open_time, scale)
                return ()
            raise AssertionError(f'unexpected mode {self.mode}')
        prior = self.candidate
        if self.mode is SearchMode.SEEK_HIGH:
            if bar.high > prior.price:
                self.candidate = _MinorCandidate(PivotType.HIGH, bar.high, bar.open_time, bar.open_time, scale)
                return ()
            if bar.high == prior.price:
                self.candidate = _MinorCandidate(PivotType.HIGH, prior.price, prior.first_time, bar.open_time, prior.scale)
                return ()
            if bar.open_time > prior.last_time and prior.price - bar.close >= self.theta * prior.scale:
                pivot = self._pivot(prior, confirmed_at=bar.close_time, confirming_open_time=bar.open_time)
                self.mode = SearchMode.SEEK_LOW
                self.candidate = None
                return (pivot,)
            return ()
        if self.mode is SearchMode.SEEK_LOW:
            if bar.low < prior.price:
                self.candidate = _MinorCandidate(PivotType.LOW, bar.low, bar.open_time, bar.open_time, scale)
                return ()
            if bar.low == prior.price:
                self.candidate = _MinorCandidate(PivotType.LOW, prior.price, prior.first_time, bar.open_time, prior.scale)
                return ()
            if bar.open_time > prior.last_time and bar.close - prior.price >= self.theta * prior.scale:
                pivot = self._pivot(prior, confirmed_at=bar.close_time, confirming_open_time=bar.open_time)
                self.mode = SearchMode.SEEK_HIGH
                self.candidate = None
                return (pivot,)
            return ()
        raise AssertionError(f'unexpected mode {self.mode}')

@dataclass
class _HierarchyCandidate:
    source: StructuralPivot

class PivotStreamDirectionalChangeEngine:
    """Generic higher-layer directional change over confirmed lower-layer pivots."""

    def __init__(self, *, output_layer: StructuralLayer, theta: Fraction) -> None:
        if output_layer is StructuralLayer.MINOR:
            raise ValueError('Use MinorDirectionalChangeEngine for MINOR')
        if theta <= 0:
            raise ValueError('theta must be positive')
        self.output_layer = output_layer
        self.theta = theta
        self.segment_id: str | None = None
        self.mode = SearchMode.UNKNOWN
        self.seed: StructuralPivot | None = None
        self.candidate: _HierarchyCandidate | None = None
        self._sequence = 0

    @staticmethod
    def _expected_input_layer(output_layer: StructuralLayer) -> StructuralLayer:
        return StructuralLayer.MINOR if output_layer is StructuralLayer.INTERMEDIATE else StructuralLayer.INTERMEDIATE

    def _reset(self, segment_id: str) -> None:
        self.segment_id = segment_id
        self.mode = SearchMode.UNKNOWN
        self.seed = None
        self.candidate = None

    def _emit(self, candidate: StructuralPivot, confirmer: StructuralPivot) -> StructuralPivot:
        self._sequence += 1
        pid = deterministic_id('pivot', candidate.symbol, candidate.timeframe_ms, self.output_layer.value, candidate.pivot_type.value, candidate.extreme_price, candidate.extreme_first_time, candidate.extreme_last_time, confirmer.confirmed_at, candidate.canonical_segment_id, self._sequence)
        return StructuralPivot(pivot_id=pid, symbol=candidate.symbol, timeframe_ms=candidate.timeframe_ms, layer=self.output_layer, pivot_type=candidate.pivot_type, extreme_price=candidate.extreme_price, extreme_first_time=candidate.extreme_first_time, extreme_last_time=candidate.extreme_last_time, confirmed_at=confirmer.confirmed_at, scale_at_extreme=candidate.scale_at_extreme, canonical_segment_id=candidate.canonical_segment_id, source_pivot_ids=(candidate.pivot_id, confirmer.pivot_id), provenance={'rule': 'MS-012', 'method': 'directional_change_over_confirmed_lower_pivot_stream'})

    def update(self, pivot: StructuralPivot) -> tuple[StructuralPivot, ...]:
        expected = self._expected_input_layer(self.output_layer)
        if pivot.layer is not expected:
            raise ValueError(f'{self.output_layer.value} requires {expected.value} input pivots')
        if self.segment_id != pivot.canonical_segment_id:
            self._reset(pivot.canonical_segment_id)
        if self.mode is SearchMode.UNKNOWN:
            self.seed = pivot
            self.mode = SearchMode.NEUTRAL
            return ()
        if self.mode is SearchMode.NEUTRAL:
            assert self.seed is not None
            if pivot.pivot_type is self.seed.pivot_type:
                if pivot.pivot_type is PivotType.HIGH and pivot.extreme_price >= self.seed.extreme_price:
                    self.seed = pivot
                elif pivot.pivot_type is PivotType.LOW and pivot.extreme_price <= self.seed.extreme_price:
                    self.seed = pivot
                return ()
            threshold = self.theta * self.seed.scale_at_extreme
            delta = pivot.extreme_price - self.seed.extreme_price
            if delta >= threshold:
                self.mode = SearchMode.SEEK_HIGH
                self.candidate = _HierarchyCandidate(pivot if pivot.pivot_type is PivotType.HIGH else self.seed)
            elif delta <= -threshold:
                self.mode = SearchMode.SEEK_LOW
                self.candidate = _HierarchyCandidate(pivot if pivot.pivot_type is PivotType.LOW else self.seed)
            return ()
        assert self.candidate is not None
        c = self.candidate.source
        if self.mode is SearchMode.SEEK_HIGH:
            if pivot.pivot_type is PivotType.LOW and c.extreme_price - pivot.extreme_price >= self.theta * c.scale_at_extreme:
                emitted = self._emit(c, pivot)
                self.mode = SearchMode.SEEK_LOW
                self.candidate = _HierarchyCandidate(pivot)
                return (emitted,)
            if pivot.pivot_type is PivotType.HIGH and pivot.extreme_price >= c.extreme_price:
                self.candidate = _HierarchyCandidate(pivot)
            return ()
        if self.mode is SearchMode.SEEK_LOW:
            if pivot.pivot_type is PivotType.HIGH and pivot.extreme_price - c.extreme_price >= self.theta * c.scale_at_extreme:
                emitted = self._emit(c, pivot)
                self.mode = SearchMode.SEEK_HIGH
                self.candidate = _HierarchyCandidate(pivot)
                return (emitted,)
            if pivot.pivot_type is PivotType.LOW and pivot.extreme_price <= c.extreme_price:
                self.candidate = _HierarchyCandidate(pivot)
            return ()
        raise AssertionError(f'unexpected mode {self.mode}')

# --- ORIGINAL d2_market_state/hierarchy.py ---
from dataclasses import dataclass
from fractions import Fraction

@dataclass(frozen=True)
class HierarchyUpdate:
    minor: tuple[StructuralPivot, ...]
    intermediate: tuple[StructuralPivot, ...]
    major: tuple[StructuralPivot, ...]

class StructuralHierarchyEngine:
    """One timeframe's Minor -> Intermediate -> Major RC1 hierarchy."""

    def __init__(self, *, symbol: str, timeframe_ms: int, params: StructuralScaleParameters) -> None:
        self.minor = MinorDirectionalChangeEngine(symbol=symbol, timeframe_ms=timeframe_ms, theta_minor=params.theta_minor)
        self.intermediate = PivotStreamDirectionalChangeEngine(output_layer=StructuralLayer.INTERMEDIATE, theta=params.theta_intermediate)
        self.major = PivotStreamDirectionalChangeEngine(output_layer=StructuralLayer.MAJOR, theta=params.theta_major)
        self._all_minor: list[StructuralPivot] = []
        self._all_intermediate: list[StructuralPivot] = []
        self._all_major: list[StructuralPivot] = []

    @property
    def all_minor(self) -> tuple[StructuralPivot, ...]:
        return tuple(self._all_minor)

    @property
    def all_intermediate(self) -> tuple[StructuralPivot, ...]:
        return tuple(self._all_intermediate)

    @property
    def all_major(self) -> tuple[StructuralPivot, ...]:
        return tuple(self._all_major)

    def update_bar(self, bar: CanonicalBar, atr14: InfoValue[Fraction], *, canonical_segment_id: str) -> HierarchyUpdate:
        minors = self.minor.update(bar, atr14, canonical_segment_id=canonical_segment_id)
        inters: list[StructuralPivot] = []
        majors: list[StructuralPivot] = []
        for p in minors:
            self._all_minor.append(p)
            new_i = self.intermediate.update(p)
            for ip in new_i:
                self._all_intermediate.append(ip)
                inters.append(ip)
                new_m = self.major.update(ip)
                for mp in new_m:
                    self._all_major.append(mp)
                    majors.append(mp)
        return HierarchyUpdate(minors, tuple(inters), tuple(majors))

# --- ORIGINAL d2_market_state/structural_legs.py ---
from dataclasses import dataclass
from fractions import Fraction
from statistics import median
from typing import Sequence

@dataclass(frozen=True)
class TimedClose:
    open_time: int
    close: Fraction

def _theil_sen_normalized_slope(closes: Sequence[TimedClose], *, timeframe_ms: int, scale_at_leg_start: Fraction) -> InfoValue[Fraction]:
    if len(closes) < 3:
        return InfoValue.na()
    if scale_at_leg_start <= 0:
        return InfoValue.error('NONPOSITIVE_LEG_START_SCALE')
    ordered = sorted(closes, key=lambda c: c.open_time)
    if len({c.open_time for c in ordered}) != len(ordered):
        return InfoValue.error('DUPLICATE_CLOSE_TIME_IN_LEG')
    slopes: list[Fraction] = []
    for i, left in enumerate(ordered[:-1]):
        for right in ordered[i + 1:]:
            delta_ms = right.open_time - left.open_time
            if delta_ms <= 0 or delta_ms % timeframe_ms != 0:
                return InfoValue.error('NONCANONICAL_ELAPSED_INTERVAL_IN_LEG')
            dx = Fraction(delta_ms, timeframe_ms)
            dy = (right.close - left.close) / scale_at_leg_start
            slopes.append(dy / dx)
    return InfoValue.known(median(slopes)) if slopes else InfoValue.na()

def build_structural_leg(start: StructuralPivot, end: StructuralPivot, *, close_path: Sequence[TimedClose]) -> StructuralLeg:
    if start.pivot_type is end.pivot_type:
        raise ValueError('Structural Leg requires adjacent opposite pivots')
    if start.layer is not end.layer:
        raise ValueError('Structural Leg requires same layer')
    if start.symbol != end.symbol or start.timeframe_ms != end.timeframe_ms:
        raise ValueError('Structural Leg requires same symbol/timeframe')
    if start.canonical_segment_id != end.canonical_segment_id:
        raise ValueError('Structural Leg cannot cross a canonical gap')
    if end.confirmed_at <= start.confirmed_at:
        raise ValueError('end pivot must be causally later')
    gross = abs(end.extreme_price - start.extreme_price)
    normalized = gross / start.scale_at_extreme
    if len(close_path) < 2:
        efficiency = InfoValue.na()
    else:
        ordered = sorted(close_path, key=lambda c: c.open_time)
        path = sum((abs(b.close - a.close) for a, b in zip(ordered, ordered[1:])))
        if path == 0:
            efficiency = InfoValue.na()
        else:
            efficiency = InfoValue.known(abs(ordered[-1].close - ordered[0].close) / path)
    slope = _theil_sen_normalized_slope(close_path, timeframe_ms=start.timeframe_ms, scale_at_leg_start=start.scale_at_extreme)
    metrics = LegMetrics(gross_displacement=gross, normalized_displacement=normalized, directional_efficiency=efficiency, robust_normalized_slope=slope)
    leg_id = deterministic_id('structural_leg', start.pivot_id, end.pivot_id, start.canonical_segment_id)
    return StructuralLeg(leg_id=leg_id, symbol=start.symbol, timeframe_ms=start.timeframe_ms, layer=start.layer, start_pivot_id=start.pivot_id, end_pivot_id=end.pivot_id, start_type=start.pivot_type, end_type=end.pivot_type, canonical_segment_id=start.canonical_segment_id, metrics=metrics)

def trend_aligned_edpr(leg: StructuralLeg, direction: TrendDirection) -> InfoValue[Fraction]:
    """B2 EDPR = TrendAlignedRobustSlope × DirectionalEfficiency."""
    slope = leg.metrics.robust_normalized_slope
    efficiency = leg.metrics.directional_efficiency
    if slope.kind.value != 'KNOWN' or efficiency.kind.value != 'KNOWN':
        return InfoValue.na()
    if direction is TrendDirection.LONG:
        aligned = slope.require_known()
    elif direction is TrendDirection.SHORT:
        aligned = -slope.require_known()
    else:
        return InfoValue.na()
    if aligned < 0:
        return InfoValue.error('LEG_NOT_TREND_ALIGNED')
    return InfoValue.known(aligned * efficiency.require_known())

# --- ORIGINAL d2_market_state/trend.py ---
from dataclasses import replace
from fractions import Fraction
from typing import Mapping, Sequence

def initial_trend_state() -> TrendEpisodeState:
    return TrendEpisodeState(direction=TrendDirection.UNKNOWN, episode_id=None, episode_start_cutoff=None, protected_pivot=None, frontier_pivot=None, phase=TrendPhase.UNKNOWN, integrity=None, reversal_candidate_cap=None, defended_pullback_after_pressure=False, prior_same_direction_edpr=InfoValue.na(), completed_trend_aligned_normalized_legs=())

def _by_id(pivots: Sequence[StructuralPivot]) -> dict[str, StructuralPivot]:
    return {p.pivot_id: p for p in pivots}

def _episode_from_establishment(evidence: EstablishmentEvidence, pivots: Sequence[StructuralPivot], *, leg_by_end_pivot: Mapping[str, StructuralLeg]) -> TrendEpisodeState:
    lookup = _by_id(pivots)
    newest = lookup[evidence.newest_pivot_id]
    protected = lookup[evidence.defended_opposite_pivot_id]
    episode_id = deterministic_id('trend_episode', newest.symbol, newest.timeframe_ms, evidence.direction.value, newest.confirmed_at, newest.pivot_id)
    leg = leg_by_end_pivot.get(newest.pivot_id)
    if leg is not None:
        lengths = (leg.metrics.normalized_displacement,)
        baseline = trend_aligned_edpr(leg, evidence.direction)
    else:
        lengths = ()
        baseline = InfoValue.na()
    return TrendEpisodeState(direction=evidence.direction, episode_id=episode_id, episode_start_cutoff=newest.confirmed_at, protected_pivot=protected, frontier_pivot=newest, phase=TrendPhase.EXPANSION, integrity=TrendIntegrity.HEALTHY, reversal_candidate_cap=None, defended_pullback_after_pressure=False, prior_same_direction_edpr=baseline, completed_trend_aligned_normalized_legs=lengths)

def _is_adverse(direction: TrendDirection, pivot: StructuralPivot) -> bool:
    return direction is TrendDirection.LONG and pivot.pivot_type is PivotType.LOW or (direction is TrendDirection.SHORT and pivot.pivot_type is PivotType.HIGH)

def _is_favorable(direction: TrendDirection, pivot: StructuralPivot) -> bool:
    return direction is TrendDirection.LONG and pivot.pivot_type is PivotType.HIGH or (direction is TrendDirection.SHORT and pivot.pivot_type is PivotType.LOW)

def _material_failure(direction: TrendDirection, protected: StructuralPivot, adverse: StructuralPivot, theta_progress: Fraction) -> bool:
    relation = same_type_progress(protected, adverse, theta_progress)
    return direction is TrendDirection.LONG and relation is ProgressRelation.MATERIAL_ADVANCE_DOWN or (direction is TrendDirection.SHORT and relation is ProgressRelation.MATERIAL_ADVANCE_UP)

def _inside_protected_zone(protected: StructuralPivot, adverse: StructuralPivot, theta_progress: Fraction) -> bool:
    return abs(normalized_delta(protected, adverse)) <= theta_progress

def _classify_edpr_phase(prior: InfoValue[Fraction], current: InfoValue[Fraction], theta_rate: Fraction) -> TrendPhase:
    if prior.kind is not InfoKind.KNOWN or current.kind is not InfoKind.KNOWN:
        return TrendPhase.EXPANSION
    delta = current.require_known() - prior.require_known()
    if delta > theta_rate:
        return TrendPhase.ACCELERATION
    if delta < -theta_rate:
        return TrendPhase.DECELERATION
    return TrendPhase.EXPANSION

def _opposite(direction: TrendDirection) -> TrendDirection:
    if direction is TrendDirection.LONG:
        return TrendDirection.SHORT
    if direction is TrendDirection.SHORT:
        return TrendDirection.LONG
    return TrendDirection.NONE

def _recovery_breaks_cap(direction: TrendDirection, cap: StructuralPivot, favorable: StructuralPivot, theta_progress: Fraction) -> bool:
    if cap.pivot_type is not favorable.pivot_type:
        return False
    rel = same_type_progress(cap, favorable, theta_progress)
    return direction is TrendDirection.LONG and rel is ProgressRelation.MATERIAL_ADVANCE_UP or (direction is TrendDirection.SHORT and rel is ProgressRelation.MATERIAL_ADVANCE_DOWN)

def on_new_intermediate_pivot(state: TrendEpisodeState, pivots: Sequence[StructuralPivot], *, theta_progress: Fraction, theta_rate: Fraction, leg_by_end_pivot: Mapping[str, StructuralLeg]) -> TrendEpisodeState:
    """UPDATE-006 event-driven D2 Trend transition on newest confirmed Intermediate pivot only."""
    if not pivots:
        return state
    newest = pivots[-1]
    if newest.layer.value != 'INTERMEDIATE':
        raise ValueError('Trend consumes Intermediate pivots only')
    if newest.confirmed_at != max((p.confirmed_at for p in pivots)):
        raise ValueError('newest pivot must be latest causal Intermediate event')
    evidence = latest_establishment_evidence(pivots, theta_progress=theta_progress)
    if state.direction not in (TrendDirection.LONG, TrendDirection.SHORT) or state.episode_id is None:
        if evidence is not None:
            return _episode_from_establishment(evidence, pivots, leg_by_end_pivot=leg_by_end_pivot)
        if len(pivots) >= 4:
            return replace(state, direction=TrendDirection.NONE, phase=TrendPhase.NO_TREND, integrity=None)
        return replace(state, direction=TrendDirection.UNKNOWN, phase=TrendPhase.UNKNOWN, integrity=None)
    direction = state.direction
    protected = state.protected_pivot
    if protected is None:
        raise ValueError('active Trend Episode requires Protected Intermediate Structure')
    if _is_adverse(direction, newest) and _material_failure(direction, protected, newest, theta_progress):
        terminal = state.episode_id
        if evidence is not None and evidence.direction is _opposite(direction):
            new_state = _episode_from_establishment(evidence, pivots, leg_by_end_pivot=leg_by_end_pivot)
            return replace(new_state, terminal_episode_id=terminal)
        return TrendEpisodeState(direction=TrendDirection.NONE, episode_id=None, episode_start_cutoff=None, protected_pivot=None, frontier_pivot=None, phase=TrendPhase.STRUCTURAL_FAILURE, integrity=TrendIntegrity.FAILED, reversal_candidate_cap=None, defended_pullback_after_pressure=False, prior_same_direction_edpr=InfoValue.na(), completed_trend_aligned_normalized_legs=(), terminal_episode_id=terminal)
    if evidence is not None and evidence.direction is _opposite(direction):
        lookup = _by_id(pivots)
        cap = lookup[evidence.defended_opposite_pivot_id]
        return replace(state, phase=TrendPhase.REVERSAL_CANDIDATE, integrity=TrendIntegrity.DETERIORATING, reversal_candidate_cap=cap, defended_pullback_after_pressure=False)
    if _is_adverse(direction, newest):
        pressured = _inside_protected_zone(protected, newest, theta_progress)
        if state.integrity is TrendIntegrity.PRESSURED:
            return replace(state, defended_pullback_after_pressure=True)
        if state.integrity is TrendIntegrity.DETERIORATING:
            return state
        if pressured:
            return replace(state, integrity=TrendIntegrity.PRESSURED, defended_pullback_after_pressure=False)
        return state
    if _is_favorable(direction, newest):
        prior_frontier = state.frontier_pivot
        state2 = replace(state, frontier_pivot=newest)
        if state.integrity is TrendIntegrity.DETERIORATING and state.reversal_candidate_cap is not None:
            if _recovery_breaks_cap(direction, state.reversal_candidate_cap, newest, theta_progress):
                leg = leg_by_end_pivot.get(newest.pivot_id)
                phase = _classify_edpr_phase(state.prior_same_direction_edpr, trend_aligned_edpr(leg, direction) if leg else InfoValue.na(), theta_rate)
                prior_edpr = trend_aligned_edpr(leg, direction) if leg is not None else state.prior_same_direction_edpr
                lengths = state.completed_trend_aligned_normalized_legs + ((leg.metrics.normalized_displacement,) if leg else ())
                return replace(state2, phase=phase, integrity=TrendIntegrity.PRESSURED, reversal_candidate_cap=None, defended_pullback_after_pressure=False, prior_same_direction_edpr=prior_edpr, completed_trend_aligned_normalized_legs=lengths)
            return state2
        material = False
        if prior_frontier is not None and prior_frontier.pivot_type is newest.pivot_type:
            rel = same_type_progress(prior_frontier, newest, theta_progress)
            material = direction is TrendDirection.LONG and rel is ProgressRelation.MATERIAL_ADVANCE_UP or (direction is TrendDirection.SHORT and rel is ProgressRelation.MATERIAL_ADVANCE_DOWN)
        if not material:
            return state2
        candidate = pivots[-2] if len(pivots) >= 2 and pivots[-2].pivot_type is not newest.pivot_type else None
        protected2 = protected
        if candidate is not None and candidate.pivot_type is protected.pivot_type:
            relp = same_type_progress(protected, candidate, theta_progress)
            if direction is TrendDirection.LONG and relp is ProgressRelation.MATERIAL_ADVANCE_UP:
                protected2 = candidate
            elif direction is TrendDirection.SHORT and relp is ProgressRelation.MATERIAL_ADVANCE_DOWN:
                protected2 = candidate
        leg = leg_by_end_pivot.get(newest.pivot_id)
        phase = _classify_edpr_phase(state.prior_same_direction_edpr, trend_aligned_edpr(leg, direction) if leg else InfoValue.na(), theta_rate)
        new_edpr = trend_aligned_edpr(leg, direction) if leg is not None else state.prior_same_direction_edpr
        lengths = state.completed_trend_aligned_normalized_legs + ((leg.metrics.normalized_displacement,) if leg else ())
        integrity = state.integrity
        defended = state.defended_pullback_after_pressure
        if integrity is TrendIntegrity.PRESSURED and defended:
            integrity = TrendIntegrity.HEALTHY
            defended = False
        return replace(state2, protected_pivot=protected2, phase=phase, integrity=integrity, defended_pullback_after_pressure=defended, prior_same_direction_edpr=new_edpr, completed_trend_aligned_normalized_legs=lengths)
    return state

# --- ORIGINAL d2_market_state/trend_position.py ---
from fractions import Fraction
from statistics import median

def protected_equivalence_zone(protected: StructuralPivot, theta_progress: Fraction) -> tuple[Fraction, Fraction]:
    half = theta_progress * protected.scale_at_extreme
    return (protected.extreme_price - half, protected.extreme_price + half)

def structural_corridor(*, direction: TrendDirection, protected: StructuralPivot | None, frontier: StructuralPivot | None, current_close: Fraction, theta_progress: Fraction) -> InfoValue[StructuralCorridor]:
    if direction not in (TrendDirection.LONG, TrendDirection.SHORT):
        return InfoValue.na()
    if protected is None or frontier is None:
        return InfoValue.unknown()
    low_zone, high_zone = protected_equivalence_zone(protected, theta_progress)
    if direction is TrendDirection.LONG:
        return InfoValue.known(StructuralCorridor(low_zone, max(current_close, frontier.extreme_price)))
    return InfoValue.known(StructuralCorridor(min(current_close, frontier.extreme_price), high_zone))

def classify_trend_position(*, direction: TrendDirection, current_close: Fraction, frontier: StructuralPivot | None, reset_pivot: StructuralPivot | None, theta_progress: Fraction, theta_overextension: Fraction, completed_trend_aligned_normalized_legs: tuple[Fraction, ...]) -> TrendPositionResult:
    if direction not in (TrendDirection.LONG, TrendDirection.SHORT):
        return TrendPositionResult(TrendPosition.NA, InfoValue.na(), InfoValue.na(), InfoValue.na(), InfoValue.na())
    if frontier is None or frontier.scale_at_extreme <= 0:
        return TrendPositionResult(TrendPosition.UNKNOWN, InfoValue.unknown(), InfoValue.unknown(), InfoValue.unknown(), InfoValue.unknown())
    sign = Fraction(1) if direction is TrendDirection.LONG else Fraction(-1)
    x = sign * (current_close - frontier.extreme_price) / frontier.scale_at_extreme
    if abs(x) <= theta_progress:
        base = TrendPosition.BALANCED
    elif x < -theta_progress:
        base = TrendPosition.PULLBACK
    else:
        base = TrendPosition.EXTENDED
    if reset_pivot is None or reset_pivot.scale_at_extreme <= 0:
        return TrendPositionResult(base, InfoValue.known(x), InfoValue.unknown(), InfoValue.unknown(), InfoValue.unknown())
    l_t = sign * (current_close - reset_pivot.extreme_price) / reset_pivot.scale_at_extreme
    positive_legs = tuple((v for v in completed_trend_aligned_normalized_legs if v > 0))
    if not positive_legs:
        return TrendPositionResult(base, InfoValue.known(x), InfoValue.known(l_t), InfoValue.na(), InfoValue.na())
    m_episode = median(positive_legs)
    if m_episode <= 0:
        return TrendPositionResult(base, InfoValue.known(x), InfoValue.known(l_t), InfoValue.error('NONPOSITIVE_EPISODE_MEDIAN'), InfoValue.error('NONPOSITIVE_EPISODE_MEDIAN'))
    ratio = l_t / m_episode
    pos = TrendPosition.OVEREXTENDED if base is TrendPosition.EXTENDED and ratio > theta_overextension else base
    return TrendPositionResult(pos, InfoValue.known(x), InfoValue.known(l_t), InfoValue.known(m_episode), InfoValue.known(ratio))

# --- ORIGINAL d2_reference.py ---
"""Non-trading WP2 D2 reference skeleton.

Only D2-owned UPDATE-005, UPDATE-006 and UPDATE-009 semantics are represented.
Construction from the current durable partial ParameterSnapshot is expected to
fail because theta_minor/intermediate/major remain OPEN.
"""
from dataclasses import dataclass, field
from fractions import Fraction
from typing import Iterable

@dataclass
class _TimeframeState:
    symbol: str
    timeframe_ms: int
    structural_params: StructuralScaleParameters
    hierarchy: StructuralHierarchyEngine = field(init=False)
    segment_id: str | None = None
    intermediate: list[StructuralPivot] = field(default_factory=list)
    legs_by_end: dict[str, StructuralLeg] = field(default_factory=dict)
    closes: list[TimedClose] = field(default_factory=list)
    trend: TrendEpisodeState = field(default_factory=initial_trend_state)

    def __post_init__(self) -> None:
        self.hierarchy = StructuralHierarchyEngine(symbol=self.symbol, timeframe_ms=self.timeframe_ms, params=self.structural_params)

    def reset_for_segment(self, segment_id: str) -> None:
        self.segment_id = segment_id
        self.hierarchy = StructuralHierarchyEngine(symbol=self.symbol, timeframe_ms=self.timeframe_ms, params=self.structural_params)
        self.intermediate.clear()
        self.legs_by_end.clear()
        self.closes.clear()
        self.trend = initial_trend_state()

@dataclass(frozen=True)
class D2CutoffResult:
    information_cutoff: int
    update_005_minor: tuple[StructuralPivot, ...]
    update_005_intermediate: tuple[StructuralPivot, ...]
    update_005_major: tuple[StructuralPivot, ...]
    update_006_trend: TrendEpisodeState
    update_009_trend_position: object
    update_009_structural_corridor: object

class D2ReferenceSkeleton:

    def __init__(self, *, symbol: str, structural_params: StructuralScaleParameters, frozen_params: FrozenD2Parameters) -> None:
        self.symbol = symbol
        self.structural_params = structural_params
        self.frozen_params = frozen_params
        self._tf: dict[int, _TimeframeState] = {}

    @classmethod
    def from_parameter_snapshot(cls, *, symbol: str, snapshot: ParameterSnapshot) -> 'D2ReferenceSkeleton':
        structural = require_structural_scale_parameters(snapshot)
        frozen = frozen_d2_parameters(snapshot)
        return cls(symbol=symbol, structural_params=structural, frozen_params=frozen)

    def _state(self, timeframe_ms: int) -> _TimeframeState:
        state = self._tf.get(timeframe_ms)
        if state is None:
            state = _TimeframeState(self.symbol, timeframe_ms, self.structural_params)
            self._tf[timeframe_ms] = state
        return state

    @staticmethod
    def _reset_pivot(state: _TimeframeState) -> StructuralPivot | None:
        if state.trend.direction is TrendDirection.LONG:
            lows = [p for p in state.intermediate if p.pivot_type is PivotType.LOW]
            return lows[-1] if lows else state.trend.protected_pivot
        if state.trend.direction is TrendDirection.SHORT:
            highs = [p for p in state.intermediate if p.pivot_type is PivotType.HIGH]
            return highs[-1] if highs else state.trend.protected_pivot
        return None

    def advance_source_bar(self, bar: CanonicalBar, atr14: InfoValue[Fraction], *, canonical_segment_id: str) -> D2CutoffResult:
        """Execute only D2's UPDATE-005 -> UPDATE-006 -> UPDATE-009 slice."""
        state = self._state(self._infer_timeframe(bar))
        if state.segment_id != canonical_segment_id:
            state.reset_for_segment(canonical_segment_id)
        state.closes.append(TimedClose(bar.open_time, bar.close))
        update = state.hierarchy.update_bar(bar, atr14, canonical_segment_id=canonical_segment_id)
        for ip in update.intermediate:
            if state.intermediate:
                prior = state.intermediate[-1]
                if prior.pivot_type is not ip.pivot_type and prior.canonical_segment_id == ip.canonical_segment_id:
                    close_path = tuple((c for c in state.closes if prior.extreme_first_time <= c.open_time <= ip.extreme_last_time))
                    try:
                        state.legs_by_end[ip.pivot_id] = build_structural_leg(prior, ip, close_path=close_path)
                    except ValueError:
                        pass
            state.intermediate.append(ip)
            state.trend = on_new_intermediate_pivot(state.trend, state.intermediate, theta_progress=self.frozen_params.theta_progress, theta_rate=self.frozen_params.theta_rate, leg_by_end_pivot=state.legs_by_end)
        reset = self._reset_pivot(state)
        tpos = classify_trend_position(direction=state.trend.direction, current_close=bar.close, frontier=state.trend.frontier_pivot, reset_pivot=reset, theta_progress=self.frozen_params.theta_progress, theta_overextension=self.frozen_params.theta_overextension, completed_trend_aligned_normalized_legs=state.trend.completed_trend_aligned_normalized_legs)
        corridor = structural_corridor(direction=state.trend.direction, protected=state.trend.protected_pivot, frontier=state.trend.frontier_pivot, current_close=bar.close, theta_progress=self.frozen_params.theta_progress)
        return D2CutoffResult(information_cutoff=bar.close_time, update_005_minor=update.minor, update_005_intermediate=update.intermediate, update_005_major=update.major, update_006_trend=state.trend, update_009_trend_position=tpos, update_009_structural_corridor=corridor)

    @staticmethod
    def _infer_timeframe(bar: CanonicalBar) -> int:
        span = bar.close_time - bar.open_time
        candidates = (15 * 60 * 1000, 60 * 60 * 1000, 4 * 60 * 60 * 1000)
        for tf in candidates:
            if span in (tf, tf - 1):
                return tf
        raise ValueError(f'Unsupported D2 source timeframe span={span}')

# --- ORIGINAL d3_boundary_intelligence/types.py ---
from dataclasses import dataclass, field
from enum import Enum
from fractions import Fraction
from typing import Mapping

class CandidateFamily(str, Enum):
    EMA20 = 'EMA20'
    EMA50 = 'EMA50'
    ST_ACTIVE = 'ST_ACTIVE'

class CandidateAvailability(str, Enum):
    AVAILABLE = 'AVAILABLE'
    UNAVAILABLE = 'UNAVAILABLE'

class AnchorValidity(str, Enum):
    PROVISIONAL = 'PROVISIONAL'
    VALID = 'VALID'
    TERMINATED = 'TERMINATED'

class AnchorActivity(str, Enum):
    ACTIVE = 'ACTIVE'
    PRESSURED = 'PRESSURED'
    TERMINATED = 'TERMINATED'

class InteractionControl(str, Enum):
    UNARMED = 'UNARMED'
    ARMED = 'ARMED'
    INTERACTION_ACTIVE = 'INTERACTION_ACTIVE'
    RESOLVED = 'RESOLVED'

class InteractionResolution(str, Enum):
    RESOLVED_CORRECT_SIDE = 'RESOLVED_CORRECT_SIDE'
    RESOLVED_WRONG_SIDE = 'RESOLVED_WRONG_SIDE'
    UNRESOLVED = 'UNRESOLVED'
    ABORTED_APPROACH = 'ABORTED_APPROACH'
    UNKNOWN_CONTINUITY = 'UNKNOWN_CONTINUITY'

class BreakState(str, Enum):
    NONE = 'NONE'
    WRONG_SIDE_UNARMED = 'WRONG_SIDE_UNARMED'
    PROBE = 'PROBE'
    TEMPORARY_BREAK = 'TEMPORARY_BREAK'
    RECLAIMING = 'RECLAIMING'
    TRUE_BREAK = 'TRUE_BREAK'
    FALSE_BREAK = 'FALSE_BREAK'

class Role(str, Enum):
    PRIMARY = 'PRIMARY'
    SECONDARY = 'SECONDARY'
    STRUCTURAL = 'STRUCTURAL'

class RoleTransition(str, Enum):
    NONE = 'NONE'
    HANDOFF = 'HANDOFF'
    PROMOTION = 'PROMOTION'
    REPLACEMENT = 'REPLACEMENT'
    UNRESOLVED = 'UNRESOLVED'

class StructuralDepthRelation(str, Enum):
    SAME_LAYER = 'SAME_LAYER'
    DEEPER = 'DEEPER'
    SHALLOWER = 'SHALLOWER'
    UNRESOLVED = 'UNRESOLVED'

@dataclass(frozen=True)
class MathematicalBoundaryCandidate:
    candidate_id: str
    symbol: str
    source_timeframe_ms: int
    target_trend_episode_id: str
    target_direction: TrendDirection
    family: CandidateFamily
    boundary: InfoValue[Fraction]
    source_scale: InfoValue[Fraction]
    source_segment_id: str
    available_at: int
    availability: CandidateAvailability
    provenance: Mapping[str, str]

@dataclass(frozen=True)
class CausalBoundarySnapshot:
    snapshot_id: str
    candidate_id: str
    anchor_episode_id: str | None
    symbol: str
    source_timeframe_ms: int
    target_trend_episode_id: str
    target_direction: TrendDirection
    family: CandidateFamily
    boundary: Fraction
    source_scale: Fraction
    source_segment_id: str
    available_at: int
    provenance: Mapping[str, str]

@dataclass(frozen=True)
class B3Geometry:
    information_cutoff: int
    snapshot_id: str
    d_close: Fraction
    d_range_nearest: Fraction
    test: bool
    approach: bool
    separated: bool
    hysteresis_intermediate: bool
    wrong_side_range_penetration: bool
    wrong_side_close: bool
    material_wrong_side_separation: bool

@dataclass(frozen=True)
class PriceDrivenReturnEvidence:
    passed: bool
    adverse_raw_movement: Fraction
    minimum_required: Fraction
    provenance: Mapping[str, str]

@dataclass(frozen=True)
class StructuralAcceptanceEvidence:
    continuation_acceptance: bool = False
    failed_return_acceptance: bool = False
    confirmed_wrong_side_minor_extreme_id: str | None = None
    renewed_wrong_side_progress_pivot_id: str | None = None
    failed_return_progress_pivot_id: str | None = None

@dataclass(frozen=True)
class CorrectSideRecoveryEvidence:
    turning_structure_confirmed: bool = False
    material_correct_side_structural_recovery: bool = False
    turning_pivot_id: str | None = None
    recovery_pivot_id: str | None = None

@dataclass(frozen=True)
class InteractionEvent:
    event_id: str
    candidate_id: str
    anchor_episode_id: str | None
    target_trend_episode_id: str
    target_direction: TrendDirection
    control: InteractionControl
    resolution: InteractionResolution
    event_reference_boundary: Fraction | None
    event_reference_scale: Fraction | None
    started_at: int | None
    resolved_at: int | None
    armed_at: int | None
    approach_lineage_started_at: int | None
    attempted_wrong_side_acceptance: bool
    material_wrong_side_separation_observed: bool
    reclaim_observed: bool
    break_state: BreakState
    terminal: bool
    provenance: Mapping[str, str] = field(default_factory=dict)

@dataclass(frozen=True)
class BreakEvaluation:
    break_state: BreakState
    terminal: bool
    resolution: InteractionResolution
    attempted_wrong_side_acceptance: bool
    material_wrong_side_separation_observed: bool
    reclaim_observed: bool
    reason: str

@dataclass(frozen=True)
class TrendSideMinorProgressEvidence:
    pivot_id: str
    confirmed_at: int
    material_progress: bool
    timeframe_ms: int
    layer: str = 'MINOR'

@dataclass(frozen=True)
class QualifiedBoundaryUse:
    use_id: str
    anchor_episode_id: str
    negotiation_event_id: str
    correct_side_resolution_cutoff: int
    trend_side_minor_progress_pivot_id: str
    progress_confirmed_at: int

@dataclass(frozen=True)
class AnchorEvidenceDossier:
    boundary_side_integrity: InfoValue[str]
    structural_integrity: InfoValue[str]
    slope_alignment: InfoValue[str]
    independent_retest_evidence: InfoValue[str]
    retest_quality: InfoValue[str]
    current_relevance: InfoValue[str]
    true_break_evidence: InfoValue[str]
    data_confidence: InfoValue[str]

@dataclass(frozen=True)
class AnchorEpisode:
    anchor_episode_id: str
    candidate_id: str
    target_trend_episode_id: str
    target_direction: TrendDirection
    validity: AnchorValidity
    activity: AnchorActivity
    started_at: int
    ended_at: int | None
    interaction_event_ids: tuple[str, ...]
    qualified_uses: tuple[QualifiedBoundaryUse, ...]
    terminal_true_break: bool
    dossier: AnchorEvidenceDossier
    provenance: Mapping[str, str] = field(default_factory=dict)

@dataclass(frozen=True)
class BoundaryContactZone:
    zone_id: str
    anchor_episode_id: str
    lower: Fraction
    upper: Fraction
    information_cutoff: int
    provenance: Mapping[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.upper < self.lower:
            raise ValueError('contact zone upper < lower')

    def intersects(self, lower: Fraction, upper: Fraction) -> bool:
        return self.lower <= upper and lower <= self.upper

@dataclass(frozen=True)
class EconomicBoundaryUnit:
    unit_id: str
    anchor_episode_ids: tuple[str, ...]
    contact_zones: tuple[BoundaryContactZone, ...]
    is_cluster: bool
    provenance: Mapping[str, str] = field(default_factory=dict)

@dataclass(frozen=True)
class BoundaryUnitRoleEvidence:
    unit: EconomicBoundaryUnit
    at_least_one_valid_member: bool
    current_relevant: bool
    latest_qualified_use_cutoff: int | None
    terminal_true_break: bool
    active_qualifying_interaction: bool
    unresolved_conflict: bool
    structural_depth_relation_to_primary: StructuralDepthRelation = StructuralDepthRelation.UNRESOLVED

@dataclass(frozen=True)
class EntryAnchorReference:
    """Interface-only reference: Entry Anchor need not equal Primary.

    WP3 does not create Opportunity or ENTRY_READY; a later D4 layer may consume
    a validated active Economic Boundary Unit through this reference.
    """
    unit_id: str
    validation_provenance: Mapping[str, str] = field(default_factory=dict)

@dataclass(frozen=True)
class RoleAssignment:
    primary_unit_id: str | None
    secondary_unit_id: str | None
    structural_unit_ids: tuple[str, ...]
    transition: RoleTransition
    unresolved_reason: str | None

@dataclass(frozen=True)
class PreBarBoundaryView:
    observer_open_time: int
    snapshots: tuple[CausalBoundarySnapshot, ...]

@dataclass(frozen=True)
class D3CutoffView:
    information_cutoff: int
    update_002_geometry: tuple[B3Geometry, ...]
    update_007_events: tuple[InteractionEvent, ...]
    update_008_anchor_episodes: tuple[AnchorEpisode, ...]
    update_008_units: tuple[EconomicBoundaryUnit, ...]
    update_008_roles: RoleAssignment | None

# --- ORIGINAL d3_boundary_intelligence/parameters.py ---
from dataclasses import dataclass
from fractions import Fraction

@dataclass(frozen=True)
class FrozenD3Parameters:
    theta_test: Fraction
    theta_approach: Fraction
    theta_separation: Fraction
    theta_accept: Fraction
    theta_progress: Fraction

def _frozen_fraction(snapshot: ParameterSnapshot, name: str) -> Fraction:
    slot = snapshot.slot(name)
    if slot.state is not ParameterState.FROZEN or slot.exact_value is None:
        raise ValueError(f'{name} must be FROZEN with an exact value for WP3')
    return Fraction(slot.exact_value)

def frozen_d3_parameters(snapshot: ParameterSnapshot) -> FrozenD3Parameters:
    p = FrozenD3Parameters(theta_test=_frozen_fraction(snapshot, 'theta_test'), theta_approach=_frozen_fraction(snapshot, 'theta_approach'), theta_separation=_frozen_fraction(snapshot, 'theta_separation'), theta_accept=_frozen_fraction(snapshot, 'theta_accept'), theta_progress=_frozen_fraction(snapshot, 'theta_progress'))
    if not Fraction(0) <= p.theta_test < p.theta_approach < p.theta_separation:
        raise ValueError('RC1 B3 geometry ordering violated')
    if p.theta_accept <= 0:
        raise ValueError('theta_accept must be > 0')
    return p

# --- ORIGINAL d3_boundary_intelligence/candidates.py ---
from fractions import Fraction
from typing import Mapping

def build_candidate(*, symbol: str, source_timeframe_ms: int, target_trend_episode_id: str, target_direction: TrendDirection, family: CandidateFamily, line: InfoValue[Fraction], source_scale: InfoValue[Fraction], source_segment_id: str, available_at: int, source_continuity_ok: bool, st_direction: Direction | None=None, provenance: Mapping[str, str] | None=None) -> MathematicalBoundaryCandidate:
    """Create a D1 mathematical boundary candidate without creating Trend truth.

    F1 availability is explicit. ST active line is UNAVAILABLE while ST direction
    is UNKNOWN. Source-TF Trend alignment is intentionally not required by F1.
    """
    available = source_continuity_ok and line.kind is InfoKind.KNOWN and (source_scale.kind is InfoKind.KNOWN)
    if family is CandidateFamily.ST_ACTIVE and (st_direction is None or st_direction is Direction.UNKNOWN):
        available = False
    candidate_id = deterministic_id('D3-CAND', symbol, str(source_timeframe_ms), target_trend_episode_id, target_direction.value, family.value, source_segment_id)
    return MathematicalBoundaryCandidate(candidate_id=candidate_id, symbol=symbol, source_timeframe_ms=source_timeframe_ms, target_trend_episode_id=target_trend_episode_id, target_direction=target_direction, family=family, boundary=line if available else InfoValue.na(), source_scale=source_scale if available else InfoValue.na(), source_segment_id=source_segment_id, available_at=available_at, availability=CandidateAvailability.AVAILABLE if available else CandidateAvailability.UNAVAILABLE, provenance=dict(provenance or {}))

# --- ORIGINAL d3_boundary_intelligence/snapshots.py ---
def snapshot_from_candidate(candidate: MathematicalBoundaryCandidate, *, anchor_episode_id: str | None) -> CausalBoundarySnapshot | None:
    if candidate.availability is CandidateAvailability.UNAVAILABLE:
        return None
    boundary = candidate.boundary.require_known()
    scale = candidate.source_scale.require_known()
    return CausalBoundarySnapshot(snapshot_id=deterministic_id('D3-SNAPSHOT', candidate.candidate_id, str(candidate.available_at), anchor_episode_id or 'WATCH'), candidate_id=candidate.candidate_id, anchor_episode_id=anchor_episode_id, symbol=candidate.symbol, source_timeframe_ms=candidate.source_timeframe_ms, target_trend_episode_id=candidate.target_trend_episode_id, target_direction=candidate.target_direction, family=candidate.family, boundary=boundary, source_scale=scale, source_segment_id=candidate.source_segment_id, available_at=candidate.available_at, provenance=dict(candidate.provenance))

def pre_bar_view(observer_open_time: int, snapshots: list[CausalBoundarySnapshot]) -> PreBarBoundaryView:
    """UPDATE-000/002 guard: only snapshots available before bar t began."""
    eligible = [s for s in snapshots if s.available_at < observer_open_time]
    latest: dict[str, CausalBoundarySnapshot] = {}
    for s in sorted(eligible, key=lambda x: (x.available_at, x.snapshot_id)):
        latest[s.candidate_id] = s
    return PreBarBoundaryView(observer_open_time=observer_open_time, snapshots=tuple(latest.values()))

# --- ORIGINAL d3_boundary_intelligence/geometry.py ---
from fractions import Fraction

def _sign(direction: TrendDirection) -> int:
    if direction is TrendDirection.LONG:
        return 1
    if direction is TrendDirection.SHORT:
        return -1
    raise ValueError('B3 geometry requires active LONG/SHORT target Trend')

def _classify_values(*, bar: OHLCBar, information_cutoff: int, reference_id: str, direction: TrendDirection, boundary: Fraction, scale: Fraction, params: FrozenD3Parameters) -> B3Geometry:
    s = _sign(direction)
    if scale <= 0:
        raise ValueError('source scale must be positive')
    d_close = Fraction(s) * (bar.close - boundary) / scale
    if direction is TrendDirection.LONG:
        d_range = (bar.low - boundary) / scale
    else:
        d_range = (boundary - bar.high) / scale
    test = d_range <= params.theta_test
    approach = params.theta_test < d_range <= params.theta_approach
    separated = d_close >= params.theta_separation
    hysteresis = d_range > params.theta_approach and d_close < params.theta_separation
    return B3Geometry(information_cutoff=information_cutoff, snapshot_id=reference_id, d_close=d_close, d_range_nearest=d_range, test=test, approach=approach, separated=separated, hysteresis_intermediate=hysteresis, wrong_side_range_penetration=d_range < 0, wrong_side_close=d_close < 0, material_wrong_side_separation=d_close <= -params.theta_accept)

def classify_geometry(*, bar: OHLCBar, information_cutoff: int, snapshot: CausalBoundarySnapshot, params: FrozenD3Parameters) -> B3Geometry:
    """Exact adopted post-RC1 B3 zone classifier.

    TEST/APPROACH are mutually exclusive range predicates. SEPARATED is an
    independent close predicate and may coexist with TEST.
    """
    return _classify_values(bar=bar, information_cutoff=information_cutoff, reference_id=snapshot.snapshot_id, direction=snapshot.target_direction, boundary=snapshot.boundary, scale=snapshot.source_scale, params=params)

def classify_event_reference_geometry(*, bar: OHLCBar, information_cutoff: int, event, params: FrozenD3Parameters) -> B3Geometry:
    """Classify active B3/B4 event against frozen reference, never Anchor drift."""
    if event.event_reference_boundary is None or event.event_reference_scale is None:
        raise ValueError('event has no frozen reference')
    return _classify_values(bar=bar, information_cutoff=information_cutoff, reference_id=f'EVENT_REFERENCE:{event.event_id}', direction=event.target_direction, boundary=event.event_reference_boundary, scale=event.event_reference_scale, params=params)

def qualify_price_driven_return(*, adverse_raw_movement: Fraction, source_scale: Fraction, params: FrozenD3Parameters, provenance: dict[str, str] | None=None) -> PriceDrivenReturnEvidence:
    """F3 return threshold only; caller must provide actual raw-price movement.

    RC1 freezes the required magnitude but not an extra theta_return. This helper
    does not invent a return-origin convention; raw movement + provenance must
    come from the caller's causal price path.
    """
    if adverse_raw_movement < 0 or source_scale <= 0:
        raise ValueError('invalid adverse movement/source scale')
    minimum = (params.theta_separation - params.theta_approach) * source_scale
    return PriceDrivenReturnEvidence(passed=adverse_raw_movement >= minimum, adverse_raw_movement=adverse_raw_movement, minimum_required=minimum, provenance=dict(provenance or {}))

# --- ORIGINAL d3_boundary_intelligence/interaction.py ---
from dataclasses import replace

def initial_watch(candidate_id: str, target_trend_episode_id: str, target_direction) -> InteractionEvent:
    return InteractionEvent(event_id=deterministic_id('D3-WATCH', candidate_id, target_trend_episode_id), candidate_id=candidate_id, anchor_episode_id=None, target_trend_episode_id=target_trend_episode_id, target_direction=target_direction, control=InteractionControl.UNARMED, resolution=InteractionResolution.UNRESOLVED, event_reference_boundary=None, event_reference_scale=None, started_at=None, resolved_at=None, armed_at=None, approach_lineage_started_at=None, attempted_wrong_side_acceptance=False, material_wrong_side_separation_observed=False, reclaim_observed=False, break_state=BreakState.NONE, terminal=False, provenance={})

def apply_geometry(event: InteractionEvent, *, geometry: B3Geometry, snapshot: CausalBoundarySnapshot, return_evidence: PriceDrivenReturnEvidence | None) -> InteractionEvent:
    """B3 event-control skeleton preserving no-same-cutoff re-open semantics."""
    if event.terminal or event.control is InteractionControl.RESOLVED:
        return event
    cutoff = geometry.information_cutoff
    if event.control is InteractionControl.UNARMED:
        if geometry.separated:
            return replace(event, control=InteractionControl.ARMED, armed_at=cutoff)
        return event
    if event.control is InteractionControl.ARMED:
        return_ok = return_evidence is not None and return_evidence.passed
        if return_ok and geometry.approach and (event.approach_lineage_started_at is None):
            return replace(event, approach_lineage_started_at=cutoff)
        if return_ok and geometry.test:
            return replace(event, event_id=deterministic_id('D3-INTERACTION', event.candidate_id, str(cutoff), snapshot.snapshot_id), control=InteractionControl.INTERACTION_ACTIVE, started_at=cutoff, approach_lineage_started_at=event.approach_lineage_started_at or cutoff, event_reference_boundary=snapshot.boundary, event_reference_scale=snapshot.source_scale, provenance={'snapshot_id': snapshot.snapshot_id})
        return event
    if geometry.separated and event.break_state not in (BreakState.TEMPORARY_BREAK, BreakState.RECLAIMING) and (not event.attempted_wrong_side_acceptance):
        return replace(event, control=InteractionControl.RESOLVED, resolution=InteractionResolution.RESOLVED_CORRECT_SIDE, resolved_at=cutoff)
    return event

def abort_approach(event: InteractionEvent, *, cutoff: int) -> InteractionEvent:
    if event.control is not InteractionControl.ARMED or event.approach_lineage_started_at is None:
        return event
    return replace(event, control=InteractionControl.RESOLVED, resolution=InteractionResolution.ABORTED_APPROACH, resolved_at=cutoff)

def break_continuity(event: InteractionEvent, *, cutoff: int) -> InteractionEvent:
    if event.control not in (InteractionControl.ARMED, InteractionControl.INTERACTION_ACTIVE):
        return event
    return replace(event, control=InteractionControl.RESOLVED, resolution=InteractionResolution.UNKNOWN_CONTINUITY, resolved_at=cutoff)

def rearm_after_resolution(event: InteractionEvent, *, geometry: B3Geometry) -> InteractionEvent:
    """Start a new independent armed cycle only after a later material re-separation."""
    if event.control is not InteractionControl.RESOLVED:
        return event
    if event.resolved_at is None or geometry.information_cutoff <= event.resolved_at:
        return event
    if not geometry.separated:
        return event
    return InteractionEvent(event_id=deterministic_id('D3-WATCH-REARM', event.candidate_id, event.event_id, str(geometry.information_cutoff)), candidate_id=event.candidate_id, anchor_episode_id=None, target_trend_episode_id=event.target_trend_episode_id, target_direction=event.target_direction, control=InteractionControl.ARMED, resolution=InteractionResolution.UNRESOLVED, event_reference_boundary=None, event_reference_scale=None, started_at=None, resolved_at=None, armed_at=geometry.information_cutoff, approach_lineage_started_at=None, attempted_wrong_side_acceptance=False, material_wrong_side_separation_observed=False, reclaim_observed=False, break_state=BreakState.NONE, terminal=False, provenance={'prior_event_id': event.event_id, 'rearm': 'MATERIAL_CORRECT_SIDE_SEPARATION'})

# --- ORIGINAL d3_boundary_intelligence/breaks.py ---
from dataclasses import replace

def evaluate_break(event: InteractionEvent, *, geometry: B3Geometry, structural_acceptance: StructuralAcceptanceEvidence | None=None, correct_side_recovery: CorrectSideRecoveryEvidence | None=None) -> BreakEvaluation:
    """B4 consumes frozen B3 event reference + D2 confirmed structure evidence."""
    if event.terminal:
        return BreakEvaluation(event.break_state, True, event.resolution, event.attempted_wrong_side_acceptance, event.material_wrong_side_separation_observed, event.reclaim_observed, 'event already terminal')
    if event.control is not InteractionControl.INTERACTION_ACTIVE or event.event_reference_boundary is None:
        if geometry.wrong_side_range_penetration or geometry.wrong_side_close:
            return BreakEvaluation(BreakState.WRONG_SIDE_UNARMED, False, InteractionResolution.UNRESOLVED, False, False, False, 'A5: wrong side without active armed lineage')
        return BreakEvaluation(BreakState.NONE, False, InteractionResolution.UNRESOLVED, False, False, False, 'no active interaction')
    attempted = event.attempted_wrong_side_acceptance or geometry.wrong_side_close
    material = event.material_wrong_side_separation_observed or geometry.material_wrong_side_separation
    reclaim = event.reclaim_observed
    if geometry.wrong_side_range_penetration and (not geometry.wrong_side_close):
        state = BreakState.PROBE
    elif geometry.wrong_side_close:
        state = BreakState.TEMPORARY_BREAK
    else:
        state = event.break_state if event.break_state in (BreakState.TEMPORARY_BREAK, BreakState.RECLAIMING, BreakState.PROBE) else BreakState.NONE
    sa = structural_acceptance or StructuralAcceptanceEvidence()
    if material and (sa.continuation_acceptance or sa.failed_return_acceptance):
        return BreakEvaluation(BreakState.TRUE_BREAK, True, InteractionResolution.RESOLVED_WRONG_SIDE, attempted, True, reclaim, 'material wrong-side separation + completed wrong-side structural acceptance')
    had_temp = event.break_state in (BreakState.TEMPORARY_BREAK, BreakState.RECLAIMING) or attempted
    if had_temp and (not geometry.wrong_side_close):
        reclaim = True
        state = BreakState.RECLAIMING
    cr = correct_side_recovery or CorrectSideRecoveryEvidence()
    if attempted and reclaim and cr.turning_structure_confirmed and cr.material_correct_side_structural_recovery:
        return BreakEvaluation(BreakState.FALSE_BREAK, True, InteractionResolution.RESOLVED_CORRECT_SIDE, True, material, True, 'attempted acceptance + reclaim + confirmed turning structure + material correct-side recovery')
    return BreakEvaluation(state, False, InteractionResolution.UNRESOLVED, attempted, material, reclaim, 'non-terminal B4 state')

def apply_break_evaluation(event: InteractionEvent, evaluation: BreakEvaluation, *, cutoff: int) -> InteractionEvent:
    updated = replace(event, attempted_wrong_side_acceptance=evaluation.attempted_wrong_side_acceptance, material_wrong_side_separation_observed=evaluation.material_wrong_side_separation_observed, reclaim_observed=evaluation.reclaim_observed, break_state=evaluation.break_state, terminal=evaluation.terminal)
    if evaluation.terminal:
        updated = replace(updated, control=InteractionControl.RESOLVED, resolution=evaluation.resolution, resolved_at=cutoff)
    return updated

# --- ORIGINAL d3_boundary_intelligence/anchors.py ---
from dataclasses import replace

def empty_dossier() -> AnchorEvidenceDossier:
    return AnchorEvidenceDossier(boundary_side_integrity=InfoValue.unknown(), structural_integrity=InfoValue.unknown(), slope_alignment=InfoValue.unknown(), independent_retest_evidence=InfoValue.none(), retest_quality=InfoValue.na(), current_relevance=InfoValue.unknown(), true_break_evidence=InfoValue.none(), data_confidence=InfoValue.unknown())

def maybe_start_anchor_episode(candidate: MathematicalBoundaryCandidate, event: InteractionEvent, *, target_trend_active: bool, candidate_terminally_invalidated: bool, cutoff: int) -> AnchorEpisode | None:
    """F1 starts PROVISIONAL only on qualifying armed Approach/Test lineage."""
    if candidate.availability is not CandidateAvailability.AVAILABLE or not target_trend_active or candidate_terminally_invalidated:
        return None
    lineage_started = event.approach_lineage_started_at is not None or event.control is InteractionControl.INTERACTION_ACTIVE
    if not lineage_started:
        return None
    aid = deterministic_id('D3-ANCHOR-EP', candidate.candidate_id, candidate.target_trend_episode_id, str(cutoff))
    return AnchorEpisode(anchor_episode_id=aid, candidate_id=candidate.candidate_id, target_trend_episode_id=candidate.target_trend_episode_id, target_direction=candidate.target_direction, validity=AnchorValidity.PROVISIONAL, activity=AnchorActivity.ACTIVE, started_at=cutoff, ended_at=None, interaction_event_ids=(event.event_id,), qualified_uses=(), terminal_true_break=False, dossier=empty_dossier(), provenance={'candidate_family': candidate.family.value})

def attach_interaction(episode: AnchorEpisode, event: InteractionEvent) -> AnchorEpisode:
    ids = episode.interaction_event_ids
    if event.event_id not in ids:
        ids = ids + (event.event_id,)
    activity = AnchorActivity.PRESSURED if event.control is InteractionControl.INTERACTION_ACTIVE else episode.activity
    return replace(episode, interaction_event_ids=ids, activity=activity)

def add_qualified_boundary_use(episode: AnchorEpisode, use: QualifiedBoundaryUse) -> AnchorEpisode:
    if use.anchor_episode_id != episode.anchor_episode_id:
        raise ValueError('QBU belongs to another Anchor Episode')
    if use.negotiation_event_id not in episode.interaction_event_ids:
        raise ValueError('QBU requires causal interaction lineage in this episode')
    return replace(episode, validity=AnchorValidity.VALID, activity=AnchorActivity.ACTIVE, qualified_uses=episode.qualified_uses + (use,), dossier=replace(episode.dossier, independent_retest_evidence=InfoValue.known('QUALIFIED_BOUNDARY_USE')))

def terminate_for_true_break(episode: AnchorEpisode, *, cutoff: int) -> AnchorEpisode:
    return replace(episode, validity=AnchorValidity.TERMINATED, activity=AnchorActivity.TERMINATED, ended_at=cutoff, terminal_true_break=True, dossier=replace(episode.dossier, true_break_evidence=InfoValue.known(BreakState.TRUE_BREAK.value)))

def recover_from_pressure(episode: AnchorEpisode, event: InteractionEvent) -> AnchorEpisode:
    if episode.validity is AnchorValidity.VALID and event.resolution is InteractionResolution.RESOLVED_CORRECT_SIDE:
        return replace(episode, activity=AnchorActivity.ACTIVE)
    return episode

def terminate_episode(episode: AnchorEpisode, *, cutoff: int, reason: str) -> AnchorEpisode:
    return replace(episode, validity=AnchorValidity.TERMINATED, activity=AnchorActivity.TERMINATED, ended_at=cutoff, provenance={**dict(episode.provenance), 'termination_reason': reason})

def bind_event_to_episode(event: InteractionEvent, episode: AnchorEpisode) -> InteractionEvent:
    if event.candidate_id != episode.candidate_id:
        raise ValueError('event/candidate mismatch')
    return replace(event, anchor_episode_id=episode.anchor_episode_id)

def make_qualified_boundary_use(episode: AnchorEpisode, event: InteractionEvent, progress: TrendSideMinorProgressEvidence) -> QualifiedBoundaryUse:
    if event.anchor_episode_id != episode.anchor_episode_id:
        raise ValueError('event is not attached to this Anchor Episode')
    if event.resolution is not InteractionResolution.RESOLVED_CORRECT_SIDE:
        raise ValueError('Qualified Boundary Use requires correct-side resolved negotiation')
    if event.break_state is BreakState.TRUE_BREAK:
        raise ValueError('True Break cannot qualify as correct-side boundary use')
    if not progress.material_progress or progress.timeframe_ms != 15 * 60 * 1000 or progress.layer != 'MINOR':
        raise ValueError('Qualified Boundary Use requires subsequent material trend-side 15M Minor progress')
    if progress.confirmed_at <= (event.resolved_at or -1):
        raise ValueError('trend-side progress must be subsequent to correct-side resolution')
    return QualifiedBoundaryUse(use_id=deterministic_id('D3-QBU', episode.anchor_episode_id, event.event_id, progress.pivot_id), anchor_episode_id=episode.anchor_episode_id, negotiation_event_id=event.event_id, correct_side_resolution_cutoff=event.resolved_at or 0, trend_side_minor_progress_pivot_id=progress.pivot_id, progress_confirmed_at=progress.confirmed_at)

# --- ORIGINAL d3_boundary_intelligence/clusters_roles.py ---
from fractions import Fraction

def cluster_units(zones: list[BoundaryContactZone]) -> tuple[EconomicBoundaryUnit, ...]:
    """Connected components over already-authoritative causal B3 contact zones.

    No new distance threshold or synthetic cluster center is created.
    """
    if not zones:
        return ()
    remaining = sorted(zones, key=lambda z: (z.lower, z.upper, z.anchor_episode_id))
    components: list[list[BoundaryContactZone]] = []
    current: list[BoundaryContactZone] = [remaining[0]]
    current_upper = remaining[0].upper
    for z in remaining[1:]:
        if z.lower <= current_upper:
            current.append(z)
            if z.upper > current_upper:
                current_upper = z.upper
        else:
            components.append(current)
            current = [z]
            current_upper = z.upper
    components.append(current)
    units: list[EconomicBoundaryUnit] = []
    for comp in components:
        members = tuple(sorted({z.anchor_episode_id for z in comp}))
        unit_id = deterministic_id('D3-EBU', *members, str(max((z.information_cutoff for z in comp))))
        units.append(EconomicBoundaryUnit(unit_id=unit_id, anchor_episode_ids=members, contact_zones=tuple(comp), is_cluster=len(members) > 1, provenance={'geometry': 'CONNECTED_CAUSAL_B3_CONTACT_ZONES_NO_SYNTHETIC_LINE'}))
    return tuple(units)

def unit_intersects_corridor(unit: EconomicBoundaryUnit, corridor: StructuralCorridor | None) -> bool:
    if corridor is None:
        return False
    return any((z.intersects(corridor.lower, corridor.upper) for z in unit.contact_zones))

def unit_intersects_protected_zone(unit: EconomicBoundaryUnit, *, protected_price: Fraction, protected_scale: Fraction, theta_progress: Fraction) -> bool:
    lower = protected_price - theta_progress * protected_scale
    upper = protected_price + theta_progress * protected_scale
    return any((z.intersects(lower, upper) for z in unit.contact_zones))

def current_relevance(unit: EconomicBoundaryUnit, *, corridor: StructuralCorridor | None, has_actual_market_use: bool, active_qualifying_interaction: bool) -> bool:
    return unit_intersects_corridor(unit, corridor) and (has_actual_market_use or active_qualifying_interaction)

def assign_roles(evidence: list[BoundaryUnitRoleEvidence], *, structural_suitable_unit_ids: set[str], prior_primary_unit_id: str | None=None, old_episode_ended: bool=False, takeover_depth_relation: StructuralDepthRelation=StructuralDepthRelation.UNRESOLVED, next_deeper_unit_id: str | None=None) -> RoleAssignment:
    """Event-driven role selection without score/family/distance tie-breaking.

    PRIMARY uses most-recent Qualified Boundary Use. Same-cutoff ambiguity is
    UNRESOLVED. SECONDARY requires an explicit DEEPER structural relation to the
    chosen primary; if several equally admissible units remain, it is UNRESOLVED.
    """
    eligible = [e for e in evidence if e.at_least_one_valid_member and e.current_relevant and (e.latest_qualified_use_cutoff is not None) and (not e.terminal_true_break) and (not e.unresolved_conflict)]
    if not eligible:
        return RoleAssignment(None, None, tuple(sorted(structural_suitable_unit_ids)), RoleTransition.NONE, None)
    latest = max((e.latest_qualified_use_cutoff for e in eligible if e.latest_qualified_use_cutoff is not None))
    primaries = [e for e in eligible if e.latest_qualified_use_cutoff == latest]
    if len(primaries) != 1:
        return RoleAssignment(None, None, tuple(sorted(structural_suitable_unit_ids)), RoleTransition.UNRESOLVED, 'multiple independent units satisfy Primary at same cutoff')
    primary = primaries[0]
    deeper = [e for e in eligible if e.unit.unit_id != primary.unit.unit_id and e.structural_depth_relation_to_primary is StructuralDepthRelation.DEEPER]
    secondary_id: str | None = None
    unresolved: str | None = None
    if deeper:
        if len(deeper) == 1:
            chosen = deeper[0]
        elif next_deeper_unit_id is not None:
            matches = [e for e in deeper if e.unit.unit_id == next_deeper_unit_id]
            chosen = matches[0] if len(matches) == 1 else None
        else:
            chosen = None
        if chosen is None:
            unresolved = 'next-deeper Secondary relation not uniquely established by supplied Price Structure context'
        elif set(chosen.unit.anchor_episode_ids).isdisjoint(primary.unit.anchor_episode_ids):
            secondary_id = chosen.unit.unit_id
    if unresolved is not None:
        transition = RoleTransition.UNRESOLVED
    elif prior_primary_unit_id is None or prior_primary_unit_id == primary.unit.unit_id:
        transition = RoleTransition.NONE
    elif old_episode_ended:
        transition = RoleTransition.REPLACEMENT
    elif takeover_depth_relation is StructuralDepthRelation.DEEPER:
        transition = RoleTransition.PROMOTION
    elif takeover_depth_relation is StructuralDepthRelation.SAME_LAYER:
        transition = RoleTransition.HANDOFF
    else:
        transition = RoleTransition.UNRESOLVED
        unresolved = 'takeover depth relation unresolved'
    return RoleAssignment(primary_unit_id=primary.unit.unit_id, secondary_unit_id=secondary_id, structural_unit_ids=tuple(sorted(structural_suitable_unit_ids)), transition=transition, unresolved_reason=unresolved)

def structural_role_eligible(evidence: BoundaryUnitRoleEvidence, *, protected_price: Fraction, protected_scale: Fraction, theta_progress: Fraction) -> bool:
    """A3/F1/B5 Structural-role gate; role multiplicity remains allowed."""
    return evidence.at_least_one_valid_member and evidence.current_relevant and (evidence.latest_qualified_use_cutoff is not None) and (not evidence.terminal_true_break) and (not evidence.unresolved_conflict) and unit_intersects_protected_zone(evidence.unit, protected_price=protected_price, protected_scale=protected_scale, theta_progress=theta_progress)

# --- ORIGINAL d3_boundary_intelligence/cutoff_contract.py ---
"""D3-owned slices of RC1 F9 global update order only."""
D3_UPDATE_ORDER = ('UPDATE-002_CAPTURE_BAR_T_BOUNDARY_GEOMETRY_FROM_PRE_BAR_SNAPSHOTS', 'UPDATE-007_RESOLVE_UPGRADE_INTERACTION_BREAK_USING_UPDATE002_PLUS_UPDATE005_STRUCTURE', 'UPDATE-008_UPDATE_ANCHOR_CANDIDATE_VALIDITY_CLUSTER_ROLES_FOR_FUTURE_BARS')
FORBIDDEN_D3_WRITES = ('MarketTrend', 'PriceStructure', 'ENTRY_READY', 'RiskFeasibility', 'RiskAnchor', 'Position', 'Exit', 'Execution')
CUTOFF_FIREWALL = {'bar_t_geometry_uses_only_pre_bar_snapshot': True, 'new_bar_t_ema_st_not_back_applied_to_bar_t_high_low': True, 'new_anchor_values_at_t_eligible_only_for_future_observer_bars': True, 'same_bar_resolve_rearm_cannot_open_next_event': True}

# --- ORIGINAL d3_reference.py ---
"""WP3 non-trading D3 reference skeleton.

This orchestrates only D3-owned RC1 slices. It never writes D2 Trend/Price
Structure, D4 Entry, D5 Risk, or D6 Position/Execution truth.
"""
from dataclasses import replace

class D3ReferenceSkeleton:

    def __init__(self, params: FrozenD3Parameters) -> None:
        self.params = params
        self._snapshots: list[CausalBoundarySnapshot] = []
        self._events: dict[str, InteractionEvent] = {}
        self._episodes: dict[str, AnchorEpisode] = {}

    @classmethod
    def from_parameter_snapshot(cls, snapshot: ParameterSnapshot) -> 'D3ReferenceSkeleton':
        return cls(frozen_d3_parameters(snapshot))

    def update_008_register_candidate(self, candidate: MathematicalBoundaryCandidate) -> CausalBoundarySnapshot | None:
        episode = self._episodes.get(candidate.candidate_id)
        snap = snapshot_from_candidate(candidate, anchor_episode_id=episode.anchor_episode_id if episode else None)
        if snap is not None:
            self._snapshots.append(snap)
        if candidate.candidate_id not in self._events:
            self._events[candidate.candidate_id] = initial_watch(candidate.candidate_id, candidate.target_trend_episode_id, candidate.target_direction)
        return snap

    def update_000_pre_bar_view(self, observer_open_time: int) -> PreBarBoundaryView:
        return pre_bar_view(observer_open_time, self._snapshots)

    def update_002_capture_geometry(self, *, bar: OHLCBar, information_cutoff: int, snapshot: CausalBoundarySnapshot) -> B3Geometry:
        event = self._events[snapshot.candidate_id]
        if event.control is InteractionControl.INTERACTION_ACTIVE and event.event_reference_boundary is not None:
            return classify_event_reference_geometry(bar=bar, information_cutoff=information_cutoff, event=event, params=self.params)
        return classify_geometry(bar=bar, information_cutoff=information_cutoff, snapshot=snapshot, params=self.params)

    def update_007_interaction_break(self, *, snapshot: CausalBoundarySnapshot, geometry: B3Geometry, return_evidence: PriceDrivenReturnEvidence | None, structural_acceptance: StructuralAcceptanceEvidence | None=None, correct_side_recovery: CorrectSideRecoveryEvidence | None=None) -> InteractionEvent:
        event = self._events[snapshot.candidate_id]
        if event.control is InteractionControl.RESOLVED:
            event = rearm_after_resolution(event, geometry=geometry)
            self._events[snapshot.candidate_id] = event
            if event.control is InteractionControl.ARMED:
                return event
        event = apply_geometry(event, geometry=geometry, snapshot=snapshot, return_evidence=return_evidence)
        evaluation = evaluate_break(event, geometry=geometry, structural_acceptance=structural_acceptance, correct_side_recovery=correct_side_recovery)
        event = apply_break_evaluation(event, evaluation, cutoff=geometry.information_cutoff)
        if not event.terminal:
            event = apply_geometry(event, geometry=geometry, snapshot=snapshot, return_evidence=return_evidence)
        self._events[snapshot.candidate_id] = event
        episode = self._episodes.get(snapshot.candidate_id)
        if episode is not None:
            episode = attach_interaction(episode, event)
            if event.break_state is BreakState.TRUE_BREAK and event.terminal:
                episode = terminate_for_true_break(episode, cutoff=geometry.information_cutoff)
            else:
                episode = recover_from_pressure(episode, event)
            self._episodes[snapshot.candidate_id] = episode
        return event

    def update_008_anchor_lifecycle(self, *, candidate: MathematicalBoundaryCandidate, target_trend_active: bool, candidate_terminally_invalidated: bool, cutoff: int) -> AnchorEpisode | None:
        existing = self._episodes.get(candidate.candidate_id)
        if existing is not None and existing.validity.value != 'TERMINATED':
            return existing
        event = self._events[candidate.candidate_id]
        episode = maybe_start_anchor_episode(candidate, event, target_trend_active=target_trend_active, candidate_terminally_invalidated=candidate_terminally_invalidated, cutoff=cutoff)
        if episode is not None:
            event = bind_event_to_episode(event, episode)
            self._events[candidate.candidate_id] = event
            self._episodes[candidate.candidate_id] = episode
        return episode

    def continuity_break(self, candidate_id: str, *, cutoff: int) -> InteractionEvent:
        event = break_continuity(self._events[candidate_id], cutoff=cutoff)
        self._events[candidate_id] = event
        episode = self._episodes.get(candidate_id)
        if episode is not None and episode.validity.value != 'TERMINATED':
            from .d3_boundary_intelligence.anchors import terminate_episode
            self._episodes[candidate_id] = terminate_episode(episode, cutoff=cutoff, reason='SOURCE_CONTINUITY_BREAK')
        return event

    def current_event(self, candidate_id: str) -> InteractionEvent:
        return self._events[candidate_id]

    def current_episode(self, candidate_id: str) -> AnchorEpisode | None:
        return self._episodes.get(candidate_id)

# --- ORIGINAL d4_opportunity/types.py ---
from dataclasses import dataclass, field
from enum import Enum
from fractions import Fraction
from typing import Mapping

class OpportunityLifecycle(str, Enum):
    """WP4-owned lifecycle subset only.

    ENTRY_READY / EXECUTED deliberately do not exist in this WP4 enum because
    B7-B and execution are outside the authorized stage.
    """
    CANDIDATE = 'CANDIDATE'
    SETUP_ACTIVE = 'SETUP_ACTIVE'
    WAIT_CONFIRMATION = 'WAIT_CONFIRMATION'
    INVALIDATED = 'INVALIDATED'
    EXPIRED = 'EXPIRED'

class OpportunityMechanism(str, Enum):
    NORMAL_RETEST_CONTINUATION = 'NORMAL_RETEST_CONTINUATION'
    FALSE_BREAK_RECLAIM = 'FALSE_BREAK_RECLAIM'
    PLATFORM_REEXPANSION = 'PLATFORM_REEXPANSION'
    DEEP_STRUCTURE_TAKEOVER = 'DEEP_STRUCTURE_TAKEOVER'
    TREND_ESTABLISHMENT_WATCH_ONLY = 'TREND_ESTABLISHMENT_WATCH_ONLY'

class GateName(str, Enum):
    MARKET_ELIGIBILITY = 'MARKET_ELIGIBILITY'
    LOCATION_ELIGIBILITY = 'LOCATION_ELIGIBILITY'
    BEHAVIOR_CONFIRMATION = 'BEHAVIOR_CONFIRMATION'

@dataclass(frozen=True)
class GateEvaluation:
    gate: GateName
    result: InfoValue[bool]
    reason: str

@dataclass(frozen=True)
class EntryBoundaryView:
    unit_id: str
    member_anchor_episode_ids: tuple[str, ...]
    valid_active: bool
    target_trend_episode_id: str
    target_direction: TrendDirection
    provenance: Mapping[str, str] = field(default_factory=dict)

@dataclass(frozen=True)
class LocalTrendControlRegainEvidence:
    """Causal D2 evidence interface consumed by D4.

    RC1 defines the semantic sequence but does not introduce another numeric
    threshold for the final material closed-price recovery. WP4 therefore does
    not invent one. The two semantic predicates below must be supplied from
    already-authoritative D2 price-structure evidence/provenance.
    """
    direction: TrendDirection
    adverse_reference_pivot_id: str
    adverse_reference_confirmed_at: int
    recovery_pivot_id: str
    recovery_pivot_confirmed_at: int
    countertrend_progression_failed: InfoValue[bool]
    material_original_direction_closed_price_recovery: InfoValue[bool]
    confirmation_cutoff: int
    provenance: Mapping[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.direction not in (TrendDirection.LONG, TrendDirection.SHORT):
            raise ValueError('Local Trend-Control Regain requires LONG/SHORT')
        if not self.adverse_reference_pivot_id or not self.recovery_pivot_id:
            raise ValueError('Local Trend-Control Regain requires causal pivot references')
        if self.adverse_reference_confirmed_at > self.confirmation_cutoff:
            raise ValueError('future adverse reference cannot be consumed')
        if self.recovery_pivot_confirmed_at > self.confirmation_cutoff:
            raise ValueError('future recovery pivot cannot be consumed')
        if self.recovery_pivot_confirmed_at < self.adverse_reference_confirmed_at:
            raise ValueError('recovery pivot cannot predate adverse reference confirmation')

@dataclass(frozen=True)
class MechanismObservation:
    mechanism: OpportunityMechanism
    candidate: bool
    setup_active: bool
    wait_confirmation: bool
    behavior_confirmation: InfoValue[bool]
    location_qualified: InfoValue[bool]
    setup_lineage: tuple[str, ...]
    source_event_ids: tuple[str, ...]
    watch_only: bool = False
    provenance: Mapping[str, str] = field(default_factory=dict)

    @property
    def active(self) -> bool:
        return self.candidate or self.setup_active or self.wait_confirmation or (self.behavior_confirmation.value is True)

@dataclass(frozen=True)
class OpportunityState:
    opportunity_id: str
    trend_episode_id: str
    direction: TrendDirection
    market_event_id: str
    lifecycle: OpportunityLifecycle
    mechanism_history: tuple[OpportunityMechanism, ...]
    primary_mechanism: OpportunityMechanism
    entry_boundary_unit_id: str | None
    entry_boundary_member_anchor_episode_ids: tuple[str, ...]
    created_at: int
    updated_at: int
    setup_lineage: tuple[str, ...]
    detector_evidence_ids: tuple[str, ...]
    confirmation_candidate_ids: tuple[str, ...] = ()
    confirmation_mechanism_history: tuple[OpportunityMechanism, ...] = ()
    terminated_at: int | None = None
    termination_reason: str | None = None
    provenance: Mapping[str, str] = field(default_factory=dict)

    @property
    def terminal(self) -> bool:
        return self.lifecycle in (OpportunityLifecycle.INVALIDATED, OpportunityLifecycle.EXPIRED)

@dataclass(frozen=True)
class BehaviorConfirmationCandidate:
    """B7-A pre-risk confirmation candidate only; never ENTRY_READY."""
    candidate_id: str
    opportunity_id: str
    trend_episode_id: str
    direction: TrendDirection
    market_event_id: str
    mechanism: OpportunityMechanism
    setup_lineage: tuple[str, ...]
    entry_boundary_unit_id: str | None
    entry_boundary_member_anchor_episode_ids: tuple[str, ...]
    behavior_confirmation: InfoValue[bool]
    confirmation_cutoff: int
    source_event_ids: tuple[str, ...]
    same_cutoff_only: bool = True
    provenance: Mapping[str, str] = field(default_factory=dict)

@dataclass(frozen=True)
class OpportunityIndependenceEvidence:
    previous_opportunity_terminated: bool
    material_trend_side_reseparation_or_control: bool
    new_independent_countertrend_or_boundary_return_event: bool
    provenance: Mapping[str, str] = field(default_factory=dict)

@dataclass(frozen=True)
class OpportunityTerminationEvidence:
    trend_episode_ended: bool = False
    entry_boundary_terminal_true_break_without_false_break_recovery: bool = False
    mechanism_required_structure_materially_failed: bool = False
    critical_role_or_structure_replaced_destroying_thesis: bool = False
    irrecoverable_continuity_end: bool = False
    event_cycle_completed_and_new_independent_event_rearmed: bool = False
    downstream_actionable_entry_absent: InfoValue[bool] = field(default_factory=InfoValue.unknown)
    other_same_cutoff_non_thesis_gate_failed_after_confirmation: bool = False
    independent_open_mechanism_after_consumed_confirmation: bool = False
    provenance: Mapping[str, str] = field(default_factory=dict)

@dataclass(frozen=True)
class D4CutoffView:
    information_cutoff: int
    opportunity: OpportunityState | None
    primary_observation: MechanismObservation | None
    market_eligibility: GateEvaluation
    location_eligibility: GateEvaluation
    behavior_confirmation: GateEvaluation
    confirmation_candidate: BehaviorConfirmationCandidate | None
    update_step: str = 'UPDATE-011'

# --- ORIGINAL d4_opportunity/parameters.py ---
from dataclasses import dataclass
from fractions import Fraction

@dataclass(frozen=True)
class FrozenD4Parameters:
    theta_progress: Fraction

    def __post_init__(self) -> None:
        if self.theta_progress < 0:
            raise ValueError('theta_progress must be nonnegative')

def frozen_d4_parameters(snapshot: ParameterSnapshot) -> FrozenD4Parameters:
    slot = snapshot.slot('theta_progress')
    if slot.state is not ParameterState.FROZEN or slot.exact_value is None:
        raise ValueError('theta_progress must be FROZEN with exact value for WP4')
    return FrozenD4Parameters(theta_progress=Fraction(slot.exact_value))

# --- ORIGINAL d4_opportunity/control_regain.py ---
def evaluate_local_trend_control_regain(evidence: LocalTrendControlRegainEvidence) -> InfoValue[bool]:
    """Combine the two RC1 D2 structural predicates without inventing a new threshold."""
    left = evidence.countertrend_progression_failed
    right = evidence.material_original_direction_closed_price_recovery
    if left.kind is InfoKind.ERROR:
        return InfoValue.error(left.error_ref or 'LOCAL_CONTROL_COUNTERTREND_ERROR')
    if right.kind is InfoKind.ERROR:
        return InfoValue.error(right.error_ref or 'LOCAL_CONTROL_RECOVERY_ERROR')
    if left.kind is InfoKind.UNKNOWN or right.kind is InfoKind.UNKNOWN:
        return InfoValue.unknown()
    if left.kind is InfoKind.NA or right.kind is InfoKind.NA:
        return InfoValue.na()
    if left.kind is InfoKind.NONE or right.kind is InfoKind.NONE:
        return InfoValue.none()
    return InfoValue.known(bool(left.value and right.value))

# --- ORIGINAL d4_opportunity/eligibility.py ---
from collections.abc import Mapping

def _propagate_nonknown_bool(value: InfoValue[bool]) -> InfoValue[bool]:
    if value.kind is InfoKind.ERROR:
        return InfoValue.error(value.error_ref or 'D4_GATE_INPUT_ERROR')
    if value.kind is InfoKind.UNKNOWN:
        return InfoValue.unknown()
    if value.kind is InfoKind.NA:
        return InfoValue.na()
    if value.kind is InfoKind.NONE:
        return InfoValue.none()
    return value

def market_eligibility(trend: TrendEpisodeState, *, opportunity_direction: TrendDirection, critical_information_known: InfoValue[bool], watch_only: bool=False) -> GateEvaluation:
    if watch_only:
        return GateEvaluation(GateName.MARKET_ELIGIBILITY, InfoValue.na(), 'TREND_ESTABLISHMENT_WATCH_ONLY')
    info = _propagate_nonknown_bool(critical_information_known)
    if info.kind is not InfoKind.KNOWN:
        return GateEvaluation(GateName.MARKET_ELIGIBILITY, info, 'CRITICAL_INFORMATION_NOT_KNOWN')
    if info.value is not True:
        return GateEvaluation(GateName.MARKET_ELIGIBILITY, InfoValue.known(False), 'CRITICAL_INFORMATION_BLOCK')
    if trend.direction not in (TrendDirection.LONG, TrendDirection.SHORT) or trend.episode_id is None:
        return GateEvaluation(GateName.MARKET_ELIGIBILITY, InfoValue.known(False), 'NO_ACTIVE_TREND_EPISODE')
    if trend.direction is not opportunity_direction:
        return GateEvaluation(GateName.MARKET_ELIGIBILITY, InfoValue.known(False), 'TREND_DIRECTION_MISMATCH')
    if trend.integrity in (TrendIntegrity.DETERIORATING, TrendIntegrity.FAILED):
        return GateEvaluation(GateName.MARKET_ELIGIBILITY, InfoValue.known(False), f'TREND_INTEGRITY_{trend.integrity.value}')
    if trend.integrity in (TrendIntegrity.HEALTHY, TrendIntegrity.PRESSURED):
        return GateEvaluation(GateName.MARKET_ELIGIBILITY, InfoValue.known(True), 'ACTIVE_MATCHING_TREND_ELIGIBLE')
    return GateEvaluation(GateName.MARKET_ELIGIBILITY, InfoValue.unknown(), 'TREND_INTEGRITY_UNKNOWN')

def location_eligibility(trend_position: TrendPositionResult, *, mechanism_location_qualified: InfoValue[bool], watch_only: bool=False) -> GateEvaluation:
    if watch_only:
        return GateEvaluation(GateName.LOCATION_ELIGIBILITY, InfoValue.na(), 'TREND_ESTABLISHMENT_WATCH_ONLY')
    if trend_position.position is TrendPosition.OVEREXTENDED:
        return GateEvaluation(GateName.LOCATION_ELIGIBILITY, InfoValue.known(False), 'OVEREXTENDED')
    value = _propagate_nonknown_bool(mechanism_location_qualified)
    if value.kind is InfoKind.KNOWN:
        return GateEvaluation(GateName.LOCATION_ELIGIBILITY, value, 'MECHANISM_LOCATION_QUALIFIED' if value.value else 'MECHANISM_LOCATION_NOT_QUALIFIED')
    return GateEvaluation(GateName.LOCATION_ELIGIBILITY, value, 'MECHANISM_LOCATION_UNRESOLVED')

def entry_boundary_view(unit: EconomicBoundaryUnit | None, episodes: Mapping[str, AnchorEpisode], *, target_trend_episode_id: str, target_direction: TrendDirection, information_cutoff: int) -> EntryBoundaryView | None:
    if unit is None:
        return None
    members = tuple(unit.anchor_episode_ids)
    if any((z.information_cutoff > information_cutoff for z in unit.contact_zones)):
        raise ValueError('D4_CANNOT_CONSUME_FUTURE_BOUNDARY_UNIT_GEOMETRY')
    valid_members: list[AnchorEpisode] = []
    for aid in members:
        ep = episodes.get(aid)
        if ep is None:
            continue
        if ep.started_at > information_cutoff or (ep.ended_at is not None and ep.ended_at > information_cutoff):
            raise ValueError('D4_CANNOT_CONSUME_FUTURE_ANCHOR_EPISODE_STATE')
        if ep.target_trend_episode_id != target_trend_episode_id or ep.target_direction is not target_direction:
            continue
        if ep.validity is AnchorValidity.VALID and ep.activity in (AnchorActivity.ACTIVE, AnchorActivity.PRESSURED) and (not ep.terminal_true_break) and (ep.ended_at is None):
            valid_members.append(ep)
    return EntryBoundaryView(unit_id=unit.unit_id, member_anchor_episode_ids=members, valid_active=bool(valid_members), target_trend_episode_id=target_trend_episode_id, target_direction=target_direction, provenance={'unit_semantics': 'D3_ECONOMIC_BOUNDARY_UNIT', 'member_selection': 'NO_MEMBER_WINNER_INVENTED', 'valid_active_member_count': str(len(valid_members))})

# --- ORIGINAL d4_opportunity/mechanisms.py ---
from dataclasses import dataclass, field
from fractions import Fraction
from typing import Mapping

@dataclass(frozen=True)
class NormalRetestEvidence:
    interaction: InteractionEvent
    qualifying_retest_or_probe: bool
    adverse_structural_reference_fixed: bool
    local_control_regain: LocalTrendControlRegainEvidence | None
    setup_lineage: tuple[str, ...]
    provenance: Mapping[str, str] = field(default_factory=dict)

@dataclass(frozen=True)
class FalseBreakReclaimEvidence:
    interaction: InteractionEvent
    setup_lineage: tuple[str, ...]
    provenance: Mapping[str, str] = field(default_factory=dict)

@dataclass(frozen=True)
class PlatformReexpansionEvidence:
    platform: PlatformState
    current_close: Fraction
    target_trend_episode_id: str
    direction: TrendDirection
    setup_lineage: tuple[str, ...]
    provenance: Mapping[str, str] = field(default_factory=dict)

@dataclass(frozen=True)
class DeepStructureTakeoverEvidence:
    shallow_operating_defense_no_longer_completes_setup: bool
    deeper_boundary_independent: bool
    deeper_interaction: InteractionEvent | None
    local_control_regain: LocalTrendControlRegainEvidence | None
    role_transition: RoleTransition
    promotion_confirmed_at: int | None
    setup_lineage: tuple[str, ...]
    provenance: Mapping[str, str] = field(default_factory=dict)

@dataclass(frozen=True)
class TrendEstablishmentWatchEvidence:
    observed: bool
    setup_lineage: tuple[str, ...]
    source_event_ids: tuple[str, ...]
    provenance: Mapping[str, str] = field(default_factory=dict)

def _market_pass(value: InfoValue[bool]) -> bool:
    return value.kind is InfoKind.KNOWN and value.value is True

def _validate_interaction_lineage(event: InteractionEvent, *, direction: TrendDirection, trend_episode_id: str, information_cutoff: int) -> None:
    if event.target_direction is not direction or event.target_trend_episode_id != trend_episode_id:
        raise ValueError('D4_INTERACTION_LINEAGE_MISMATCH')
    for value in (event.started_at, event.armed_at, event.approach_lineage_started_at, event.resolved_at):
        if value is not None and value > information_cutoff:
            raise ValueError('D4_CANNOT_CONSUME_FUTURE_INTERACTION_STATE')

def _current_or_historical_regain(evidence: LocalTrendControlRegainEvidence | None, *, direction: TrendDirection, information_cutoff: int, emit_only_if_current: bool) -> InfoValue[bool]:
    if evidence is None:
        return InfoValue.none()
    if evidence.direction is not direction:
        raise ValueError('D4_LOCAL_CONTROL_DIRECTION_MISMATCH')
    if evidence.confirmation_cutoff > information_cutoff:
        raise ValueError('D4_CANNOT_CONSUME_FUTURE_LOCAL_CONTROL_REGAIN')
    value = evaluate_local_trend_control_regain(evidence)
    if emit_only_if_current and evidence.confirmation_cutoff < information_cutoff and (value.kind is InfoKind.KNOWN) and (value.value is True):
        return InfoValue.none()
    return value

def normal_retest_observation(evidence: NormalRetestEvidence, *, direction: TrendDirection, trend_episode_id: str, information_cutoff: int, market_gate: InfoValue[bool], entry_boundary: EntryBoundaryView | None) -> MechanismObservation:
    valid_boundary = entry_boundary is not None and entry_boundary.valid_active
    event = evidence.interaction
    _validate_interaction_lineage(event, direction=direction, trend_episode_id=trend_episode_id, information_cutoff=information_cutoff)
    qualifying_lineage = event.control in (InteractionControl.ARMED, InteractionControl.INTERACTION_ACTIVE, InteractionControl.RESOLVED) and event.approach_lineage_started_at is not None and (event.break_state in (BreakState.NONE, BreakState.PROBE))
    candidate = _market_pass(market_gate) and valid_boundary and qualifying_lineage
    setup = candidate and evidence.qualifying_retest_or_probe
    regain = InfoValue.none()
    if setup and evidence.adverse_structural_reference_fixed:
        regain = _current_or_historical_regain(evidence.local_control_regain, direction=direction, information_cutoff=information_cutoff, emit_only_if_current=True)
    wait = setup and evidence.adverse_structural_reference_fixed and (not (regain.kind is InfoKind.KNOWN and regain.value is True))
    return MechanismObservation(mechanism=OpportunityMechanism.NORMAL_RETEST_CONTINUATION, candidate=candidate, setup_active=setup, wait_confirmation=wait, behavior_confirmation=regain, location_qualified=InfoValue.known(valid_boundary and setup), setup_lineage=evidence.setup_lineage, source_event_ids=(event.event_id,), provenance={**dict(evidence.provenance), 'semantic': 'RETEST_OR_PROBE_PLUS_LOCAL_CONTROL_REGAIN'})

def false_break_reclaim_observation(evidence: FalseBreakReclaimEvidence, *, direction: TrendDirection, trend_episode_id: str, information_cutoff: int, market_gate: InfoValue[bool], entry_boundary: EntryBoundaryView | None) -> MechanismObservation:
    valid_boundary = entry_boundary is not None and entry_boundary.valid_active
    _validate_interaction_lineage(evidence.interaction, direction=direction, trend_episode_id=trend_episode_id, information_cutoff=information_cutoff)
    state = evidence.interaction.break_state
    candidate_state = state in (BreakState.TEMPORARY_BREAK, BreakState.RECLAIMING, BreakState.FALSE_BREAK)
    candidate = _market_pass(market_gate) and valid_boundary and candidate_state
    setup = candidate and state in (BreakState.RECLAIMING, BreakState.FALSE_BREAK)
    confirmed = setup and state is BreakState.FALSE_BREAK and (evidence.interaction.resolved_at == information_cutoff)
    behavior = InfoValue.known(True) if confirmed else InfoValue.none()
    wait = setup and (not confirmed)
    return MechanismObservation(mechanism=OpportunityMechanism.FALSE_BREAK_RECLAIM, candidate=candidate, setup_active=setup, wait_confirmation=wait, behavior_confirmation=behavior, location_qualified=InfoValue.known(valid_boundary and setup), setup_lineage=evidence.setup_lineage, source_event_ids=(evidence.interaction.event_id,), provenance={**dict(evidence.provenance), 'semantic': 'B4_FALSE_BREAK_ONLY; PROBE_ALONE_NEVER_CONFIRMS'})

def platform_reexpansion_observation(evidence: PlatformReexpansionEvidence, *, direction: TrendDirection, trend_episode_id: str, information_cutoff: int, market_gate: InfoValue[bool], entry_boundary: EntryBoundaryView | None, theta_progress: Fraction) -> MechanismObservation:
    valid_boundary = entry_boundary is not None and entry_boundary.valid_active
    if evidence.direction is not direction or evidence.target_trend_episode_id != trend_episode_id:
        raise ValueError('D4_PLATFORM_LINEAGE_MISMATCH')
    state = evidence.platform
    if state.confirmed_at is not None and state.confirmed_at > information_cutoff:
        raise ValueError('D4_CANNOT_CONSUME_FUTURE_PLATFORM_STATE')
    candidate = _market_pass(market_gate) and state.status in (PlatformStatus.PLATFORM_CANDIDATE, PlatformStatus.PLATFORM_CONFIRMED)
    setup = candidate and state.status is PlatformStatus.PLATFORM_CONFIRMED and valid_boundary
    behavior: InfoValue[bool] = InfoValue.none()
    if setup:
        if state.platform_cap_price is None or state.platform_scale is None:
            behavior = InfoValue.error('PLATFORM_CONFIRMED_MISSING_FROZEN_CAP_OR_SCALE')
        elif direction is TrendDirection.LONG:
            behavior = InfoValue.known(evidence.current_close > state.platform_cap_price + theta_progress * state.platform_scale)
        elif direction is TrendDirection.SHORT:
            behavior = InfoValue.known(evidence.current_close < state.platform_cap_price - theta_progress * state.platform_scale)
        else:
            behavior = InfoValue.na()
    wait = setup and (not (behavior.kind is InfoKind.KNOWN and behavior.value is True))
    return MechanismObservation(mechanism=OpportunityMechanism.PLATFORM_REEXPANSION, candidate=candidate, setup_active=setup, wait_confirmation=wait, behavior_confirmation=behavior, location_qualified=InfoValue.known(valid_boundary and setup), setup_lineage=evidence.setup_lineage, source_event_ids=tuple(state.contributing_event_ids), provenance={**dict(evidence.provenance), 'semantic': 'FROZEN_PLATFORM_CAP_STRICT_ESCAPE'})

def deep_structure_takeover_observation(evidence: DeepStructureTakeoverEvidence, *, direction: TrendDirection, trend_episode_id: str, information_cutoff: int, market_gate: InfoValue[bool], entry_boundary: EntryBoundaryView | None) -> MechanismObservation:
    valid_boundary = entry_boundary is not None and entry_boundary.valid_active
    if evidence.deeper_interaction is not None:
        _validate_interaction_lineage(evidence.deeper_interaction, direction=direction, trend_episode_id=trend_episode_id, information_cutoff=information_cutoff)
    interaction_active = evidence.deeper_interaction is not None and evidence.deeper_interaction.control in (InteractionControl.ARMED, InteractionControl.INTERACTION_ACTIVE, InteractionControl.RESOLVED)
    candidate = _market_pass(market_gate) and valid_boundary and evidence.shallow_operating_defense_no_longer_completes_setup and evidence.deeper_boundary_independent
    setup = candidate and interaction_active
    regain: InfoValue[bool] = InfoValue.none()
    if setup:
        regain = _current_or_historical_regain(evidence.local_control_regain, direction=direction, information_cutoff=information_cutoff, emit_only_if_current=False)
    if evidence.promotion_confirmed_at is not None and evidence.promotion_confirmed_at > information_cutoff:
        raise ValueError('D4_CANNOT_CONSUME_FUTURE_PROMOTION')
    promotion = evidence.role_transition is RoleTransition.PROMOTION and evidence.promotion_confirmed_at is not None
    latest_required_cutoff = max(evidence.local_control_regain.confirmation_cutoff if evidence.local_control_regain is not None else -1, evidence.promotion_confirmed_at if evidence.promotion_confirmed_at is not None else -1)
    if regain.kind is InfoKind.ERROR:
        behavior = regain
    elif regain.kind is InfoKind.UNKNOWN:
        behavior = InfoValue.unknown()
    elif regain.kind is InfoKind.NA:
        behavior = InfoValue.na()
    elif regain.kind is InfoKind.NONE:
        behavior = InfoValue.none()
    else:
        passed = bool(regain.value and promotion)
        behavior = InfoValue.known(True) if passed and latest_required_cutoff == information_cutoff else InfoValue.none() if passed else InfoValue.known(False)
    wait = setup and (not (behavior.kind is InfoKind.KNOWN and behavior.value is True))
    event_ids = () if evidence.deeper_interaction is None else (evidence.deeper_interaction.event_id,)
    return MechanismObservation(mechanism=OpportunityMechanism.DEEP_STRUCTURE_TAKEOVER, candidate=candidate, setup_active=setup, wait_confirmation=wait, behavior_confirmation=behavior, location_qualified=InfoValue.known(valid_boundary and setup), setup_lineage=evidence.setup_lineage, source_event_ids=event_ids, provenance={**dict(evidence.provenance), 'semantic': 'LOCAL_CONTROL_REGAIN_AND_B5_PROMOTION'})

def trend_establishment_watch_observation(evidence: TrendEstablishmentWatchEvidence) -> MechanismObservation:
    return MechanismObservation(mechanism=OpportunityMechanism.TREND_ESTABLISHMENT_WATCH_ONLY, candidate=evidence.observed, setup_active=False, wait_confirmation=False, behavior_confirmation=InfoValue.na(), location_qualified=InfoValue.na(), setup_lineage=evidence.setup_lineage, source_event_ids=evidence.source_event_ids, watch_only=True, provenance={**dict(evidence.provenance), 'semantic': 'WATCH_ONLY_NEVER_EXECUTABLE'})
_EXECUTABLE_PRECEDENCE = (OpportunityMechanism.DEEP_STRUCTURE_TAKEOVER, OpportunityMechanism.PLATFORM_REEXPANSION, OpportunityMechanism.FALSE_BREAK_RECLAIM, OpportunityMechanism.NORMAL_RETEST_CONTINUATION)

def select_primary_observation(observations: tuple[MechanismObservation, ...]) -> MechanismObservation | None:
    active = [o for o in observations if o.active]
    if not active:
        return None
    by_mech = {o.mechanism: o for o in active}
    deep = by_mech.get(OpportunityMechanism.DEEP_STRUCTURE_TAKEOVER)
    if deep is not None and deep.setup_active:
        return deep
    if OpportunityMechanism.PLATFORM_REEXPANSION in by_mech and by_mech[OpportunityMechanism.PLATFORM_REEXPANSION].setup_active:
        return by_mech[OpportunityMechanism.PLATFORM_REEXPANSION]
    fbr = by_mech.get(OpportunityMechanism.FALSE_BREAK_RECLAIM)
    normal = by_mech.get(OpportunityMechanism.NORMAL_RETEST_CONTINUATION)
    if fbr is not None and fbr.behavior_confirmation.kind is InfoKind.KNOWN and (fbr.behavior_confirmation.value is True):
        return fbr
    if normal is not None:
        return normal
    if fbr is not None:
        return fbr
    platform = by_mech.get(OpportunityMechanism.PLATFORM_REEXPANSION)
    if platform is not None:
        return platform
    if deep is not None:
        return deep
    watch = by_mech.get(OpportunityMechanism.TREND_ESTABLISHMENT_WATCH_ONLY)
    return watch

def canonical_active_mechanisms(observations: tuple[MechanismObservation, ...]) -> tuple[OpportunityMechanism, ...]:
    active = {o.mechanism for o in observations if o.active}
    order = (OpportunityMechanism.NORMAL_RETEST_CONTINUATION, OpportunityMechanism.FALSE_BREAK_RECLAIM, OpportunityMechanism.PLATFORM_REEXPANSION, OpportunityMechanism.DEEP_STRUCTURE_TAKEOVER, OpportunityMechanism.TREND_ESTABLISHMENT_WATCH_ONLY)
    return tuple((m for m in order if m in active))

# --- ORIGINAL d4_opportunity/confirmation.py ---
from dataclasses import replace

class StaleConfirmationError(RuntimeError):
    pass

def make_behavior_confirmation_candidate(opportunity: OpportunityState, observation: MechanismObservation, *, information_cutoff: int) -> tuple[OpportunityState, BehaviorConfirmationCandidate | None]:
    if observation.watch_only or observation.mechanism is OpportunityMechanism.TREND_ESTABLISHMENT_WATCH_ONLY:
        return (opportunity, None)
    if observation.behavior_confirmation.kind is not InfoKind.KNOWN or observation.behavior_confirmation.value is not True:
        return (opportunity, None)
    if observation.mechanism in opportunity.confirmation_mechanism_history:
        return (opportunity, None)
    cid = deterministic_id('D4-B7A-CONFIRMATION', opportunity.opportunity_id, observation.mechanism.value, str(information_cutoff), *observation.source_event_ids)
    candidate = BehaviorConfirmationCandidate(candidate_id=cid, opportunity_id=opportunity.opportunity_id, trend_episode_id=opportunity.trend_episode_id, direction=opportunity.direction, market_event_id=opportunity.market_event_id, mechanism=observation.mechanism, setup_lineage=observation.setup_lineage, entry_boundary_unit_id=opportunity.entry_boundary_unit_id, entry_boundary_member_anchor_episode_ids=opportunity.entry_boundary_member_anchor_episode_ids, behavior_confirmation=InfoValue.known(True), confirmation_cutoff=information_cutoff, source_event_ids=observation.source_event_ids, provenance={'stage': 'B7-A_PRE_RISK_ONLY', 'no_risk_feasibility': 'true', 'no_entry_ready': 'true'})
    if cid in opportunity.confirmation_candidate_ids:
        return (opportunity, candidate)
    return (replace(opportunity, confirmation_candidate_ids=opportunity.confirmation_candidate_ids + (cid,), confirmation_mechanism_history=opportunity.confirmation_mechanism_history + (observation.mechanism,), updated_at=information_cutoff), candidate)

def require_same_cutoff(candidate: BehaviorConfirmationCandidate, information_cutoff: int) -> None:
    if information_cutoff != candidate.confirmation_cutoff:
        raise StaleConfirmationError(f'B7A_CONFIRMATION_STALE: candidate cutoff={candidate.confirmation_cutoff}, requested={information_cutoff}')

# --- ORIGINAL d4_opportunity/opportunity.py ---
from dataclasses import replace

class OpportunityIndependenceBlock(RuntimeError):
    pass

def _lifecycle_from_observation(obs: MechanismObservation) -> OpportunityLifecycle:
    if obs.wait_confirmation or obs.behavior_confirmation.value is True:
        return OpportunityLifecycle.WAIT_CONFIRMATION
    if obs.setup_active:
        return OpportunityLifecycle.SETUP_ACTIVE
    return OpportunityLifecycle.CANDIDATE

def _merge_history(prior: tuple[OpportunityMechanism, ...], observations: tuple[MechanismObservation, ...]) -> tuple[OpportunityMechanism, ...]:
    out = list(prior)
    for mech in canonical_active_mechanisms(observations):
        if mech not in out:
            out.append(mech)
    return tuple(out)

def open_or_update_opportunity(*, existing: OpportunityState | None, trend_episode_id: str, direction, market_event_id: str, information_cutoff: int, primary_observation: MechanismObservation, observations: tuple[MechanismObservation, ...], detector_evidence_ids: tuple[str, ...], entry_boundary: EntryBoundaryView | None, independence: OpportunityIndependenceEvidence | None) -> OpportunityState:
    """Identity follows market-event lineage; detector count never changes the ID."""
    if existing is not None and (not existing.terminal):
        if existing.trend_episode_id != trend_episode_id or existing.direction is not direction:
            raise OpportunityIndependenceBlock('ACTIVE_OPPORTUNITY_TREND_LINEAGE_MISMATCH')
        if existing.market_event_id != market_event_id:
            raise OpportunityIndependenceBlock('ACTIVE_OPPORTUNITY_MUST_TERMINATE_BEFORE_NEW_MARKET_EVENT')
        return replace(existing, lifecycle=_lifecycle_from_observation(primary_observation), mechanism_history=_merge_history(existing.mechanism_history, observations), primary_mechanism=primary_observation.mechanism, entry_boundary_unit_id=entry_boundary.unit_id if entry_boundary is not None else existing.entry_boundary_unit_id, entry_boundary_member_anchor_episode_ids=entry_boundary.member_anchor_episode_ids if entry_boundary is not None else existing.entry_boundary_member_anchor_episode_ids, updated_at=information_cutoff, setup_lineage=tuple(dict.fromkeys(existing.setup_lineage + primary_observation.setup_lineage)), detector_evidence_ids=tuple(sorted(set(existing.detector_evidence_ids + detector_evidence_ids))))
    if existing is not None and existing.terminal:
        if independence is None or not (independence.previous_opportunity_terminated and independence.material_trend_side_reseparation_or_control and independence.new_independent_countertrend_or_boundary_return_event):
            raise OpportunityIndependenceBlock('NEW_OPPORTUNITY_INDEPENDENCE_NOT_PROVEN')
    oid = deterministic_id('D4-OPPORTUNITY', trend_episode_id, direction.value, market_event_id)
    return OpportunityState(opportunity_id=oid, trend_episode_id=trend_episode_id, direction=direction, market_event_id=market_event_id, lifecycle=_lifecycle_from_observation(primary_observation), mechanism_history=_merge_history((), observations), primary_mechanism=primary_observation.mechanism, entry_boundary_unit_id=entry_boundary.unit_id if entry_boundary is not None else None, entry_boundary_member_anchor_episode_ids=entry_boundary.member_anchor_episode_ids if entry_boundary is not None else (), created_at=information_cutoff, updated_at=information_cutoff, setup_lineage=primary_observation.setup_lineage, detector_evidence_ids=tuple(sorted(set(detector_evidence_ids))), provenance={'identity': 'TREND_EPISODE_PLUS_INDEPENDENT_MARKET_EVENT_NOT_DETECTOR_COUNT'})

# --- ORIGINAL d4_opportunity/termination.py ---
from dataclasses import replace

def apply_wp4_termination(opportunity: OpportunityState, evidence: OpportunityTerminationEvidence, *, information_cutoff: int, behavior_confirmation_emitted: bool, location_failed_same_cutoff: bool) -> OpportunityState:
    """F7 subset safely decidable in WP4; downstream risk truth is not computed here."""
    if opportunity.terminal:
        return opportunity
    invalidation_reason: str | None = None
    if evidence.trend_episode_ended:
        invalidation_reason = 'SUPPORTING_TREND_EPISODE_ENDED'
    elif evidence.entry_boundary_terminal_true_break_without_false_break_recovery:
        invalidation_reason = 'ENTRY_BOUNDARY_TERMINAL_TRUE_BREAK'
    elif evidence.mechanism_required_structure_materially_failed:
        invalidation_reason = 'MECHANISM_REQUIRED_STRUCTURE_FAILED'
    elif evidence.critical_role_or_structure_replaced_destroying_thesis:
        invalidation_reason = 'CRITICAL_ROLE_OR_STRUCTURE_REPLACED'
    if invalidation_reason is not None:
        return replace(opportunity, lifecycle=OpportunityLifecycle.INVALIDATED, terminated_at=information_cutoff, updated_at=information_cutoff, termination_reason=invalidation_reason)
    if evidence.irrecoverable_continuity_end:
        return replace(opportunity, lifecycle=OpportunityLifecycle.EXPIRED, terminated_at=information_cutoff, updated_at=information_cutoff, termination_reason='IRRECOVERABLE_CANONICAL_CONTINUITY_END')
    consumed_nonactionable = behavior_confirmation_emitted and (location_failed_same_cutoff or evidence.other_same_cutoff_non_thesis_gate_failed_after_confirmation)
    if consumed_nonactionable and (not evidence.independent_open_mechanism_after_consumed_confirmation):
        return replace(opportunity, lifecycle=OpportunityLifecycle.EXPIRED, terminated_at=information_cutoff, updated_at=information_cutoff, termination_reason='CONFIRMATION_CONSUMED_NONACTIONABLE_SAME_CUTOFF')
    if evidence.event_cycle_completed_and_new_independent_event_rearmed:
        absent = evidence.downstream_actionable_entry_absent
        if absent.kind is InfoKind.KNOWN and absent.value is True:
            return replace(opportunity, lifecycle=OpportunityLifecycle.EXPIRED, terminated_at=information_cutoff, updated_at=information_cutoff, termination_reason='EVENT_CYCLE_COMPLETED_BEFORE_NEW_INDEPENDENT_EVENT')
    return opportunity

# --- ORIGINAL d4_opportunity/cutoff_contract.py ---
"""WP4 owns UPDATE-011 only.

It may consume immutable D2/D3 state but cannot write Price Structure, Trend,
Anchor, Interaction, Break, Roles, Risk, Position, Exit, or Execution truth.
"""
D4_OWNED_UPDATE_STEPS = ('UPDATE-011',)
D4_CONSUMES = ('D2_PRICE_STRUCTURE_TREND_POSITION_PLATFORM', 'D3_ANCHOR_INTERACTION_BREAK_ROLES')
D4_FORBIDDEN_WRITES = ('PRICE_STRUCTURE', 'MARKET_TREND', 'ANCHOR_INTERACTION_BREAK_ROLES', 'RISK_FEASIBILITY', 'ENTRY_READY', 'POSITION', 'EXIT', 'EXECUTION')

# --- ORIGINAL d4_opportunity/engine.py ---
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Mapping

@dataclass(frozen=True)
class D4CutoffInput:
    information_cutoff: int
    trend: TrendEpisodeState
    trend_position: TrendPositionResult
    opportunity_direction: TrendDirection
    market_event_id: str
    detector_evidence_ids: tuple[str, ...]
    critical_information_known: InfoValue[bool]
    entry_boundary_unit: EconomicBoundaryUnit | None
    anchor_episodes: Mapping[str, AnchorEpisode]
    parameters: FrozenD4Parameters
    existing_opportunity: OpportunityState | None = None
    independence: OpportunityIndependenceEvidence | None = None
    termination: OpportunityTerminationEvidence = field(default_factory=OpportunityTerminationEvidence)
    normal_retest: NormalRetestEvidence | None = None
    false_break_reclaim: FalseBreakReclaimEvidence | None = None
    platform_reexpansion: PlatformReexpansionEvidence | None = None
    deep_takeover: DeepStructureTakeoverEvidence | None = None
    trend_establishment_watch: TrendEstablishmentWatchEvidence | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, 'anchor_episodes', MappingProxyType(dict(self.anchor_episodes)))
        if not self.market_event_id:
            raise ValueError('market_event_id required')

def _blocked_behavior_from_critical_info(info: InfoValue[bool]) -> GateEvaluation | None:
    if info.kind is InfoKind.ERROR:
        return GateEvaluation(GateName.BEHAVIOR_CONFIRMATION, InfoValue.error(info.error_ref or 'CRITICAL_INFO_ERROR'), 'SYSTEM_UNCERTAINTY')
    if info.kind is InfoKind.UNKNOWN:
        return GateEvaluation(GateName.BEHAVIOR_CONFIRMATION, InfoValue.unknown(), 'SYSTEM_UNCERTAINTY')
    if info.kind is InfoKind.KNOWN and info.value is not True:
        return GateEvaluation(GateName.BEHAVIOR_CONFIRMATION, InfoValue.unknown(), 'CRITICAL_INFORMATION_BLOCK')
    return None

def update_011(inp: D4CutoffInput) -> D4CutoffView:
    """Deterministic non-trading D4 reference update. No B8/B7-B work occurs."""
    watch_only_input = inp.trend_establishment_watch is not None and (not any((inp.normal_retest, inp.false_break_reclaim, inp.platform_reexpansion, inp.deep_takeover)))
    market_gate = market_eligibility(inp.trend, opportunity_direction=inp.opportunity_direction, critical_information_known=inp.critical_information_known, watch_only=watch_only_input)
    trend_episode_id = inp.trend.episode_id or (inp.existing_opportunity.trend_episode_id if inp.existing_opportunity is not None else 'WATCH_ONLY_NO_ACTIVE_EPISODE')
    entry_view = entry_boundary_view(inp.entry_boundary_unit, inp.anchor_episodes, target_trend_episode_id=trend_episode_id, target_direction=inp.opportunity_direction, information_cutoff=inp.information_cutoff)
    observations = []
    if inp.normal_retest is not None:
        observations.append(normal_retest_observation(inp.normal_retest, direction=inp.opportunity_direction, trend_episode_id=trend_episode_id, information_cutoff=inp.information_cutoff, market_gate=market_gate.result, entry_boundary=entry_view))
    if inp.false_break_reclaim is not None:
        observations.append(false_break_reclaim_observation(inp.false_break_reclaim, direction=inp.opportunity_direction, trend_episode_id=trend_episode_id, information_cutoff=inp.information_cutoff, market_gate=market_gate.result, entry_boundary=entry_view))
    if inp.platform_reexpansion is not None:
        pe = PlatformReexpansionEvidence(platform=inp.platform_reexpansion.platform, current_close=inp.platform_reexpansion.current_close, target_trend_episode_id=inp.platform_reexpansion.target_trend_episode_id, direction=inp.platform_reexpansion.direction, setup_lineage=inp.platform_reexpansion.setup_lineage, provenance=inp.platform_reexpansion.provenance)
        observations.append(platform_reexpansion_observation(pe, direction=inp.opportunity_direction, trend_episode_id=trend_episode_id, information_cutoff=inp.information_cutoff, market_gate=market_gate.result, entry_boundary=entry_view, theta_progress=inp.parameters.theta_progress))
    if inp.deep_takeover is not None:
        observations.append(deep_structure_takeover_observation(inp.deep_takeover, direction=inp.opportunity_direction, trend_episode_id=trend_episode_id, information_cutoff=inp.information_cutoff, market_gate=market_gate.result, entry_boundary=entry_view))
    if inp.trend_establishment_watch is not None:
        observations.append(trend_establishment_watch_observation(inp.trend_establishment_watch))
    observations_t = tuple(observations)
    primary = select_primary_observation(observations_t)
    if primary is None:
        system_block = _blocked_behavior_from_critical_info(inp.critical_information_known)
        behavior = system_block or GateEvaluation(GateName.BEHAVIOR_CONFIRMATION, InfoValue.none(), 'NO_ACTIVE_MECHANISM')
        return D4CutoffView(information_cutoff=inp.information_cutoff, opportunity=inp.existing_opportunity, primary_observation=None, market_eligibility=market_gate, location_eligibility=GateEvaluation(GateName.LOCATION_ELIGIBILITY, InfoValue.none(), 'NO_ACTIVE_MECHANISM'), behavior_confirmation=behavior, confirmation_candidate=None)
    watch_only = primary.mechanism is OpportunityMechanism.TREND_ESTABLISHMENT_WATCH_ONLY
    location_gate = location_eligibility(inp.trend_position, mechanism_location_qualified=primary.location_qualified, watch_only=watch_only)
    opportunity = open_or_update_opportunity(existing=inp.existing_opportunity, trend_episode_id=trend_episode_id, direction=inp.opportunity_direction, market_event_id=inp.market_event_id, information_cutoff=inp.information_cutoff, primary_observation=primary, observations=observations_t, detector_evidence_ids=inp.detector_evidence_ids, entry_boundary=entry_view, independence=inp.independence)
    system_block = _blocked_behavior_from_critical_info(inp.critical_information_known)
    if system_block is not None and (not watch_only):
        behavior_gate = system_block
        candidate = None
    else:
        behavior_gate = GateEvaluation(GateName.BEHAVIOR_CONFIRMATION, primary.behavior_confirmation, 'B7A_MECHANISM_BEHAVIOR_TRUTH')
        opportunity, candidate = make_behavior_confirmation_candidate(opportunity, primary, information_cutoff=inp.information_cutoff)
    location_failed = location_gate.result.kind is InfoKind.KNOWN and location_gate.result.value is False
    opportunity = apply_wp4_termination(opportunity, inp.termination, information_cutoff=inp.information_cutoff, behavior_confirmation_emitted=candidate is not None, location_failed_same_cutoff=location_failed)
    return D4CutoffView(information_cutoff=inp.information_cutoff, opportunity=opportunity, primary_observation=primary, market_eligibility=market_gate, location_eligibility=location_gate, behavior_confirmation=behavior_gate, confirmation_candidate=candidate)
