"""Bind superseding TAC authority (Oct 6 D5 and UPDATE014) for AI Pro port.

The SHA-frozen 91 source is the scientific rule base, NOT final D5/F9
operational authority. This builder binds later existing authorities exactly;
it never invents theta_stop, capital, order, signal or entry_ready.
"""
from __future__ import annotations

from hashlib import sha256
import json
from pathlib import Path

from build_original_d1_singlemodule import DEST, ROOT

FORMAL_D5=ROOT/"work/live/full_live_d5_operational_risk_policy_authority_v1.json"
FINAL_ENTRY=ROOT/"work/live/full_live_final_entry_observation_authority_v1.py"
PRODUCTION_D5=ROOT/"work/live/full_live_remaining_d5_policy_enforcement_v1.py"
PRODUCTION_AUTH=ROOT/"work/live/full_live_production_operational_authorization_v1.py"
FROZEN_528=ROOT/"provisional_shadow_v1/prospective_usdm_universe_v1_recovered_canonical.json"
FROZEN_SYMBOL_SHA="4bb105592aaf8af4f7027f3806019d0dffdff1372842d2aec45e150b4c990bc1"

EXPECTED_SLOTS=frozenset((
    "per_trade_account_risk",
    "per_symbol_risk_cap",
    "total_portfolio_risk_cap",
    "same_direction_aggregate_cap",
    "correlation_common_factor_budget",
    "listing_liquidity_capacity_thresholds",
    "spread_slippage_depth_feasibility_boundaries",
    "execution_allowance",
    "kill_switch_numeric_triggers",
    "PORT_007_allocation_priority_policy",
))

def stop(code):
    raise ValueError("NATIVE_CURRENT_AUTHORITY_BUILD_BLOCKED:"+code)

def must(test,code):
    if not test: stop(code)


def make():
    formal=json.loads(FORMAL_D5.read_text(encoding="utf8"))
    must(formal.get("schema")=="TAC_FULL_LIVE_D5_OPERATIONAL_RISK_POLICY_AUTHORITY_V1","SCHEMA")
    must(formal.get("status")=="FROZEN","FORMAL_D5_NOT_FROZEN")
    must(formal.get("version")=="D5_OPERATIONAL_RISK_PORTFOLIO_USER_FREEZE_V1","D5_VERSION")
    must(formal.get("required_user_decision","MISSING") is None,"MISSING_USER_AUTH")
    grant=formal.get("user_authorization",{})
    must(grant.get("authorized_at_date")=="2026-10-06","DATE")
    must(grant.get("real_trading_authorized") is False,"NO_TRADING_GRANT")
    slots=formal.get("slots",{})
    must(set(slots)==EXPECTED_SLOTS,"TEN_SLOTS_DRIFT")
    must(all(x.get("state")=="KNOWN" for x in slots.values()),"UNFROZEN_D5_SLOT")
    current=formal.get("current_effect",{})
    must(current.get("runtime_all_ten_slot_enforcement")==
         "IMPLEMENTED_AND_REGRESSION_VALIDATED","OFFLINE_ENFORCEMENT_NOT_PROVEN")
    must(current.get("real_trading_authorized") is False,"CURRENT_TRADING_NOT_ALLOWED")
    f=lambda name:slots[name]["exact_value"]
    for name,value in (("per_trade_account_risk","0.005"),
                       ("per_symbol_risk_cap","0.005"),
                       ("total_portfolio_risk_cap","0.05"),
                       ("same_direction_aggregate_cap","0.03")):
        must(f(name).get("fraction")==value,"RISK_RATE_DRIFT_"+name)
    must(f("correlation_common_factor_budget").get("factor_policy")==
         "SYSTEMIC_DIRECTION_EXPOSURE_V1","FACTOR_DEFINITION_DRIFT")
    must(f("spread_slippage_depth_feasibility_boundaries").get("intended_quote_notional_usdt")=="80",
         "NOTIONAL_DRIFT")
    must(f("spread_slippage_depth_feasibility_boundaries").get("depth_limit")==100,"DEPTH_DRIFT")
    must(f("spread_slippage_depth_feasibility_boundaries").get("rpi_liquidity_included") is False,
         "RPI_DRIFT")
    must(f("spread_slippage_depth_feasibility_boundaries").get("max_spread_bps")=="12.17",
         "SPREAD_DRIFT")
    must(f("spread_slippage_depth_feasibility_boundaries").get("max_impact_from_best_bps")=="4.57",
         "IMPACT_DRIFT")
    alloc=f("PORT_007_allocation_priority_policy")
    must(alloc.get("policy")=="CUTOFF_ROTATED_FROZEN_CANONICAL_UNIVERSE_V1",
         "FROZEN_PORT007_CUTOFF_ROTATION_DRIFT")
    must(alloc.get("quality_ranking") is False and alloc.get("signal_score") is False
         and alloc.get("pnl") is False,"PORT007_SCORE_SELECTOR_FORBIDDEN")
    must(alloc.get("scarce_capacity")=="STRICT_ORDERED_PREFIX_NO_SKIP",
         "PORT007_NO_SKIP_DRIFT")
    must(f("kill_switch_numeric_triggers").get("immediate_execution_uncertainty_latch") is True,
         "UNCERTAINTY_LATCH_MISSING")
    symbols=json.loads(FROZEN_528.read_text(encoding="utf8"))["symbols"]
    must(len(symbols)==528 and len(set(symbols))==528,"UNIVERSE_LENGTH_DUPLICATION")
    must(sha256(("\n".join(symbols)+"\n").encode()).hexdigest()==FROZEN_SYMBOL_SHA,
         "UNIVERSE_FROZEN_SHA_DRIFT")
    refs={}
    for name,path in (("d5_authority",FORMAL_D5),
                      ("current_d5_runtime",PRODUCTION_D5),
                      ("current_d5_authorization",PRODUCTION_AUTH),
                      ("final_update014_admission",FINAL_ENTRY),
                      ("frozen_528",FROZEN_528)):
        raw=path.read_bytes()
        must(len(raw)>100,"SOURCE_UNAVAILABLE_"+name)
        refs[name]={"path":str(path.relative_to(ROOT)),
                    "sha256":sha256(raw).hexdigest(),"bytes":len(raw)}
    output={
        "schema":"TAC_BINANCE_AI_PRO_CURRENT_CORE_AUTHORITY_BINDING_V1",
        "lineage":"FROZEN_91_ORIGINAL_SCIENCE_PLUS_SUPERSEDING_OCT06_OPERATIONAL_RULES",
        "formal_policy_version":formal["version"],
        "formal_policy_state":"FROZEN",
        "current_d5_slots":slots,
        "current_d5_enforcement_source":refs["current_d5_runtime"],
        "current_d5_authorization_source":refs["current_d5_authorization"],
        "final_entry_guard":"UPDATE014_ONLY_AFTER_SIGNED_CUTOFF_ENGINE_STAGE_RESULT",
        "final_entry_guard_source":refs["final_update014_admission"],
        "historical_91_source_PORT007_status":"BLOCKED_HISTORICAL_REFERENCE_NOT_CURRENT",
        "current_PORT007_requirement":alloc["policy"],
        "frozen_528_count":528,
        "frozen_528_sha256":FROZEN_SYMBOL_SHA,
        "frozen_symbols":symbols,
        "source_file_hashes":refs,
        "no_new_numeric_theta_stop_from_d5_policy":True,
        "final_entry_ready_without_UPDATE014_permitted":False,
        "portfolio_selection_or_quality_ranking":False,
        "native_528_compute_executed":False,
        "native_code_audited":False,
        "AI_Pro_native_strategy_running":False,
        "TAC_LIVE_ENABLED":0,"orders":0,"fills":0,
    }
    return output


def main():
    data=make()
    DEST.mkdir(parents=True,exist_ok=True)
    f=DEST/"current_native_authority_binding_v1.json"
    f.write_text(json.dumps(data,ensure_ascii=False,sort_keys=True,indent=2)+"\n",encoding="utf8")
    print("CURRENT_D5_UPDATE014_AUTHORITY_BUILD_PASS",json.dumps({
        "d5_authority_version":data["formal_policy_version"],
        "d5_count":len(data["current_d5_slots"]),
        "frozen_528":data["frozen_528_count"],
        "sha256":sha256(f.read_bytes()).hexdigest(),
        "update014_final":data["final_entry_guard"],
        "historical_f9_port007":"SUPERSEDED_UNRESOLVED_REFERENCE",
        "no_orders":True,
        "native_run":False,
    },sort_keys=True))


if __name__=="__main__":
    main()
