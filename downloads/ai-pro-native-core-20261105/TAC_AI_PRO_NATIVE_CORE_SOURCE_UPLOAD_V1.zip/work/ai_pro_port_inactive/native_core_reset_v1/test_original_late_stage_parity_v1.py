"""Differential original D5, D6, and F9 before any Binance AI Pro submission.

This is genuine source from the SHA-frozen 91, executing original algorithms
against identical typed synthetic evidence. It never creates real orders,
accounts or an AI Pro native strategy. Original WP5/WP6 have explicit no-trade
state due to the locked theta_stop, and that behavior MUST remain unchanged.
"""
from __future__ import annotations

from collections.abc import Mapping
from dataclasses import fields, is_dataclass
from enum import Enum
from fractions import Fraction
import importlib
import importlib.util
from pathlib import Path
import sys
import tempfile
import unittest
from types import SimpleNamespace

from build_original_d1_singlemodule import DEST, ORIGINALS, originals
from build_original_d1d2_singlemodule import D2_FILES
from build_original_d1d2d3_singlemodule import D3_FILES
from build_original_d1d2d3d4_singlemodule import D4_FILES
from build_original_d1_to_d6_f9_singlemodule import FILES,make
from inspect_original_d5d6_native_dependencies_v1 import D5_FILES,D6_FILES,F9_FILES

CUTOFF=1800000899999

ORIGINAL_IMPORTS=(
    "strategy_rc1.parameter_snapshot",
    "strategy_rc1.runtime_guards.information_state",
    "strategy_rc1.d2_market_state.types",
    "strategy_rc1.d4_opportunity.types",
    "strategy_rc1.d5_risk.types",
    "strategy_rc1.d5_risk.parameters",
    "strategy_rc1.d5_risk.operational_inputs",
    "strategy_rc1.d5_risk.hard_stop",
    "strategy_rc1.d5_risk.engine",
    "strategy_rc1.d4_b7b_entry_ready",
    "strategy_rc1.d6_position_execution.types",
    "strategy_rc1.d6_position_execution.parameters",
    "strategy_rc1.d6_position_execution.management",
    "strategy_rc1.d6_position_execution.position",
    "strategy_rc1.d6_position_execution.engine",
    "strategy_rc1.cutoff_engine.types",
    "strategy_rc1.cutoff_engine.portfolio_boundary",
)

def normalize(v):
    if isinstance(v, Enum): return v.value
    if isinstance(v, Fraction): return (v.numerator,v.denominator)
    if is_dataclass(v): return {f.name:normalize(getattr(v,f.name)) for f in fields(v)}
    if isinstance(v, Mapping): return {str(k):normalize(val) for k,val in v.items()}
    if isinstance(v, (tuple,list)): return [normalize(x) for x in v]
    return v

def make_original_view():
    out=SimpleNamespace()
    for name in ORIGINAL_IMPORTS:
        mod=importlib.import_module(name)
        for k,v in vars(mod).items():
            if k.startswith("__"): continue
            if hasattr(out,k) and getattr(out,k) is not v:
                # imported convenience aliases can mask same-named source
                # bindings; anything used by tests must have one identity.
                if getattr(v,"__module__",None)!=mod.__name__:
                    continue
                raise ValueError("ORIGINAL_SOURCE_ALIAS_COLLISION:"+k)
            setattr(out,k,v)
    return out

class FullOriginalLateStageDifferential(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp=tempfile.TemporaryDirectory()
        work=Path(cls.tmp.name)
        requested=tuple(dict.fromkeys(ORIGINALS+D2_FILES+D3_FILES+D4_FILES+D5_FILES+D6_FILES+F9_FILES))
        for filename,blob in originals(requested):
            p=work/"strategy_rc1"/filename
            p.parent.mkdir(parents=True,exist_ok=True)
            p.write_bytes(blob)
        sys.path.insert(0,str(work))
        cls.original=make_original_view()
        spec=importlib.util.spec_from_file_location(
            "original_D1_D6_F9_inline_exact_test",
            DEST/"original_d1_to_d6_f9_source.py")
        cls.merged=importlib.util.module_from_spec(spec)
        sys.modules[spec.name]=cls.merged
        spec.loader.exec_module(cls.merged)

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    def get(self,original):
        return self.original if original else self.merged

    def test_core_source_unique_names_unchanged(self):
        src,records=make()
        self.assertEqual(src,(DEST/"original_d1_to_d6_f9_source.py").read_text())
        self.assertEqual(len(records),len(FILES))
        self.assertTrue(all(row["nonimport_science_ast_unchanged"] for row in records))
        self.assertGreater(len(src),100000)
        for symbol in ("update_011","update_012_013","update_010",
                       "assemble_b7b_entry_ready","DeterministicCutoffEngine",
                       "evaluate_portfolio_boundary"):
            self.assertTrue(hasattr(self.merged,symbol),symbol)

    def test_original_D5_watch_only_never_admits_entry(self):
        outputs=[]
        for original in (True,False):
            m=self.get(original)
            s=m.current_partial_parameter_snapshot()
            p=m.d5_parameter_view(s)
            self.assertEqual(p.theta_stop_state.value,"LOCKED")
            self.assertIsNone(p.theta_stop_exact_value)
            opp=m.OpportunityState(
                opportunity_id="D4_OPP_WATCH_ONLY",trend_episode_id="D2_EP1",
                direction=m.TrendDirection.LONG,market_event_id="D4_EVENT",
                lifecycle=m.OpportunityLifecycle.CANDIDATE,
                mechanism_history=(m.OpportunityMechanism.TREND_ESTABLISHMENT_WATCH_ONLY,),
                primary_mechanism=m.OpportunityMechanism.TREND_ESTABLISHMENT_WATCH_ONLY,
                entry_boundary_unit_id=None,entry_boundary_member_anchor_episode_ids=(),
                created_at=CUTOFF,updated_at=CUTOFF,
                setup_lineage=("WATCH_ONLY",),detector_evidence_ids=(),
            )
            na=m.InfoValue.na()
            d4=m.D4CutoffView(
                information_cutoff=CUTOFF,opportunity=opp,primary_observation=None,
                market_eligibility=m.GateEvaluation(m.GateName.MARKET_ELIGIBILITY,na,"WATCH_ONLY"),
                location_eligibility=m.GateEvaluation(m.GateName.LOCATION_ELIGIBILITY,na,"WATCH_ONLY"),
                behavior_confirmation=m.GateEvaluation(m.GateName.BEHAVIOR_CONFIRMATION,na,"WATCH_ONLY"),
                confirmation_candidate=None,
            )
            inp=m.D5CutoffInput(
                information_cutoff=CUTOFF,d4_view=d4,
                risk_evidence=None,
                canonical_segment_id="D1_FROZEN_SEGMENT",
                strategy_entry_reference_price=m.InfoValue.unknown(),
                atr_at_risk_reference=m.InfoValue.unknown(),
                canonical_continuity_intact=m.InfoValue.known(True),
                risk_anchor_not_invalidated=m.InfoValue.unknown(),
                operational_inputs=m.current_unresolved_operational_inputs(),
                parameters=p,
            )
            x=m.update_012_013(inp)
            self.assertEqual(x.entry_ready.decision.state.value,"N/A")
            self.assertFalse(x.entry_ready.semantic_entry_ready_emitted)
            self.assertIsNone(x.entry_ready.entry_ready_id)
            self.assertFalse(x.entry_ready.executable)
            outputs.append(normalize(x))
        self.assertEqual(outputs[0],outputs[1])

    def test_original_D5_locked_numeric_hard_stop_blocks(self):
        observed=[]
        for original in (True,False):
            m=self.get(original)
            anchor=m.RiskAnchorReference(
                risk_anchor_id="RA",opportunity_id="OPP",confirmation_candidate_id="C",
                mechanism=m.OpportunityMechanism.NORMAL_RETEST_CONTINUATION,
                direction=m.TrendDirection.LONG,pivot_id="P",
                pivot_type=m.PivotType.LOW,layer=m.StructuralLayer.INTERMEDIATE,
                price=Fraction(100),confirmed_at=CUTOFF-900000,
                canonical_segment_id="D1_SEG",source_scale_at_extreme=Fraction(2),
                reason="EXPLICIT_TEST_ONLY_ANCHOR",
            )
            out=m.symbolic_initial_hard_stop_candidate(
                anchor,direction=m.TrendDirection.LONG,
                atr_at_risk_reference=m.InfoValue.known(Fraction(2)),
                parameters=m.d5_parameter_view(m.current_partial_parameter_snapshot()),
            )
            self.assertEqual(out.decision.state.value,"BLOCKED")
            self.assertEqual(out.decision.reason,"THETA_STOP_LOCKED_NO_AUTHORIZED_NUMERIC_VALUE")
            self.assertIsNone(out.numeric_stop_price)
            observed.append(normalize(out))
        self.assertEqual(*observed)

    def test_original_D6_ratchet_and_gap_is_degraded_not_market_failure(self):
        observed=[]
        for original in (True,False):
            m=self.get(original)
            self.assertEqual(m.monotonic_stop_semantics(
                m.TrendDirection.LONG,Fraction(100),Fraction(98)),Fraction(100))
            self.assertEqual(m.monotonic_stop_semantics(
                m.TrendDirection.SHORT,Fraction(100),Fraction(102)),Fraction(100))
            par=m.d6_parameter_view(m.current_partial_parameter_snapshot())
            entry=m.FrozenEntryProvenance(
                provenance_class=m.PositionProvenanceClass.NONAUTHORITATIVE_SYNTHETIC_FIXTURE_ONLY,
                entry_ready_id="TEST_READY_NOT_REAL",entry_ready_cutoff=CUTOFF-900000,
                symbol="BTCUSDT",direction=m.TrendDirection.LONG,
                trend_episode_id="D2_EP1",opportunity_id="D4_OPP",
                market_event_id="D4_EVENT",entry_boundary_unit_id=None,
                risk_anchor_id="D5_RA",risk_anchor_pivot_id="D2_P0",
                risk_anchor_layer=m.StructuralLayer.INTERMEDIATE,
                risk_anchor_price=Fraction(100),risk_anchor_scale=Fraction(2),
                risk_anchor_confirmed_at=CUTOFF-1800000,
                risk_anchor_timeframe_ms=900000,
                canonical_segment_id="D1_SEG",
                strategy_entry_reference_price=Fraction(101),
                initial_hard_stop_state=m.DecisionState.BLOCKED,
                initial_hard_stop_numeric=None,
            )
            pos=m.StrategyPositionSnapshot(
                position_id="TEST_SYNTHETIC_ONLY",entry=entry,
                opened_from_execution_evidence_id=None,opened_real_time=None,
                mode=m.PositionMode.ACTIVE,
                latest_qualified_protective_pivot=None,
                current_protective_stop=m.InfoValue.unknown(),
            )
            inp=m.D6CutoffInput(
                information_cutoff=CUTOFF,position=pos,
                protective_pivot_evidence=m.ProtectivePivotEvidence(
                    adverse_minor_pivot=None,
                    material_favorable_post_entry_progress=m.InfoValue.unknown(),
                    trade_thesis_intact=m.InfoValue.unknown(),
                    trend_thesis_intact=m.InfoValue.unknown(),
                    local_trend_control_regained=m.InfoValue.unknown(),
                ),
                new_adverse_pivot=None,
                protected_intermediate_structure_failed=m.InfoValue.unknown(),
                supporting_trend_episode_end=m.TrendEpisodeEndEvidence(
                    ended=m.InfoValue.known(False),cause=m.TrendEpisodeEndCause.NONE),
                canonical_continuity_intact=m.InfoValue.known(False),
                hard_protection=m.HardProtectionEvidence(
                    triggered=m.InfoValue.known(False),
                    execution_event_id=None,real_event_time=None),
                exit_candidate_evidence=m.ExitCandidateEvidence(),
                parameters=par,
            )
            out=m.update_010(inp)
            self.assertEqual(out.position_mode.value,"DEGRADED_PROTECTIVE")
            self.assertTrue(out.new_risk_blocked)
            self.assertIsNone(out.exit_evaluation.exit_record)
            self.assertEqual(out.exit_evaluation.decision.state.value,"UNKNOWN")
            observed.append(normalize(out))
        self.assertEqual(*observed)

    def test_original_D6_real_position_activation_guard(self):
        for original in (True,False):
            m=self.get(original)
            blocked=m.EntryReadyAssemblyResult(
                decision=m.DecisionResult(m.DecisionState.BLOCKED,"TEST_ONLY"),
                information_cutoff=CUTOFF,opportunity_id=None,
                confirmation_candidate_id=None,
                risk_feasibility_state=m.DecisionState.BLOCKED,
                entry_ready_id=None,semantic_entry_ready_emitted=False,
                executable=False,runtime_usable=False)
            m.assert_current_wp5_cannot_create_real_position(blocked)
            fake_ready=m.EntryReadyAssemblyResult(
                decision=m.DecisionResult(m.DecisionState.PASS,"FAKE"),
                information_cutoff=CUTOFF,opportunity_id="OPP",
                confirmation_candidate_id="C",
                risk_feasibility_state=m.DecisionState.PASS,
                entry_ready_id="SHOULD_NOT_BE_ACCEPTED",
                semantic_entry_ready_emitted=True,
                executable=False,runtime_usable=False)
            with self.assertRaisesRegex(ValueError,"unexpected current-state ENTRY_READY"):
                m.assert_current_wp5_cannot_create_real_position(fake_ready)

    def test_original_F9_port007_is_blocked_not_a_selector(self):
        outputs=[]
        for original in (True,False):
            m=self.get(original)
            rows=(
                m.PortfolioCandidate("ETHUSDT","R2","TX2"),
                m.PortfolioCandidate("BTCUSDT","R1","TX1"),
            )
            x=m.evaluate_portfolio_boundary(rows)
            self.assertEqual(x.state.value,"BLOCKED")
            self.assertIsNone(x.allocation)
            self.assertFalse(x.port_007_frozen)
            self.assertEqual([v.symbol for v in x.candidates],["BTCUSDT","ETHUSDT"])
            outputs.append(normalize(x))
        self.assertEqual(*outputs)

if __name__=="__main__":
    unittest.main()
