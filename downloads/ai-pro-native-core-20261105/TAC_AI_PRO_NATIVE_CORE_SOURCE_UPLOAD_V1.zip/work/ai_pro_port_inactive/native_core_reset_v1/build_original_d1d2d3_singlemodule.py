"""Extend ORIGINAL source-preserving native-core source with actual D3 rules.

Not a fully native-deployable strategy; this is source code for D1→D2→D3,
and later must be fitted alongside D4/F9/D5/D6 within the Binance AI Pro
runtime constraints. Preserve the original AST on every nonimport source item.
"""
from __future__ import annotations
from hashlib import sha256
import json

from build_original_d1_singlemodule import DEST,originals,transform_for_one_module
from build_original_d1d2_singlemodule import make as d1d2_make

D3_FILES=(
    "d3_boundary_intelligence/types.py",
    "d3_boundary_intelligence/parameters.py",
    "d3_boundary_intelligence/candidates.py",
    "d3_boundary_intelligence/snapshots.py",
    "d3_boundary_intelligence/geometry.py",
    "d3_boundary_intelligence/interaction.py",
    "d3_boundary_intelligence/breaks.py",
    "d3_boundary_intelligence/anchors.py",
    "d3_boundary_intelligence/clusters_roles.py",
    "d3_boundary_intelligence/cutoff_contract.py",
    "d3_reference.py",
)
def make():
    base,_=d1d2_make()
    parts=[base]
    members=[]
    for name,data in originals(D3_FILES):
        code,imports=transform_for_one_module(name,data)
        parts.append("# --- ORIGINAL "+name+" ---\n"+code+"\n")
        members.append({
            "name":"strategy_rc1/"+name,
            "source_sha256":sha256(data).hexdigest(),
            "source_length":len(data),
            "removed_relative_imports":imports,
            "algorithm_ast_identical":True,
        })
    result="\n".join(parts)
    compile(result,"original_d1d2d3_singlemodule.py","exec")
    return result,members


def main():
    text,rows=make()
    DEST.mkdir(parents=True,exist_ok=True)
    (DEST/"original_d1d2d3_singlemodule.py").write_text(text,encoding="utf8")
    info={
        "schema":"TAC_ORIGINAL_D1_D2_D3_EXACT_RULES_SINGLEMODULE_V1",
        "source_transport_sha256":"36111563b5778513d5803a3ec7c2b86f967a71d915fbcfd9bee5cb4ebebf8174",
        "d1_source_count":10,
        "d2_source_count":11,
        "d3_source_count":len(rows),
        "total_source_count":21+len(rows),
        "code_sha256":sha256(text.encode("utf8")).hexdigest(),
        "code_chars":len(text),
        "code_semantics_changed":False,
        "D3_original_update_000_002_007_008":"PRESENT_AS_UNCHANGED_REFERENCE_CODE",
        "B5_original_assign_roles":"PRESENT_AS_UNCHANGED_REFERENCE_CODE",
        "native_audit":"NOT_CALLED",
        "native_running":"NOT_PROVEN",
        "D4_F9_D5_D6":"NOT_INCLUDED",
        "trade_authorized":False,
        "TAC_LIVE_ENABLED":0,
        "orders":0,
        "members":rows,
    }
    (DEST/"original_d1d2d3_singlemodule_manifest.json").write_text(
        json.dumps(info,sort_keys=True,indent=2)+"\n",encoding="utf8")
    print("ORIGINAL_D1_D2_D3_SOURCE_BUILD_PASS",json.dumps(
        {k:v for k,v in info.items() if k!="members"},sort_keys=True))


if __name__=="__main__":
    main()
