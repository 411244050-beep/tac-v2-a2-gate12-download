"""Source-preserving D1→D2→D3→D4 engine including ORIGINAL update_011.

No invented opportunity gates. Uses frozen 91 original source and only removes
module-relative imports after validating every scientific body AST. This is
an intermediate source candidate, NOT a saved Binance AI Pro runtime version.
"""
from __future__ import annotations
from hashlib import sha256
import json

from build_original_d1_singlemodule import DEST,originals,transform_for_one_module
from build_original_d1d2d3_singlemodule import make as d123_make

D4_FILES=(
    "d4_opportunity/types.py",
    "d4_opportunity/parameters.py",
    "d4_opportunity/control_regain.py",
    "d4_opportunity/eligibility.py",
    "d4_opportunity/mechanisms.py",
    "d4_opportunity/confirmation.py",
    "d4_opportunity/opportunity.py",
    "d4_opportunity/termination.py",
    "d4_opportunity/cutoff_contract.py",
    "d4_opportunity/engine.py",
)

def make():
    d123,_=d123_make()
    parts=[d123]
    manifest=[]
    for name,data in originals(D4_FILES):
        result,deleted=transform_for_one_module(name,data)
        parts.append("# --- ORIGINAL "+name+" ---\n"+result+"\n")
        manifest.append({
            "name":"strategy_rc1/"+name,
            "sha256":sha256(data).hexdigest(),
            "removed_relative_imports":deleted,
            "scientific_body_ast_unchanged":True,
        })
    code="\n".join(parts)
    compile(code,"original_d1d2d3d4_singlemodule.py","exec")
    return code,manifest

def main():
    code,manifest=make()
    DEST.mkdir(parents=True,exist_ok=True)
    (DEST/"original_d1d2d3d4_singlemodule.py").write_text(code,encoding="utf8")
    report={
        "schema":"TAC_AI_PRO_ORIGINAL_D1_D2_D3_D4_SCIENCE_SOURCE_V1",
        "frozen_transport_sha256":"36111563b5778513d5803a3ec7c2b86f967a71d915fbcfd9bee5cb4ebebf8174",
        "original_files":42,
        "new_D4_files":len(manifest),
        "original_D4_update_011_reachable":True,
        "D4_behavior_confirmation_not_ENTRY_READY":True,
        "science_body_ast_changed":False,
        "chars":len(code),
        "sha256":sha256(code.encode("utf8")).hexdigest(),
        "F9_D5_D6_NATIVE_NOT_INTEGRATED":True,
        "native_audit":"NOT_CALLED",
        "native_runtime":"NOT_TESTED",
        "TAC_LIVE_ENABLED":0,
        "orders":0,
        "d4_members":manifest,
    }
    (DEST/"original_d1d2d3d4_singlemodule_manifest.json").write_text(
        json.dumps(report,ensure_ascii=False,sort_keys=True,indent=2)+"\n",encoding="utf8")
    print("ORIGINAL_D1_TO_D4_BUILD_PASS",json.dumps(
        {k:v for k,v in report.items() if k!="d4_members"},sort_keys=True))

if __name__=="__main__":
    main()
