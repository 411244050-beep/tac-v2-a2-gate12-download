# TAC → Binance AI Pro 原生核心迁移：重新建立唯一主线

Status: SOURCE-LOCKED / NATIVE-CORE-BUILD-NOT-YET-COMPLETE. This file is a handoff for a real native implementation, **not** an alternative strategy, an offline backtest, a Docker/REST watcher, or proof of deployment.

## 本项目唯一验收目标

保留已有 TAC 冻结交易规则，允许按 AI Pro 单模块限制调整组织与代码结构，最终形成 **一套在 Binance AI Pro 运行的原生 TAC 核心策略**。必须能说明每个原版核心阶段是否真实计算并依次生效。严禁把 EMA+ATR+SuperTrend 一致性策略冒充完整 TAC。

范围：Binance AI Pro `strategy/strategy.py` + `strategy/spec.yaml`。GitHub 只用于不可丢失的源码、差异与构建结果。**禁用旁路**：外部服务器、Docker、GitHub 定时策略、与 Binance AI 无关的实时运行替代方案。

Original base: SHA-verified 91 source files recovered from `provisional_shadow_v1/wp8_strategy_rc1_transport_v1/`. Transport SHA256 `36111563b5778513d5803a3ec7c2b86f967a71d915fbcfd9bee5cb4ebebf8174`. Readable original subset:
- `work/ai_pro_port_inactive/verified_d1d2_v1/tac_port_inactive/d1_port.py`, `d2_port.py`, `d3_port.py`, `d3_aux_port.py`, each wrapping unmodified source and explicitly NOT production runtime.
- `work/ai_pro_port_inactive/wp8_reference_91_v1/strategy_rc1/d3_boundary_intelligence/*`; original candidate/anchor/interaction, next-bar no lookahead.
- `work/ai_pro_port_inactive/wp8_d4_reference_v1/strategy_rc1/d4_opportunity/*`; original `update_011`.
- `work/live/full_live_d5_operational_risk_policy_authority_v1.json`; all 10 D5 slots frozen 2026-10-06.
- `work/live/full_live_final_entry_observation_authority_v1.py`; UPDATE-012/013/014 admission authority.
- `work/live/full_live_d6_position_manager_v1.py` and frozen `strategy_rc1/d6_position_execution/` original D6 stop/exit.
Public source-package link for native agent input: `https://github.com/411244050-beep/tac-v2-a2-gate12-download/tree/main/downloads/ai-pro-d1-original-20261023` (91-source ZIP; read hash before use).
Private GitHub branch: `tac-ai-pro-native-core-reset-v1`. Never overwrite frozen original or earlier saved strategy r1.

## 必须原样保持的经济规则 / 数据和因果规则

1. **D1**: frozen 528 universe target, intersect with current Binance USD-M `TRADING` state (nontrading not eligible but stays in audit); exact closed 15m with monotonic time, missing/unknown/error separately tracked, no history-based fabricated prospective continuity, no warmup bypass. Original D1 precision is `Fraction(Decimal(raw_string))`, not floats cast back to strings. Prefer native `kline_stream` exact `k.o,h,l,c,v,q` strings; user-forwarded native BTC stage1 already observed this in sandbox on 2026-10-23. Compute the original EMA/ATR14/SuperTrend, completed 1h/4h, canonical segment resets and information cutoff semantics.
2. **D2**: original trend/pivot/leg and higher-timeframe trend episode, structural position and corridor; do not replace with naive two-left/two-right pivot and 3-indicator voting. Keep original `theta_minor/intermediate/major` requirements and signed provenance; never present TRAIN candidate values as frozen science.
3. **D3**: exact causal candidate `build_candidate`, SOURCE-TF family and line availability, registered candidate ID, original UPDATE-000 pre-bar view, UPDATE-002 geometry, UPDATE-007 interaction/break, UPDATE-008 anchor lifecycle, qualified use and B5 economic boundary role. Candidate visible only at allowed future observation boundary; no same-bar UPDATE-008 backflow to UPDATE-007.
4. **D4**: frozen four active mechanisms: normal retest continuation, false-break reclaim, platform re-expansion, deep-structure takeover, plus separately watch-only trend establishment. Use original D4 `update_011`, its market/location/behavior gates, independent event lineage, termination and confirmation candidate. UNKNOWN != FALSE; lack of source event evidence never becomes a positive signal.
5. **F9 / UPDATE-012/013/014**: frozen causal phase order, prestate and same-cutoff consistency, D5 risk feasibility after original D4 signal; formal UPDATE014 admitted `entry_ready` ref is the **sole final entry authority**. No manual symbol/direction/entry-ready substitute. No lookahead, no background backfill.
6. **D5**: all ten frozen risk slots, not merely basic stop-loss. Per trade/symbol 0.5% capital base, portfolio 5%, same direction 3%, common factor directional 3%, exchange-legal current status, USD80 feasibility, standard non-RPI depth100 and spread≤12.17bps/impact≤4.57bps, strict PORT_007 cutoff-rotated 528 canonical order (no quality rank), immediate execution uncertainty latch. Do not synthesize signed capital evidence or unverified depth timestamps. These gates must fail closed.
7. **D6**: initial exchange-native hard stop, original qualified protective pivots and structural exits, position identity/ledger, restart and pause protection. Vendor-reported Binance AI Pro lacks original 528-wide transactional durable checkpoint; therefore **no paper/live orders** unless platform-specific protection and restart failure behavior independently demonstrated. A native signal-only deterministic core process can be tested separately.

Frozen D5 is authorized as risk policy but does NOT grant trading permission. Four outstanding theta slots from `work/live/experimental_operational_parameter_snapshot_v1.json`: `theta_minor=0.655417496698647720797643159793938746032740795679425`, `theta_intermediate=1.7477799911963939221270484261171699894206421218118`, `theta_major=3.4955599823927878442540968522343399788412842436236` are TEST_ONLY TRAIN observations, never scientifically frozen; `theta_stop=1.0` is operational initialization, not optimum. Use these only under clearly labeled TEST_ONLY with operator permission, never silently.

## 具体原生实现路径 — 不再单独造一个观察策略

Build ONE isolated native strategy ID and incrementally replace the same candidate's code (new version only if platform requirements demand), making real D1→D2→D3→D4→F9→D5→D6 code reachable from a single `@workflow`, with source and spec node graph reflecting each actual computation. Input nodes are native data-capability nodes; `klines` is synchronous and is called only inside `@node("std:fetch")`; `kline_stream` exact strings are preferred where supported. `main()` owns UTC 15m fixed-cutoff scheduling and must wait before first run unless an explicitly isolated TEST_ONLY run. No separate scheduler in spec. Native `strategy/strategy.py` is runtime authority; spec must not point to unrelated stub source. No node calls another node; only workflow awaits nodes.

Implementation must show **per-stage actual outputs or clear typed BLOCKED** at exactly the information cutoff. A stage labeled missing is not implemented; a gate-only stub is not a completed stage. Keep 528 target; if rate quotas force staged waves, preserve all 528 membership and explicit excluded/nontrading flags without silently downscoping.

Acceptance sequence:
1. Native source generated from frozen source's economically relevant rules; explicit per-stage provenance/diff for any new variant. At minimum the real D1/D2/D3/D4 chain has reachable, meaningful computations before calling it a core strategy.
2. Native `validate_code`, `validate_spec`; then `audit_code` to save. **`validate_spec` only validates; only audit_code saves both Spec+Code** under latest user-forwarded contract. `audit_code` has previously errored twice `required save parameters are missing or empty` even with seven config fields; do not loop retries or invent params; compare exact tool schema and JSON-string serialization. If same failure remains, report one consolidated native blocker, no external workaround.
3. Only after saved-version readback + code binding, observe 2 actual successive 15m native cutoffs with 528 target accounting, original stage status, no account/orders. Do not label offline tests, small probes or synthetic inputs as native running.
4. Only after core parity and hard risk protections does Paper/Live become a separately authorized decision; `TAC_LIVE_ENABLED=0` until then.

## Prohibited diversion

Do not reuse `work/ai_pro_port_inactive/pragmatic_core_v1/` as science or runtime authority. Its EMA/ATR/ST + simplified pivots are NOT TAC. Do not create new GitHub hosted watcher, Docker runtime, four-symbol trading substitute, dashboard, another vague support question, new arbitrary strategy rules, unrelated benchmarks or unbounded status documentation.

This handoff does NOT claim that the new AI Pro strategy has been created/saved/audited/executed. The connected Binance plugin exposes only public market data, not AI Pro strategy workspace actions. The user's exact input/authorization is required for native creation/run in AI Pro.
