"""No silent fallback from 2026-10-06 D5 authority to 91-source WP7 gate.

Current UPDATE014 is the final entry observation authority; a caller cannot
manufacture it from D4 signal or D5 PASS outside authoritative stage ledger.
"""
from __future__ import annotations
import importlib.util
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import build_current_native_authority_bundle_v1 as b

class CurrentNativeAuthorityBindingTests(unittest.TestCase):
    def test_ten_formal_D5_sources_and_exact_528(self):
        x=b.make()
        self.assertEqual(len(x["current_d5_slots"]),10)
        self.assertEqual(x["formal_policy_state"],"FROZEN")
        self.assertEqual(x["frozen_528_count"],528)
        self.assertEqual(len(set(x["frozen_symbols"])),528)
        self.assertEqual(x["frozen_528_sha256"],b.FROZEN_SYMBOL_SHA)
        self.assertEqual(x["current_PORT007_requirement"],
                         "CUTOFF_ROTATED_FROZEN_CANONICAL_UNIVERSE_V1")
        self.assertEqual(x["historical_91_source_PORT007_status"],
                         "BLOCKED_HISTORICAL_REFERENCE_NOT_CURRENT")
        self.assertTrue(x["no_new_numeric_theta_stop_from_d5_policy"])
        self.assertFalse(x["final_entry_ready_without_UPDATE014_permitted"])
        self.assertFalse(x["AI_Pro_native_strategy_running"])
        self.assertEqual(x["orders"],0)

    def test_d5_risk_policy_drift_fails_build(self):
        raw=json.loads(b.FORMAL_D5.read_text(encoding="utf8"))
        raw["slots"]["per_trade_account_risk"]["exact_value"]["fraction"]="0.5"
        with tempfile.TemporaryDirectory() as tmp:
            f=Path(tmp)/"wrong.json"
            f.write_text(json.dumps(raw),encoding="utf8")
            with patch.object(b,"FORMAL_D5",f):
                with self.assertRaisesRegex(ValueError,"RISK_RATE_DRIFT"):
                    b.make()

    def test_528_order_drift_fails_build(self):
        raw=json.loads(b.FROZEN_528.read_text(encoding="utf8"))
        raw["symbols"][0],raw["symbols"][1]=raw["symbols"][1],raw["symbols"][0]
        with tempfile.TemporaryDirectory() as tmp:
            f=Path(tmp)/"wrong_528.json"
            f.write_text(json.dumps(raw),encoding="utf8")
            with patch.object(b,"FROZEN_528",f):
                with self.assertRaisesRegex(ValueError,"UNIVERSE_FROZEN_SHA_DRIFT"):
                    b.make()

    def test_actual_latest_update014_guard_demands_signed_symbol_stages(self):
        spec=importlib.util.spec_from_file_location(
            "native_test_real_update014",b.FINAL_ENTRY)
        mod=importlib.util.module_from_spec(spec)
        import sys
        sys.modules[spec.name]=mod
        spec.loader.exec_module(mod)
        fake_sr=SimpleNamespace(
            symbol="BTCUSDT",transaction_id="TX",information_cutoff=1000,
            entry_ready_admitted_by_update014=True,stages=[])
        batch=SimpleNamespace(terminal="COMMITTED",symbol_results=[fake_sr])
        with self.assertRaisesRegex(mod.FinalEntryObservationAuthorityBlock,
                                    "UPDATE-012_STAGE_CARDINALITY"):
            mod.extract_admitted_authorities(batch)
        fake_sr.entry_ready_admitted_by_update014=False
        self.assertEqual(mod.extract_admitted_authorities(batch),())
        with self.assertRaisesRegex(mod.FinalEntryObservationAuthorityBlock,
                                    "AUTHORITATIVE_BATCH_NOT_COMMITTED"):
            mod.extract_admitted_authorities(SimpleNamespace(
                terminal="ABORTED",symbol_results=[fake_sr]))

    def test_manifest_matches_authoritative_bytes_without_permission(self):
        x=b.make()
        for name,rec in x["source_file_hashes"].items():
            raw=(b.ROOT/rec["path"]).read_bytes()
            from hashlib import sha256
            self.assertEqual(rec["sha256"],sha256(raw).hexdigest())
        self.assertFalse(x["native_code_audited"])
        self.assertFalse(x["native_528_compute_executed"])
        self.assertEqual(x["TAC_LIVE_ENABLED"],0)

if __name__=="__main__":
    unittest.main()
