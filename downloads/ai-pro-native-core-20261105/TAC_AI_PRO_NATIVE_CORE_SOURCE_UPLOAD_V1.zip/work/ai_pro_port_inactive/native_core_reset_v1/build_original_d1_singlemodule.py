"""Build an exact-algorithm D1 single module from the SHA-pinned original 91.

ONLY relative-import layout is transformed; class bodies, functions, update
recurrences, parameters and constants retain their original AST meaning.
This is D1 only, an input into the eventual native strategy.py (not trading).
"""
from __future__ import annotations
import ast
import base64
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import tarfile

ROOT=Path(__file__).resolve().parents[3]
SOURCE=ROOT/"provisional_shadow_v1/wp8_strategy_rc1_transport_v1"
DEST=Path(__file__).parent/"source"
ORIGINALS=(
    "result_types.py",
    "ids.py",
    "runtime_guards/information_state.py",
    "runtime_guards/continuity_guard.py",
    "d1_data_math/ohlc_protocol.py",
    "d1_data_math/canonical.py",
    "d1_data_math/ema.py",
    "d1_data_math/atr.py",
    "d1_data_math/supertrend.py",
    "d1_data_math/htf_aggregation.py",
)
def originals(names=ORIGINALS):
    man=json.loads((SOURCE/"wp8_strategy_rc1_exact_transport_v1.json").read_text())
    parts=[]
    for part in man["parts"]:
        data=(SOURCE/part["filename"]).read_bytes()
        if sha256(data).hexdigest()!=part["sha256"]:
            raise ValueError("FROZEN_ARCHIVE_PART_HASH_MISMATCH")
        parts.append(data)
    raw=b"".join(parts)
    if sha256(raw).hexdigest()!=man["deterministic_packaging"]["base64_sha256"]:
        raise ValueError("BASE64_SHA_MISMATCH")
    archive=base64.b64decode(raw,validate=True)
    if sha256(archive).hexdigest()!=man["deterministic_packaging"]["tar_xz_sha256"]:
        raise ValueError("FROZEN_ORIGINAL_ARCHIVE_DRIFT")
    with tarfile.open(fileobj=BytesIO(archive),mode="r:xz") as tf:
        items={m.name:m for m in tf.getmembers() if m.isfile()}
        if len(items)!=91:
            raise ValueError("FROZEN_ORIGINAL_MEMBER_COUNT_DRIFT")
        for name in names:
            f=tf.extractfile(items["strategy_rc1/"+name])
            if f is None: raise ValueError("SOURCE_MISSING:"+name)
            yield name,f.read()


def transform_for_one_module(name, source):
    """Cut relative-import nodes ONLY; other AST nodes are unchanged."""
    text=source.decode("utf-8")
    tree=ast.parse(text,filename=name)
    kept=[]
    removed=[]
    for node in tree.body:
        if isinstance(node,ast.ImportFrom) and node.module=="__future__":
            continue
        if isinstance(node,ast.ImportFrom) and node.level>0:
            removed.append(ast.get_source_segment(text,node))
            continue
        kept.append(node)
    try:
        result=ast.unparse(ast.Module(body=kept,type_ignores=[]))
    except Exception as exc:
        raise RuntimeError("AST_UNPARSE_FAILED:"+name) from exc
    # Verify AST equivalence after removing ONLY allowed relative imports.
    orig=ast.dump(ast.Module(body=kept,type_ignores=[]),include_attributes=False)
    generated=ast.dump(ast.parse(result),include_attributes=False)
    if orig!=generated:
        raise RuntimeError("ORIGINAL_D1_NONIMPORT_AST_CHANGED:"+name)
    return result,removed


def make():
    sections=[]
    manifest=[]
    for name,data in originals():
        body,imports=transform_for_one_module(name,data)
        sections.append("# --- ORIGINAL "+name+" ---\n"+body+"\n")
        manifest.append({"path":"strategy_rc1/"+name,
                         "source_sha256":sha256(data).hexdigest(),
                         "source_bytes":len(data),
                         "removed_relative_imports":imports,
                         "code_body_ast_preserved":True})
    out='''"""Source-preserving D1 single-module dependency closure, generated from SHA-pinned original 91 files.

NOT a full TAC strategy; consume only within a Binance AI Pro native D1-D6
assembly. No synthetic pivot logic. All original scientific function bodies
and numeric constants are unchanged; only module-relative imports removed.
"""
from __future__ import annotations
'''+("\n".join(sections))
    compile(out,"original_d1_singlemodule.py","exec")
    return out,manifest


def main():
    code,rows=make()
    DEST.mkdir(parents=True,exist_ok=True)
    path=DEST/"original_d1_singlemodule.py"
    manpath=DEST/"original_d1_singlemodule_manifest.json"
    path.write_text(code,encoding="utf8")
    manpath.write_text(json.dumps({
       "schema":"TAC_NATIVE_D1_ORIGINAL_SCIENCE_SINGLEMODULE_V1",
       "source_transport_sha256":"36111563b5778513d5803a3ec7c2b86f967a71d915fbcfd9bee5cb4ebebf8174",
       "source_file_count":len(rows),
       "singlemodule_sha256":sha256(code.encode("utf8")).hexdigest(),
       "singlemodule_bytes":len(code.encode("utf8")),
       "original_algorithm_ast_preserved_per_section":True,
       "relative_import_layout_only_changed":True,
       "scope":"D1_ONLY_NOT_D2_D3_D4_F9_D5_D6",
       "native_AIPro_tested":False,
       "orders":0,"TAC_LIVE_ENABLED":0,
       "members":rows
    },sort_keys=True,indent=2)+"\n",encoding="utf8")
    print(f"ORIGINAL_D1_BUILD_PASS sha256={sha256(code.encode('utf8')).hexdigest()} bytes={len(code)} source_modules={len(rows)}")

if __name__=="__main__":
    main()
