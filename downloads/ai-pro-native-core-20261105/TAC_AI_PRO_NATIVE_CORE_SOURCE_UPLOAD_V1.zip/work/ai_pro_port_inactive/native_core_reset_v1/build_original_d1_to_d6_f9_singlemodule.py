"""Generate an ACTUAL original TAC D1→D6/F9 single-code reference.

Strict source provenance; ALL algorithm-bearing Python ASTs preserved and
imports flattened. This artifact is a large intermediate parity/reference,
NOT an AI Pro-deployable code-size claim, NOT a trading implementation.
Do not replace the frozen D5 10-slot authority with reference skeleton defaults.
"""
from __future__ import annotations

import ast
from hashlib import sha256
import json

from build_original_d1_singlemodule import DEST,originals,transform_for_one_module
from build_original_d1d2d3d4_singlemodule import make as make_original_d1234
from inspect_original_d5d6_native_dependencies_v1 import D5_FILES,D6_FILES,F9_FILES

# Exclude literal re-export and dormant metadata stubs; not economic rules.
INCLUDE_D5=tuple(x for x in D5_FILES if x!="d5_reference.py")
INCLUDE_D6=tuple(x for x in D6_FILES if x!="d6_reference.py")
INCLUDE_F9=tuple(x for x in F9_FILES if x!="wp8_reference.py")
FILES=INCLUDE_D5+INCLUDE_D6+INCLUDE_F9

def exports(ast_tree):
    names=set()
    for n in ast_tree.body:
        if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)):
            names.add(n.name)
        elif isinstance(n,ast.Assign):
            names.update(x.id for t in n.targets for x in ast.walk(t) if isinstance(x,ast.Name))
        elif isinstance(n,ast.AnnAssign) and isinstance(n.target,ast.Name):
            names.add(n.target.id)
    return names


def make():
    base,_=make_original_d1234()
    seen=exports(ast.parse(base))
    components=[base]
    entries=[]
    for path,raw in originals(FILES):
        transformed,imports=transform_for_one_module(path,raw)
        found=exports(ast.parse(transformed))
        duplicate=found&seen
        if duplicate:
            raise ValueError("ORIGINAL_NATIVE_SINGLEMODULE_SYMBOL_COLLISION:"+
                             path+":"+repr(sorted(duplicate)))
        seen.update(found)
        components.append("# --- ORIGINAL "+path+" ---\n"+transformed+"\n")
        entries.append({
            "source":"strategy_rc1/"+path,
            "source_sha256":sha256(raw).hexdigest(),
            "raw_bytes":len(raw),
            "nonimport_science_ast_unchanged":True,
            "removed_package_imports":imports,
            "top_level_exports":sorted(found),
        })
    code="\n".join(components)
    compile(code,"original_d1_to_d6_f9_source.py","exec")
    return code,entries


def main():
    code,entries=make()
    DEST.mkdir(parents=True,exist_ok=True)
    (DEST/"original_d1_to_d6_f9_source.py").write_text(code,encoding="utf8")
    meta={
        "schema":"TAC_AI_PRO_ORIGINAL_SOURCE_D1_TO_D6_F9_V1",
        "original_archive_sha256":"36111563b5778513d5803a3ec7c2b86f967a71d915fbcfd9bee5cb4ebebf8174",
        "science_section_count":42+len(entries),
        "new_late_stage_modules":len(entries),
        "original_nonimport_ast_preserved":True,
        "python_code_compiles":True,
        "code_chars":len(code),
        "code_sha256":sha256(code.encode("utf8")).hexdigest(),
        "native_binance_code_limit_confirmed":False,
        "native_binance_validation_or_audit":False,
        "native_binance_running":False,
        "frozen_528_in_native_execution":False,
        "full_original_causal_end_to_end_integration":False,
        "original_latest_update014_source_location":"work/live/full_live_final_entry_observation_authority_v1.py",
        "formal_D5_10slot_source_location":"work/live/full_live_d5_operational_risk_policy_authority_v1.json",
        "full_D5_policy_in_native":False,
        "D6_durable_restart_native":False,
        "TAC_LIVE_ENABLED":0,
        "orders":0,"fills":0,
        "original_source_members":entries,
    }
    (DEST/"original_d1_to_d6_f9_source_manifest.json").write_text(
        json.dumps(meta,indent=2,sort_keys=True,ensure_ascii=False)+"\n",encoding="utf8")
    print("ORIGINAL_D1_D6_F9_SOURCE_BUILD_PASS",json.dumps(
        {k:v for k,v in meta.items() if k!="original_source_members"},sort_keys=True))


if __name__=="__main__":
    main()
