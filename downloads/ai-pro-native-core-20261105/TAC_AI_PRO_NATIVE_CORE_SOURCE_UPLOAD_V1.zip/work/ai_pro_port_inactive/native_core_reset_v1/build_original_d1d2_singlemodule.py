"""Compile original D1+D2 into ONE single science module without logic edits.

This is a build input for final Binance AI Pro native source. Not yet a runnable
native strategy; 60k native codepoint cap and later D3-D6 remain open.
"""
from __future__ import annotations
from hashlib import sha256
import json

from build_original_d1_singlemodule import (
    DEST, make as original_d1_make, originals, transform_for_one_module,
)

D2_FILES=(
    "parameter_snapshot.py",
    "d2_market_state/parameters.py",
    "d2_market_state/types.py",
    "d2_market_state/progress.py",
    "d2_market_state/establishment.py",
    "d2_market_state/pivots.py",
    "d2_market_state/hierarchy.py",
    "d2_market_state/structural_legs.py",
    "d2_market_state/trend.py",
    "d2_market_state/trend_position.py",
    "d2_reference.py",
)
def make():
    d1, _=original_d1_make()
    output=[d1]
    manifest=[]
    for path,data in originals(D2_FILES):
        code,imports=transform_for_one_module(path,data)
        output.append("# --- ORIGINAL "+path+" ---\n"+code+"\n")
        manifest.append({
            "path":"strategy_rc1/"+path,
            "original_sha256":sha256(data).hexdigest(),
            "original_bytes":len(data),
            "removed_module_relative_imports":imports,
            "original_nonimport_ast_preserved":True,
        })
    result="\n".join(output)
    compile(result,"original_d1d2_singlemodule.py","exec")
    return result,manifest


def main():
    code,rows=make()
    DEST.mkdir(parents=True,exist_ok=True)
    (DEST/"original_d1d2_singlemodule.py").write_text(code,encoding="utf8")
    info={
        "schema":"TAC_NATIVE_D1_D2_ORIGINAL_SCIENCE_SINGLEMODULE_V1",
        "source_transport_sha256":"36111563b5778513d5803a3ec7c2b86f967a71d915fbcfd9bee5cb4ebebf8174",
        "d1_included_original_sections":10,
        "d2_included_original_sections":len(rows),
        "all_nonimport_original_ast_preserved":True,
        "code_sha256":sha256(code.encode("utf8")).hexdigest(),
        "code_chars":len(code),
        "native_saved_code_compatible":"NOT_TESTED",
        "full_D3_D4_F9_D5_D6":"NOT_YET_INCLUDED",
        "parameter_theta_minor_intermediate_major":"OPEN_HISTORICALLY_TEST_ONLY_ALLOWED_WITH_PROVENANCE",
        "TAC_LIVE_ENABLED":0,"orders":0,
        "d2_members":rows,
    }
    (DEST/"original_d1d2_singlemodule_manifest.json").write_text(
        json.dumps(info,sort_keys=True,indent=2)+"\n",encoding="utf8")
    print("ORIGINAL_D1_D2_BUILD_PASS",json.dumps({k:v for k,v in info.items() if k!="d2_members"},sort_keys=True))


if __name__=="__main__":
    main()
