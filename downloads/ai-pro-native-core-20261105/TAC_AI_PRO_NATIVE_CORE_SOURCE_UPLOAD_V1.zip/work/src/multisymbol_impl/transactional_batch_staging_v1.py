from __future__ import annotations

"""Engineering-only transactional batch staging surface for Raw V6.

This module does not change frozen scientific semantics.  It provides:
- exact immutable Raw V6 prestate capture/restore;
- isolated per-symbol preparation from one common prestate;
- capture of disposable working-copy poststate and packet authority;
- no durable adoption, no final authoritative batch execution, no collector I/O.

The frozen Raw V6 source is imported without modification and is blob-pinned.
"""

from contextlib import contextmanager
from copy import deepcopy
from dataclasses import dataclass, field
from hashlib import sha256
import json
from pathlib import Path
import sys
from threading import RLock
from types import MappingProxyType
from typing import Any, Iterator, Mapping


REPO_ROOT = Path(__file__).resolve().parents[3]
PROVISIONAL_ROOT = REPO_ROOT / "provisional_shadow_v1"
LIVE_ROOT = REPO_ROOT / "work" / "live"
if str(PROVISIONAL_ROOT) not in sys.path:
    sys.path.insert(0, str(PROVISIONAL_ROOT))
if str(LIVE_ROOT) not in sys.path:
    sys.path.insert(0, str(LIVE_ROOT))

import live_runtime_raw_authority_extraction_packet_orchestration_binding_v6 as rawv6
import reusable_known_frozen_runtime_b3_cohort_composition_production_binding_v1 as known_cohort
import full_live_generic_active_d4_production_binding_v1 as active_d4


SURFACE_ID = "I3A3_TRANSACTIONAL_BATCH_STAGING_SURFACE_V1"
RAW_V6_EXPECTED_BLOB_SHA256 = "775ab80eb71e6c834f784118c33bf0072531023a47a1b6ff4a7129543593b6e3"

RAW_V6_FIELDS = (
    "adapter_state",
    "ledger_events",
    "next_snapshots",
    "assembler_state",
    "lineage_state",
    "candidate_state",
    "b3_state",
    "b5_state",
    "platform_state",
    "minor_history",
    "intermediate_history",
    "completed",
    "last_cutoff",
)

ENGINE_OWNED_FIELDS = (
    "adapter_state",
    "ledger_events",
    "next_snapshots",
)

_CAPTURE_LOCK = RLock()


class BatchStagingBlock(RuntimeError):
    """Engineering fail-closed staging error."""


def _sha256_bytes(data: bytes) -> str:
    return sha256(data).hexdigest()


def _state_digest(raw_state: str) -> str:
    return _sha256_bytes(raw_state.encode("utf-8"))


def _canonical_json(value: Any) -> str:
    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    )


def _value_digest(value: Any) -> str:
    return _sha256_bytes(_canonical_json(value).encode("utf-8"))


def _load_export(raw_state: str) -> dict[str, Any]:
    try:
        payload = json.loads(raw_state)
    except Exception as exc:
        raise BatchStagingBlock("PRESTATE_JSON_INVALID") from exc
    if not isinstance(payload, dict):
        raise BatchStagingBlock("PRESTATE_NOT_OBJECT")
    missing = [name for name in RAW_V6_FIELDS if name not in payload]
    if missing:
        raise BatchStagingBlock(
            "PRESTATE_MISSING_FIELDS:" + ",".join(missing)
        )
    return payload


def _verify_raw_v6_blob() -> None:
    source = Path(rawv6.__file__).resolve()
    got = _sha256_bytes(source.read_bytes())
    if got != RAW_V6_EXPECTED_BLOB_SHA256:
        raise BatchStagingBlock(
            "RAW_V6_BLOB_DRIFT:"
            f"expected={RAW_V6_EXPECTED_BLOB_SHA256}:got={got}"
        )


@dataclass(frozen=True)
class RawV6BatchPrestate:
    raw_state: str
    digest: str
    last_cutoff: int | None

    @classmethod
    def from_export(cls, raw_state: str) -> "RawV6BatchPrestate":
        _verify_raw_v6_blob()
        payload = _load_export(raw_state)
        digest = _state_digest(raw_state)
        last_cutoff = payload.get("last_cutoff")
        if last_cutoff is not None and not isinstance(last_cutoff, int):
            raise BatchStagingBlock("PRESTATE_LAST_CUTOFF_TYPE")
        restored = rawv6.LiveRuntimeRawAuthorityOrchestrationV6.restore_state(
            raw_state
        )
        if restored.export_state() != raw_state:
            raise BatchStagingBlock("PRESTATE_RESTORE_NOT_BYTE_EXACT")
        return cls(
            raw_state=raw_state,
            digest=digest,
            last_cutoff=last_cutoff,
        )

    @classmethod
    def capture(
        cls,
        runtime: Any,
    ) -> "RawV6BatchPrestate":
        return cls.from_export(runtime.export_state())

    def verify(self) -> None:
        if _state_digest(self.raw_state) != self.digest:
            raise BatchStagingBlock("PRESTATE_DIGEST_DRIFT")
        payload = _load_export(self.raw_state)
        if payload.get("last_cutoff") != self.last_cutoff:
            raise BatchStagingBlock("PRESTATE_LAST_CUTOFF_DRIFT")

    def restore_working_copy(self) -> Any:
        self.verify()
        working = rawv6.LiveRuntimeRawAuthorityOrchestrationV6.restore_state(
            self.raw_state
        )
        if working.export_state() != self.raw_state:
            raise BatchStagingBlock("WORKING_COPY_NOT_EXACT_PRESTATE")
        return working


@dataclass(frozen=True)
class RawV6FieldPoststate:
    name: str
    changed: bool
    before_digest: str
    after_digest: str
    after_value: Any


@dataclass(frozen=True)
class PreparedPacketAuthority:
    symbol: str
    cutoff: int
    expected_transaction_id: str
    initial_packet: Any
    final_packet: Any
    origin: str


@dataclass(frozen=True)
class PreparedRawV6Symbol:
    symbol: str
    cutoff: int
    prestate_digest: str
    input_evidence_digest: str
    transaction_id: str
    result: Any
    mode: str
    trend_episode_id: str | None
    relation: Any | None
    poststate_raw: str
    poststate_digest: str
    field_poststates: Mapping[str, RawV6FieldPoststate]
    changed_fields: tuple[str, ...]
    packet_authority: PreparedPacketAuthority
    provenance: Mapping[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        object.__setattr__(
            self,
            "field_poststates",
            MappingProxyType(dict(self.field_poststates)),
        )
        object.__setattr__(
            self,
            "provenance",
            MappingProxyType(
                {str(k): str(v) for k, v in self.provenance.items()}
            ),
        )


@dataclass(frozen=True)
class _CapturedSession:
    initial_packet: Any
    final_packet: Any


@contextmanager
def _capture_preassembled_sessions() -> Iterator[list[_CapturedSession]]:
    """Capture session packet authority without changing frozen source."""
    captures: list[_CapturedSession] = []
    original = rawv6._PreassembledPacketSession

    class CapturingPreassembledPacketSession(original):
        def __init__(
            self,
            adapter: Any,
            initial_packet: Any,
            final_packet: Any,
        ) -> None:
            captures.append(
                _CapturedSession(
                    initial_packet=initial_packet,
                    final_packet=final_packet,
                )
            )
            super().__init__(adapter, initial_packet, final_packet)

    with _CAPTURE_LOCK:
        rawv6._PreassembledPacketSession = CapturingPreassembledPacketSession
        try:
            yield captures
        finally:
            rawv6._PreassembledPacketSession = original


def _transaction_id_from_result(result: Any) -> str:
    engine_result = getattr(result, "engine_result", None)
    rows = getattr(engine_result, "symbol_results", None)
    if rows is None or len(rows) != 1:
        raise BatchStagingBlock(
            "PREPARED_ENGINE_RESULT_NOT_SINGLE_SYMBOL"
        )
    txid = getattr(rows[0], "transaction_id", None)
    if not isinstance(txid, str) or not txid:
        raise BatchStagingBlock("PREPARED_TRANSACTION_ID_MISSING")
    return txid


def _raw_packet() -> Any:
    return rawv6.frozen.CutoffEvidencePacket(
        d3=rawv6.repaired.D3EvidencePacketRC1V1(),
        d4=None,
    )


def _packet_authority(
    *,
    bar: Any,
    result: Any,
    captures: list[_CapturedSession],
) -> PreparedPacketAuthority:
    txid = _transaction_id_from_result(result)

    if len(captures) == 0:
        if getattr(result, "mode", None) != "RAW_PRETREND":
            raise BatchStagingBlock(
                "PREASSEMBLED_SESSION_MISSING_FOR_NON_RAW_MODE"
            )
        packet = _raw_packet()
        return PreparedPacketAuthority(
            symbol=str(bar.symbol),
            cutoff=int(bar.close_time),
            expected_transaction_id=txid,
            initial_packet=packet,
            final_packet=packet,
            origin="RAW_SHADOW_FIXED_PACKET",
        )

    if len(captures) != 1:
        raise BatchStagingBlock(
            f"PREASSEMBLED_SESSION_COUNT:{len(captures)}"
        )

    captured = captures[0]
    return PreparedPacketAuthority(
        symbol=str(bar.symbol),
        cutoff=int(bar.close_time),
        expected_transaction_id=txid,
        initial_packet=captured.initial_packet,
        final_packet=captured.final_packet,
        origin="EPHEMERAL_NONAUTHORITATIVE_WORKING_COPY_ONLY",
    )


def _capture_field_poststates(
    before_raw: str,
    after_raw: str,
) -> tuple[Mapping[str, RawV6FieldPoststate], tuple[str, ...]]:
    before = _load_export(before_raw)
    after = _load_export(after_raw)
    rows: dict[str, RawV6FieldPoststate] = {}
    changed: list[str] = []

    for name in RAW_V6_FIELDS:
        before_value = deepcopy(before[name])
        after_value = deepcopy(after[name])
        before_digest = _value_digest(before_value)
        after_digest = _value_digest(after_value)
        is_changed = before_digest != after_digest
        if is_changed:
            changed.append(name)
        rows[name] = RawV6FieldPoststate(
            name=name,
            changed=is_changed,
            before_digest=before_digest,
            after_digest=after_digest,
            after_value=after_value,
        )

    return MappingProxyType(rows), tuple(changed)


def prepare_symbol_from_common_prestate(
    prestate: RawV6BatchPrestate,
    bar: Any,
) -> PreparedRawV6Symbol:
    """Run one symbol only inside an exact disposable clone of P.

    The working copy may perform its existing producer commits and singleton
    engine calls, but none of those mutations are durable.  This function
    never adopts the working state into any parent runtime.
    """
    _verify_raw_v6_blob()
    prestate.verify()

    symbol = str(getattr(bar, "symbol"))
    cutoff = int(getattr(bar, "close_time"))
    input_digest = str(rawv6.live.digest(bar))

    working = prestate.restore_working_copy()

    # Strong common-prestate assertion before evaluation.
    if working.export_state() != prestate.raw_state:
        raise BatchStagingBlock("WORKING_COPY_PRESTART_DRIFT")

    try:
        with _capture_preassembled_sessions() as captures:
            durable_d3 = working._adapter()._d3_rebuild(symbol)
            prebar = durable_d3.update_000_pre_bar_view(
                int(getattr(bar, "open_time"))
            )
            prebar_count = len(tuple(prebar.snapshots))
            if prebar_count == 0:
                dispatch_mode = "BASE_V6_ZERO_CAUSAL_PREBAR_SNAPSHOT"
                result = working.run_cutoff(bar)
                active_probe = None
            else:
                active_probe = active_d4.probe_active_d4_surface(
                    working,
                    bar,
                )
                if active_probe.prebar_snapshot_count != prebar_count:
                    raise BatchStagingBlock(
                        "ACTIVE_D4_PROBE_PREBAR_COUNT_DRIFT"
                    )
                if active_probe.active or active_probe.nonconsumable_d3_only:
                    # The nonconsumable alternative is a typed no-D4
                    # operational lane, not a new strategy selector. Its
                    # frozen B3 and no-entry invariants are independently
                    # enforced inside the generic binding.
                    dispatch_mode = (
                        "GENERIC_ACTIVE_D4_TYPED_SURFACE"
                        if active_probe.active
                        else "GENERIC_NONCONSUMABLE_B3_D3_ONLY_TYPED_SURFACE"
                    )
                    result = active_d4.run_full_live_generic_active_d4(
                        working,
                        bar,
                    )
                else:
                    dispatch_mode = "GENERIC_KNOWN_COHORT_NO_ACTIVE_SURFACE"
                    result = known_cohort.run_reusable_known_cohort(
                        working,
                        bar,
                    )
    except Exception:
        # The clone is intentionally discarded; no durable adoption exists.
        raise

    # P is immutable and must remain byte/digest exact.
    prestate.verify()

    poststate_raw = working.export_state()
    poststate_digest = _state_digest(poststate_raw)

    field_poststates, changed_fields = _capture_field_poststates(
        prestate.raw_state,
        poststate_raw,
    )

    packet_authority = _packet_authority(
        bar=bar,
        result=result,
        captures=captures,
    )

    txid = _transaction_id_from_result(result)
    if packet_authority.expected_transaction_id != txid:
        raise BatchStagingBlock("PACKET_TRANSACTION_ID_DRIFT")

    return PreparedRawV6Symbol(
        symbol=symbol,
        cutoff=cutoff,
        prestate_digest=prestate.digest,
        input_evidence_digest=input_digest,
        transaction_id=txid,
        result=result,
        mode=str(getattr(result, "mode")),
        trend_episode_id=getattr(result, "trend_episode_id", None),
        relation=getattr(result, "relation", None),
        poststate_raw=poststate_raw,
        poststate_digest=poststate_digest,
        field_poststates=field_poststates,
        changed_fields=changed_fields,
        packet_authority=packet_authority,
        provenance={
            "surface_id": SURFACE_ID,
            "raw_v6_blob_sha256": RAW_V6_EXPECTED_BLOB_SHA256,
            "working_copy_commit": "NOT_DURABLE",
            "singleton_engine_authority":
                "EPHEMERAL_NONAUTHORITATIVE_WORKING_COPY_ONLY",
            "dispatch_mode": dispatch_mode,
            "active_d4_probe_reasons": (
                ""
                if active_probe is None
                else ",".join(active_probe.reasons)
            ),
            "exception_text_dispatch": "false",
            "durable_adoption": "NONE",
        },
    )


def selfcheck_prestate_roundtrip() -> dict[str, Any]:
    """Pure engineering self-check; no bar, market I/O, or durable mutation."""
    _verify_raw_v6_blob()
    runtime = rawv6.LiveRuntimeRawAuthorityOrchestrationV6()
    before = runtime.export_state()
    prestate = RawV6BatchPrestate.capture(runtime)
    restored = prestate.restore_working_copy()
    after = restored.export_state()

    if before != after:
        raise BatchStagingBlock("SELFCHECK_PRESTATE_ROUNDTRIP_DRIFT")
    if _state_digest(before) != prestate.digest:
        raise BatchStagingBlock("SELFCHECK_PRESTATE_DIGEST_DRIFT")
    if tuple(RAW_V6_FIELDS) != (
        "adapter_state",
        "ledger_events",
        "next_snapshots",
        "assembler_state",
        "lineage_state",
        "candidate_state",
        "b3_state",
        "b5_state",
        "platform_state",
        "minor_history",
        "intermediate_history",
        "completed",
        "last_cutoff",
    ):
        raise BatchStagingBlock("SELFCHECK_FIELD_AUTHORITY_DRIFT")

    return {
        "surface_id": SURFACE_ID,
        "raw_v6_blob_sha256": RAW_V6_EXPECTED_BLOB_SHA256,
        "prestate_roundtrip_exact": True,
        "field_count": len(RAW_V6_FIELDS),
        "durable_mutation": False,
        "scientific_semantics_changed": False,
        "frozen_producer_modification_required": False,
        "state_driven_three_way_dispatch": True,
        "exception_text_dispatch": False,
    }


__all__ = [
    "BatchStagingBlock",
    "ENGINE_OWNED_FIELDS",
    "PreparedPacketAuthority",
    "PreparedRawV6Symbol",
    "RAW_V6_FIELDS",
    "RawV6BatchPrestate",
    "RawV6FieldPoststate",
    "SURFACE_ID",
    "prepare_symbol_from_common_prestate",
    "selfcheck_prestate_roundtrip",
]
