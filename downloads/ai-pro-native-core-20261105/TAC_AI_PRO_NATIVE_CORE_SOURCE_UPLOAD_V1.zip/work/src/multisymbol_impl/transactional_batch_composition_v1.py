from __future__ import annotations

"""I3A3B engineering-only batch packet routing and common-prestate delta composition.

This module adds no scientific semantics. It composes only proposed producer
poststates derived from one immutable RawV6 common prestate. Engine-owned
adapter/ledger/snapshot fields are intentionally excluded from composition.
"""

from copy import deepcopy
from dataclasses import dataclass
from hashlib import sha1, sha256
import json
from pathlib import Path
from types import MappingProxyType
from typing import Any, Iterable, Mapping

from . import transactional_batch_staging_v1 as staging

rawv6 = staging.rawv6
live = rawv6.live
frozen = rawv6.frozen

SURFACE_ID = "I3A3_BATCH_PACKET_AND_COMPOSITION_SURFACE_V1"
I3A3A_EXPECTED_GIT_BLOB_SHA1 = "a457a71216892744e95baab668f4d6160f6ea264"

INITIAL_VISIBLE_STEPS = tuple(live.INITIAL_VISIBLE_STEPS)
FINAL_VISIBLE_STEPS = tuple(live.FINAL_VISIBLE_STEPS)
ENGINE_OWNED_FIELDS = tuple(staging.ENGINE_OWNED_FIELDS)

COMPOSED_FIELDS = (
    "assembler_state",
    "lineage_state",
    "candidate_state",
    "b3_state",
    "b5_state",
    "platform_state",
    "minor_history",
    "intermediate_history",
    "completed",
    "last_cutoff",
)


class BatchCompositionBlock(RuntimeError):
    pass


class BatchCompositionConflict(BatchCompositionBlock):
    pass


_MISSING = object()


def _canon(value: Any) -> str:
    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        default=repr,
    )


def _digest(value: Any) -> str:
    if isinstance(value, str):
        data = value.encode("utf-8")
    else:
        data = _canon(value).encode("utf-8")
    return sha256(data).hexdigest()


def _merge_tagged_map(base: Any, values: tuple[Any, ...], path: str) -> Any:
    def decode(node: Any) -> dict[str, Any]:
        if node is _MISSING:
            return {}
        if not isinstance(node, dict) or set(node) != {"$map"}:
            raise BatchCompositionConflict("TAGGED_MAP_SCHEMA:" + path)
        rows = node["$map"]
        if not isinstance(rows, list):
            raise BatchCompositionConflict("TAGGED_MAP_ROWS_SCHEMA:" + path)
        out: dict[str, Any] = {}
        for row in rows:
            if not isinstance(row, list) or len(row) != 2:
                raise BatchCompositionConflict("TAGGED_MAP_ROW_SCHEMA:" + path)
            key = str(row[0])
            if key in out:
                raise BatchCompositionConflict("TAGGED_MAP_DUPLICATE_KEY:" + path + ":" + key)
            out[key] = row[1]
        return out

    base_map = decode(base)
    proposal_maps = tuple(decode(v) if v is not _MISSING else {} for v in values)
    merged = _merge_dict(base_map, proposal_maps, path + ".$map")
    return {"$map": [[k, merged[k]] for k in sorted(merged)]}


def _merge_dataclass_tag(base: Any, values: tuple[Any, ...], path: str) -> Any:
    nodes = (base,) + values
    present = [x for x in nodes if x is not _MISSING]
    tags = []
    for node in present:
        if not isinstance(node, dict) or "$dataclass" not in node or "fields" not in node:
            raise BatchCompositionConflict("DATACLASS_SCHEMA:" + path)
        tags.append(node["$dataclass"])
    if any(tag != tags[0] for tag in tags[1:]):
        raise BatchCompositionConflict("DATACLASS_IDENTITY_CONFLICT:" + path)
    base_fields = {} if base is _MISSING else base["fields"]
    proposal_fields = tuple({} if v is _MISSING else v["fields"] for v in values)
    merged_fields = _merge_dict(base_fields, proposal_fields, path + ".fields")
    return {"$dataclass": deepcopy(tags[0]), "fields": merged_fields}


def _merge_node(base: Any, values: tuple[Any, ...], path: str) -> Any:
    if base is _MISSING:
     changed = tuple(v for v in values if v is not _MISSING)
    else:
     changed = tuple(v for v in values if v is _MISSING or v != base)
    if not changed:
        return deepcopy(base)

    if any(v is _MISSING for v in changed):
        nonmissing = tuple(v for v in changed if v is not _MISSING)
        if nonmissing:
            raise BatchCompositionConflict("DELETE_VS_MODIFY:" + path)
        return _MISSING

    first = changed[0]
    if all(v == first for v in changed[1:]):
        return deepcopy(first)

    dictish = all(isinstance(v, dict) for v in changed)
    if base is not _MISSING:
        dictish = dictish and isinstance(base, dict)

    if dictish:
        sample = first
        if set(sample) == {"$map"}:
            return _merge_tagged_map(base, changed, path)
        if "$dataclass" in sample or "fields" in sample:
            return _merge_dataclass_tag(base, changed, path)
        base_dict = {} if base is _MISSING else base
        return _merge_dict(base_dict, changed, path)

    raise BatchCompositionConflict("DIVERGENT_OVERLAP:" + path)


def _merge_dict(
    base: Mapping[str, Any],
    proposals: tuple[Mapping[str, Any], ...],
    path: str,
) -> dict[str, Any]:
    keys = set(base)
    for proposal in proposals:
        keys.update(proposal)
    out: dict[str, Any] = {}
    for key in sorted(keys, key=str):
        b = base.get(key, _MISSING)
        vals = tuple(p.get(key, _MISSING) for p in proposals)
        merged = _merge_node(b, vals, path + "." + str(key))
        if merged is not _MISSING:
            out[str(key)] = merged
    return out


def merge_common_prestate_mapping(
    base: Mapping[str, Any],
    proposals: Iterable[Mapping[str, Any]],
    *,
    path: str = "state",
) -> dict[str, Any]:
    rows = tuple(proposals)
    if not rows:
        return deepcopy(dict(base))
    return _merge_dict(dict(base), tuple(dict(x) for x in rows), path)


def _parse_json_state(raw: str, field: str) -> Any:
    try:
        return json.loads(raw)
    except Exception as exc:
        raise BatchCompositionConflict(field + "_JSON_INVALID") from exc


def _merge_lineage_state(base: str, proposals: tuple[str, ...]) -> str:
    base_obj = _parse_json_state(base, "lineage_state")
    objs = tuple(_parse_json_state(x, "lineage_state") for x in proposals)

    static = ("schema", "producer_id", "semantic_id")
    for key in static:
        expected = base_obj.get(key)
        if any(obj.get(key) != expected for obj in objs):
            raise BatchCompositionConflict("LINEAGE_STATIC_IDENTITY_CONFLICT:" + key)

    def pairs_to_map(obj: Mapping[str, Any], key: str) -> dict[str, Any]:
        rows = obj.get(key, [])
        if not isinstance(rows, list):
            raise BatchCompositionConflict("LINEAGE_LIST_SCHEMA:" + key)
        out: dict[str, Any] = {}
        for row in rows:
            if not isinstance(row, list) or len(row) != 2:
                raise BatchCompositionConflict("LINEAGE_ROW_SCHEMA:" + key)
            k = str(row[0])
            if k in out:
                raise BatchCompositionConflict("LINEAGE_DUPLICATE_KEY:" + key + ":" + k)
            out[k] = row[1]
        return out

    merged = {
        "schema": base_obj["schema"],
        "producer_id": base_obj["producer_id"],
        "semantic_id": base_obj["semantic_id"],
    }
    for key in ("ledgers", "committed_transactions"):
        base_map = pairs_to_map(base_obj, key)
        prop_maps = tuple(pairs_to_map(obj, key) for obj in objs)
        value = _merge_dict(base_map, prop_maps, "lineage_state." + key)
        merged[key] = [[k, value[k]] for k in sorted(value)]
    return json.dumps(merged, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def _merge_candidate_state(base: str, proposals: tuple[str, ...]) -> str:
    base_obj = _parse_json_state(base, "candidate_state")
    objs = tuple(_parse_json_state(x, "candidate_state") for x in proposals)
    merged = _merge_node(base_obj, objs, "candidate_state")
    if merged is _MISSING:
        raise BatchCompositionConflict("CANDIDATE_STATE_DELETED")
    return json.dumps(merged, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def _merge_b3_state(base: str, proposals: tuple[str, ...]) -> str:
    """Merge frozen Runtime-B3 list-pair maps from one common prestate."""
    base_obj = _parse_json_state(base, "b3_state")
    objs = tuple(_parse_json_state(x, "b3_state") for x in proposals)
    if not isinstance(base_obj, dict) or any(
        not isinstance(x, dict) for x in objs
    ):
        raise BatchCompositionConflict("B3_STATE_NOT_OBJECT")

    static = ("producer_id", "semantic_id")
    for key in static:
        expected = base_obj.get(key)
        if not isinstance(expected, str) or not expected:
            raise BatchCompositionConflict(
                "B3_STATE_STATIC_IDENTITY_MISSING:" + key
            )
        if any(obj.get(key) != expected for obj in objs):
            raise BatchCompositionConflict(
                "B3_STATE_STATIC_IDENTITY_CONFLICT:" + key
            )

    def pairs_to_map(obj: Mapping[str, Any], key: str) -> dict[str, Any]:
        rows = obj.get(key, [])
        if not isinstance(rows, list):
            raise BatchCompositionConflict(
                "B3_STATE_LIST_SCHEMA:" + key
            )
        out: dict[str, Any] = {}
        for row in rows:
            if not isinstance(row, list) or len(row) != 2:
                raise BatchCompositionConflict(
                    "B3_STATE_ROW_SCHEMA:" + key
                )
            identity = str(row[0])
            if identity in out:
                raise BatchCompositionConflict(
                    "B3_STATE_DUPLICATE_KEY:" + key + ":" + identity
                )
            out[identity] = row[1]
        return out

    merged: dict[str, Any] = {
        "producer_id": base_obj["producer_id"],
        "semantic_id": base_obj["semantic_id"],
    }
    for key in ("lineages", "completed_transactions"):
        base_map = pairs_to_map(base_obj, key)
        prop_maps = tuple(pairs_to_map(obj, key) for obj in objs)
        value = _merge_dict(
            base_map,
            prop_maps,
            "b3_state." + key,
        )
        merged[key] = [[k, value[k]] for k in sorted(value)]

    return json.dumps(
        merged,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    )


def _merge_identity_tuple(
    base: tuple[Any, ...],
    proposals: tuple[tuple[Any, ...], ...],
    *,
    identity_attr: str,
) -> tuple[Any, ...]:
    def keyed(rows: tuple[Any, ...]) -> dict[str, Any]:
        out: dict[str, Any] = {}
        for row in rows:
            identity = str(getattr(row, identity_attr))
            prior = out.get(identity)
            if prior is not None and prior != row:
                raise BatchCompositionConflict("IDENTITY_TUPLE_DIVERGENT:" + identity)
            out[identity] = row
        return out

    base_map = keyed(base)
    merged = dict(base_map)
    for proposal in proposals:
        proposal_map = keyed(proposal)
        missing = set(base_map) - set(proposal_map)
        if missing:
            raise BatchCompositionConflict(
                "IDENTITY_TUPLE_DELETE:" + ",".join(sorted(missing))
            )
        for identity, row in proposal_map.items():
            prior = merged.get(identity)
            if prior is not None and prior != row:
                raise BatchCompositionConflict(
                    "IDENTITY_TUPLE_DIVERGENT:" + identity
                )
            merged[identity] = row

    def sort_key(row: Any) -> tuple[Any, str]:
        return (getattr(row, "confirmed_at", 0), str(getattr(row, identity_attr)))

    return tuple(sorted(merged.values(), key=sort_key))


def _merge_completed(
    base: Mapping[str, Any],
    proposals: tuple[Mapping[str, Any], ...],
) -> dict[str, Any]:
    out = dict(base)
    for proposal in proposals:
        missing = set(base) - set(proposal)
        if missing:
            raise BatchCompositionConflict(
                "COMPLETED_DELETE:" + ",".join(sorted(missing))
            )
        for key, value in proposal.items():
            prior = out.get(key, _MISSING)
            if prior is not _MISSING and prior != value:
                raise BatchCompositionConflict("COMPLETED_DIVERGENT:" + str(key))
            out[str(key)] = value
    return out


@dataclass(frozen=True)
class ComposedProducerCandidate:
    cutoff: int
    prestate_digest: str
    assembler_state: Mapping[str, Any]
    lineage_state: str
    candidate_state: str
    b3_state: str
    b5_state: Mapping[str, Any]
    platform_state: Mapping[str, Any]
    minor_history: tuple[Any, ...]
    intermediate_history: tuple[Any, ...]
    completed: Mapping[str, Any]
    last_cutoff: int
    source_symbols: tuple[str, ...]
    digest: str


def compose_prepared_symbol_deltas(
    prestate: staging.RawV6BatchPrestate,
    prepared: Iterable[staging.PreparedRawV6Symbol],
) -> ComposedProducerCandidate:
    rows = tuple(prepared)
    if not rows:
        raise BatchCompositionBlock("EMPTY_PREPARED_BATCH")

    symbols = [row.symbol for row in rows]
    if len(set(symbols)) != len(symbols):
        raise BatchCompositionConflict("DUPLICATE_SYMBOL")

    cutoffs = {row.cutoff for row in rows}
    if len(cutoffs) != 1:
        raise BatchCompositionConflict("MIXED_CUTOFF")
    cutoff = next(iter(cutoffs))

    if any(row.prestate_digest != prestate.digest for row in rows):
        raise BatchCompositionConflict("PRESTATE_DIGEST_MISMATCH")

    base_rt = rawv6.LiveRuntimeRawAuthorityOrchestrationV6.restore_state(
        prestate.raw_state
    )
    base = base_rt.state

    assembler = merge_common_prestate_mapping(
        dict(base.assembler_state),
        tuple(dict(rawv6.live._decode(row.field_poststates["assembler_state"].after_value)) for row in rows),
        path="assembler_state",
    )
    lineage = _merge_lineage_state(
        base.lineage_state,
        tuple(str(row.field_poststates["lineage_state"].after_value) for row in rows),
    )
    candidate = _merge_candidate_state(
        base.candidate_state,
        tuple(str(row.field_poststates["candidate_state"].after_value) for row in rows),
    )
    b3 = _merge_b3_state(
        base.b3_state,
        tuple(str(row.field_poststates["b3_state"].after_value) for row in rows),
    )
    b5 = merge_common_prestate_mapping(
        dict(base.b5_state),
        tuple(dict(rawv6.live._decode(row.field_poststates["b5_state"].after_value)) for row in rows),
        path="b5_state",
    )
    platform = merge_common_prestate_mapping(
        dict(base.platform_state),
        tuple(dict(rawv6.live._decode(row.field_poststates["platform_state"].after_value)) for row in rows),
        path="platform_state",
    )
    minor = _merge_identity_tuple(
        tuple(base.minor_history),
        tuple(tuple(rawv6.live._decode(row.field_poststates["minor_history"].after_value)) for row in rows),
        identity_attr="pivot_id",
    )
    intermediate = _merge_identity_tuple(
        tuple(base.intermediate_history),
        tuple(tuple(rawv6.live._decode(row.field_poststates["intermediate_history"].after_value)) for row in rows),
        identity_attr="pivot_id",
    )
    completed = _merge_completed(
        dict(base.completed),
        tuple(rawv6.live._decode(row.field_poststates["completed"].after_value) for row in rows),
    )

    record = {
        "cutoff": cutoff,
        "prestate_digest": prestate.digest,
        "assembler_state_digest": _digest(assembler),
        "lineage_state_digest": _digest(lineage),
        "candidate_state_digest": _digest(candidate),
        "b3_state_digest": _digest(b3),
        "b5_state_digest": _digest(b5),
        "platform_state_digest": _digest(platform),
        "minor_history_digest": _digest([repr(x) for x in minor]),
        "intermediate_history_digest": _digest([repr(x) for x in intermediate]),
        "completed_digest": _digest(
            {k: repr(v) for k, v in sorted(completed.items())}
        ),
        "last_cutoff": cutoff,
        "source_symbols": sorted(symbols),
    }
    digest = sha256(
        json.dumps(
            record,
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
        ).encode("utf-8")
    ).hexdigest()

    return ComposedProducerCandidate(
        cutoff=cutoff,
        prestate_digest=prestate.digest,
        assembler_state=MappingProxyType(assembler),
        lineage_state=lineage,
        candidate_state=candidate,
        b3_state=b3,
        b5_state=MappingProxyType(b5),
        platform_state=MappingProxyType(platform),
        minor_history=minor,
        intermediate_history=intermediate,
        completed=MappingProxyType(completed),
        last_cutoff=cutoff,
        source_symbols=tuple(sorted(symbols)),
        digest=digest,
    )


class BatchPreassembledPacketSession:
    def __init__(
        self,
        adapter: Any,
        prepared_rows: Iterable[Any],
    ) -> None:
        self.adapter = adapter
        rows = tuple(prepared_rows)
        if not rows:
            raise BatchCompositionBlock("EMPTY_PACKET_SESSION")

        by_key: dict[tuple[str, str], staging.PreparedPacketAuthority] = {}
        symbols: set[str] = set()
        txs: set[str] = set()
        cutoffs: set[int] = set()

        for row in rows:
            symbol = str(row.symbol)
            cutoff = int(row.cutoff)
            tx = str(row.transaction_id)
            authority = row.packet_authority
            if authority is None:
                raise BatchCompositionBlock("MISSING_PACKET_AUTHORITY:" + symbol)
            if (
                authority.symbol != symbol
                or authority.cutoff != cutoff
                or authority.expected_transaction_id != tx
            ):
                raise BatchCompositionConflict(
                    "PACKET_AUTHORITY_IDENTITY_MISMATCH:" + symbol
                )
            if symbol in symbols:
                raise BatchCompositionConflict("DUPLICATE_SYMBOL:" + symbol)
            if tx in txs:
                raise BatchCompositionConflict("DUPLICATE_TRANSACTION:" + tx)
            key = (symbol, tx)
            if key in by_key and by_key[key] != authority:
                raise BatchCompositionConflict(
                    "CONFLICTING_PACKET_AUTHORITY:" + symbol + ":" + tx
                )
            by_key[key] = authority
            symbols.add(symbol)
            txs.add(tx)
            cutoffs.add(cutoff)

        if len(cutoffs) != 1:
            raise BatchCompositionConflict("MIXED_CUTOFF_PACKET_SESSION")

        self.cutoff = next(iter(cutoffs))
        self._by_key = MappingProxyType(by_key)
        self.initial_steps: dict[str, list[str]] = {}
        self.final_steps: dict[str, list[str]] = {}

    def _authority_for(self, ctx: Any) -> staging.PreparedPacketAuthority:
        symbol = str(ctx.symbol_input.symbol)
        tx = str(ctx.transaction_id)
        authority = self._by_key.get((symbol, tx))
        if authority is None:
            raise BatchCompositionBlock(
                "MISSING_PACKET_AUTHORITY:" + symbol + ":" + tx
            )
        close_time = int(ctx.symbol_input.observer_bar.close_time)
        if close_time != authority.cutoff or close_time != self.cutoff:
            raise BatchCompositionConflict(
                "PACKET_CUTOFF_MISMATCH:" + symbol + ":" + tx
            )
        return authority

    def adapter_for(self, step: Any):
        def run(ctx: Any) -> Any:
            if ctx.step is not step:
                raise BatchCompositionConflict("STAGE_CONTEXT_MISMATCH")
            authority = self._authority_for(ctx)
            if step.value in INITIAL_VISIBLE_STEPS:
                packet = authority.initial_packet
                self.initial_steps.setdefault(ctx.transaction_id, []).append(step.value)
            elif step.value in FINAL_VISIBLE_STEPS:
                packet = authority.final_packet
                self.final_steps.setdefault(ctx.transaction_id, []).append(step.value)
            else:
                raise BatchCompositionConflict(
                    "UNKNOWN_PACKET_VISIBILITY_STEP:" + str(step.value)
                )
            self.adapter.set_evidence(
                ctx.symbol_input.symbol,
                ctx.symbol_input.observer_bar.open_time,
                packet,
            )
            return self.adapter._make_adapter(step)(ctx)
        return run

    def registry(self) -> Any:
        steps = tuple(
            live.engine_mod.UpdateStep(f"UPDATE-{i:03d}")
            for i in range(1, 14)
        )
        return live.engine_mod.AdapterRegistry(
            {step: self.adapter_for(step) for step in steps}
        )


def _module_sha(path: Path) -> str:
    return sha256(path.read_bytes()).hexdigest()


def _git_blob_sha1(path: Path) -> str:
    data = path.read_bytes()
    header = b"blob " + str(len(data)).encode("ascii") + b"\0"
    return sha1(header + data).hexdigest()


def selfcheck_composition_primitives() -> dict[str, Any]:
    i3a3a_path = Path(staging.__file__).resolve()
    i3a3a_sha = _module_sha(i3a3a_path)
    i3a3a_blob = _git_blob_sha1(i3a3a_path)
    if i3a3a_blob != I3A3A_EXPECTED_GIT_BLOB_SHA1:
        raise BatchCompositionBlock(
            "I3A3A_GIT_BLOB_DRIFT:expected="
            + I3A3A_EXPECTED_GIT_BLOB_SHA1
            + ":got="
            + i3a3a_blob
        )

    base = {"a": 1, "b": 1}
    ab = merge_common_prestate_mapping(
        base,
        ({"a": 2, "b": 1}, {"a": 1, "b": 2}),
        path="selfcheck",
    )
    ba = merge_common_prestate_mapping(
        base,
        ({"a": 1, "b": 2}, {"a": 2, "b": 1}),
        path="selfcheck",
    )
    if ab != {"a": 2, "b": 2} or ab != ba:
        raise BatchCompositionConflict("SELFCHECK_DISJOINT_COMMUTE")

    identical = merge_common_prestate_mapping(
        {"a": 1},
        ({"a": 2}, {"a": 2}),
        path="selfcheck",
    )
    if identical != {"a": 2}:
        raise BatchCompositionConflict("SELFCHECK_IDENTICAL_OVERLAP")

    divergent = False
    try:
        merge_common_prestate_mapping(
            {"a": 1},
            ({"a": 2}, {"a": 3}),
            path="selfcheck",
        )
    except BatchCompositionConflict:
        divergent = True
    if not divergent:
        raise BatchCompositionConflict("SELFCHECK_DIVERGENT_NOT_BLOCKED")

    delete_modify = False
    try:
        merge_common_prestate_mapping(
            {"a": {"x": 1}},
            ({}, {"a": {"x": 2}}),
            path="selfcheck",
        )
    except BatchCompositionConflict:
        delete_modify = True
    if not delete_modify:
        raise BatchCompositionConflict("SELFCHECK_DELETE_MODIFY_NOT_BLOCKED")

    b3_base = json.dumps(
        {
            "producer_id": "B3",
            "semantic_id": "SEM",
            "lineages": [],
            "completed_transactions": [],
        },
        sort_keys=True,
        separators=(",", ":"),
    )
    b3_a = json.dumps(
        {
            "producer_id": "B3",
            "semantic_id": "SEM",
            "lineages": [["A\\u001fC1", {"v": 1}]],
            "completed_transactions": [["TX-A", {"v": 1}]],
        },
        sort_keys=True,
        separators=(",", ":"),
    )
    b3_b = json.dumps(
        {
            "producer_id": "B3",
            "semantic_id": "SEM",
            "lineages": [["B\\u001fC2", {"v": 2}]],
            "completed_transactions": [["TX-B", {"v": 2}]],
        },
        sort_keys=True,
        separators=(",", ":"),
    )
    b3_merged = json.loads(_merge_b3_state(b3_base, (b3_a, b3_b)))
    if [x[0] for x in b3_merged["lineages"]] != [
        "A\\u001fC1",
        "B\\u001fC2",
    ]:
        raise BatchCompositionConflict(
            "SELFCHECK_B3_LINEAGE_DISJOINT_MERGE"
        )
    if [x[0] for x in b3_merged["completed_transactions"]] != [
        "TX-A",
        "TX-B",
    ]:
        raise BatchCompositionConflict(
            "SELFCHECK_B3_TX_DISJOINT_MERGE"
        )

    b3_divergent = False
    try:
        _merge_b3_state(
            b3_base,
            (
                json.dumps(
                    {
                        "producer_id": "B3",
                        "semantic_id": "SEM",
                        "lineages": [["A\\u001fC1", {"v": 1}]],
                        "completed_transactions": [],
                    },
                    sort_keys=True,
                    separators=(",", ":"),
                ),
                json.dumps(
                    {
                        "producer_id": "B3",
                        "semantic_id": "SEM",
                        "lineages": [["A\\u001fC1", {"v": 2}]],
                        "completed_transactions": [],
                    },
                    sort_keys=True,
                    separators=(",", ":"),
                ),
            ),
        )
    except BatchCompositionConflict:
        b3_divergent = True
    if not b3_divergent:
        raise BatchCompositionConflict(
            "SELFCHECK_B3_DIVERGENT_NOT_BLOCKED"
        )

    tagged = merge_common_prestate_mapping(
        {"x": {"$map": [["a", 1]]}},
        (
            {"x": {"$map": [["a", 1], ["b", 2]]}},
            {"x": {"$map": [["a", 1], ["c", 3]]}},
        ),
        path="selfcheck",
    )
    if tagged != {"x": {"$map": [["a", 1], ["b", 2], ["c", 3]]}}:
        raise BatchCompositionConflict("SELFCHECK_TAGGED_MAP")

    return {
        "surface_id": SURFACE_ID,
        "i3a3a_sha256_observed": i3a3a_sha,
        "i3a3a_git_blob_sha1": i3a3a_blob,
        "disjoint_commute": True,
        "identical_overlap_idempotent": True,
        "divergent_overlap_fail_closed": divergent,
        "delete_vs_modify_fail_closed": delete_modify,
        "tagged_map_disjoint_compose": True,
        "b3_disjoint_state_compose": True,
        "b3_divergent_overlap_fail_closed": b3_divergent,
        "initial_visible_steps": INITIAL_VISIBLE_STEPS,
        "final_visible_steps": FINAL_VISIBLE_STEPS,
        "engine_owned_fields_composed": False,
        "authoritative_formal_batch_engine_calls": 0,
        "durable_mutation": False,
        "scientific_semantics_changed": False,
        "frozen_producer_modification_required": False,
    }


__all__ = (
    "BatchCompositionBlock",
    "BatchCompositionConflict",
    "BatchPreassembledPacketSession",
    "ComposedProducerCandidate",
    "ENGINE_OWNED_FIELDS",
    "FINAL_VISIBLE_STEPS",
    "INITIAL_VISIBLE_STEPS",
    "SURFACE_ID",
    "compose_prepared_symbol_deltas",
    "merge_common_prestate_mapping",
    "selfcheck_composition_primitives",
)
