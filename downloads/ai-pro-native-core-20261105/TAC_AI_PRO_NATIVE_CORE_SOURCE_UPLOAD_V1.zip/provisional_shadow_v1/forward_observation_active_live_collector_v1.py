"""Active Forward Observation collector with one combined runtime+ledger transaction.

Each eligible completed 15m envelope is processed against staged copies of:
  1) AtomicBinanceSessionToStateDrivenRuntimeV1, and
  2) LatestRuntimeForwardObservationCompatibilityV1.

A single combined checkpoint is persisted before either staged state is adopted.
Partial events and completed cutoffs at/before collector start are never persisted.
No missed cutoff is backfilled.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from hashlib import sha256
from typing import Any, Callable

import binance_concrete_session_to_latest_atomic_runtime_v1 as runtime_binding
import forward_observation_latest_runtime_ledger_compatibility_v1 as observer_binding


BINDING_ID = "FORWARD_OBSERVATION_ACTIVE_LIVE_COLLECTOR_SINGLE_TRANSACTION_V1"
STATE_SCHEMA = "TAC_FORWARD_OBSERVATION_ACTIVE_LIVE_COLLECTOR_V1_STATE"
ACTIVATION_TERMINAL_BLOB = "663a17653ed0fb3bc948374b08a8c3715ddab85a"
COMPATIBILITY_TERMINAL_BLOB = "2c89dc3c05414b4261a31b2f71a9329a7ccbc6ef"
RUNTIME_BINDING_BLOB = "a1fd1cfcd11bf52d90e31c3b4dc6249037fdbf72"
OBSERVER_BINDING_BLOB = "16ead44385e4d0a599a8d3dff9558b7ce7db3519"
ACTIVATION_BOUNDARY_MS = observer_binding.ACTIVATION_BOUNDARY_MS
FIRST_ELIGIBLE_FORWARD_CUTOFF_MS = observer_binding.FIRST_ELIGIBLE_FORWARD_CUTOFF_MS


class ActiveCollectorBlock(RuntimeError):
    pass


class ActiveCollectorConflict(RuntimeError):
    pass


def canonical_json(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def digest(value: Any) -> str:
    payload = value if isinstance(value, str) else canonical_json(value)
    return sha256(payload.encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class CollectorCutoffResult:
    status: str
    symbol: str
    cutoff: int | None
    runtime_status: str | None
    observer_status: str | None
    observation_count: int
    checkpoint_digest: str


@dataclass(frozen=True)
class CollectorSegmentResult:
    status: str
    collector_started_at_ms: int
    envelope_count: int
    partial_count: int
    missed_closed_count: int
    eligible_closed_count: int
    accepted_symbol: str
    accepted_cutoff: int
    runtime_status: str
    observer_status: str
    observation_count: int
    checkpoint_digest: str


class ActiveForwardObservationCollectorV1:
    def __init__(
        self,
        universe: tuple[str, ...] | list[str],
        *,
        runtime: runtime_binding.AtomicBinanceSessionToStateDrivenRuntimeV1 | None = None,
        observer: observer_binding.LatestRuntimeForwardObservationCompatibilityV1 | None = None,
        last_committed_cutoff: int | None = None,
    ) -> None:
        self.universe = tuple(universe)
        self.runtime = runtime or runtime_binding.AtomicBinanceSessionToStateDrivenRuntimeV1(
            self.universe
        )
        self.observer = observer or observer_binding.LatestRuntimeForwardObservationCompatibilityV1()
        self.last_committed_cutoff = last_committed_cutoff

    def _state_object(
        self,
        runtime_obj: runtime_binding.AtomicBinanceSessionToStateDrivenRuntimeV1,
        observer_obj: observer_binding.LatestRuntimeForwardObservationCompatibilityV1,
        last_committed_cutoff: int | None,
    ) -> dict[str, Any]:
        return {
            "schema": STATE_SCHEMA,
            "binding_id": BINDING_ID,
            "authorities": {
                "activation_terminal_blob": ACTIVATION_TERMINAL_BLOB,
                "compatibility_terminal_blob": COMPATIBILITY_TERMINAL_BLOB,
                "runtime_binding_blob": RUNTIME_BINDING_BLOB,
                "observer_binding_blob": OBSERVER_BINDING_BLOB,
            },
            "activation": {
                "forward_observation": "ACTIVE",
                "activation_boundary_ms": ACTIVATION_BOUNDARY_MS,
                "first_eligible_forward_cutoff_ms": FIRST_ELIGIBLE_FORWARD_CUTOFF_MS,
                "no_backfill": True,
            },
            "runtime_state": json.loads(runtime_obj.export_state()),
            "observer_state": json.loads(observer_obj.export_state()),
            "last_committed_cutoff": last_committed_cutoff,
            "observation_count": observer_obj.observation_count,
            "governance": {
                "test": "NOT_AUTHORIZED",
                "test_read": False,
                "test_availability_checked": False,
                "outcome_read": False,
                "pnl": False,
                "trading": "FORBIDDEN",
                "orders": 0,
                "fills": 0,
                "execution_intents": 0,
                "zero_feedback": True,
                "minimal_runnable_baseline_persisted": False,
            },
        }

    def export_state(self) -> bytes:
        return (
            canonical_json(
                self._state_object(
                    self.runtime,
                    self.observer,
                    self.last_committed_cutoff,
                )
            )
            + "\n"
        ).encode("utf-8")

    def state_digest(self) -> str:
        return sha256(self.export_state()).hexdigest()

    @classmethod
    def restore(
        cls,
        universe: tuple[str, ...] | list[str],
        payload: bytes | str,
    ) -> "ActiveForwardObservationCollectorV1":
        try:
            raw = json.loads(payload)
        except Exception as exc:
            raise ActiveCollectorBlock("COLLECTOR_STATE_JSON_INVALID") from exc
        if raw.get("schema") != STATE_SCHEMA or raw.get("binding_id") != BINDING_ID:
            raise ActiveCollectorBlock("COLLECTOR_STATE_SCHEMA_MISMATCH")
        auth = raw.get("authorities", {})
        expected = {
            "activation_terminal_blob": ACTIVATION_TERMINAL_BLOB,
            "compatibility_terminal_blob": COMPATIBILITY_TERMINAL_BLOB,
            "runtime_binding_blob": RUNTIME_BINDING_BLOB,
            "observer_binding_blob": OBSERVER_BINDING_BLOB,
        }
        if auth != expected:
            raise ActiveCollectorBlock("COLLECTOR_STATE_AUTHORITY_MISMATCH")
        activation = raw.get("activation", {})
        if (
            activation.get("forward_observation") != "ACTIVE"
            or activation.get("activation_boundary_ms") != ACTIVATION_BOUNDARY_MS
            or activation.get("first_eligible_forward_cutoff_ms")
            != FIRST_ELIGIBLE_FORWARD_CUTOFF_MS
            or activation.get("no_backfill") is not True
        ):
            raise ActiveCollectorBlock("COLLECTOR_STATE_ACTIVATION_MISMATCH")
        gov = raw.get("governance", {})
        if (
            gov.get("test") != "NOT_AUTHORIZED"
            or gov.get("test_read") is not False
            or gov.get("test_availability_checked") is not False
            or gov.get("outcome_read") is not False
            or gov.get("pnl") is not False
            or gov.get("trading") != "FORBIDDEN"
            or any(gov.get(k) != 0 for k in ("orders", "fills", "execution_intents"))
            or gov.get("zero_feedback") is not True
            or gov.get("minimal_runnable_baseline_persisted") is not False
        ):
            raise ActiveCollectorBlock("COLLECTOR_STATE_GOVERNANCE_MISMATCH")
        runtime = runtime_binding.AtomicBinanceSessionToStateDrivenRuntimeV1.restore(
            universe,
            canonical_json(raw["runtime_state"]) + "\n",
        )
        observer = observer_binding.LatestRuntimeForwardObservationCompatibilityV1.restore_state(
            canonical_json(raw["observer_state"]) + "\n",
        )
        if raw.get("observation_count") != observer.observation_count:
            raise ActiveCollectorBlock("COLLECTOR_STATE_OBSERVATION_COUNT_MISMATCH")
        cutoff = raw.get("last_committed_cutoff")
        if cutoff is not None and (not isinstance(cutoff, int) or cutoff < FIRST_ELIGIBLE_FORWARD_CUTOFF_MS):
            raise ActiveCollectorBlock("COLLECTOR_STATE_LAST_CUTOFF_INVALID")
        return cls(
            universe,
            runtime=runtime,
            observer=observer,
            last_committed_cutoff=cutoff,
        )

    def process_envelope_atomic(
        self,
        envelope: dict[str, Any],
        *,
        collector_started_at_ms: int,
        persist: Callable[[bytes], Any] | None = None,
    ) -> CollectorCutoffResult:
        # The frozen runtime binding supplies the exact stateless transport gates.
        _event, _stream, kline, symbol = self.runtime._validate_transport_surface(envelope)
        if kline.get("x") is not True:
            return CollectorCutoffResult(
                status="IGNORED_PARTIAL",
                symbol=symbol,
                cutoff=None,
                runtime_status=None,
                observer_status=None,
                observation_count=self.observer.observation_count,
                checkpoint_digest=self.state_digest(),
            )

        try:
            cutoff = int(kline["T"])
        except Exception as exc:
            raise ActiveCollectorBlock("COMPLETED_KLINE_CUTOFF_INVALID") from exc

        if cutoff < FIRST_ELIGIBLE_FORWARD_CUTOFF_MS or cutoff <= collector_started_at_ms:
            return CollectorCutoffResult(
                status="MISSED_BEFORE_COLLECTOR_START_NO_BACKFILL",
                symbol=symbol,
                cutoff=cutoff,
                runtime_status=None,
                observer_status=None,
                observation_count=self.observer.observation_count,
                checkpoint_digest=self.state_digest(),
            )
        if self.last_committed_cutoff is not None and cutoff < self.last_committed_cutoff:
            return CollectorCutoffResult(
                status="OLDER_THAN_DURABLE_COLLECTOR_CHECKPOINT_NO_BACKFILL",
                symbol=symbol,
                cutoff=cutoff,
                runtime_status=None,
                observer_status=None,
                observation_count=self.observer.observation_count,
                checkpoint_digest=self.state_digest(),
            )

        before = self.export_state()
        staged_runtime = runtime_binding.AtomicBinanceSessionToStateDrivenRuntimeV1.restore(
            self.universe,
            self.runtime.export_state(),
        )
        staged_observer = observer_binding.LatestRuntimeForwardObservationCompatibilityV1.restore_state(
            self.observer.export_state()
        )

        runtime_result = staged_runtime.process_official_envelope_atomic(envelope)
        if runtime_result.status not in ("COMMITTED", "IDEMPOTENT_REPLAY"):
            if self.export_state() != before:
                raise ActiveCollectorConflict("RUNTIME_NONCOMMIT_MUTATED_COLLECTOR_STATE")
            raise ActiveCollectorBlock(
                "RUNTIME_RESULT_NOT_DURABLE:" + runtime_result.status
            )
        if runtime_result.cutoff != cutoff or runtime_result.symbol != symbol:
            raise ActiveCollectorConflict("RUNTIME_RESULT_IDENTITY_MISMATCH")
        raw_result = runtime_result.runtime_result
        if raw_result is None:
            raise ActiveCollectorBlock("RUNTIME_RESULT_MISSING_RAW_V6_RESULT")

        observer_result = staged_observer.project_and_open(
            staged_runtime.runtime.raw_runtime,
            raw_result,
            symbol=symbol,
            cutoff=cutoff,
        )
        if observer_result.status == "PREBOUNDARY_INELIGIBLE":
            raise ActiveCollectorConflict("POST_START_CUTOFF_BECAME_PREBOUNDARY")

        candidate_cutoff = (
            cutoff
            if self.last_committed_cutoff is None
            else max(self.last_committed_cutoff, cutoff)
        )
        candidate = (
            canonical_json(
                self._state_object(
                    staged_runtime,
                    staged_observer,
                    candidate_cutoff,
                )
            )
            + "\n"
        ).encode("utf-8")
        status = "IDEMPOTENT_REPLAY" if candidate == before else "COMMITTED"

        if status == "COMMITTED" and persist is not None:
            try:
                persist(candidate)
            except Exception as exc:
                if self.export_state() != before:
                    raise ActiveCollectorConflict(
                        "COLLECTOR_PERSISTENCE_FAILURE_MUTATED_STATE"
                    ) from exc
                raise ActiveCollectorBlock("COLLECTOR_PERSISTENCE_FAILURE") from exc

        if status == "COMMITTED":
            self.runtime = staged_runtime
            self.observer = staged_observer
            self.last_committed_cutoff = candidate_cutoff

        return CollectorCutoffResult(
            status=status,
            symbol=symbol,
            cutoff=cutoff,
            runtime_status=runtime_result.status,
            observer_status=observer_result.status,
            observation_count=self.observer.observation_count,
            checkpoint_digest=self.state_digest(),
        )

    def run_until_first_live_completed(
        self,
        session: Any,
        *,
        collector_started_at_ms: int,
        persist: Callable[[bytes], Any],
    ) -> CollectorSegmentResult:
        required = ("open_public_read_only", "receive_envelope", "close")
        if any(not callable(getattr(session, name, None)) for name in required):
            raise ActiveCollectorBlock("SESSION_INTERFACE_MISMATCH")

        before_open = self.export_state()
        try:
            session.open_public_read_only(self.runtime.subscription_streams)
        except Exception as exc:
            if self.export_state() != before_open:
                raise ActiveCollectorConflict("SESSION_OPEN_MUTATED_STATE") from exc
            raise ActiveCollectorBlock("SESSION_OPEN_FAILURE") from exc

        envelope_count = 0
        partial_count = 0
        missed_closed_count = 0
        accepted: CollectorCutoffResult | None = None
        primary_error: BaseException | None = None
        try:
            while accepted is None:
                try:
                    envelope = session.receive_envelope()
                except Exception as exc:
                    primary_error = ActiveCollectorBlock("SESSION_RECEIVE_FAILURE")
                    primary_error.__cause__ = exc
                    break
                if envelope is None:
                    primary_error = ActiveCollectorBlock(
                        "SESSION_ENDED_BEFORE_ELIGIBLE_COMPLETED_15M"
                    )
                    break
                envelope_count += 1
                try:
                    result = self.process_envelope_atomic(
                        envelope,
                        collector_started_at_ms=collector_started_at_ms,
                        persist=persist,
                    )
                except (ActiveCollectorBlock, ActiveCollectorConflict) as exc:
                    primary_error = exc
                    break

                if result.status == "IGNORED_PARTIAL":
                    partial_count += 1
                    continue
                if result.status in (
                    "MISSED_BEFORE_COLLECTOR_START_NO_BACKFILL",
                    "OLDER_THAN_DURABLE_COLLECTOR_CHECKPOINT_NO_BACKFILL",
                ):
                    missed_closed_count += 1
                    continue
                if result.status in ("COMMITTED", "IDEMPOTENT_REPLAY"):
                    accepted = result
                    break
                primary_error = ActiveCollectorBlock(
                    "UNSUPPORTED_COLLECTOR_RESULT:" + result.status
                )
                break
        finally:
            try:
                session.close()
            except Exception as close_exc:
                if primary_error is None:
                    primary_error = ActiveCollectorBlock("SESSION_CLOSE_FAILURE")
                    primary_error.__cause__ = close_exc

        if primary_error is not None:
            raise primary_error
        if accepted is None or accepted.cutoff is None:
            raise ActiveCollectorBlock("NO_ELIGIBLE_COMPLETED_15M_ACCEPTED")

        return CollectorSegmentResult(
            status="FIRST_LIVE_COMPLETED_CUTOFF_DURABLY_COMMITTED",
            collector_started_at_ms=collector_started_at_ms,
            envelope_count=envelope_count,
            partial_count=partial_count,
            missed_closed_count=missed_closed_count,
            eligible_closed_count=1,
            accepted_symbol=accepted.symbol,
            accepted_cutoff=accepted.cutoff,
            runtime_status=str(accepted.runtime_status),
            observer_status=str(accepted.observer_status),
            observation_count=accepted.observation_count,
            checkpoint_digest=accepted.checkpoint_digest,
        )
