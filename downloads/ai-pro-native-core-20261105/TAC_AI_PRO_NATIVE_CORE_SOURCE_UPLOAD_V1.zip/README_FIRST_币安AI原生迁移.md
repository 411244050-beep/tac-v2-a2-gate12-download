# TAC → 币安 AI Pro 原生迁移：源码输入包

这是 **源码输入包**，不是可直接启用的原生策略，也不是简化观察策略。
不得把离线源码构建成功误报成币安 AI Pro 已保存/已运行。

## 必须先读
1. `work/ai_pro_port_inactive/native_core_reset_v1/AI_PRO_NATIVE_CORE_EXECUTION_CONTRACT.md`
2. `work/ai_pro_port_inactive/native_core_reset_v1/source/original_d1_to_d6_f9_source.py`（冻结 91 文件中的原版 D1–D6/F9 算法展开；目前仍是开发基准）
3. `work/ai_pro_port_inactive/native_core_reset_v1/source/current_native_authority_binding_v1.json`（原始 528 身份及后续正式政策）
4. `work/live/full_live_remaining_d5_policy_enforcement_v1.py`
5. `work/live/full_live_production_operational_authorization_v1.py`
6. `work/live/full_live_final_entry_observation_authority_v1.py`
7. `work/live/full_live_d5_operational_risk_policy_authority_v1.json`
8. `provisional_shadow_v1/prospective_usdm_universe_v1_recovered_canonical.json`

其余保留依赖和源码 SHA 列于 `MANIFEST_SHA256.json`，冻结源于
`provisional_shadow_v1/wp8_strategy_rc1_transport_v1`，勿任意改动经济规则。

## 任务
仅在币安 AI Pro 内构建 D1→D2→D3→D4→F9→D5→UPDATE014→D6 原生策略；
合乎平台限制可等价重构，逐阶段标明真正可执行代码和证据；
不可用 EMA/ATR/SuperTrend 简化版替代核心 TAC。严格保留 528 标的
目标和 D5 十项政策、按 cutoff 轮换的 PORT007；原版旧 WP7 阻断
是历史规则状态，不得覆盖新冻结政策。UPDATE014 才有最终入场许可。
不可编造 theta 参数、资本/账户/成交/订单或持仓证据。

先校验可否完整读文件；读取不到必须明确报错，不许推测。
`strategy/spec.yaml` 与 `strategy/strategy.py` 的原生生成/校验/
审核保存/原生 dry-run 均尚未完成。请禁止 Paper/Live，且
`TAC_LIVE_ENABLED=0`。当前不授权任何实盘交易或账户写操作。
