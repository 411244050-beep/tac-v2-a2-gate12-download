"""TAC RC1 non-trading reference implementation through WP6."""
