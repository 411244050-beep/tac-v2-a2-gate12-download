from __future__ import annotations
import json
from pathlib import Path

_ROOT = Path(__file__).resolve().parents[2]
def load_registry() -> dict:
    return json.loads((_ROOT / "wp8_traceability_registry_v1.json").read_text())
def load_authority_catalog() -> dict:
    return json.loads((_ROOT / "authority_catalog_v1.json").read_text())
