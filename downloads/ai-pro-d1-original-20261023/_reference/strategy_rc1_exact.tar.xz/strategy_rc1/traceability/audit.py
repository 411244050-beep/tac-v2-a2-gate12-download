from __future__ import annotations
import ast, json, re
from pathlib import Path
from .registry import load_registry, load_authority_catalog

ROOT=Path(__file__).resolve().parents[2]

def _public_units():
    out=[]
    for p in sorted((ROOT/'strategy_rc1').rglob('*.py')):
        if 'traceability' in p.parts or '__pycache__' in p.parts: continue
        rel=str(p.relative_to(ROOT))
        try: tree=ast.parse(p.read_text())
        except Exception: continue
        class V(ast.NodeVisitor):
            def __init__(self): self.cls=[]
            def visit_ClassDef(self,n): self.cls.append(n.name); self.generic_visit(n); self.cls.pop()
            def visit_FunctionDef(self,n):
                if n.name.startswith('_'): return
                name='.'.join(self.cls+[n.name]) if self.cls else n.name
                out.append(f'{rel}::{name}'); self.generic_visit(n)
        V().visit(tree)
    return sorted(out)


def _source_reasons():
    out=[]
    class RV(ast.NodeVisitor):
        def __init__(self,path): self.path=path
        def visit_Call(self,n):
            fn=n.func
            nm=fn.attr if isinstance(fn,ast.Attribute) else fn.id if isinstance(fn,ast.Name) else ''
            vals=[]
            if nm in {'DecisionResult','ValueError','RuntimeError'}:
                idx=1 if nm=='DecisionResult' else 0
                if len(n.args)>idx and isinstance(n.args[idx],ast.Constant) and isinstance(n.args[idx].value,str): vals.append(n.args[idx].value)
            for kw in n.keywords:
                if kw.arg=='reason' and isinstance(kw.value,ast.Constant) and isinstance(kw.value.value,str): vals.append(kw.value.value)
            for v in vals:
                if re.fullmatch(r'[A-Z][A-Z0-9_:+.-]{2,}',v): out.append((self.path,v))
            self.generic_visit(n)
    for p in sorted((ROOT/'strategy_rc1').rglob('*.py')):
        if 'traceability' in p.parts or '__pycache__' in p.parts: continue
        rel=str(p.relative_to(ROOT))
        try: tree=ast.parse(p.read_text())
        except Exception: continue
        RV(rel).visit(tree)
    out.append(('strategy_rc1/runtime_guards/ambiguity.py','STOP_AND_REPORT_AMBIGUITY'))
    return sorted(set(out))

def _literal_event_types():
    out=[]
    for p in sorted((ROOT/'strategy_rc1').rglob('*.py')):
        if 'traceability' in p.parts or '__pycache__' in p.parts: continue
        try: tree=ast.parse(p.read_text())
        except Exception: continue
        for n in ast.walk(tree):
            if isinstance(n,ast.Call):
                for kw in n.keywords:
                    if kw.arg=='event_type' and isinstance(kw.value,ast.Constant) and isinstance(kw.value.value,str):
                        out.append(kw.value.value)
    return sorted(set(out))

def audit_registry(registry=None,catalog=None):
    registry=registry or load_registry(); catalog=catalog or load_authority_catalog()
    valid_rules=set(catalog['valid_rule_ids']); valid_scns=set(catalog['valid_scenario_ids'])
    failures=[]
    declared={u['unit'] for u in registry['callable_units']}
    actual=set(_public_units())
    if declared!=actual:
        failures.append({'check':'callable_inventory_exact','missing':sorted(actual-declared),'stale':sorted(declared-actual)})
    for u in registry['callable_units']:
        if u['classification']=='semantic' and not u['implements_rules']:
            failures.append({'check':'semantic_unit_without_rules','unit':u['unit']})
        bad=set(u['implements_rules'])-valid_rules
        if bad: failures.append({'check':'invalid_rule_reference','unit':u['unit'],'bad':sorted(bad)})
        bads=set(u['acceptance_scenarios'])-valid_scns
        if bads: failures.append({'check':'invalid_scenario_reference','unit':u['unit'],'bad':sorted(bads)})
    for e in registry['event_types']:
        bad=set(e['rules'])-valid_rules
        if bad: failures.append({'check':'event_invalid_rules','event':e['event_type'],'bad':sorted(bad)})
        if e['channel']=='STRATEGY' and e['owner']=='D6_EXECUTION':
            failures.append({'check':'strategy_execution_owner_conflict','event':e['event_type']})
    for r in registry['reason_mappings']:
        if r['classification']=='semantic_reason' and not r['implements_rules']:
            failures.append({'check':'semantic_reason_without_rules','reason':r['reason'],'path':r['path']})
        bad=set(r['implements_rules'])-valid_rules
        if bad: failures.append({'check':'reason_invalid_rules','reason':r['reason'],'bad':sorted(bad)})
    declared_reasons={(r['path'],r['reason']) for r in registry['reason_mappings']}
    actual_reasons=set(_source_reasons())
    if declared_reasons!=actual_reasons:
        failures.append({'check':'reason_inventory_exact','missing':sorted(actual_reasons-declared_reasons),'stale':sorted(declared_reasons-actual_reasons)})
    # Any literal event type embedded in implementation source must exist in event registry.
    declared_events={e['event_type'] for e in registry['event_types']}
    source_events=set(_literal_event_types())
    if not source_events.issubset(declared_events):
        failures.append({'check':'literal_event_type_unmapped','missing':sorted(source_events-declared_events)})
    if len(declared_events)!=len(registry['event_types']): failures.append({'check':'duplicate_event_type_claim'})
    if len({u['unit'] for u in registry['callable_units']})!=len(registry['callable_units']): failures.append({'check':'duplicate_callable_claim'})
    if any(u['owner']=='UNCLASSIFIED' for u in registry['callable_units']): failures.append({'check':'unclassified_callable_owner'})
    expected_event_owners={'PRICE_STRUCTURE_TRANSITION':'D2_MARKET_STATE','MARKET_TREND_TRANSITION':'D2_MARKET_STATE','TREND_POSITION_TRANSITION':'D2_MARKET_STATE','INTERACTION_BREAK_TRANSITION':'D3_BOUNDARY_INTELLIGENCE','ANCHOR_ROLE_TRANSITION':'D3_BOUNDARY_INTELLIGENCE','BEHAVIOR_CONFIRMATION':'D4_OPPORTUNITY_DECISION','ENTRY_READY':'D4_OPPORTUNITY_DECISION','RISK_FEASIBILITY':'D5_RISK','STRATEGY_EXIT':'D6_STRATEGY','EXECUTION_STATUS':'D6_EXECUTION','RECONCILIATION_STATUS':'D6_EXECUTION'}
    event_owner={e['event_type']:e['owner'] for e in registry['event_types']}
    for et,ow in expected_event_owners.items():
        if event_owner.get(et)!=ow: failures.append({'check':'single_writer_event_owner_conflict','event':et,'expected':ow,'actual':event_owner.get(et)})
    mapped={x['scenario_id'] for x in registry['scenario_mappings']}
    if mapped!=valid_scns:
        failures.append({'check':'scenario_catalog_coverage','unmapped':sorted(valid_scns-mapped),'unknown':sorted(mapped-valid_scns)})
    # one-for-one UPDATE coverage in cutoff engine enum is mechanically verified by prior WP7 + registry validity.
    updates={f'UPDATE-{i:03d}' for i in range(17)}
    unit_rules=set().union(*(set(u['implements_rules']) for u in registry['callable_units']))
    if not updates.issubset(unit_rules): failures.append({'check':'update_000_016_traceability','missing':sorted(updates-unit_rules)})
    # owner claims for Strategy truth domains must remain unique.
    canonical={'D2_MARKET_STATE','D3_BOUNDARY_INTELLIGENCE','D4_OPPORTUNITY_DECISION','D5_RISK','D6_STRATEGY','D6_EXECUTION','ORCHESTRATOR','LEDGER'}
    if not canonical.issubset(registry['writer_ownership']): failures.append({'check':'writer_ownership_missing'})
    return {'status':'PASS' if not failures else 'FAIL','failed':failures,
            'public_callable_count':len(actual),'semantic_callable_count':sum(u['classification']=='semantic' for u in registry['callable_units']),
            'engineering_invariant_callable_count':sum(u['classification']=='engineering_invariant' for u in registry['callable_units']),
            'event_type_count':len(registry['event_types']),'reason_mapping_count':len(registry['reason_mappings']),
            'scenario_mapping_count':len(registry['scenario_mappings']),'valid_rule_count':len(valid_rules),'valid_scenario_count':len(valid_scns)}
