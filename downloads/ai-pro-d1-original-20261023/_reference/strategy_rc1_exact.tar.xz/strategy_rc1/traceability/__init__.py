"""WP8 read-only semantic traceability metadata. Not Strategy authority."""
from .registry import load_registry, load_authority_catalog
__all__ = ["load_registry", "load_authority_catalog"]
