V2_NAMESPACE_PREFIX = "tac_v2_rc1"
FORBIDDEN_LEGACY_MARKERS = ("version_c", "tac_version_c")


class NamespaceViolation(RuntimeError):
    pass


def require_v2_namespace(namespace: str) -> None:
    lowered = namespace.lower()
    if any(marker in lowered for marker in FORBIDDEN_LEGACY_MARKERS):
        raise NamespaceViolation("Legacy Version C namespace is forbidden as v2 runtime fallback")
    if not namespace.startswith(V2_NAMESPACE_PREFIX):
        raise NamespaceViolation(f"Namespace must start with {V2_NAMESPACE_PREFIX!r}")
