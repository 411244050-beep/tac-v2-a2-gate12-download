from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Generic, TypeVar

T = TypeVar("T")


class InfoKind(str, Enum):
    KNOWN = "KNOWN"
    NONE = "NONE"
    UNKNOWN = "UNKNOWN"
    NA = "N/A"
    ERROR = "ERROR"


@dataclass(frozen=True)
class InfoValue(Generic[T]):
    kind: InfoKind
    value: T | None = None
    error_ref: str | None = None

    def __post_init__(self) -> None:
        if self.kind is InfoKind.KNOWN:
            if self.value is None or self.error_ref is not None:
                raise ValueError("KNOWN requires a value and no error_ref")
        elif self.kind is InfoKind.ERROR:
            if self.error_ref is None or self.value is not None:
                raise ValueError("ERROR requires error_ref and no value")
        elif self.value is not None or self.error_ref is not None:
            raise ValueError(f"{self.kind.value} cannot carry value/error_ref")

    @classmethod
    def known(cls, value: T) -> "InfoValue[T]":
        return cls(InfoKind.KNOWN, value=value)

    @classmethod
    def none(cls) -> "InfoValue[T]":
        return cls(InfoKind.NONE)

    @classmethod
    def unknown(cls) -> "InfoValue[T]":
        return cls(InfoKind.UNKNOWN)

    @classmethod
    def na(cls) -> "InfoValue[T]":
        return cls(InfoKind.NA)

    @classmethod
    def error(cls, error_ref: str) -> "InfoValue[T]":
        return cls(InfoKind.ERROR, error_ref=error_ref)

    def require_known(self) -> T:
        if self.kind is not InfoKind.KNOWN:
            raise ValueError(f"Value is {self.kind.value}, not KNOWN")
        return self.value  # type: ignore[return-value]
