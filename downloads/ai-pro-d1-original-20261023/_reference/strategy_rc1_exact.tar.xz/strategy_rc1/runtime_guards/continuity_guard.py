class DataIntegrityBlock(RuntimeError):
    """System-level integrity block; never a market Strategy failure."""


class ContinuityReset(RuntimeError):
    """Marker exception for callers that choose exception-based segment handling."""
