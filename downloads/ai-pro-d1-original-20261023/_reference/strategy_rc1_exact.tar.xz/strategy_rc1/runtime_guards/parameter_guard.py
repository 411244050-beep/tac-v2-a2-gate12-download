from __future__ import annotations

from ..parameter_snapshot import ParameterSnapshot, ParameterState


class RuntimeEligibilityError(RuntimeError):
    pass


def unresolved_slots(snapshot: ParameterSnapshot) -> tuple[str, ...]:
    return tuple(
        name
        for name, slot in sorted(snapshot.slots.items())
        if slot.state is not ParameterState.FROZEN
    )


def require_runtime_usable(snapshot: ParameterSnapshot) -> None:
    unresolved = unresolved_slots(snapshot)
    if unresolved or not snapshot.complete_strategy_parameter_snapshot or not snapshot.runtime_usable:
        raise RuntimeEligibilityError(
            "RUNTIME_NOT_USABLE: incomplete authorized parameter snapshot; unresolved="
            + ",".join(unresolved)
        )
