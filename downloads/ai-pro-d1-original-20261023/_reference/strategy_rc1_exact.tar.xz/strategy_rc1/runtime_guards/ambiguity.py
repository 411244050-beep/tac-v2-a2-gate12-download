class AmbiguityStop(RuntimeError):
    marker = "STOP_AND_REPORT_AMBIGUITY"


def stop_and_report_ambiguity(detail: str) -> None:
    raise AmbiguityStop(f"{AmbiguityStop.marker}: {detail}")
