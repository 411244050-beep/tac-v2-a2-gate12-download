from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from fractions import Fraction
from typing import Mapping

from ..runtime_guards.information_state import InfoValue


class StructuralLayer(str, Enum):
    MINOR = "MINOR"
    INTERMEDIATE = "INTERMEDIATE"
    MAJOR = "MAJOR"


class PivotType(str, Enum):
    HIGH = "HIGH"
    LOW = "LOW"


class SearchMode(str, Enum):
    UNKNOWN = "UNKNOWN"
    NEUTRAL = "NEUTRAL"
    SEEK_HIGH = "SEEK_HIGH"
    SEEK_LOW = "SEEK_LOW"


class ProgressRelation(str, Enum):
    MATERIAL_ADVANCE_UP = "MATERIAL_ADVANCE_UP"
    MATERIAL_ADVANCE_DOWN = "MATERIAL_ADVANCE_DOWN"
    STRUCTURALLY_EQUIVALENT = "STRUCTURALLY_EQUIVALENT"


class TrendDirection(str, Enum):
    LONG = "LONG"
    SHORT = "SHORT"
    NONE = "NONE"
    UNKNOWN = "UNKNOWN"


class TrendIntegrity(str, Enum):
    HEALTHY = "HEALTHY"
    PRESSURED = "PRESSURED"
    DETERIORATING = "DETERIORATING"
    FAILED = "FAILED"


class TrendPhase(str, Enum):
    UNKNOWN = "UNKNOWN"
    NO_TREND = "NO_TREND"
    EXPANSION = "EXPANSION"
    ACCELERATION = "ACCELERATION"
    DECELERATION = "DECELERATION"
    PLATFORM_CANDIDATE = "PLATFORM_CANDIDATE"
    PLATFORM_CONFIRMED = "PLATFORM_CONFIRMED"
    REVERSAL_CANDIDATE = "REVERSAL_CANDIDATE"
    STRUCTURAL_FAILURE = "STRUCTURAL_FAILURE"


class TrendPosition(str, Enum):
    BALANCED = "BALANCED"
    PULLBACK = "PULLBACK"
    EXTENDED = "EXTENDED"
    OVEREXTENDED = "OVEREXTENDED"
    UNKNOWN = "UNKNOWN"
    NA = "N/A"


class PlatformStatus(str, Enum):
    NONE = "NONE"
    PLATFORM_CANDIDATE = "PLATFORM_CANDIDATE"
    PLATFORM_CONFIRMED = "PLATFORM_CONFIRMED"


@dataclass(frozen=True)
class StructuralPivot:
    pivot_id: str
    symbol: str
    timeframe_ms: int
    layer: StructuralLayer
    pivot_type: PivotType
    extreme_price: Fraction
    extreme_first_time: int
    extreme_last_time: int
    confirmed_at: int
    scale_at_extreme: Fraction
    canonical_segment_id: str
    source_pivot_ids: tuple[str, ...]
    provenance: Mapping[str, str]

    def __post_init__(self) -> None:
        if self.extreme_last_time < self.extreme_first_time:
            raise ValueError("extreme_last_time precedes extreme_first_time")
        if self.confirmed_at < self.extreme_last_time:
            raise ValueError("confirmed_at precedes extreme_last_time")
        if self.scale_at_extreme <= 0:
            raise ValueError("scale_at_extreme must be positive")
        if not self.canonical_segment_id:
            raise ValueError("canonical_segment_id is required")


@dataclass(frozen=True)
class LegMetrics:
    gross_displacement: Fraction
    normalized_displacement: Fraction
    directional_efficiency: InfoValue[Fraction]
    robust_normalized_slope: InfoValue[Fraction]


@dataclass(frozen=True)
class StructuralLeg:
    leg_id: str
    symbol: str
    timeframe_ms: int
    layer: StructuralLayer
    start_pivot_id: str
    end_pivot_id: str
    start_type: PivotType
    end_type: PivotType
    canonical_segment_id: str
    metrics: LegMetrics


@dataclass(frozen=True)
class EstablishmentEvidence:
    direction: TrendDirection
    newest_pivot_id: str
    sequence_pivot_ids: tuple[str, str, str, str]
    defended_opposite_pivot_id: str
    opposing_structural_cap_pivot_id: str


@dataclass(frozen=True)
class TrendEpisodeState:
    direction: TrendDirection
    episode_id: str | None
    episode_start_cutoff: int | None
    protected_pivot: StructuralPivot | None
    frontier_pivot: StructuralPivot | None
    phase: TrendPhase
    integrity: TrendIntegrity | None
    reversal_candidate_cap: StructuralPivot | None
    defended_pullback_after_pressure: bool
    prior_same_direction_edpr: InfoValue[Fraction]
    completed_trend_aligned_normalized_legs: tuple[Fraction, ...]
    terminal_episode_id: str | None = None


@dataclass(frozen=True)
class TrendPositionResult:
    position: TrendPosition
    x: InfoValue[Fraction]
    episode_excursion: InfoValue[Fraction]
    episode_median_leg_length: InfoValue[Fraction]
    overextension_ratio: InfoValue[Fraction]


@dataclass(frozen=True)
class StructuralCorridor:
    lower: Fraction
    upper: Fraction


@dataclass(frozen=True)
class FailedReexpansionEvent:
    event_id: str
    symbol: str
    timeframe_ms: int
    direction: TrendDirection
    confirmation_cutoff: int
    trend_side_minor_extreme_price: Fraction
    trend_side_minor_extreme_first_time: int
    trend_side_minor_extreme_last_time: int
    protected_structure_intact: bool
    independent_from_prior: bool
    rearmed_from_prior: bool


@dataclass(frozen=True)
class PlatformState:
    status: PlatformStatus
    contributing_event_ids: tuple[str, ...]
    trend_side_extremes: tuple[Fraction, ...]
    platform_cap_price: Fraction | None
    platform_scale: Fraction | None
    confirmed_at: int | None
    cap_first_time: int | None
    cap_last_time: int | None
