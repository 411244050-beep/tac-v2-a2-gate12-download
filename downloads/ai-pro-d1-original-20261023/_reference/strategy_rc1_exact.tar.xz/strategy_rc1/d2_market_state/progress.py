from __future__ import annotations

from fractions import Fraction

from .types import ProgressRelation, StructuralPivot


def same_type_progress(p0: StructuralPivot, p1: StructuralPivot, theta_progress: Fraction) -> ProgressRelation:
    if p0.pivot_type is not p1.pivot_type:
        raise ValueError("same_type_progress requires same pivot type")
    if p0.layer is not p1.layer:
        raise ValueError("same_type_progress requires same structural layer")
    if p0.symbol != p1.symbol or p0.timeframe_ms != p1.timeframe_ms:
        raise ValueError("same_type_progress requires same symbol/timeframe")
    if p0.canonical_segment_id != p1.canonical_segment_id:
        raise ValueError("cross-gap progress comparison is forbidden")
    if p1.confirmed_at <= p0.confirmed_at:
        raise ValueError("p1 must be causally later than p0")
    if p0.scale_at_extreme <= 0:
        raise ValueError("p0 scale_at_extreme must be positive")

    delta_n = (p1.extreme_price - p0.extreme_price) / p0.scale_at_extreme
    if delta_n > theta_progress:
        return ProgressRelation.MATERIAL_ADVANCE_UP
    if delta_n < -theta_progress:
        return ProgressRelation.MATERIAL_ADVANCE_DOWN
    return ProgressRelation.STRUCTURALLY_EQUIVALENT


def normalized_delta(p0: StructuralPivot, p1: StructuralPivot) -> Fraction:
    if p0.scale_at_extreme <= 0:
        raise ValueError("p0 scale_at_extreme must be positive")
    return (p1.extreme_price - p0.extreme_price) / p0.scale_at_extreme
