from __future__ import annotations

from fractions import Fraction
from typing import Sequence

from .progress import same_type_progress
from .types import EstablishmentEvidence, PivotType, ProgressRelation, StructuralPivot, TrendDirection


def latest_establishment_evidence(
    pivots: Sequence[StructuralPivot], *, theta_progress: Fraction
) -> EstablishmentEvidence | None:
    """Evaluate only the latest complete alternating 4-pivot sequence ending at newest pivot."""
    if len(pivots) < 4:
        return None
    seq = tuple(pivots[-4:])
    if any(p.layer.value != "INTERMEDIATE" for p in seq):
        raise ValueError("Trend establishment consumes Intermediate pivots only")
    if len({p.canonical_segment_id for p in seq}) != 1:
        return None
    if not all(a.confirmed_at < b.confirmed_at for a, b in zip(seq, seq[1:])):
        raise ValueError("Intermediate pivot stream must be causally ordered")

    types = tuple(p.pivot_type for p in seq)
    if types == (PivotType.LOW, PivotType.HIGH, PivotType.LOW, PivotType.HIGH):
        l0, h0, l1, h1 = seq
        high_progress = same_type_progress(h0, h1, theta_progress)
        low_progress = same_type_progress(l0, l1, theta_progress)
        if high_progress is ProgressRelation.MATERIAL_ADVANCE_UP and low_progress is not ProgressRelation.MATERIAL_ADVANCE_DOWN:
            return EstablishmentEvidence(
                direction=TrendDirection.LONG,
                newest_pivot_id=h1.pivot_id,
                sequence_pivot_ids=tuple(p.pivot_id for p in seq),  # type: ignore[arg-type]
                defended_opposite_pivot_id=l1.pivot_id,
                opposing_structural_cap_pivot_id=l1.pivot_id,
            )

    if types == (PivotType.HIGH, PivotType.LOW, PivotType.HIGH, PivotType.LOW):
        h0, l0, h1, l1 = seq
        low_progress = same_type_progress(l0, l1, theta_progress)
        high_progress = same_type_progress(h0, h1, theta_progress)
        if low_progress is ProgressRelation.MATERIAL_ADVANCE_DOWN and high_progress is not ProgressRelation.MATERIAL_ADVANCE_UP:
            return EstablishmentEvidence(
                direction=TrendDirection.SHORT,
                newest_pivot_id=l1.pivot_id,
                sequence_pivot_ids=tuple(p.pivot_id for p in seq),  # type: ignore[arg-type]
                defended_opposite_pivot_id=h1.pivot_id,
                opposing_structural_cap_pivot_id=h1.pivot_id,
            )
    return None
