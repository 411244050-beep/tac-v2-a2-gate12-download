from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction

from ..d1_data_math.canonical import CanonicalBar
from ..runtime_guards.information_state import InfoValue
from .parameters import StructuralScaleParameters
from .pivots import MinorDirectionalChangeEngine, PivotStreamDirectionalChangeEngine
from .types import StructuralLayer, StructuralPivot


@dataclass(frozen=True)
class HierarchyUpdate:
    minor: tuple[StructuralPivot, ...]
    intermediate: tuple[StructuralPivot, ...]
    major: tuple[StructuralPivot, ...]


class StructuralHierarchyEngine:
    """One timeframe's Minor -> Intermediate -> Major RC1 hierarchy."""

    def __init__(self, *, symbol: str, timeframe_ms: int, params: StructuralScaleParameters) -> None:
        self.minor = MinorDirectionalChangeEngine(
            symbol=symbol, timeframe_ms=timeframe_ms, theta_minor=params.theta_minor
        )
        self.intermediate = PivotStreamDirectionalChangeEngine(
            output_layer=StructuralLayer.INTERMEDIATE, theta=params.theta_intermediate
        )
        self.major = PivotStreamDirectionalChangeEngine(
            output_layer=StructuralLayer.MAJOR, theta=params.theta_major
        )
        self._all_minor: list[StructuralPivot] = []
        self._all_intermediate: list[StructuralPivot] = []
        self._all_major: list[StructuralPivot] = []

    @property
    def all_minor(self) -> tuple[StructuralPivot, ...]:
        return tuple(self._all_minor)

    @property
    def all_intermediate(self) -> tuple[StructuralPivot, ...]:
        return tuple(self._all_intermediate)

    @property
    def all_major(self) -> tuple[StructuralPivot, ...]:
        return tuple(self._all_major)

    def update_bar(
        self,
        bar: CanonicalBar,
        atr14: InfoValue[Fraction],
        *,
        canonical_segment_id: str,
    ) -> HierarchyUpdate:
        minors = self.minor.update(bar, atr14, canonical_segment_id=canonical_segment_id)
        inters: list[StructuralPivot] = []
        majors: list[StructuralPivot] = []
        for p in minors:
            self._all_minor.append(p)
            new_i = self.intermediate.update(p)
            for ip in new_i:
                self._all_intermediate.append(ip)
                inters.append(ip)
                new_m = self.major.update(ip)
                for mp in new_m:
                    self._all_major.append(mp)
                    majors.append(mp)
        return HierarchyUpdate(minors, tuple(inters), tuple(majors))
