from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from fractions import Fraction

from ..parameter_snapshot import ParameterSnapshot, ParameterState


class StructuralParameterResolutionBlock(RuntimeError):
    pass


def _exact_fraction(value: str) -> Fraction:
    return Fraction(Decimal(value))


@dataclass(frozen=True)
class StructuralScaleParameters:
    theta_minor: Fraction
    theta_intermediate: Fraction
    theta_major: Fraction

    def __post_init__(self) -> None:
        if not (0 < self.theta_minor < self.theta_intermediate < self.theta_major):
            raise ValueError("RC1 requires 0 < theta_minor < theta_intermediate < theta_major")


@dataclass(frozen=True)
class FrozenD2Parameters:
    theta_progress: Fraction
    theta_rate: Fraction
    theta_overextension: Fraction

    def __post_init__(self) -> None:
        if self.theta_progress < 0:
            raise ValueError("theta_progress must be >= 0")
        if self.theta_rate < 0:
            raise ValueError("theta_rate must be >= 0")
        if self.theta_overextension <= 1:
            raise ValueError("theta_overextension must be > 1")


def require_structural_scale_parameters(snapshot: ParameterSnapshot) -> StructuralScaleParameters:
    names = ("theta_minor", "theta_intermediate", "theta_major")
    slots = [snapshot.slot(name) for name in names]
    unresolved = [slot.name for slot in slots if slot.state is not ParameterState.FROZEN]
    if unresolved:
        raise StructuralParameterResolutionBlock(
            "WP2_STRUCTURAL_SCALE_PARAMETERS_UNRESOLVED: " + ",".join(unresolved)
        )
    return StructuralScaleParameters(*(_exact_fraction(slot.exact_value or "") for slot in slots))


def frozen_d2_parameters(snapshot: ParameterSnapshot) -> FrozenD2Parameters:
    values: list[Fraction] = []
    for name in ("theta_progress", "theta_rate", "theta_overextension"):
        slot = snapshot.slot(name)
        if slot.state is not ParameterState.FROZEN or slot.exact_value is None:
            raise StructuralParameterResolutionBlock(f"D2_FROZEN_PARAMETER_MISSING: {name}")
        values.append(_exact_fraction(slot.exact_value))
    return FrozenD2Parameters(*values)
