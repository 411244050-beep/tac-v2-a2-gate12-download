from __future__ import annotations

from dataclasses import replace
from fractions import Fraction

from .types import FailedReexpansionEvent, PlatformState, PlatformStatus, TrendDirection


EMPTY_PLATFORM = PlatformState(
    status=PlatformStatus.NONE,
    contributing_event_ids=(),
    trend_side_extremes=(),
    platform_cap_price=None,
    platform_scale=None,
    confirmed_at=None,
    cap_first_time=None,
    cap_last_time=None,
)


def update_platform(
    state: PlatformState,
    event: FailedReexpansionEvent,
    *,
    atr14_at_confirmation: Fraction,
) -> PlatformState:
    """D2-only platform state interface.

    Independence/rearm is an explicit semantic input, never inferred from bar count.
    """
    if not event.protected_structure_intact:
        return EMPTY_PLATFORM
    if atr14_at_confirmation <= 0:
        raise ValueError("platform confirmation ATR scale must be positive")

    if state.status is PlatformStatus.NONE:
        return PlatformState(
            status=PlatformStatus.PLATFORM_CANDIDATE,
            contributing_event_ids=(event.event_id,),
            trend_side_extremes=(event.trend_side_minor_extreme_price,),
            platform_cap_price=None,
            platform_scale=None,
            confirmed_at=None,
            cap_first_time=event.trend_side_minor_extreme_first_time,
            cap_last_time=event.trend_side_minor_extreme_last_time,
        )

    if state.status is PlatformStatus.PLATFORM_CANDIDATE:
        if not event.independent_from_prior or not event.rearmed_from_prior:
            return state
        extremes = state.trend_side_extremes + (event.trend_side_minor_extreme_price,)
        if event.direction is TrendDirection.LONG:
            cap = max(extremes)
        elif event.direction is TrendDirection.SHORT:
            cap = min(extremes)
        else:
            raise ValueError("Platform requires active LONG/SHORT direction")
        cap_events = []
        # The candidate state's first event is represented by its stored cap times/extreme.
        first_extreme = state.trend_side_extremes[0]
        if first_extreme == cap:
            cap_events.append((state.cap_first_time, state.cap_last_time))
        if event.trend_side_minor_extreme_price == cap:
            cap_events.append((event.trend_side_minor_extreme_first_time, event.trend_side_minor_extreme_last_time))
        first = min(t[0] for t in cap_events if t[0] is not None)
        last = max(t[1] for t in cap_events if t[1] is not None)
        return PlatformState(
            status=PlatformStatus.PLATFORM_CONFIRMED,
            contributing_event_ids=state.contributing_event_ids + (event.event_id,),
            trend_side_extremes=extremes,
            platform_cap_price=cap,
            platform_scale=atr14_at_confirmation,
            confirmed_at=event.confirmation_cutoff,
            cap_first_time=first,
            cap_last_time=last,
        )

    # F6: cap and scale remain frozen for the confirmed lineage.
    return replace(state)
