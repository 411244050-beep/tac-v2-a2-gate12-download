"""D2-owned slice of RC1 UPDATE-005 / UPDATE-006 / UPDATE-009 only.

This module intentionally contains no D3-D6 writers and is not a full cutoff engine.
"""
from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction

from ..runtime_guards.information_state import InfoValue
from .types import StructuralCorridor, TrendEpisodeState, TrendPositionResult


@dataclass(frozen=True)
class Update005Result:
    minor_pivot_ids: tuple[str, ...]
    intermediate_pivot_ids: tuple[str, ...]
    major_pivot_ids: tuple[str, ...]


@dataclass(frozen=True)
class Update006Result:
    trend_state: TrendEpisodeState


@dataclass(frozen=True)
class Update009Result:
    trend_position: TrendPositionResult
    structural_corridor: InfoValue[StructuralCorridor]
    current_close: Fraction
