from __future__ import annotations

from fractions import Fraction
from statistics import median

from ..runtime_guards.information_state import InfoValue
from .types import StructuralCorridor, StructuralPivot, TrendDirection, TrendPosition, TrendPositionResult


def protected_equivalence_zone(protected: StructuralPivot, theta_progress: Fraction) -> tuple[Fraction, Fraction]:
    half = theta_progress * protected.scale_at_extreme
    return protected.extreme_price - half, protected.extreme_price + half


def structural_corridor(
    *,
    direction: TrendDirection,
    protected: StructuralPivot | None,
    frontier: StructuralPivot | None,
    current_close: Fraction,
    theta_progress: Fraction,
) -> InfoValue[StructuralCorridor]:
    if direction not in (TrendDirection.LONG, TrendDirection.SHORT):
        return InfoValue.na()
    if protected is None or frontier is None:
        return InfoValue.unknown()
    low_zone, high_zone = protected_equivalence_zone(protected, theta_progress)
    if direction is TrendDirection.LONG:
        return InfoValue.known(StructuralCorridor(low_zone, max(current_close, frontier.extreme_price)))
    return InfoValue.known(StructuralCorridor(min(current_close, frontier.extreme_price), high_zone))


def classify_trend_position(
    *,
    direction: TrendDirection,
    current_close: Fraction,
    frontier: StructuralPivot | None,
    reset_pivot: StructuralPivot | None,
    theta_progress: Fraction,
    theta_overextension: Fraction,
    completed_trend_aligned_normalized_legs: tuple[Fraction, ...],
) -> TrendPositionResult:
    if direction not in (TrendDirection.LONG, TrendDirection.SHORT):
        return TrendPositionResult(
            TrendPosition.NA, InfoValue.na(), InfoValue.na(), InfoValue.na(), InfoValue.na()
        )
    if frontier is None or frontier.scale_at_extreme <= 0:
        return TrendPositionResult(
            TrendPosition.UNKNOWN, InfoValue.unknown(), InfoValue.unknown(), InfoValue.unknown(), InfoValue.unknown()
        )
    sign = Fraction(1) if direction is TrendDirection.LONG else Fraction(-1)
    x = sign * (current_close - frontier.extreme_price) / frontier.scale_at_extreme
    if abs(x) <= theta_progress:
        base = TrendPosition.BALANCED
    elif x < -theta_progress:
        base = TrendPosition.PULLBACK
    else:
        base = TrendPosition.EXTENDED

    if reset_pivot is None or reset_pivot.scale_at_extreme <= 0:
        return TrendPositionResult(base, InfoValue.known(x), InfoValue.unknown(), InfoValue.unknown(), InfoValue.unknown())

    l_t = sign * (current_close - reset_pivot.extreme_price) / reset_pivot.scale_at_extreme
    positive_legs = tuple(v for v in completed_trend_aligned_normalized_legs if v > 0)
    if not positive_legs:
        return TrendPositionResult(base, InfoValue.known(x), InfoValue.known(l_t), InfoValue.na(), InfoValue.na())
    m_episode = median(positive_legs)
    if m_episode <= 0:
        return TrendPositionResult(base, InfoValue.known(x), InfoValue.known(l_t), InfoValue.error("NONPOSITIVE_EPISODE_MEDIAN"), InfoValue.error("NONPOSITIVE_EPISODE_MEDIAN"))
    ratio = l_t / m_episode
    pos = TrendPosition.OVEREXTENDED if base is TrendPosition.EXTENDED and ratio > theta_overextension else base
    return TrendPositionResult(pos, InfoValue.known(x), InfoValue.known(l_t), InfoValue.known(m_episode), InfoValue.known(ratio))
