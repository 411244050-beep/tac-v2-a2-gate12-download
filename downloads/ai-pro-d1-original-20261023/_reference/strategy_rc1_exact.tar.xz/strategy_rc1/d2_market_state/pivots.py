from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction

from ..d1_data_math.canonical import CanonicalBar
from ..ids import deterministic_id
from ..runtime_guards.information_state import InfoKind, InfoValue
from .types import PivotType, SearchMode, StructuralLayer, StructuralPivot


@dataclass
class _MinorCandidate:
    pivot_type: PivotType
    price: Fraction
    first_time: int
    last_time: int
    scale: Fraction


class MinorDirectionalChangeEngine:
    """RC1 Minor directional-change state machine.

    Only canonical OHLC is consumed. A confirmation close may confirm a prior
    candidate, but the same confirmation bar's opposite wick is deliberately
    not reused as the next candidate because intrabar ordering is unknowable.
    """

    def __init__(self, *, symbol: str, timeframe_ms: int, theta_minor: Fraction) -> None:
        if theta_minor <= 0:
            raise ValueError("theta_minor must be positive")
        self.symbol = symbol
        self.timeframe_ms = timeframe_ms
        self.theta = theta_minor
        self.segment_id: str | None = None
        self.mode = SearchMode.UNKNOWN
        self.seed_close: Fraction | None = None
        self.seed_scale: Fraction | None = None
        self.candidate: _MinorCandidate | None = None
        self._sequence = 0

    def _reset(self, segment_id: str) -> None:
        self.segment_id = segment_id
        self.mode = SearchMode.UNKNOWN
        self.seed_close = None
        self.seed_scale = None
        self.candidate = None

    def _pivot(self, c: _MinorCandidate, *, confirmed_at: int, confirming_open_time: int) -> StructuralPivot:
        self._sequence += 1
        pid = deterministic_id(
            "pivot",
            self.symbol,
            self.timeframe_ms,
            StructuralLayer.MINOR.value,
            c.pivot_type.value,
            c.price,
            c.first_time,
            c.last_time,
            confirmed_at,
            self.segment_id,
            self._sequence,
        )
        return StructuralPivot(
            pivot_id=pid,
            symbol=self.symbol,
            timeframe_ms=self.timeframe_ms,
            layer=StructuralLayer.MINOR,
            pivot_type=c.pivot_type,
            extreme_price=c.price,
            extreme_first_time=c.first_time,
            extreme_last_time=c.last_time,
            confirmed_at=confirmed_at,
            scale_at_extreme=c.scale,
            canonical_segment_id=self.segment_id or "",
            source_pivot_ids=(),
            provenance={
                "rule": "MS-003..MS-008",
                "confirming_bar_open_time": str(confirming_open_time),
                "ohlc_ordering": "confirmation_close_may_confirm_prior_candidate; opposite_wick_not_reused_same_bar",
            },
        )

    def update(
        self,
        bar: CanonicalBar,
        atr14: InfoValue[Fraction],
        *,
        canonical_segment_id: str,
    ) -> tuple[StructuralPivot, ...]:
        if bar.symbol != self.symbol:
            raise ValueError("symbol mismatch")
        if self.segment_id != canonical_segment_id:
            self._reset(canonical_segment_id)

        if atr14.kind is not InfoKind.KNOWN:
            return ()
        scale = atr14.require_known()
        if scale <= 0:
            return ()

        if self.mode is SearchMode.UNKNOWN:
            self.seed_close = bar.close
            self.seed_scale = scale
            self.mode = SearchMode.NEUTRAL
            return ()

        if self.mode is SearchMode.NEUTRAL:
            assert self.seed_close is not None and self.seed_scale is not None
            threshold = self.theta * self.seed_scale
            up = bar.close - self.seed_close
            down = self.seed_close - bar.close
            if up >= threshold:
                self.mode = SearchMode.SEEK_HIGH
                self.candidate = _MinorCandidate(PivotType.HIGH, bar.high, bar.open_time, bar.open_time, scale)
            elif down >= threshold:
                self.mode = SearchMode.SEEK_LOW
                self.candidate = _MinorCandidate(PivotType.LOW, bar.low, bar.open_time, bar.open_time, scale)
            return ()

        if self.candidate is None:
            # The confirmation bar's opposite wick is intentionally excluded.
            # The first later bar seeds the next opposite candidate.
            if self.mode is SearchMode.SEEK_HIGH:
                self.candidate = _MinorCandidate(PivotType.HIGH, bar.high, bar.open_time, bar.open_time, scale)
                return ()
            if self.mode is SearchMode.SEEK_LOW:
                self.candidate = _MinorCandidate(PivotType.LOW, bar.low, bar.open_time, bar.open_time, scale)
                return ()
            raise AssertionError(f"unexpected mode {self.mode}")

        prior = self.candidate

        # RC1 later-closed-bar rule: if this bar extends/equal-extends the
        # candidate extreme, its own Close cannot confirm that newly current
        # extreme. Only a later bar may confirm it.
        if self.mode is SearchMode.SEEK_HIGH:
            if bar.high > prior.price:
                self.candidate = _MinorCandidate(PivotType.HIGH, bar.high, bar.open_time, bar.open_time, scale)
                return ()
            if bar.high == prior.price:
                self.candidate = _MinorCandidate(PivotType.HIGH, prior.price, prior.first_time, bar.open_time, prior.scale)
                return ()
            if bar.open_time > prior.last_time and prior.price - bar.close >= self.theta * prior.scale:
                pivot = self._pivot(prior, confirmed_at=bar.close_time, confirming_open_time=bar.open_time)
                self.mode = SearchMode.SEEK_LOW
                self.candidate = None
                return (pivot,)
            return ()

        if self.mode is SearchMode.SEEK_LOW:
            if bar.low < prior.price:
                self.candidate = _MinorCandidate(PivotType.LOW, bar.low, bar.open_time, bar.open_time, scale)
                return ()
            if bar.low == prior.price:
                self.candidate = _MinorCandidate(PivotType.LOW, prior.price, prior.first_time, bar.open_time, prior.scale)
                return ()
            if bar.open_time > prior.last_time and bar.close - prior.price >= self.theta * prior.scale:
                pivot = self._pivot(prior, confirmed_at=bar.close_time, confirming_open_time=bar.open_time)
                self.mode = SearchMode.SEEK_HIGH
                self.candidate = None
                return (pivot,)
            return ()

        raise AssertionError(f"unexpected mode {self.mode}")


@dataclass
class _HierarchyCandidate:
    source: StructuralPivot


class PivotStreamDirectionalChangeEngine:
    """Generic higher-layer directional change over confirmed lower-layer pivots."""

    def __init__(self, *, output_layer: StructuralLayer, theta: Fraction) -> None:
        if output_layer is StructuralLayer.MINOR:
            raise ValueError("Use MinorDirectionalChangeEngine for MINOR")
        if theta <= 0:
            raise ValueError("theta must be positive")
        self.output_layer = output_layer
        self.theta = theta
        self.segment_id: str | None = None
        self.mode = SearchMode.UNKNOWN
        self.seed: StructuralPivot | None = None
        self.candidate: _HierarchyCandidate | None = None
        self._sequence = 0

    @staticmethod
    def _expected_input_layer(output_layer: StructuralLayer) -> StructuralLayer:
        return StructuralLayer.MINOR if output_layer is StructuralLayer.INTERMEDIATE else StructuralLayer.INTERMEDIATE

    def _reset(self, segment_id: str) -> None:
        self.segment_id = segment_id
        self.mode = SearchMode.UNKNOWN
        self.seed = None
        self.candidate = None

    def _emit(self, candidate: StructuralPivot, confirmer: StructuralPivot) -> StructuralPivot:
        self._sequence += 1
        pid = deterministic_id(
            "pivot",
            candidate.symbol,
            candidate.timeframe_ms,
            self.output_layer.value,
            candidate.pivot_type.value,
            candidate.extreme_price,
            candidate.extreme_first_time,
            candidate.extreme_last_time,
            confirmer.confirmed_at,
            candidate.canonical_segment_id,
            self._sequence,
        )
        return StructuralPivot(
            pivot_id=pid,
            symbol=candidate.symbol,
            timeframe_ms=candidate.timeframe_ms,
            layer=self.output_layer,
            pivot_type=candidate.pivot_type,
            extreme_price=candidate.extreme_price,
            extreme_first_time=candidate.extreme_first_time,
            extreme_last_time=candidate.extreme_last_time,
            confirmed_at=confirmer.confirmed_at,
            scale_at_extreme=candidate.scale_at_extreme,
            canonical_segment_id=candidate.canonical_segment_id,
            source_pivot_ids=(candidate.pivot_id, confirmer.pivot_id),
            provenance={"rule": "MS-012", "method": "directional_change_over_confirmed_lower_pivot_stream"},
        )

    def update(self, pivot: StructuralPivot) -> tuple[StructuralPivot, ...]:
        expected = self._expected_input_layer(self.output_layer)
        if pivot.layer is not expected:
            raise ValueError(f"{self.output_layer.value} requires {expected.value} input pivots")
        if self.segment_id != pivot.canonical_segment_id:
            self._reset(pivot.canonical_segment_id)

        if self.mode is SearchMode.UNKNOWN:
            self.seed = pivot
            self.mode = SearchMode.NEUTRAL
            return ()

        if self.mode is SearchMode.NEUTRAL:
            assert self.seed is not None
            if pivot.pivot_type is self.seed.pivot_type:
                # Same-type should not normally occur in a well-formed lower stream; preserve the more extreme seed.
                if pivot.pivot_type is PivotType.HIGH and pivot.extreme_price >= self.seed.extreme_price:
                    self.seed = pivot
                elif pivot.pivot_type is PivotType.LOW and pivot.extreme_price <= self.seed.extreme_price:
                    self.seed = pivot
                return ()
            threshold = self.theta * self.seed.scale_at_extreme
            delta = pivot.extreme_price - self.seed.extreme_price
            if delta >= threshold:
                self.mode = SearchMode.SEEK_HIGH
                self.candidate = _HierarchyCandidate(pivot if pivot.pivot_type is PivotType.HIGH else self.seed)
            elif delta <= -threshold:
                self.mode = SearchMode.SEEK_LOW
                self.candidate = _HierarchyCandidate(pivot if pivot.pivot_type is PivotType.LOW else self.seed)
            return ()

        assert self.candidate is not None
        c = self.candidate.source
        if self.mode is SearchMode.SEEK_HIGH:
            if pivot.pivot_type is PivotType.LOW and c.extreme_price - pivot.extreme_price >= self.theta * c.scale_at_extreme:
                emitted = self._emit(c, pivot)
                self.mode = SearchMode.SEEK_LOW
                self.candidate = _HierarchyCandidate(pivot)
                return (emitted,)
            if pivot.pivot_type is PivotType.HIGH and pivot.extreme_price >= c.extreme_price:
                self.candidate = _HierarchyCandidate(pivot)
            return ()

        if self.mode is SearchMode.SEEK_LOW:
            if pivot.pivot_type is PivotType.HIGH and pivot.extreme_price - c.extreme_price >= self.theta * c.scale_at_extreme:
                emitted = self._emit(c, pivot)
                self.mode = SearchMode.SEEK_HIGH
                self.candidate = _HierarchyCandidate(pivot)
                return (emitted,)
            if pivot.pivot_type is PivotType.LOW and pivot.extreme_price <= c.extreme_price:
                self.candidate = _HierarchyCandidate(pivot)
            return ()

        raise AssertionError(f"unexpected mode {self.mode}")
