from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from statistics import median
from typing import Sequence

from ..ids import deterministic_id
from ..runtime_guards.information_state import InfoValue
from .types import LegMetrics, StructuralLeg, StructuralPivot, TrendDirection


@dataclass(frozen=True)
class TimedClose:
    open_time: int
    close: Fraction


def _theil_sen_normalized_slope(
    closes: Sequence[TimedClose], *, timeframe_ms: int, scale_at_leg_start: Fraction
) -> InfoValue[Fraction]:
    if len(closes) < 3:
        return InfoValue.na()
    if scale_at_leg_start <= 0:
        return InfoValue.error("NONPOSITIVE_LEG_START_SCALE")
    ordered = sorted(closes, key=lambda c: c.open_time)
    if len({c.open_time for c in ordered}) != len(ordered):
        return InfoValue.error("DUPLICATE_CLOSE_TIME_IN_LEG")
    slopes: list[Fraction] = []
    for i, left in enumerate(ordered[:-1]):
        for right in ordered[i + 1 :]:
            delta_ms = right.open_time - left.open_time
            if delta_ms <= 0 or delta_ms % timeframe_ms != 0:
                return InfoValue.error("NONCANONICAL_ELAPSED_INTERVAL_IN_LEG")
            dx = Fraction(delta_ms, timeframe_ms)
            dy = (right.close - left.close) / scale_at_leg_start
            slopes.append(dy / dx)
    return InfoValue.known(median(slopes)) if slopes else InfoValue.na()


def build_structural_leg(
    start: StructuralPivot,
    end: StructuralPivot,
    *,
    close_path: Sequence[TimedClose],
) -> StructuralLeg:
    if start.pivot_type is end.pivot_type:
        raise ValueError("Structural Leg requires adjacent opposite pivots")
    if start.layer is not end.layer:
        raise ValueError("Structural Leg requires same layer")
    if start.symbol != end.symbol or start.timeframe_ms != end.timeframe_ms:
        raise ValueError("Structural Leg requires same symbol/timeframe")
    if start.canonical_segment_id != end.canonical_segment_id:
        raise ValueError("Structural Leg cannot cross a canonical gap")
    if end.confirmed_at <= start.confirmed_at:
        raise ValueError("end pivot must be causally later")

    gross = abs(end.extreme_price - start.extreme_price)
    normalized = gross / start.scale_at_extreme

    if len(close_path) < 2:
        efficiency = InfoValue.na()
    else:
        ordered = sorted(close_path, key=lambda c: c.open_time)
        path = sum(abs(b.close - a.close) for a, b in zip(ordered, ordered[1:]))
        if path == 0:
            efficiency = InfoValue.na()
        else:
            efficiency = InfoValue.known(abs(ordered[-1].close - ordered[0].close) / path)

    slope = _theil_sen_normalized_slope(
        close_path, timeframe_ms=start.timeframe_ms, scale_at_leg_start=start.scale_at_extreme
    )
    metrics = LegMetrics(
        gross_displacement=gross,
        normalized_displacement=normalized,
        directional_efficiency=efficiency,
        robust_normalized_slope=slope,
    )
    leg_id = deterministic_id(
        "structural_leg", start.pivot_id, end.pivot_id, start.canonical_segment_id
    )
    return StructuralLeg(
        leg_id=leg_id,
        symbol=start.symbol,
        timeframe_ms=start.timeframe_ms,
        layer=start.layer,
        start_pivot_id=start.pivot_id,
        end_pivot_id=end.pivot_id,
        start_type=start.pivot_type,
        end_type=end.pivot_type,
        canonical_segment_id=start.canonical_segment_id,
        metrics=metrics,
    )


def trend_aligned_edpr(leg: StructuralLeg, direction: TrendDirection) -> InfoValue[Fraction]:
    """B2 EDPR = TrendAlignedRobustSlope × DirectionalEfficiency."""
    slope = leg.metrics.robust_normalized_slope
    efficiency = leg.metrics.directional_efficiency
    if slope.kind.value != "KNOWN" or efficiency.kind.value != "KNOWN":
        return InfoValue.na()
    if direction is TrendDirection.LONG:
        aligned = slope.require_known()
    elif direction is TrendDirection.SHORT:
        aligned = -slope.require_known()
    else:
        return InfoValue.na()
    if aligned < 0:
        return InfoValue.error("LEG_NOT_TREND_ALIGNED")
    return InfoValue.known(aligned * efficiency.require_known())
