from __future__ import annotations

from dataclasses import replace
from fractions import Fraction
from typing import Mapping, Sequence

from ..ids import deterministic_id
from ..runtime_guards.information_state import InfoKind, InfoValue
from .establishment import latest_establishment_evidence
from .progress import normalized_delta, same_type_progress
from .structural_legs import trend_aligned_edpr
from .types import (
    EstablishmentEvidence,
    PivotType,
    ProgressRelation,
    StructuralLeg,
    StructuralPivot,
    TrendDirection,
    TrendEpisodeState,
    TrendIntegrity,
    TrendPhase,
)


def initial_trend_state() -> TrendEpisodeState:
    return TrendEpisodeState(
        direction=TrendDirection.UNKNOWN,
        episode_id=None,
        episode_start_cutoff=None,
        protected_pivot=None,
        frontier_pivot=None,
        phase=TrendPhase.UNKNOWN,
        integrity=None,
        reversal_candidate_cap=None,
        defended_pullback_after_pressure=False,
        prior_same_direction_edpr=InfoValue.na(),
        completed_trend_aligned_normalized_legs=(),
    )


def _by_id(pivots: Sequence[StructuralPivot]) -> dict[str, StructuralPivot]:
    return {p.pivot_id: p for p in pivots}


def _episode_from_establishment(
    evidence: EstablishmentEvidence,
    pivots: Sequence[StructuralPivot],
    *,
    leg_by_end_pivot: Mapping[str, StructuralLeg],
) -> TrendEpisodeState:
    lookup = _by_id(pivots)
    newest = lookup[evidence.newest_pivot_id]
    protected = lookup[evidence.defended_opposite_pivot_id]
    episode_id = deterministic_id(
        "trend_episode", newest.symbol, newest.timeframe_ms, evidence.direction.value, newest.confirmed_at, newest.pivot_id
    )

    # Adopted post-RC1 binding: the establishing directional leg is the first
    # completed trend-aligned leg of the new Episode. It supplies the first EDPR
    # baseline but no acceleration/deceleration comparison exists yet.
    leg = leg_by_end_pivot.get(newest.pivot_id)
    if leg is not None:
        lengths = (leg.metrics.normalized_displacement,)
        baseline = trend_aligned_edpr(leg, evidence.direction)
    else:
        lengths = ()
        baseline = InfoValue.na()

    return TrendEpisodeState(
        direction=evidence.direction,
        episode_id=episode_id,
        episode_start_cutoff=newest.confirmed_at,
        protected_pivot=protected,
        frontier_pivot=newest,
        phase=TrendPhase.EXPANSION,
        integrity=TrendIntegrity.HEALTHY,
        reversal_candidate_cap=None,
        defended_pullback_after_pressure=False,
        prior_same_direction_edpr=baseline,
        completed_trend_aligned_normalized_legs=lengths,
    )


def _is_adverse(direction: TrendDirection, pivot: StructuralPivot) -> bool:
    return (direction is TrendDirection.LONG and pivot.pivot_type is PivotType.LOW) or (
        direction is TrendDirection.SHORT and pivot.pivot_type is PivotType.HIGH
    )


def _is_favorable(direction: TrendDirection, pivot: StructuralPivot) -> bool:
    return (direction is TrendDirection.LONG and pivot.pivot_type is PivotType.HIGH) or (
        direction is TrendDirection.SHORT and pivot.pivot_type is PivotType.LOW
    )


def _material_failure(direction: TrendDirection, protected: StructuralPivot, adverse: StructuralPivot, theta_progress: Fraction) -> bool:
    relation = same_type_progress(protected, adverse, theta_progress)
    return (direction is TrendDirection.LONG and relation is ProgressRelation.MATERIAL_ADVANCE_DOWN) or (
        direction is TrendDirection.SHORT and relation is ProgressRelation.MATERIAL_ADVANCE_UP
    )


def _inside_protected_zone(protected: StructuralPivot, adverse: StructuralPivot, theta_progress: Fraction) -> bool:
    return abs(normalized_delta(protected, adverse)) <= theta_progress


def _classify_edpr_phase(
    prior: InfoValue[Fraction], current: InfoValue[Fraction], theta_rate: Fraction
) -> TrendPhase:
    if prior.kind is not InfoKind.KNOWN or current.kind is not InfoKind.KNOWN:
        return TrendPhase.EXPANSION
    delta = current.require_known() - prior.require_known()
    if delta > theta_rate:
        return TrendPhase.ACCELERATION
    if delta < -theta_rate:
        return TrendPhase.DECELERATION
    return TrendPhase.EXPANSION


def _opposite(direction: TrendDirection) -> TrendDirection:
    if direction is TrendDirection.LONG:
        return TrendDirection.SHORT
    if direction is TrendDirection.SHORT:
        return TrendDirection.LONG
    return TrendDirection.NONE


def _recovery_breaks_cap(
    direction: TrendDirection, cap: StructuralPivot, favorable: StructuralPivot, theta_progress: Fraction
) -> bool:
    if cap.pivot_type is not favorable.pivot_type:
        return False
    rel = same_type_progress(cap, favorable, theta_progress)
    return (direction is TrendDirection.LONG and rel is ProgressRelation.MATERIAL_ADVANCE_UP) or (
        direction is TrendDirection.SHORT and rel is ProgressRelation.MATERIAL_ADVANCE_DOWN
    )


def on_new_intermediate_pivot(
    state: TrendEpisodeState,
    pivots: Sequence[StructuralPivot],
    *,
    theta_progress: Fraction,
    theta_rate: Fraction,
    leg_by_end_pivot: Mapping[str, StructuralLeg],
) -> TrendEpisodeState:
    """UPDATE-006 event-driven D2 Trend transition on newest confirmed Intermediate pivot only."""
    if not pivots:
        return state
    newest = pivots[-1]
    if newest.layer.value != "INTERMEDIATE":
        raise ValueError("Trend consumes Intermediate pivots only")
    if newest.confirmed_at != max(p.confirmed_at for p in pivots):
        raise ValueError("newest pivot must be latest causal Intermediate event")

    evidence = latest_establishment_evidence(pivots, theta_progress=theta_progress)

    if state.direction not in (TrendDirection.LONG, TrendDirection.SHORT) or state.episode_id is None:
        if evidence is not None:
            return _episode_from_establishment(evidence, pivots, leg_by_end_pivot=leg_by_end_pivot)
        # Mature enough for one complete alternating establishment sequence but no direction => NONE.
        if len(pivots) >= 4:
            return replace(state, direction=TrendDirection.NONE, phase=TrendPhase.NO_TREND, integrity=None)
        return replace(state, direction=TrendDirection.UNKNOWN, phase=TrendPhase.UNKNOWN, integrity=None)

    direction = state.direction
    protected = state.protected_pivot
    if protected is None:
        raise ValueError("active Trend Episode requires Protected Intermediate Structure")

    # FAILED has highest same-cutoff precedence.
    if _is_adverse(direction, newest) and _material_failure(direction, protected, newest, theta_progress):
        terminal = state.episode_id
        if evidence is not None and evidence.direction is _opposite(direction):
            new_state = _episode_from_establishment(evidence, pivots, leg_by_end_pivot=leg_by_end_pivot)
            return replace(new_state, terminal_episode_id=terminal)
        return TrendEpisodeState(
            direction=TrendDirection.NONE,
            episode_id=None,
            episode_start_cutoff=None,
            protected_pivot=None,
            frontier_pivot=None,
            phase=TrendPhase.STRUCTURAL_FAILURE,
            integrity=TrendIntegrity.FAILED,
            reversal_candidate_cap=None,
            defended_pullback_after_pressure=False,
            prior_same_direction_edpr=InfoValue.na(),
            completed_trend_aligned_normalized_legs=(),
            terminal_episode_id=terminal,
        )

    # Opposite establishment-like structure while protected intact => DETERIORATING.
    if evidence is not None and evidence.direction is _opposite(direction):
        lookup = _by_id(pivots)
        cap = lookup[evidence.defended_opposite_pivot_id]
        return replace(
            state,
            phase=TrendPhase.REVERSAL_CANDIDATE,
            integrity=TrendIntegrity.DETERIORATING,
            reversal_candidate_cap=cap,
            defended_pullback_after_pressure=False,
        )

    if _is_adverse(direction, newest):
        pressured = _inside_protected_zone(protected, newest, theta_progress)
        if state.integrity is TrendIntegrity.PRESSURED:
            return replace(state, defended_pullback_after_pressure=True)
        if state.integrity is TrendIntegrity.DETERIORATING:
            return state
        if pressured:
            return replace(state, integrity=TrendIntegrity.PRESSURED, defended_pullback_after_pressure=False)
        return state

    if _is_favorable(direction, newest):
        prior_frontier = state.frontier_pivot
        state2 = replace(state, frontier_pivot=newest)

        # DETERIORATING recovery: original Trend materially breaks opposing structural cap.
        if state.integrity is TrendIntegrity.DETERIORATING and state.reversal_candidate_cap is not None:
            if _recovery_breaks_cap(direction, state.reversal_candidate_cap, newest, theta_progress):
                leg = leg_by_end_pivot.get(newest.pivot_id)
                phase = _classify_edpr_phase(state.prior_same_direction_edpr, trend_aligned_edpr(leg, direction) if leg else InfoValue.na(), theta_rate)
                prior_edpr = trend_aligned_edpr(leg, direction) if leg is not None else state.prior_same_direction_edpr
                lengths = state.completed_trend_aligned_normalized_legs + ((leg.metrics.normalized_displacement,) if leg else ())
                return replace(
                    state2,
                    phase=phase,
                    integrity=TrendIntegrity.PRESSURED,
                    reversal_candidate_cap=None,
                    defended_pullback_after_pressure=False,
                    prior_same_direction_edpr=prior_edpr,
                    completed_trend_aligned_normalized_legs=lengths,
                )
            return state2

        # Expansion is only material favorable Intermediate progress.
        material = False
        if prior_frontier is not None and prior_frontier.pivot_type is newest.pivot_type:
            rel = same_type_progress(prior_frontier, newest, theta_progress)
            material = (direction is TrendDirection.LONG and rel is ProgressRelation.MATERIAL_ADVANCE_UP) or (
                direction is TrendDirection.SHORT and rel is ProgressRelation.MATERIAL_ADVANCE_DOWN
            )
        if not material:
            return state2

        # F3 protected candidate is latest opposite pivot immediately preceding material progress.
        candidate = pivots[-2] if len(pivots) >= 2 and pivots[-2].pivot_type is not newest.pivot_type else None
        protected2 = protected
        if candidate is not None and candidate.pivot_type is protected.pivot_type:
            relp = same_type_progress(protected, candidate, theta_progress)
            if direction is TrendDirection.LONG and relp is ProgressRelation.MATERIAL_ADVANCE_UP:
                protected2 = candidate
            elif direction is TrendDirection.SHORT and relp is ProgressRelation.MATERIAL_ADVANCE_DOWN:
                protected2 = candidate

        leg = leg_by_end_pivot.get(newest.pivot_id)
        phase = _classify_edpr_phase(state.prior_same_direction_edpr, trend_aligned_edpr(leg, direction) if leg else InfoValue.na(), theta_rate)
        new_edpr = trend_aligned_edpr(leg, direction) if leg is not None else state.prior_same_direction_edpr
        lengths = state.completed_trend_aligned_normalized_legs + ((leg.metrics.normalized_displacement,) if leg else ())
        integrity = state.integrity
        defended = state.defended_pullback_after_pressure
        if integrity is TrendIntegrity.PRESSURED and defended:
            integrity = TrendIntegrity.HEALTHY
            defended = False
        return replace(
            state2,
            protected_pivot=protected2,
            phase=phase,
            integrity=integrity,
            defended_pullback_after_pressure=defended,
            prior_same_direction_edpr=new_edpr,
            completed_trend_aligned_normalized_legs=lengths,
        )

    return state
