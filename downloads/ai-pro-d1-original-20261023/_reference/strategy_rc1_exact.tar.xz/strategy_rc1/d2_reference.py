"""Non-trading WP2 D2 reference skeleton.

Only D2-owned UPDATE-005, UPDATE-006 and UPDATE-009 semantics are represented.
Construction from the current durable partial ParameterSnapshot is expected to
fail because theta_minor/intermediate/major remain OPEN.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from fractions import Fraction
from typing import Iterable

from .d1_data_math.canonical import CanonicalBar
from .d2_market_state.hierarchy import StructuralHierarchyEngine
from .d2_market_state.parameters import (
    FrozenD2Parameters,
    StructuralScaleParameters,
    frozen_d2_parameters,
    require_structural_scale_parameters,
)
from .d2_market_state.structural_legs import TimedClose, build_structural_leg
from .d2_market_state.trend import initial_trend_state, on_new_intermediate_pivot
from .d2_market_state.trend_position import classify_trend_position, structural_corridor
from .d2_market_state.types import (
    PivotType,
    StructuralLeg,
    StructuralPivot,
    TrendDirection,
    TrendEpisodeState,
)
from .parameter_snapshot import ParameterSnapshot
from .runtime_guards.information_state import InfoValue


@dataclass
class _TimeframeState:
    symbol: str
    timeframe_ms: int
    structural_params: StructuralScaleParameters
    hierarchy: StructuralHierarchyEngine = field(init=False)
    segment_id: str | None = None
    intermediate: list[StructuralPivot] = field(default_factory=list)
    legs_by_end: dict[str, StructuralLeg] = field(default_factory=dict)
    closes: list[TimedClose] = field(default_factory=list)
    trend: TrendEpisodeState = field(default_factory=initial_trend_state)

    def __post_init__(self) -> None:
        self.hierarchy = StructuralHierarchyEngine(
            symbol=self.symbol, timeframe_ms=self.timeframe_ms, params=self.structural_params
        )

    def reset_for_segment(self, segment_id: str) -> None:
        self.segment_id = segment_id
        self.hierarchy = StructuralHierarchyEngine(
            symbol=self.symbol, timeframe_ms=self.timeframe_ms, params=self.structural_params
        )
        self.intermediate.clear()
        self.legs_by_end.clear()
        self.closes.clear()
        self.trend = initial_trend_state()


@dataclass(frozen=True)
class D2CutoffResult:
    information_cutoff: int
    update_005_minor: tuple[StructuralPivot, ...]
    update_005_intermediate: tuple[StructuralPivot, ...]
    update_005_major: tuple[StructuralPivot, ...]
    update_006_trend: TrendEpisodeState
    update_009_trend_position: object
    update_009_structural_corridor: object


class D2ReferenceSkeleton:
    def __init__(
        self,
        *,
        symbol: str,
        structural_params: StructuralScaleParameters,
        frozen_params: FrozenD2Parameters,
    ) -> None:
        self.symbol = symbol
        self.structural_params = structural_params
        self.frozen_params = frozen_params
        self._tf: dict[int, _TimeframeState] = {}

    @classmethod
    def from_parameter_snapshot(cls, *, symbol: str, snapshot: ParameterSnapshot) -> "D2ReferenceSkeleton":
        # This call must block on the current partial snapshot; no fallback/default exists.
        structural = require_structural_scale_parameters(snapshot)
        frozen = frozen_d2_parameters(snapshot)
        return cls(symbol=symbol, structural_params=structural, frozen_params=frozen)

    def _state(self, timeframe_ms: int) -> _TimeframeState:
        state = self._tf.get(timeframe_ms)
        if state is None:
            state = _TimeframeState(self.symbol, timeframe_ms, self.structural_params)
            self._tf[timeframe_ms] = state
        return state

    @staticmethod
    def _reset_pivot(state: _TimeframeState) -> StructuralPivot | None:
        if state.trend.direction is TrendDirection.LONG:
            lows = [p for p in state.intermediate if p.pivot_type is PivotType.LOW]
            return lows[-1] if lows else state.trend.protected_pivot
        if state.trend.direction is TrendDirection.SHORT:
            highs = [p for p in state.intermediate if p.pivot_type is PivotType.HIGH]
            return highs[-1] if highs else state.trend.protected_pivot
        return None

    def advance_source_bar(
        self,
        bar: CanonicalBar,
        atr14: InfoValue[Fraction],
        *,
        canonical_segment_id: str,
    ) -> D2CutoffResult:
        """Execute only D2's UPDATE-005 -> UPDATE-006 -> UPDATE-009 slice."""
        state = self._state(self._infer_timeframe(bar))
        if state.segment_id != canonical_segment_id:
            state.reset_for_segment(canonical_segment_id)

        state.closes.append(TimedClose(bar.open_time, bar.close))
        update = state.hierarchy.update_bar(bar, atr14, canonical_segment_id=canonical_segment_id)

        for ip in update.intermediate:
            if state.intermediate:
                prior = state.intermediate[-1]
                if prior.pivot_type is not ip.pivot_type and prior.canonical_segment_id == ip.canonical_segment_id:
                    close_path = tuple(
                        c for c in state.closes
                        if prior.extreme_first_time <= c.open_time <= ip.extreme_last_time
                    )
                    try:
                        state.legs_by_end[ip.pivot_id] = build_structural_leg(prior, ip, close_path=close_path)
                    except ValueError:
                        # Skeleton preserves missing/insufficient leg measurement rather than guessing.
                        pass
            state.intermediate.append(ip)
            state.trend = on_new_intermediate_pivot(
                state.trend,
                state.intermediate,
                theta_progress=self.frozen_params.theta_progress,
                theta_rate=self.frozen_params.theta_rate,
                leg_by_end_pivot=state.legs_by_end,
            )

        reset = self._reset_pivot(state)
        tpos = classify_trend_position(
            direction=state.trend.direction,
            current_close=bar.close,
            frontier=state.trend.frontier_pivot,
            reset_pivot=reset,
            theta_progress=self.frozen_params.theta_progress,
            theta_overextension=self.frozen_params.theta_overextension,
            completed_trend_aligned_normalized_legs=state.trend.completed_trend_aligned_normalized_legs,
        )
        corridor = structural_corridor(
            direction=state.trend.direction,
            protected=state.trend.protected_pivot,
            frontier=state.trend.frontier_pivot,
            current_close=bar.close,
            theta_progress=self.frozen_params.theta_progress,
        )
        return D2CutoffResult(
            information_cutoff=bar.close_time,
            update_005_minor=update.minor,
            update_005_intermediate=update.intermediate,
            update_005_major=update.major,
            update_006_trend=state.trend,
            update_009_trend_position=tpos,
            update_009_structural_corridor=corridor,
        )

    @staticmethod
    def _infer_timeframe(bar: CanonicalBar) -> int:
        # Canonical source bars use close_time as the end of a half-open interval;
        # Binance-style close_time may be end-1ms. Infer to the nearest authorized TF.
        span = bar.close_time - bar.open_time
        candidates = (15 * 60 * 1000, 60 * 60 * 1000, 4 * 60 * 60 * 1000)
        for tf in candidates:
            if span in (tf, tf - 1):
                return tf
        raise ValueError(f"Unsupported D2 source timeframe span={span}")
