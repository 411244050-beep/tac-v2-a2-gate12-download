"""WP3 non-trading D3 reference skeleton.

This orchestrates only D3-owned RC1 slices. It never writes D2 Trend/Price
Structure, D4 Entry, D5 Risk, or D6 Position/Execution truth.
"""
from __future__ import annotations

from dataclasses import replace

from .d1_data_math.ohlc_protocol import OHLCBar
from .d3_boundary_intelligence.anchors import (
    attach_interaction,
    bind_event_to_episode,
    maybe_start_anchor_episode,
    recover_from_pressure,
    terminate_for_true_break,
)
from .d3_boundary_intelligence.breaks import apply_break_evaluation, evaluate_break
from .d3_boundary_intelligence.geometry import classify_event_reference_geometry, classify_geometry
from .d3_boundary_intelligence.interaction import apply_geometry, break_continuity, initial_watch, rearm_after_resolution
from .d3_boundary_intelligence.parameters import FrozenD3Parameters, frozen_d3_parameters
from .d3_boundary_intelligence.snapshots import pre_bar_view, snapshot_from_candidate
from .d3_boundary_intelligence.types import (
    AnchorEpisode,
    B3Geometry,
    BreakState,
    CausalBoundarySnapshot,
    CorrectSideRecoveryEvidence,
    InteractionControl,
    InteractionEvent,
    MathematicalBoundaryCandidate,
    PreBarBoundaryView,
    PriceDrivenReturnEvidence,
    StructuralAcceptanceEvidence,
)
from .parameter_snapshot import ParameterSnapshot


class D3ReferenceSkeleton:
    def __init__(self, params: FrozenD3Parameters) -> None:
        self.params = params
        self._snapshots: list[CausalBoundarySnapshot] = []
        self._events: dict[str, InteractionEvent] = {}
        self._episodes: dict[str, AnchorEpisode] = {}

    @classmethod
    def from_parameter_snapshot(cls, snapshot: ParameterSnapshot) -> "D3ReferenceSkeleton":
        # WP3 uses only already-frozen geometry/progress thresholds. This does not
        # make the overall Strategy runtime usable while structural slots are OPEN.
        return cls(frozen_d3_parameters(snapshot))

    def update_008_register_candidate(self, candidate: MathematicalBoundaryCandidate) -> CausalBoundarySnapshot | None:
        episode = self._episodes.get(candidate.candidate_id)
        snap = snapshot_from_candidate(candidate, anchor_episode_id=episode.anchor_episode_id if episode else None)
        if snap is not None:
            self._snapshots.append(snap)
        if candidate.candidate_id not in self._events:
            self._events[candidate.candidate_id] = initial_watch(
                candidate.candidate_id, candidate.target_trend_episode_id, candidate.target_direction
            )
        return snap

    def update_000_pre_bar_view(self, observer_open_time: int) -> PreBarBoundaryView:
        return pre_bar_view(observer_open_time, self._snapshots)

    def update_002_capture_geometry(
        self,
        *,
        bar: OHLCBar,
        information_cutoff: int,
        snapshot: CausalBoundarySnapshot,
    ) -> B3Geometry:
        event = self._events[snapshot.candidate_id]
        if event.control is InteractionControl.INTERACTION_ACTIVE and event.event_reference_boundary is not None:
            return classify_event_reference_geometry(
                bar=bar, information_cutoff=information_cutoff, event=event, params=self.params
            )
        return classify_geometry(bar=bar, information_cutoff=information_cutoff, snapshot=snapshot, params=self.params)

    def update_007_interaction_break(
        self,
        *,
        snapshot: CausalBoundarySnapshot,
        geometry: B3Geometry,
        return_evidence: PriceDrivenReturnEvidence | None,
        structural_acceptance: StructuralAcceptanceEvidence | None = None,
        correct_side_recovery: CorrectSideRecoveryEvidence | None = None,
    ) -> InteractionEvent:
        event = self._events[snapshot.candidate_id]
        if event.control is InteractionControl.RESOLVED:
            event = rearm_after_resolution(event, geometry=geometry)
            self._events[snapshot.candidate_id] = event
            if event.control is InteractionControl.ARMED:
                # Rearm bar cannot also open the next independent event at same cutoff.
                return event
        event = apply_geometry(event, geometry=geometry, snapshot=snapshot, return_evidence=return_evidence)
        evaluation = evaluate_break(
            event,
            geometry=geometry,
            structural_acceptance=structural_acceptance,
            correct_side_recovery=correct_side_recovery,
        )
        event = apply_break_evaluation(event, evaluation, cutoff=geometry.information_cutoff)
        if not event.terminal:
            # Allow normal correct-side resolution after B4 has had first claim on
            # an active temporary-break/reclaim path. Same cutoff cannot open a new event.
            event = apply_geometry(event, geometry=geometry, snapshot=snapshot, return_evidence=return_evidence)
        self._events[snapshot.candidate_id] = event
        episode = self._episodes.get(snapshot.candidate_id)
        if episode is not None:
            episode = attach_interaction(episode, event)
            if event.break_state is BreakState.TRUE_BREAK and event.terminal:
                episode = terminate_for_true_break(episode, cutoff=geometry.information_cutoff)
            else:
                episode = recover_from_pressure(episode, event)
            self._episodes[snapshot.candidate_id] = episode
        return event

    def update_008_anchor_lifecycle(
        self,
        *,
        candidate: MathematicalBoundaryCandidate,
        target_trend_active: bool,
        candidate_terminally_invalidated: bool,
        cutoff: int,
    ) -> AnchorEpisode | None:
        existing = self._episodes.get(candidate.candidate_id)
        if existing is not None and existing.validity.value != "TERMINATED":
            return existing
        event = self._events[candidate.candidate_id]
        episode = maybe_start_anchor_episode(
            candidate,
            event,
            target_trend_active=target_trend_active,
            candidate_terminally_invalidated=candidate_terminally_invalidated,
            cutoff=cutoff,
        )
        if episode is not None:
            event = bind_event_to_episode(event, episode)
            self._events[candidate.candidate_id] = event
            self._episodes[candidate.candidate_id] = episode
        return episode

    def continuity_break(self, candidate_id: str, *, cutoff: int) -> InteractionEvent:
        event = break_continuity(self._events[candidate_id], cutoff=cutoff)
        self._events[candidate_id] = event
        episode = self._episodes.get(candidate_id)
        if episode is not None and episode.validity.value != "TERMINATED":
            from .d3_boundary_intelligence.anchors import terminate_episode
            self._episodes[candidate_id] = terminate_episode(episode, cutoff=cutoff, reason="SOURCE_CONTINUITY_BREAK")
        return event

    def current_event(self, candidate_id: str) -> InteractionEvent:
        return self._events[candidate_id]

    def current_episode(self, candidate_id: str) -> AnchorEpisode | None:
        return self._episodes.get(candidate_id)
