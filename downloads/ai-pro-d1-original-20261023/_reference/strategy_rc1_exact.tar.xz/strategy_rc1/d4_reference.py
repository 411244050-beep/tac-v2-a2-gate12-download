"""WP4 D4 façade.

This façade exposes UPDATE-011 only. It has no B8 RiskFeasibility, B7-B
ENTRY_READY, portfolio, position, exit, execution, exchange, or order path.
"""

from .d4_opportunity.engine import D4CutoffInput, update_011

__all__ = ["D4CutoffInput", "update_011"]
