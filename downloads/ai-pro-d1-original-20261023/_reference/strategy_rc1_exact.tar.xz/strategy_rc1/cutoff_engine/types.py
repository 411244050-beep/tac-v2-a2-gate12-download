from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from types import MappingProxyType
from typing import Any, Mapping

from ..d1_data_math.canonical import CanonicalBar
from ..ids import canonical_json, deterministic_id


class UpdateStep(str, Enum):
    UPDATE_000 = "UPDATE-000"
    UPDATE_001 = "UPDATE-001"
    UPDATE_002 = "UPDATE-002"
    UPDATE_003 = "UPDATE-003"
    UPDATE_004 = "UPDATE-004"
    UPDATE_005 = "UPDATE-005"
    UPDATE_006 = "UPDATE-006"
    UPDATE_007 = "UPDATE-007"
    UPDATE_008 = "UPDATE-008"
    UPDATE_009 = "UPDATE-009"
    UPDATE_010 = "UPDATE-010"
    UPDATE_011 = "UPDATE-011"
    UPDATE_012 = "UPDATE-012"
    UPDATE_013 = "UPDATE-013"
    UPDATE_014 = "UPDATE-014"
    UPDATE_015 = "UPDATE-015"
    UPDATE_016 = "UPDATE-016"


UPDATE_ORDER: tuple[UpdateStep, ...] = tuple(UpdateStep(f"UPDATE-{i:03d}") for i in range(17))


class DomainOwner(str, Enum):
    ORCHESTRATOR = "ORCHESTRATOR"
    CANONICAL_DATA = "CANONICAL_DATA"
    D1_DATA_MATH = "D1_DATA_MATH"
    D2_MARKET_STATE = "D2_MARKET_STATE"
    D3_BOUNDARY_INTELLIGENCE = "D3_BOUNDARY_INTELLIGENCE"
    D4_OPPORTUNITY_DECISION = "D4_OPPORTUNITY_DECISION"
    D5_RISK = "D5_RISK"
    D6_STRATEGY = "D6_STRATEGY"
    D6_EXECUTION = "D6_EXECUTION"
    PORTFOLIO_BOUNDARY = "PORTFOLIO_BOUNDARY"
    LEDGER = "LEDGER"


EXPECTED_OWNER: Mapping[UpdateStep, DomainOwner] = MappingProxyType({
    UpdateStep.UPDATE_000: DomainOwner.ORCHESTRATOR,
    UpdateStep.UPDATE_001: DomainOwner.CANONICAL_DATA,
    UpdateStep.UPDATE_002: DomainOwner.D3_BOUNDARY_INTELLIGENCE,
    UpdateStep.UPDATE_003: DomainOwner.D1_DATA_MATH,
    UpdateStep.UPDATE_004: DomainOwner.D1_DATA_MATH,
    UpdateStep.UPDATE_005: DomainOwner.D2_MARKET_STATE,
    UpdateStep.UPDATE_006: DomainOwner.D2_MARKET_STATE,
    UpdateStep.UPDATE_007: DomainOwner.D3_BOUNDARY_INTELLIGENCE,
    UpdateStep.UPDATE_008: DomainOwner.D3_BOUNDARY_INTELLIGENCE,
    UpdateStep.UPDATE_009: DomainOwner.D2_MARKET_STATE,
    UpdateStep.UPDATE_010: DomainOwner.D6_STRATEGY,
    UpdateStep.UPDATE_011: DomainOwner.D4_OPPORTUNITY_DECISION,
    UpdateStep.UPDATE_012: DomainOwner.D5_RISK,
    UpdateStep.UPDATE_013: DomainOwner.D4_OPPORTUNITY_DECISION,
    UpdateStep.UPDATE_014: DomainOwner.ORCHESTRATOR,
    UpdateStep.UPDATE_015: DomainOwner.PORTFOLIO_BOUNDARY,
    UpdateStep.UPDATE_016: DomainOwner.LEDGER,
})

NEW_RISK_STEPS = frozenset({
    UpdateStep.UPDATE_011,
    UpdateStep.UPDATE_012,
    UpdateStep.UPDATE_013,
    UpdateStep.UPDATE_014,
    UpdateStep.UPDATE_015,
})


class StageState(str, Enum):
    PASS = "PASS"
    BLOCKED = "BLOCKED"
    SKIPPED = "SKIPPED"
    NA = "N/A"
    ERROR = "ERROR"


class EventChannel(str, Enum):
    STRATEGY = "STRATEGY"
    EXECUTION = "EXECUTION"
    RECONCILIATION = "RECONCILIATION"


@dataclass(frozen=True)
class ProposedEvent:
    event_type: str
    source: str
    payload_json: str
    channel: EventChannel = EventChannel.STRATEGY
    prior_state_ref: str | None = None
    canonical_segment_id: str | None = None
    admission_tag: str | None = None

    @classmethod
    def from_payload(
        cls,
        *,
        event_type: str,
        source: str,
        payload: Any,
        channel: EventChannel = EventChannel.STRATEGY,
        prior_state_ref: str | None = None,
        canonical_segment_id: str | None = None,
        admission_tag: str | None = None,
    ) -> "ProposedEvent":
        return cls(
            event_type=event_type,
            source=source,
            payload_json=canonical_json(payload),
            channel=channel,
            prior_state_ref=prior_state_ref,
            canonical_segment_id=canonical_segment_id,
            admission_tag=admission_tag,
        )


@dataclass(frozen=True)
class StageResult:
    owner: DomainOwner
    state: StageState
    reason: str
    payload_json: str
    proposed_events: tuple[ProposedEvent, ...] = ()
    blocks_new_risk: bool = False
    information_cutoff: int | None = None
    canonical_segment_id: str | None = None
    strategy_exit_created: bool = False
    entry_ready_created: bool = False
    entry_ready_ref: str | None = None
    runtime_usable_signal: bool = False
    next_boundary_snapshot_refs: tuple[str, ...] = ()
    next_interaction_control_refs: tuple[str, ...] = ()
    next_strategy_state_refs: tuple[str, ...] = ()

    @classmethod
    def make(
        cls,
        *,
        owner: DomainOwner,
        state: StageState = StageState.PASS,
        reason: str = "OK",
        payload: Any = None,
        proposed_events: tuple[ProposedEvent, ...] = (),
        blocks_new_risk: bool = False,
        information_cutoff: int | None = None,
        canonical_segment_id: str | None = None,
        strategy_exit_created: bool = False,
        entry_ready_created: bool = False,
        entry_ready_ref: str | None = None,
        runtime_usable_signal: bool = False,
        next_boundary_snapshot_refs: tuple[str, ...] = (),
        next_interaction_control_refs: tuple[str, ...] = (),
        next_strategy_state_refs: tuple[str, ...] = (),
    ) -> "StageResult":
        return cls(
            owner=owner,
            state=state,
            reason=reason,
            payload_json=canonical_json(payload),
            proposed_events=tuple(proposed_events),
            blocks_new_risk=blocks_new_risk,
            information_cutoff=information_cutoff,
            canonical_segment_id=canonical_segment_id,
            strategy_exit_created=strategy_exit_created,
            entry_ready_created=entry_ready_created,
            entry_ready_ref=entry_ready_ref,
            runtime_usable_signal=runtime_usable_signal,
            next_boundary_snapshot_refs=tuple(next_boundary_snapshot_refs),
            next_interaction_control_refs=tuple(next_interaction_control_refs),
            next_strategy_state_refs=tuple(next_strategy_state_refs),
        )


@dataclass(frozen=True)
class StageEnvelope:
    step: UpdateStep
    owner: DomainOwner
    state: StageState
    reason: str
    input_digest: str
    output_digest: str
    payload_json: str


@dataclass(frozen=True)
class CausalObserverSnapshot:
    snapshot_id: str
    symbol: str
    source_information_cutoff: int
    eligible_from_open_time: int
    boundary_snapshot_refs: tuple[str, ...]
    interaction_control_refs: tuple[str, ...]
    strategy_state_refs: tuple[str, ...]


def make_causal_observer_snapshot(
    *,
    symbol: str,
    source_information_cutoff: int,
    eligible_from_open_time: int,
    boundary_snapshot_refs: tuple[str, ...] = (),
    interaction_control_refs: tuple[str, ...] = (),
    strategy_state_refs: tuple[str, ...] = (),
) -> CausalObserverSnapshot:
    boundary = tuple(sorted(set(boundary_snapshot_refs)))
    interaction = tuple(sorted(set(interaction_control_refs)))
    strategy = tuple(sorted(set(strategy_state_refs)))
    sid = deterministic_id(
        "observer_snapshot",
        symbol,
        source_information_cutoff,
        eligible_from_open_time,
        boundary,
        interaction,
        strategy,
    )
    return CausalObserverSnapshot(
        snapshot_id=sid,
        symbol=symbol,
        source_information_cutoff=source_information_cutoff,
        eligible_from_open_time=eligible_from_open_time,
        boundary_snapshot_refs=boundary,
        interaction_control_refs=interaction,
        strategy_state_refs=strategy,
    )


@dataclass(frozen=True)
class SymbolCutoffInput:
    strategy_id: str
    parameter_snapshot_id: str
    observer_bar: CanonicalBar
    prebar_snapshot: CausalObserverSnapshot
    fixture_class: str | None = None

    @property
    def symbol(self) -> str:
        return self.observer_bar.symbol


@dataclass(frozen=True)
class StageContext:
    transaction_id: str
    step: UpdateStep
    symbol_input: SymbolCutoffInput
    information_cutoff: int | None
    canonical_segment_id: str | None
    new_risk_blocked: bool
    prior_envelopes: tuple[StageEnvelope, ...]
    prior_results: Mapping[UpdateStep, StageResult] = field(default_factory=dict)

    def __post_init__(self) -> None:
        object.__setattr__(self, "prior_results", MappingProxyType(dict(self.prior_results)))


class TransactionTerminal(str, Enum):
    COMMITTED = "COMMITTED"
    COMMITTED_WITH_BLOCKS = "COMMITTED_WITH_BLOCKS"
    ABORTED_ERROR = "ABORTED_ERROR"
    ABORTED_AMBIGUITY = "ABORTED_AMBIGUITY"


@dataclass(frozen=True)
class PortfolioCandidate:
    symbol: str
    entry_ready_ref: str
    transaction_id: str


@dataclass(frozen=True)
class PortfolioBoundaryResult:
    state: StageState
    reason: str
    candidates: tuple[PortfolioCandidate, ...]
    allocation: None = None
    port_007_frozen: bool = False

    def __post_init__(self) -> None:
        if self.allocation is not None or self.port_007_frozen:
            raise ValueError("WP7 forbids portfolio allocation or PORT-007 freeze")


@dataclass(frozen=True)
class SymbolTransactionResult:
    transaction_id: str
    symbol: str
    information_cutoff: int | None
    canonical_segment_id: str | None
    terminal: TransactionTerminal
    new_risk_blocked: bool
    stages: tuple[StageEnvelope, ...]
    next_bar_snapshot: CausalObserverSnapshot | None
    appended_event_ids: tuple[str, ...]
    entry_ready_admitted_by_update014: bool
    error_reason: str | None = None


@dataclass(frozen=True)
class CutoffBatchResult:
    batch_id: str
    terminal: TransactionTerminal
    portfolio_boundary: PortfolioBoundaryResult | None
    symbol_results: tuple[SymbolTransactionResult, ...]
    ledger_event_ids: tuple[str, ...]
