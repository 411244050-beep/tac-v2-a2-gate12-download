from __future__ import annotations

from .types import PortfolioBoundaryResult, PortfolioCandidate, StageState

PORT_007_STATE = "OPEN_OPERATIONAL_OPEN_RESEARCH_UNFROZEN"


def evaluate_portfolio_boundary(candidates: tuple[PortfolioCandidate, ...]) -> PortfolioBoundaryResult:
    ordered = tuple(sorted(candidates, key=lambda c: (c.symbol, c.entry_ready_ref, c.transaction_id)))
    return PortfolioBoundaryResult(
        state=StageState.BLOCKED,
        reason="PORT007_UNRESOLVED_PRODUCTION_ALLOCATION_BLOCKED",
        candidates=ordered,
        allocation=None,
        port_007_frozen=False,
    )
