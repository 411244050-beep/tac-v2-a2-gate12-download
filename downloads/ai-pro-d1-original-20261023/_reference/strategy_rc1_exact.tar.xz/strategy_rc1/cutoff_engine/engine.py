from __future__ import annotations

import hashlib
from dataclasses import dataclass
from typing import Iterable

from ..ids import canonical_json, deterministic_id
from ..ledger.append_only_store import AppendOnlyLedger
from ..runtime_guards.ambiguity import AmbiguityStop, stop_and_report_ambiguity
from .adapters import AdapterRegistry
from .ledger_bridge import materialize_event
from .portfolio_boundary import evaluate_portfolio_boundary
from .types import (
    EXPECTED_OWNER,
    NEW_RISK_STEPS,
    CausalObserverSnapshot,
    CutoffBatchResult,
    DomainOwner,
    PortfolioCandidate,
    ProposedEvent,
    StageContext,
    StageEnvelope,
    StageResult,
    StageState,
    SymbolCutoffInput,
    SymbolTransactionResult,
    TransactionTerminal,
    UPDATE_ORDER,
    UpdateStep,
    make_causal_observer_snapshot,
)


def _digest(value: object) -> str:
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def _stage_envelope(step: UpdateStep, result: StageResult, *, context_digest: str) -> StageEnvelope:
    return StageEnvelope(
        step=step,
        owner=result.owner,
        state=result.state,
        reason=result.reason,
        input_digest=context_digest,
        output_digest=_digest(result),
        payload_json=result.payload_json,
    )


def _skip_result(step: UpdateStep, reason: str) -> StageResult:
    return StageResult.make(
        owner=EXPECTED_OWNER[step],
        state=StageState.SKIPPED,
        reason=reason,
        payload={"blocked": True, "step": step.value},
    )


@dataclass
class _ProvisionalSymbol:
    symbol_input: SymbolCutoffInput
    transaction_id: str
    information_cutoff: int | None
    canonical_segment_id: str | None
    new_risk_blocked: bool
    stages: list[StageEnvelope]
    results: dict[UpdateStep, StageResult]
    buffered_events: list[tuple[UpdateStep, ProposedEvent]]
    entry_ready_admitted: bool = False
    terminal: TransactionTerminal | None = None
    error_reason: str | None = None


class DeterministicCutoffEngine:
    """WP7 orchestration only; it never computes D1-D6 market semantics itself."""

    def __init__(
        self,
        *,
        adapters: AdapterRegistry,
        ledger: AppendOnlyLedger,
        runtime_usable: bool = False,
    ) -> None:
        if runtime_usable:
            raise ValueError("WP7 current incomplete parameter state forbids runtime_usable=True")
        self.adapters = adapters
        self.ledger = ledger
        self.runtime_usable = False

    def _validate_prebar(self, item: SymbolCutoffInput) -> None:
        snap = item.prebar_snapshot
        bar = item.observer_bar
        if snap.symbol != bar.symbol:
            stop_and_report_ambiguity("prebar snapshot symbol mismatch")
        if snap.eligible_from_open_time > bar.open_time:
            stop_and_report_ambiguity("prebar snapshot is not causally eligible for observer bar")
        if snap.source_information_cutoff >= bar.close_time:
            stop_and_report_ambiguity("same/future cutoff snapshot cannot be used for bar-t geometry")

    def _run_until_014(self, item: SymbolCutoffInput) -> _ProvisionalSymbol:
        self._validate_prebar(item)
        txid = deterministic_id(
            "cutoff_tx",
            item.strategy_id,
            item.parameter_snapshot_id,
            item.symbol,
            item.observer_bar.open_time,
            item.observer_bar.close_time,
            item.prebar_snapshot.snapshot_id,
            item.fixture_class,
        )
        p = _ProvisionalSymbol(item, txid, None, None, False, [], {}, [])

        # UPDATE-000 is orchestrator-owned and exposes only the pre-bar frozen snapshot.
        r0 = StageResult.make(
            owner=DomainOwner.ORCHESTRATOR,
            payload={
                "prebar_snapshot_id": item.prebar_snapshot.snapshot_id,
                "boundary_snapshot_refs": item.prebar_snapshot.boundary_snapshot_refs,
                "interaction_control_refs": item.prebar_snapshot.interaction_control_refs,
                "strategy_state_refs": item.prebar_snapshot.strategy_state_refs,
            },
            reason="PRE_BAR_STATE_FROZEN",
        )
        c0 = _digest({"tx": txid, "step": UpdateStep.UPDATE_000.value, "input": item})
        p.results[UpdateStep.UPDATE_000] = r0
        p.stages.append(_stage_envelope(UpdateStep.UPDATE_000, r0, context_digest=c0))

        try:
            for step in tuple(UpdateStep(f"UPDATE-{i:03d}") for i in range(1, 14)):
                if p.new_risk_blocked and step in NEW_RISK_STEPS:
                    result = _skip_result(step, "CRITICAL_BLOCK_STOPS_NEW_RISK_PROCESSING")
                else:
                    ctx = StageContext(
                        transaction_id=txid,
                        step=step,
                        symbol_input=item,
                        information_cutoff=p.information_cutoff,
                        canonical_segment_id=p.canonical_segment_id,
                        new_risk_blocked=p.new_risk_blocked,
                        prior_envelopes=tuple(p.stages),
                        prior_results=p.results,
                    )
                    result = self.adapters.run(step, ctx)

                if result.runtime_usable_signal:
                    raise RuntimeError("WP7_RUNTIME_USABLE_SIGNAL_FORBIDDEN")
                if step is UpdateStep.UPDATE_001:
                    if result.information_cutoff is None:
                        raise RuntimeError("UPDATE-001 must establish information_cutoff")
                    if result.information_cutoff != item.observer_bar.close_time:
                        raise RuntimeError("UPDATE-001 information_cutoff must equal committed observer bar close_time")
                    if result.canonical_segment_id is None:
                        raise RuntimeError("UPDATE-001 must expose canonical_segment_id")
                    p.information_cutoff = result.information_cutoff
                    p.canonical_segment_id = result.canonical_segment_id
                elif result.information_cutoff is not None and result.information_cutoff != p.information_cutoff:
                    raise RuntimeError(f"CROSS_CUTOFF_STAGE_OUTPUT step={step.value}")

                if result.blocks_new_risk:
                    p.new_risk_blocked = True
                if result.state is StageState.ERROR:
                    raise RuntimeError(f"STAGE_ERROR {step.value}: {result.reason}")

                context_digest = _digest({
                    "tx": txid,
                    "step": step.value,
                    "cutoff": p.information_cutoff,
                    "segment": p.canonical_segment_id,
                    "prior_output_digests": tuple(e.output_digest for e in p.stages),
                })
                p.results[step] = result
                p.stages.append(_stage_envelope(step, result, context_digest=context_digest))
                p.buffered_events.extend((step, event) for event in result.proposed_events)

            # UPDATE-014 is a pure orchestrator admission guard; it never creates Entry truth.
            exit_created = p.results[UpdateStep.UPDATE_010].strategy_exit_created
            entry_result = p.results[UpdateStep.UPDATE_013]
            if exit_created and entry_result.entry_ready_created:
                p.entry_ready_admitted = False
                r14 = StageResult.make(
                    owner=DomainOwner.ORCHESTRATOR,
                    state=StageState.BLOCKED,
                    reason="SAME_CUTOFF_EXIT_BLOCKS_ENTRY_READY",
                    payload={"entry_ready_ref": entry_result.entry_ready_ref, "exit_same_cutoff": True},
                    blocks_new_risk=True,
                )
                p.new_risk_blocked = True
            elif entry_result.entry_ready_created:
                p.entry_ready_admitted = True
                r14 = StageResult.make(
                    owner=DomainOwner.ORCHESTRATOR,
                    state=StageState.PASS,
                    reason="ENTRY_READY_ADMITTED_BY_SAME_CUTOFF_SAFETY",
                    payload={"entry_ready_ref": entry_result.entry_ready_ref, "exit_same_cutoff": False},
                )
            else:
                r14 = StageResult.make(
                    owner=DomainOwner.ORCHESTRATOR,
                    state=StageState.NA,
                    reason="NO_ENTRY_READY_CANDIDATE",
                    payload=None,
                )
            c14 = _digest({"tx": txid, "step": UpdateStep.UPDATE_014.value, "u010": p.results[UpdateStep.UPDATE_010], "u013": entry_result})
            p.results[UpdateStep.UPDATE_014] = r14
            p.stages.append(_stage_envelope(UpdateStep.UPDATE_014, r14, context_digest=c14))
            p.terminal = TransactionTerminal.COMMITTED_WITH_BLOCKS if p.new_risk_blocked else TransactionTerminal.COMMITTED
            return p

        except AmbiguityStop as exc:
            p.terminal = TransactionTerminal.ABORTED_AMBIGUITY
            p.error_reason = str(exc)
            return p
        except Exception as exc:
            p.terminal = TransactionTerminal.ABORTED_ERROR
            p.error_reason = str(exc)
            return p

    def run_cutoff_batch(self, items: Iterable[SymbolCutoffInput]) -> CutoffBatchResult:
        ordered = tuple(sorted(items, key=lambda x: x.symbol))
        if not ordered:
            stop_and_report_ambiguity("cutoff batch cannot be empty")
        if len({x.symbol for x in ordered}) != len(ordered):
            stop_and_report_ambiguity("duplicate symbol in cutoff batch")
        expected_close = ordered[0].observer_bar.close_time
        if any(x.observer_bar.close_time != expected_close for x in ordered):
            stop_and_report_ambiguity("all symbols in UPDATE-015 batch must share information cutoff")

        batch_id = deterministic_id(
            "cutoff_batch",
            expected_close,
            tuple((x.symbol, x.observer_bar.open_time, x.prebar_snapshot.snapshot_id) for x in ordered),
        )
        before_ledger = self.ledger.snapshot()
        provisionals = [self._run_until_014(x) for x in ordered]
        fatal = next((p for p in provisionals if p.terminal in (TransactionTerminal.ABORTED_ERROR, TransactionTerminal.ABORTED_AMBIGUITY)), None)
        if fatal is not None:
            if self.ledger.snapshot() != before_ledger:
                raise RuntimeError("PARTIAL_LEDGER_COMMIT_ON_ABORT")
            results = tuple(self._final_result_without_016(p) for p in provisionals)
            return CutoffBatchResult(
                batch_id=batch_id,
                terminal=fatal.terminal or TransactionTerminal.ABORTED_ERROR,
                portfolio_boundary=None,
                symbol_results=results,
                ledger_event_ids=tuple(e.event_id for e in self.ledger.snapshot()),
            )

        candidates: list[PortfolioCandidate] = []
        for p in provisionals:
            er = p.results[UpdateStep.UPDATE_013]
            if p.entry_ready_admitted and er.entry_ready_created and er.entry_ready_ref:
                candidates.append(PortfolioCandidate(p.symbol_input.symbol, er.entry_ready_ref, p.transaction_id))
        portfolio = evaluate_portfolio_boundary(tuple(candidates))

        # UPDATE-015 is batch-global but represented in each symbol trace identically.
        for p in provisionals:
            r15 = StageResult.make(
                owner=DomainOwner.PORTFOLIO_BOUNDARY,
                state=StageState.BLOCKED,
                reason=portfolio.reason,
                payload={
                    "candidate_refs": tuple((c.symbol, c.entry_ready_ref) for c in portfolio.candidates),
                    "allocation": None,
                    "port_007_frozen": False,
                },
                blocks_new_risk=bool(portfolio.candidates),
            )
            c15 = _digest({"batch": batch_id, "step": UpdateStep.UPDATE_015.value, "portfolio": portfolio})
            p.results[UpdateStep.UPDATE_015] = r15
            p.stages.append(_stage_envelope(UpdateStep.UPDATE_015, r15, context_digest=c15))
            if portfolio.candidates:
                p.new_risk_blocked = True
                p.terminal = TransactionTerminal.COMMITTED_WITH_BLOCKS

        # UPDATE-016: build all events/snapshots first, then append one atomic ledger batch.
        all_events = []
        per_symbol_event_ids: dict[str, list[str]] = {p.symbol_input.symbol: [] for p in provisionals}
        next_snaps: dict[str, CausalObserverSnapshot] = {}
        for p in provisionals:
            assert p.information_cutoff is not None
            admitted_events: list[tuple[UpdateStep, ProposedEvent]] = []
            for step, proposed in p.buffered_events:
                if proposed.admission_tag == "ENTRY_READY" and not p.entry_ready_admitted:
                    continue
                admitted_events.append((step, proposed))
            for step, proposed in admitted_events:
                ev = materialize_event(
                    proposed,
                    strategy_id=p.symbol_input.strategy_id,
                    parameter_snapshot_id=p.symbol_input.parameter_snapshot_id,
                    symbol=p.symbol_input.symbol,
                    information_cutoff=p.information_cutoff,
                    transaction_id=p.transaction_id,
                    update_step=step.value,
                )
                all_events.append(ev)
                per_symbol_event_ids[p.symbol_input.symbol].append(ev.event_id)

            u7 = p.results[UpdateStep.UPDATE_007]
            u8 = p.results[UpdateStep.UPDATE_008]
            u10 = p.results[UpdateStep.UPDATE_010]
            next_open = p.symbol_input.observer_bar.open_time + 15 * 60 * 1000
            next_snaps[p.symbol_input.symbol] = make_causal_observer_snapshot(
                symbol=p.symbol_input.symbol,
                source_information_cutoff=p.information_cutoff,
                eligible_from_open_time=next_open,
                boundary_snapshot_refs=u8.next_boundary_snapshot_refs,
                interaction_control_refs=u7.next_interaction_control_refs,
                strategy_state_refs=u10.next_strategy_state_refs,
            )

        self.ledger.append_batch_atomic(tuple(all_events))

        symbol_results: list[SymbolTransactionResult] = []
        for p in provisionals:
            snap = next_snaps[p.symbol_input.symbol]
            r16 = StageResult.make(
                owner=DomainOwner.LEDGER,
                state=StageState.PASS,
                reason="ATOMIC_EVENT_APPEND_AND_T_PLUS_1_SNAPSHOT_FROZEN",
                payload={
                    "appended_event_ids": tuple(per_symbol_event_ids[p.symbol_input.symbol]),
                    "next_bar_snapshot_id": snap.snapshot_id,
                    "eligible_from_open_time": snap.eligible_from_open_time,
                },
            )
            c16 = _digest({"tx": p.transaction_id, "step": UpdateStep.UPDATE_016.value, "events": tuple(per_symbol_event_ids[p.symbol_input.symbol]), "snapshot": snap})
            p.results[UpdateStep.UPDATE_016] = r16
            p.stages.append(_stage_envelope(UpdateStep.UPDATE_016, r16, context_digest=c16))
            if tuple(e.step for e in p.stages) != UPDATE_ORDER:
                raise RuntimeError("FULL_UPDATE_ORDER_VIOLATION")
            symbol_results.append(SymbolTransactionResult(
                transaction_id=p.transaction_id,
                symbol=p.symbol_input.symbol,
                information_cutoff=p.information_cutoff,
                canonical_segment_id=p.canonical_segment_id,
                terminal=p.terminal or TransactionTerminal.COMMITTED,
                new_risk_blocked=p.new_risk_blocked,
                stages=tuple(p.stages),
                next_bar_snapshot=snap,
                appended_event_ids=tuple(per_symbol_event_ids[p.symbol_input.symbol]),
                entry_ready_admitted_by_update014=p.entry_ready_admitted,
                error_reason=None,
            ))

        batch_terminal = TransactionTerminal.COMMITTED_WITH_BLOCKS if any(r.new_risk_blocked for r in symbol_results) else TransactionTerminal.COMMITTED
        return CutoffBatchResult(
            batch_id=batch_id,
            terminal=batch_terminal,
            portfolio_boundary=portfolio,
            symbol_results=tuple(symbol_results),
            ledger_event_ids=tuple(e.event_id for e in self.ledger.snapshot()),
        )

    def _final_result_without_016(self, p: _ProvisionalSymbol) -> SymbolTransactionResult:
        return SymbolTransactionResult(
            transaction_id=p.transaction_id,
            symbol=p.symbol_input.symbol,
            information_cutoff=p.information_cutoff,
            canonical_segment_id=p.canonical_segment_id,
            terminal=p.terminal or TransactionTerminal.ABORTED_ERROR,
            new_risk_blocked=p.new_risk_blocked,
            stages=tuple(p.stages),
            next_bar_snapshot=None,
            appended_event_ids=(),
            entry_ready_admitted_by_update014=False,
            error_reason=p.error_reason,
        )
