from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Mapping, Protocol

from ..runtime_guards.ambiguity import stop_and_report_ambiguity
from .types import EXPECTED_OWNER, UpdateStep, StageContext, StageResult


class StageAdapter(Protocol):
    def __call__(self, context: StageContext) -> StageResult: ...


REQUIRED_ADAPTER_STEPS: tuple[UpdateStep, ...] = tuple(
    UpdateStep(f"UPDATE-{i:03d}") for i in range(1, 14)
)


@dataclass(frozen=True)
class AdapterRegistry:
    adapters: Mapping[UpdateStep, StageAdapter]

    def __post_init__(self) -> None:
        missing = [s.value for s in REQUIRED_ADAPTER_STEPS if s not in self.adapters]
        extra = [s.value for s in self.adapters if s not in REQUIRED_ADAPTER_STEPS]
        if missing or extra:
            stop_and_report_ambiguity(
                f"WP7 adapter registry must exactly cover UPDATE-001..013; missing={missing}; extra={extra}"
            )

    def run(self, step: UpdateStep, context: StageContext) -> StageResult:
        adapter = self.adapters[step]
        result = adapter(context)
        expected = EXPECTED_OWNER[step]
        if result.owner is not expected:
            raise RuntimeError(
                f"WRITER_FIREWALL_VIOLATION step={step.value} expected={expected.value} got={result.owner.value}"
            )
        return result
