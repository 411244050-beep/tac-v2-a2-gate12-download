from __future__ import annotations

import json

from ..ledger.append_only_store import AppendOnlyLedger
from ..ledger.events import EventEnvelope, make_event
from .types import EventChannel, ProposedEvent


def materialize_event(
    proposed: ProposedEvent,
    *,
    strategy_id: str,
    parameter_snapshot_id: str,
    symbol: str,
    information_cutoff: int,
    transaction_id: str,
    update_step: str,
) -> EventEnvelope:
    return make_event(
        strategy_id=strategy_id,
        parameter_snapshot_id=parameter_snapshot_id,
        symbol=symbol,
        information_cutoff=information_cutoff,
        event_type=proposed.event_type,
        source=proposed.source,
        payload=json.loads(proposed.payload_json),
        prior_state_ref=proposed.prior_state_ref,
        canonical_segment_id=proposed.canonical_segment_id,
        event_channel=proposed.channel.value,
        transaction_id=transaction_id,
        update_step=update_step,
    )


def append_external_execution_outcome(
    ledger: AppendOnlyLedger,
    *,
    strategy_id: str,
    parameter_snapshot_id: str,
    symbol: str,
    information_cutoff: int,
    event_type: str,
    payload: object,
    strategy_signal_ref: str,
    channel: EventChannel = EventChannel.EXECUTION,
) -> EventEnvelope:
    if channel is EventChannel.STRATEGY:
        raise ValueError("External execution bridge may not append Strategy-channel truth")
    event = make_event(
        strategy_id=strategy_id,
        parameter_snapshot_id=parameter_snapshot_id,
        symbol=symbol,
        information_cutoff=information_cutoff,
        event_type=event_type,
        source="D6_EXECUTION_INTERFACE",
        payload={"strategy_signal_ref": strategy_signal_ref, "outcome": payload},
        event_channel=channel.value,
        prior_state_ref=strategy_signal_ref,
        update_step="EXECUTION_INTERFACE",
    )
    ledger.append(event)
    return event
