from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from fractions import Fraction
from typing import Any


class Direction(str, Enum):
    UP = "UP"
    DOWN = "DOWN"
    UNKNOWN = "UNKNOWN"


class IntegritySeverity(str, Enum):
    INFO = "INFO"
    BLOCK = "BLOCK"


@dataclass(frozen=True)
class IntegrityIssue:
    code: str
    severity: IntegritySeverity
    detail: str
    open_time: int | None = None


Number = Fraction


def number_to_exact_dict(value: Fraction) -> dict[str, int]:
    return {"numerator": value.numerator, "denominator": value.denominator}


def freeze_payload(value: Any) -> Any:
    """Convert supported objects into deterministic JSON-safe primitives."""
    from dataclasses import asdict, is_dataclass

    if isinstance(value, Fraction):
        return {"__fraction__": [value.numerator, value.denominator]}
    if isinstance(value, Enum):
        return value.value
    if is_dataclass(value):
        return {k: freeze_payload(v) for k, v in asdict(value).items()}
    if isinstance(value, dict):
        return {str(k): freeze_payload(v) for k, v in sorted(value.items(), key=lambda kv: str(kv[0]))}
    if isinstance(value, (list, tuple)):
        return [freeze_payload(v) for v in value]
    if value is None or isinstance(value, (str, int, bool)):
        return value
    raise TypeError(f"Unsupported deterministic payload type: {type(value)!r}")
