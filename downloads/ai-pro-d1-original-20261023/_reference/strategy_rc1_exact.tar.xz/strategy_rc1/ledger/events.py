from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from ..ids import canonical_json, deterministic_id
from ..spec_binding import SPEC_VERSION


@dataclass(frozen=True)
class EventEnvelope:
    event_id: str
    strategy_id: str
    spec_version: str
    parameter_snapshot_id: str
    symbol: str
    information_cutoff: int
    event_type: str
    source: str
    payload_json: str
    prior_state_ref: str | None = None
    canonical_segment_id: str | None = None
    event_channel: str = "STRATEGY"
    transaction_id: str | None = None
    update_step: str | None = None


def make_event(
    *,
    strategy_id: str,
    parameter_snapshot_id: str,
    symbol: str,
    information_cutoff: int,
    event_type: str,
    source: str,
    payload: Any,
    prior_state_ref: str | None = None,
    canonical_segment_id: str | None = None,
    event_channel: str = "STRATEGY",
    transaction_id: str | None = None,
    update_step: str | None = None,
) -> EventEnvelope:
    payload_json = canonical_json(payload)
    event_id = deterministic_id(
        "event",
        strategy_id,
        SPEC_VERSION,
        parameter_snapshot_id,
        symbol,
        information_cutoff,
        event_type,
        source,
        payload_json,
        prior_state_ref,
        canonical_segment_id,
        event_channel,
        transaction_id,
        update_step,
    )
    return EventEnvelope(
        event_id=event_id,
        strategy_id=strategy_id,
        spec_version=SPEC_VERSION,
        parameter_snapshot_id=parameter_snapshot_id,
        symbol=symbol,
        information_cutoff=information_cutoff,
        event_type=event_type,
        source=source,
        payload_json=payload_json,
        prior_state_ref=prior_state_ref,
        canonical_segment_id=canonical_segment_id,
        event_channel=event_channel,
        transaction_id=transaction_id,
        update_step=update_step,
    )
