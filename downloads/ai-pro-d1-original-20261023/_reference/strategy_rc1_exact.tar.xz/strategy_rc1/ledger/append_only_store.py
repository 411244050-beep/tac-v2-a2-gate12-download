from __future__ import annotations

from .events import EventEnvelope


class AppendOnlyViolation(RuntimeError):
    pass


class AppendOnlyLedger:
    def __init__(self) -> None:
        self._events: list[EventEnvelope] = []
        self._ids: set[str] = set()

    def append(self, event: EventEnvelope) -> None:
        if event.event_id in self._ids:
            raise AppendOnlyViolation(f"Event ID already appended: {event.event_id}")
        self._events.append(event)
        self._ids.add(event.event_id)

    def append_batch_atomic(self, events: tuple[EventEnvelope, ...]) -> None:
        incoming = [e.event_id for e in events]
        if len(incoming) != len(set(incoming)):
            raise AppendOnlyViolation("Duplicate Event ID inside atomic batch")
        collision = next((eid for eid in incoming if eid in self._ids), None)
        if collision is not None:
            raise AppendOnlyViolation(f"Event ID already appended: {collision}")
        # Only mutate after the whole batch has passed validation.
        self._events.extend(events)
        self._ids.update(incoming)

    def snapshot(self) -> tuple[EventEnvelope, ...]:
        return tuple(self._events)
