from __future__ import annotations

from dataclasses import dataclass, field
from types import MappingProxyType
from typing import Mapping

from ..d2_market_state.types import TrendDirection, TrendEpisodeState, TrendPositionResult
from ..d3_boundary_intelligence.types import AnchorEpisode, EconomicBoundaryUnit
from ..runtime_guards.information_state import InfoKind, InfoValue
from .confirmation import make_behavior_confirmation_candidate
from .eligibility import entry_boundary_view, location_eligibility, market_eligibility
from .mechanisms import (
    DeepStructureTakeoverEvidence,
    FalseBreakReclaimEvidence,
    NormalRetestEvidence,
    PlatformReexpansionEvidence,
    TrendEstablishmentWatchEvidence,
    deep_structure_takeover_observation,
    false_break_reclaim_observation,
    normal_retest_observation,
    platform_reexpansion_observation,
    select_primary_observation,
    trend_establishment_watch_observation,
)
from .opportunity import open_or_update_opportunity
from .parameters import FrozenD4Parameters
from .termination import apply_wp4_termination
from .types import (
    D4CutoffView,
    GateEvaluation,
    GateName,
    OpportunityIndependenceEvidence,
    OpportunityMechanism,
    OpportunityState,
    OpportunityTerminationEvidence,
)


@dataclass(frozen=True)
class D4CutoffInput:
    information_cutoff: int
    trend: TrendEpisodeState
    trend_position: TrendPositionResult
    opportunity_direction: TrendDirection
    market_event_id: str
    detector_evidence_ids: tuple[str, ...]
    critical_information_known: InfoValue[bool]
    entry_boundary_unit: EconomicBoundaryUnit | None
    anchor_episodes: Mapping[str, AnchorEpisode]
    parameters: FrozenD4Parameters
    existing_opportunity: OpportunityState | None = None
    independence: OpportunityIndependenceEvidence | None = None
    termination: OpportunityTerminationEvidence = field(default_factory=OpportunityTerminationEvidence)
    normal_retest: NormalRetestEvidence | None = None
    false_break_reclaim: FalseBreakReclaimEvidence | None = None
    platform_reexpansion: PlatformReexpansionEvidence | None = None
    deep_takeover: DeepStructureTakeoverEvidence | None = None
    trend_establishment_watch: TrendEstablishmentWatchEvidence | None = None

    def __post_init__(self) -> None:
        object.__setattr__(self, "anchor_episodes", MappingProxyType(dict(self.anchor_episodes)))
        if not self.market_event_id:
            raise ValueError("market_event_id required")


def _blocked_behavior_from_critical_info(info: InfoValue[bool]) -> GateEvaluation | None:
    if info.kind is InfoKind.ERROR:
        return GateEvaluation(GateName.BEHAVIOR_CONFIRMATION, InfoValue.error(info.error_ref or "CRITICAL_INFO_ERROR"), "SYSTEM_UNCERTAINTY")
    if info.kind is InfoKind.UNKNOWN:
        return GateEvaluation(GateName.BEHAVIOR_CONFIRMATION, InfoValue.unknown(), "SYSTEM_UNCERTAINTY")
    if info.kind is InfoKind.KNOWN and info.value is not True:
        return GateEvaluation(GateName.BEHAVIOR_CONFIRMATION, InfoValue.unknown(), "CRITICAL_INFORMATION_BLOCK")
    return None


def update_011(inp: D4CutoffInput) -> D4CutoffView:
    """Deterministic non-trading D4 reference update. No B8/B7-B work occurs."""
    watch_only_input = inp.trend_establishment_watch is not None and not any(
        (inp.normal_retest, inp.false_break_reclaim, inp.platform_reexpansion, inp.deep_takeover)
    )
    market_gate = market_eligibility(
        inp.trend,
        opportunity_direction=inp.opportunity_direction,
        critical_information_known=inp.critical_information_known,
        watch_only=watch_only_input,
    )
    trend_episode_id = inp.trend.episode_id or (
        inp.existing_opportunity.trend_episode_id if inp.existing_opportunity is not None else "WATCH_ONLY_NO_ACTIVE_EPISODE"
    )
    entry_view = entry_boundary_view(
        inp.entry_boundary_unit,
        inp.anchor_episodes,
        target_trend_episode_id=trend_episode_id,
        target_direction=inp.opportunity_direction,
        information_cutoff=inp.information_cutoff,
    )

    observations = []
    if inp.normal_retest is not None:
        observations.append(
            normal_retest_observation(
                inp.normal_retest,
                direction=inp.opportunity_direction,
                trend_episode_id=trend_episode_id,
                information_cutoff=inp.information_cutoff,
                market_gate=market_gate.result,
                entry_boundary=entry_view,
            )
        )
    if inp.false_break_reclaim is not None:
        observations.append(
            false_break_reclaim_observation(
                inp.false_break_reclaim,
                direction=inp.opportunity_direction,
                trend_episode_id=trend_episode_id,
                information_cutoff=inp.information_cutoff,
                market_gate=market_gate.result,
                entry_boundary=entry_view
            )
        )
    if inp.platform_reexpansion is not None:
        # Enforce the exact frozen theta_progress supplied to the cutoff input.
        pe = PlatformReexpansionEvidence(
            platform=inp.platform_reexpansion.platform,
            current_close=inp.platform_reexpansion.current_close,
            target_trend_episode_id=inp.platform_reexpansion.target_trend_episode_id,
            direction=inp.platform_reexpansion.direction,
            setup_lineage=inp.platform_reexpansion.setup_lineage,
            provenance=inp.platform_reexpansion.provenance,
        )
        observations.append(
            platform_reexpansion_observation(
                pe,
                direction=inp.opportunity_direction,
                trend_episode_id=trend_episode_id,
                information_cutoff=inp.information_cutoff,
                market_gate=market_gate.result,
                entry_boundary=entry_view,
                theta_progress=inp.parameters.theta_progress,
            )
        )
    if inp.deep_takeover is not None:
        observations.append(
            deep_structure_takeover_observation(
                inp.deep_takeover,
                direction=inp.opportunity_direction,
                trend_episode_id=trend_episode_id,
                information_cutoff=inp.information_cutoff,
                market_gate=market_gate.result,
                entry_boundary=entry_view
            )
        )
    if inp.trend_establishment_watch is not None:
        observations.append(trend_establishment_watch_observation(inp.trend_establishment_watch))
    observations_t = tuple(observations)
    primary = select_primary_observation(observations_t)

    if primary is None:
        system_block = _blocked_behavior_from_critical_info(inp.critical_information_known)
        behavior = system_block or GateEvaluation(
            GateName.BEHAVIOR_CONFIRMATION, InfoValue.none(), "NO_ACTIVE_MECHANISM"
        )
        return D4CutoffView(
            information_cutoff=inp.information_cutoff,
            opportunity=inp.existing_opportunity,
            primary_observation=None,
            market_eligibility=market_gate,
            location_eligibility=GateEvaluation(GateName.LOCATION_ELIGIBILITY, InfoValue.none(), "NO_ACTIVE_MECHANISM"),
            behavior_confirmation=behavior,
            confirmation_candidate=None,
        )

    watch_only = primary.mechanism is OpportunityMechanism.TREND_ESTABLISHMENT_WATCH_ONLY
    location_gate = location_eligibility(
        inp.trend_position,
        mechanism_location_qualified=primary.location_qualified,
        watch_only=watch_only,
    )

    opportunity = open_or_update_opportunity(
        existing=inp.existing_opportunity,
        trend_episode_id=trend_episode_id,
        direction=inp.opportunity_direction,
        market_event_id=inp.market_event_id,
        information_cutoff=inp.information_cutoff,
        primary_observation=primary,
        observations=observations_t,
        detector_evidence_ids=inp.detector_evidence_ids,
        entry_boundary=entry_view,
        independence=inp.independence,
    )

    system_block = _blocked_behavior_from_critical_info(inp.critical_information_known)
    if system_block is not None and not watch_only:
        behavior_gate = system_block
        candidate = None
    else:
        behavior_gate = GateEvaluation(
            GateName.BEHAVIOR_CONFIRMATION,
            primary.behavior_confirmation,
            "B7A_MECHANISM_BEHAVIOR_TRUTH",
        )
        opportunity, candidate = make_behavior_confirmation_candidate(
            opportunity, primary, information_cutoff=inp.information_cutoff
        )

    location_failed = location_gate.result.kind is InfoKind.KNOWN and location_gate.result.value is False
    opportunity = apply_wp4_termination(
        opportunity,
        inp.termination,
        information_cutoff=inp.information_cutoff,
        behavior_confirmation_emitted=candidate is not None,
        location_failed_same_cutoff=location_failed,
    )

    return D4CutoffView(
        information_cutoff=inp.information_cutoff,
        opportunity=opportunity,
        primary_observation=primary,
        market_eligibility=market_gate,
        location_eligibility=location_gate,
        behavior_confirmation=behavior_gate,
        confirmation_candidate=candidate,
    )
