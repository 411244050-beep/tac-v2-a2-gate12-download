from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction

from ..parameter_snapshot import ParameterSnapshot, ParameterState


@dataclass(frozen=True)
class FrozenD4Parameters:
    theta_progress: Fraction

    def __post_init__(self) -> None:
        if self.theta_progress < 0:
            raise ValueError("theta_progress must be nonnegative")


def frozen_d4_parameters(snapshot: ParameterSnapshot) -> FrozenD4Parameters:
    slot = snapshot.slot("theta_progress")
    if slot.state is not ParameterState.FROZEN or slot.exact_value is None:
        raise ValueError("theta_progress must be FROZEN with exact value for WP4")
    return FrozenD4Parameters(theta_progress=Fraction(slot.exact_value))
