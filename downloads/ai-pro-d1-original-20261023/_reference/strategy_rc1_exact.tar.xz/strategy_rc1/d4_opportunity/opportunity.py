from __future__ import annotations

from dataclasses import replace

from ..ids import deterministic_id
from .mechanisms import canonical_active_mechanisms
from .types import (
    EntryBoundaryView,
    MechanismObservation,
    OpportunityIndependenceEvidence,
    OpportunityLifecycle,
    OpportunityMechanism,
    OpportunityState,
)


class OpportunityIndependenceBlock(RuntimeError):
    pass


def _lifecycle_from_observation(obs: MechanismObservation) -> OpportunityLifecycle:
    if obs.wait_confirmation or obs.behavior_confirmation.value is True:
        return OpportunityLifecycle.WAIT_CONFIRMATION
    if obs.setup_active:
        return OpportunityLifecycle.SETUP_ACTIVE
    return OpportunityLifecycle.CANDIDATE


def _merge_history(
    prior: tuple[OpportunityMechanism, ...], observations: tuple[MechanismObservation, ...]
) -> tuple[OpportunityMechanism, ...]:
    out = list(prior)
    for mech in canonical_active_mechanisms(observations):
        if mech not in out:
            out.append(mech)
    return tuple(out)


def open_or_update_opportunity(
    *,
    existing: OpportunityState | None,
    trend_episode_id: str,
    direction,
    market_event_id: str,
    information_cutoff: int,
    primary_observation: MechanismObservation,
    observations: tuple[MechanismObservation, ...],
    detector_evidence_ids: tuple[str, ...],
    entry_boundary: EntryBoundaryView | None,
    independence: OpportunityIndependenceEvidence | None,
) -> OpportunityState:
    """Identity follows market-event lineage; detector count never changes the ID."""
    if existing is not None and not existing.terminal:
        if existing.trend_episode_id != trend_episode_id or existing.direction is not direction:
            raise OpportunityIndependenceBlock("ACTIVE_OPPORTUNITY_TREND_LINEAGE_MISMATCH")
        if existing.market_event_id != market_event_id:
            raise OpportunityIndependenceBlock("ACTIVE_OPPORTUNITY_MUST_TERMINATE_BEFORE_NEW_MARKET_EVENT")
        return replace(
            existing,
            lifecycle=_lifecycle_from_observation(primary_observation),
            mechanism_history=_merge_history(existing.mechanism_history, observations),
            primary_mechanism=primary_observation.mechanism,
            entry_boundary_unit_id=(entry_boundary.unit_id if entry_boundary is not None else existing.entry_boundary_unit_id),
            entry_boundary_member_anchor_episode_ids=(
                entry_boundary.member_anchor_episode_ids
                if entry_boundary is not None
                else existing.entry_boundary_member_anchor_episode_ids
            ),
            updated_at=information_cutoff,
            setup_lineage=tuple(dict.fromkeys(existing.setup_lineage + primary_observation.setup_lineage)),
            detector_evidence_ids=tuple(sorted(set(existing.detector_evidence_ids + detector_evidence_ids))),
        )

    if existing is not None and existing.terminal:
        if independence is None or not (
            independence.previous_opportunity_terminated
            and independence.material_trend_side_reseparation_or_control
            and independence.new_independent_countertrend_or_boundary_return_event
        ):
            raise OpportunityIndependenceBlock("NEW_OPPORTUNITY_INDEPENDENCE_NOT_PROVEN")

    oid = deterministic_id("D4-OPPORTUNITY", trend_episode_id, direction.value, market_event_id)
    return OpportunityState(
        opportunity_id=oid,
        trend_episode_id=trend_episode_id,
        direction=direction,
        market_event_id=market_event_id,
        lifecycle=_lifecycle_from_observation(primary_observation),
        mechanism_history=_merge_history((), observations),
        primary_mechanism=primary_observation.mechanism,
        entry_boundary_unit_id=entry_boundary.unit_id if entry_boundary is not None else None,
        entry_boundary_member_anchor_episode_ids=(entry_boundary.member_anchor_episode_ids if entry_boundary is not None else ()),
        created_at=information_cutoff,
        updated_at=information_cutoff,
        setup_lineage=primary_observation.setup_lineage,
        detector_evidence_ids=tuple(sorted(set(detector_evidence_ids))),
        provenance={"identity": "TREND_EPISODE_PLUS_INDEPENDENT_MARKET_EVENT_NOT_DETECTOR_COUNT"},
    )
