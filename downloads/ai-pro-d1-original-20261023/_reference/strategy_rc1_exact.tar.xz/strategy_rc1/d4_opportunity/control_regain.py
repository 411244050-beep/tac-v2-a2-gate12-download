from __future__ import annotations

from ..runtime_guards.information_state import InfoKind, InfoValue
from .types import LocalTrendControlRegainEvidence


def evaluate_local_trend_control_regain(evidence: LocalTrendControlRegainEvidence) -> InfoValue[bool]:
    """Combine the two RC1 D2 structural predicates without inventing a new threshold."""
    left = evidence.countertrend_progression_failed
    right = evidence.material_original_direction_closed_price_recovery

    if left.kind is InfoKind.ERROR:
        return InfoValue.error(left.error_ref or "LOCAL_CONTROL_COUNTERTREND_ERROR")
    if right.kind is InfoKind.ERROR:
        return InfoValue.error(right.error_ref or "LOCAL_CONTROL_RECOVERY_ERROR")
    if left.kind is InfoKind.UNKNOWN or right.kind is InfoKind.UNKNOWN:
        return InfoValue.unknown()
    if left.kind is InfoKind.NA or right.kind is InfoKind.NA:
        return InfoValue.na()
    if left.kind is InfoKind.NONE or right.kind is InfoKind.NONE:
        return InfoValue.none()
    return InfoValue.known(bool(left.value and right.value))
