from __future__ import annotations

from dataclasses import replace

from ..runtime_guards.information_state import InfoKind
from .types import OpportunityLifecycle, OpportunityState, OpportunityTerminationEvidence


def apply_wp4_termination(
    opportunity: OpportunityState,
    evidence: OpportunityTerminationEvidence,
    *,
    information_cutoff: int,
    behavior_confirmation_emitted: bool,
    location_failed_same_cutoff: bool,
) -> OpportunityState:
    """F7 subset safely decidable in WP4; downstream risk truth is not computed here."""
    if opportunity.terminal:
        return opportunity

    invalidation_reason: str | None = None
    if evidence.trend_episode_ended:
        invalidation_reason = "SUPPORTING_TREND_EPISODE_ENDED"
    elif evidence.entry_boundary_terminal_true_break_without_false_break_recovery:
        invalidation_reason = "ENTRY_BOUNDARY_TERMINAL_TRUE_BREAK"
    elif evidence.mechanism_required_structure_materially_failed:
        invalidation_reason = "MECHANISM_REQUIRED_STRUCTURE_FAILED"
    elif evidence.critical_role_or_structure_replaced_destroying_thesis:
        invalidation_reason = "CRITICAL_ROLE_OR_STRUCTURE_REPLACED"
    if invalidation_reason is not None:
        return replace(
            opportunity,
            lifecycle=OpportunityLifecycle.INVALIDATED,
            terminated_at=information_cutoff,
            updated_at=information_cutoff,
            termination_reason=invalidation_reason,
        )

    if evidence.irrecoverable_continuity_end:
        return replace(
            opportunity,
            lifecycle=OpportunityLifecycle.EXPIRED,
            terminated_at=information_cutoff,
            updated_at=information_cutoff,
            termination_reason="IRRECOVERABLE_CANONICAL_CONTINUITY_END",
        )

    consumed_nonactionable = behavior_confirmation_emitted and (
        location_failed_same_cutoff or evidence.other_same_cutoff_non_thesis_gate_failed_after_confirmation
    )
    if consumed_nonactionable and not evidence.independent_open_mechanism_after_consumed_confirmation:
        return replace(
            opportunity,
            lifecycle=OpportunityLifecycle.EXPIRED,
            terminated_at=information_cutoff,
            updated_at=information_cutoff,
            termination_reason="CONFIRMATION_CONSUMED_NONACTIONABLE_SAME_CUTOFF",
        )

    if evidence.event_cycle_completed_and_new_independent_event_rearmed:
        absent = evidence.downstream_actionable_entry_absent
        if absent.kind is InfoKind.KNOWN and absent.value is True:
            return replace(
                opportunity,
                lifecycle=OpportunityLifecycle.EXPIRED,
                terminated_at=information_cutoff,
                updated_at=information_cutoff,
                termination_reason="EVENT_CYCLE_COMPLETED_BEFORE_NEW_INDEPENDENT_EVENT",
            )
        # If the downstream state is not known, fail closed: do not fabricate expiry,
        # and therefore do not permit a new Opportunity yet.
    return opportunity
