from __future__ import annotations

from dataclasses import replace

from ..ids import deterministic_id
from ..runtime_guards.information_state import InfoKind, InfoValue
from .types import BehaviorConfirmationCandidate, MechanismObservation, OpportunityMechanism, OpportunityState


class StaleConfirmationError(RuntimeError):
    pass


def make_behavior_confirmation_candidate(
    opportunity: OpportunityState,
    observation: MechanismObservation,
    *,
    information_cutoff: int,
) -> tuple[OpportunityState, BehaviorConfirmationCandidate | None]:
    if observation.watch_only or observation.mechanism is OpportunityMechanism.TREND_ESTABLISHMENT_WATCH_ONLY:
        return opportunity, None
    if observation.behavior_confirmation.kind is not InfoKind.KNOWN or observation.behavior_confirmation.value is not True:
        return opportunity, None
    if observation.mechanism in opportunity.confirmation_mechanism_history:
        # A same-mechanism Behavior Confirmation is a causal event, not a per-bar predicate.
        # Historical truth may remain visible, but a new B7-A candidate is not re-emitted.
        return opportunity, None
    cid = deterministic_id(
        "D4-B7A-CONFIRMATION",
        opportunity.opportunity_id,
        observation.mechanism.value,
        str(information_cutoff),
        *observation.source_event_ids,
    )
    candidate = BehaviorConfirmationCandidate(
        candidate_id=cid,
        opportunity_id=opportunity.opportunity_id,
        trend_episode_id=opportunity.trend_episode_id,
        direction=opportunity.direction,
        market_event_id=opportunity.market_event_id,
        mechanism=observation.mechanism,
        setup_lineage=observation.setup_lineage,
        entry_boundary_unit_id=opportunity.entry_boundary_unit_id,
        entry_boundary_member_anchor_episode_ids=opportunity.entry_boundary_member_anchor_episode_ids,
        behavior_confirmation=InfoValue.known(True),
        confirmation_cutoff=information_cutoff,
        source_event_ids=observation.source_event_ids,
        provenance={
            "stage": "B7-A_PRE_RISK_ONLY",
            "no_risk_feasibility": "true",
            "no_entry_ready": "true",
        },
    )
    if cid in opportunity.confirmation_candidate_ids:
        return opportunity, candidate
    return replace(
        opportunity,
        confirmation_candidate_ids=opportunity.confirmation_candidate_ids + (cid,),
        confirmation_mechanism_history=opportunity.confirmation_mechanism_history + (observation.mechanism,),
        updated_at=information_cutoff,
    ), candidate


def require_same_cutoff(candidate: BehaviorConfirmationCandidate, information_cutoff: int) -> None:
    if information_cutoff != candidate.confirmation_cutoff:
        raise StaleConfirmationError(
            f"B7A_CONFIRMATION_STALE: candidate cutoff={candidate.confirmation_cutoff}, requested={information_cutoff}"
        )
