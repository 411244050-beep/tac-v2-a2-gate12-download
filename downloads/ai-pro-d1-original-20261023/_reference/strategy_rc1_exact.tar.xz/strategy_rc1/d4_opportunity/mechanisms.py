from __future__ import annotations

from dataclasses import dataclass, field
from fractions import Fraction
from typing import Mapping

from ..d2_market_state.types import PlatformState, PlatformStatus, TrendDirection
from ..d3_boundary_intelligence.types import BreakState, InteractionControl, InteractionEvent, RoleTransition
from ..runtime_guards.information_state import InfoKind, InfoValue
from .control_regain import evaluate_local_trend_control_regain
from .types import (
    EntryBoundaryView,
    LocalTrendControlRegainEvidence,
    MechanismObservation,
    OpportunityMechanism,
)


@dataclass(frozen=True)
class NormalRetestEvidence:
    interaction: InteractionEvent
    qualifying_retest_or_probe: bool
    adverse_structural_reference_fixed: bool
    local_control_regain: LocalTrendControlRegainEvidence | None
    setup_lineage: tuple[str, ...]
    provenance: Mapping[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class FalseBreakReclaimEvidence:
    interaction: InteractionEvent
    setup_lineage: tuple[str, ...]
    provenance: Mapping[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class PlatformReexpansionEvidence:
    platform: PlatformState
    current_close: Fraction
    target_trend_episode_id: str
    direction: TrendDirection
    setup_lineage: tuple[str, ...]
    provenance: Mapping[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class DeepStructureTakeoverEvidence:
    shallow_operating_defense_no_longer_completes_setup: bool
    deeper_boundary_independent: bool
    deeper_interaction: InteractionEvent | None
    local_control_regain: LocalTrendControlRegainEvidence | None
    role_transition: RoleTransition
    promotion_confirmed_at: int | None
    setup_lineage: tuple[str, ...]
    provenance: Mapping[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class TrendEstablishmentWatchEvidence:
    observed: bool
    setup_lineage: tuple[str, ...]
    source_event_ids: tuple[str, ...]
    provenance: Mapping[str, str] = field(default_factory=dict)


def _market_pass(value: InfoValue[bool]) -> bool:
    return value.kind is InfoKind.KNOWN and value.value is True


def _validate_interaction_lineage(
    event: InteractionEvent,
    *,
    direction: TrendDirection,
    trend_episode_id: str,
    information_cutoff: int,
) -> None:
    if event.target_direction is not direction or event.target_trend_episode_id != trend_episode_id:
        raise ValueError("D4_INTERACTION_LINEAGE_MISMATCH")
    for value in (event.started_at, event.armed_at, event.approach_lineage_started_at, event.resolved_at):
        if value is not None and value > information_cutoff:
            raise ValueError("D4_CANNOT_CONSUME_FUTURE_INTERACTION_STATE")


def _current_or_historical_regain(
    evidence: LocalTrendControlRegainEvidence | None,
    *,
    direction: TrendDirection,
    information_cutoff: int,
    emit_only_if_current: bool,
) -> InfoValue[bool]:
    if evidence is None:
        return InfoValue.none()
    if evidence.direction is not direction:
        raise ValueError("D4_LOCAL_CONTROL_DIRECTION_MISMATCH")
    if evidence.confirmation_cutoff > information_cutoff:
        raise ValueError("D4_CANNOT_CONSUME_FUTURE_LOCAL_CONTROL_REGAIN")
    value = evaluate_local_trend_control_regain(evidence)
    if emit_only_if_current and evidence.confirmation_cutoff < information_cutoff and value.kind is InfoKind.KNOWN and value.value is True:
        return InfoValue.none()
    return value


def normal_retest_observation(
    evidence: NormalRetestEvidence,
    *,
    direction: TrendDirection,
    trend_episode_id: str,
    information_cutoff: int,
    market_gate: InfoValue[bool],
    entry_boundary: EntryBoundaryView | None,
) -> MechanismObservation:
    valid_boundary = entry_boundary is not None and entry_boundary.valid_active
    event = evidence.interaction
    _validate_interaction_lineage(
        event, direction=direction, trend_episode_id=trend_episode_id, information_cutoff=information_cutoff
    )
    qualifying_lineage = (
        event.control in (InteractionControl.ARMED, InteractionControl.INTERACTION_ACTIVE, InteractionControl.RESOLVED)
        and event.approach_lineage_started_at is not None
        and event.break_state in (BreakState.NONE, BreakState.PROBE)
    )
    candidate = _market_pass(market_gate) and valid_boundary and qualifying_lineage
    setup = candidate and evidence.qualifying_retest_or_probe
    regain = InfoValue.none()
    if setup and evidence.adverse_structural_reference_fixed:
        regain = _current_or_historical_regain(
            evidence.local_control_regain,
            direction=direction,
            information_cutoff=information_cutoff,
            emit_only_if_current=True,
        )
    wait = setup and evidence.adverse_structural_reference_fixed and not (
        regain.kind is InfoKind.KNOWN and regain.value is True
    )
    return MechanismObservation(
        mechanism=OpportunityMechanism.NORMAL_RETEST_CONTINUATION,
        candidate=candidate,
        setup_active=setup,
        wait_confirmation=wait,
        behavior_confirmation=regain,
        location_qualified=InfoValue.known(valid_boundary and setup),
        setup_lineage=evidence.setup_lineage,
        source_event_ids=(event.event_id,),
        provenance={**dict(evidence.provenance), "semantic": "RETEST_OR_PROBE_PLUS_LOCAL_CONTROL_REGAIN"},
    )


def false_break_reclaim_observation(
    evidence: FalseBreakReclaimEvidence,
    *,
    direction: TrendDirection,
    trend_episode_id: str,
    information_cutoff: int,
    market_gate: InfoValue[bool],
    entry_boundary: EntryBoundaryView | None,
) -> MechanismObservation:
    valid_boundary = entry_boundary is not None and entry_boundary.valid_active
    _validate_interaction_lineage(
        evidence.interaction, direction=direction, trend_episode_id=trend_episode_id, information_cutoff=information_cutoff
    )
    state = evidence.interaction.break_state
    candidate_state = state in (BreakState.TEMPORARY_BREAK, BreakState.RECLAIMING, BreakState.FALSE_BREAK)
    candidate = _market_pass(market_gate) and valid_boundary and candidate_state
    setup = candidate and state in (BreakState.RECLAIMING, BreakState.FALSE_BREAK)
    confirmed = (
        setup
        and state is BreakState.FALSE_BREAK
        and evidence.interaction.resolved_at == information_cutoff
    )
    behavior = InfoValue.known(True) if confirmed else InfoValue.none()
    wait = setup and not confirmed
    return MechanismObservation(
        mechanism=OpportunityMechanism.FALSE_BREAK_RECLAIM,
        candidate=candidate,
        setup_active=setup,
        wait_confirmation=wait,
        behavior_confirmation=behavior,
        location_qualified=InfoValue.known(valid_boundary and setup),
        setup_lineage=evidence.setup_lineage,
        source_event_ids=(evidence.interaction.event_id,),
        provenance={**dict(evidence.provenance), "semantic": "B4_FALSE_BREAK_ONLY; PROBE_ALONE_NEVER_CONFIRMS"},
    )


def platform_reexpansion_observation(
    evidence: PlatformReexpansionEvidence,
    *,
    direction: TrendDirection,
    trend_episode_id: str,
    information_cutoff: int,
    market_gate: InfoValue[bool],
    entry_boundary: EntryBoundaryView | None,
    theta_progress: Fraction,
) -> MechanismObservation:
    valid_boundary = entry_boundary is not None and entry_boundary.valid_active
    if evidence.direction is not direction or evidence.target_trend_episode_id != trend_episode_id:
        raise ValueError("D4_PLATFORM_LINEAGE_MISMATCH")
    state = evidence.platform
    if state.confirmed_at is not None and state.confirmed_at > information_cutoff:
        raise ValueError("D4_CANNOT_CONSUME_FUTURE_PLATFORM_STATE")
    candidate = _market_pass(market_gate) and state.status in (
        PlatformStatus.PLATFORM_CANDIDATE,
        PlatformStatus.PLATFORM_CONFIRMED,
    )
    setup = candidate and state.status is PlatformStatus.PLATFORM_CONFIRMED and valid_boundary
    behavior: InfoValue[bool] = InfoValue.none()
    if setup:
        if state.platform_cap_price is None or state.platform_scale is None:
            behavior = InfoValue.error("PLATFORM_CONFIRMED_MISSING_FROZEN_CAP_OR_SCALE")
        elif direction is TrendDirection.LONG:
            behavior = InfoValue.known(
                evidence.current_close > state.platform_cap_price + theta_progress * state.platform_scale
            )
        elif direction is TrendDirection.SHORT:
            behavior = InfoValue.known(
                evidence.current_close < state.platform_cap_price - theta_progress * state.platform_scale
            )
        else:
            behavior = InfoValue.na()
    wait = setup and not (behavior.kind is InfoKind.KNOWN and behavior.value is True)
    return MechanismObservation(
        mechanism=OpportunityMechanism.PLATFORM_REEXPANSION,
        candidate=candidate,
        setup_active=setup,
        wait_confirmation=wait,
        behavior_confirmation=behavior,
        location_qualified=InfoValue.known(valid_boundary and setup),
        setup_lineage=evidence.setup_lineage,
        source_event_ids=tuple(state.contributing_event_ids),
        provenance={**dict(evidence.provenance), "semantic": "FROZEN_PLATFORM_CAP_STRICT_ESCAPE"},
    )


def deep_structure_takeover_observation(
    evidence: DeepStructureTakeoverEvidence,
    *,
    direction: TrendDirection,
    trend_episode_id: str,
    information_cutoff: int,
    market_gate: InfoValue[bool],
    entry_boundary: EntryBoundaryView | None,
) -> MechanismObservation:
    valid_boundary = entry_boundary is not None and entry_boundary.valid_active
    if evidence.deeper_interaction is not None:
        _validate_interaction_lineage(
            evidence.deeper_interaction,
            direction=direction,
            trend_episode_id=trend_episode_id,
            information_cutoff=information_cutoff,
        )
    interaction_active = evidence.deeper_interaction is not None and evidence.deeper_interaction.control in (
        InteractionControl.ARMED,
        InteractionControl.INTERACTION_ACTIVE,
        InteractionControl.RESOLVED,
    )
    candidate = (
        _market_pass(market_gate)
        and valid_boundary
        and evidence.shallow_operating_defense_no_longer_completes_setup
        and evidence.deeper_boundary_independent
    )
    setup = candidate and interaction_active
    regain: InfoValue[bool] = InfoValue.none()
    if setup:
        regain = _current_or_historical_regain(
            evidence.local_control_regain,
            direction=direction,
            information_cutoff=information_cutoff,
            emit_only_if_current=False,
        )
    if evidence.promotion_confirmed_at is not None and evidence.promotion_confirmed_at > information_cutoff:
        raise ValueError("D4_CANNOT_CONSUME_FUTURE_PROMOTION")
    promotion = evidence.role_transition is RoleTransition.PROMOTION and evidence.promotion_confirmed_at is not None
    latest_required_cutoff = max(
        evidence.local_control_regain.confirmation_cutoff if evidence.local_control_regain is not None else -1,
        evidence.promotion_confirmed_at if evidence.promotion_confirmed_at is not None else -1,
    )
    if regain.kind is InfoKind.ERROR:
        behavior = regain
    elif regain.kind is InfoKind.UNKNOWN:
        behavior = InfoValue.unknown()
    elif regain.kind is InfoKind.NA:
        behavior = InfoValue.na()
    elif regain.kind is InfoKind.NONE:
        behavior = InfoValue.none()
    else:
        passed = bool(regain.value and promotion)
        behavior = InfoValue.known(True) if passed and latest_required_cutoff == information_cutoff else (InfoValue.none() if passed else InfoValue.known(False))
    wait = setup and not (behavior.kind is InfoKind.KNOWN and behavior.value is True)
    event_ids = () if evidence.deeper_interaction is None else (evidence.deeper_interaction.event_id,)
    return MechanismObservation(
        mechanism=OpportunityMechanism.DEEP_STRUCTURE_TAKEOVER,
        candidate=candidate,
        setup_active=setup,
        wait_confirmation=wait,
        behavior_confirmation=behavior,
        location_qualified=InfoValue.known(valid_boundary and setup),
        setup_lineage=evidence.setup_lineage,
        source_event_ids=event_ids,
        provenance={**dict(evidence.provenance), "semantic": "LOCAL_CONTROL_REGAIN_AND_B5_PROMOTION"},
    )


def trend_establishment_watch_observation(evidence: TrendEstablishmentWatchEvidence) -> MechanismObservation:
    return MechanismObservation(
        mechanism=OpportunityMechanism.TREND_ESTABLISHMENT_WATCH_ONLY,
        candidate=evidence.observed,
        setup_active=False,
        wait_confirmation=False,
        behavior_confirmation=InfoValue.na(),
        location_qualified=InfoValue.na(),
        setup_lineage=evidence.setup_lineage,
        source_event_ids=evidence.source_event_ids,
        watch_only=True,
        provenance={**dict(evidence.provenance), "semantic": "WATCH_ONLY_NEVER_EXECUTABLE"},
    )


_EXECUTABLE_PRECEDENCE = (
    OpportunityMechanism.DEEP_STRUCTURE_TAKEOVER,
    OpportunityMechanism.PLATFORM_REEXPANSION,
    OpportunityMechanism.FALSE_BREAK_RECLAIM,
    OpportunityMechanism.NORMAL_RETEST_CONTINUATION,
)


def select_primary_observation(observations: tuple[MechanismObservation, ...]) -> MechanismObservation | None:
    active = [o for o in observations if o.active]
    if not active:
        return None
    by_mech = {o.mechanism: o for o in active}
    deep = by_mech.get(OpportunityMechanism.DEEP_STRUCTURE_TAKEOVER)
    if deep is not None and deep.setup_active:
        return deep
    if OpportunityMechanism.PLATFORM_REEXPANSION in by_mech and by_mech[
        OpportunityMechanism.PLATFORM_REEXPANSION
    ].setup_active:
        return by_mech[OpportunityMechanism.PLATFORM_REEXPANSION]
    fbr = by_mech.get(OpportunityMechanism.FALSE_BREAK_RECLAIM)
    normal = by_mech.get(OpportunityMechanism.NORMAL_RETEST_CONTINUATION)
    if fbr is not None and fbr.behavior_confirmation.kind is InfoKind.KNOWN and fbr.behavior_confirmation.value is True:
        return fbr
    if normal is not None:
        return normal
    if fbr is not None:
        return fbr
    platform = by_mech.get(OpportunityMechanism.PLATFORM_REEXPANSION)
    if platform is not None:
        return platform
    if deep is not None:
        return deep
    watch = by_mech.get(OpportunityMechanism.TREND_ESTABLISHMENT_WATCH_ONLY)
    return watch


def canonical_active_mechanisms(observations: tuple[MechanismObservation, ...]) -> tuple[OpportunityMechanism, ...]:
    active = {o.mechanism for o in observations if o.active}
    order = (
        OpportunityMechanism.NORMAL_RETEST_CONTINUATION,
        OpportunityMechanism.FALSE_BREAK_RECLAIM,
        OpportunityMechanism.PLATFORM_REEXPANSION,
        OpportunityMechanism.DEEP_STRUCTURE_TAKEOVER,
        OpportunityMechanism.TREND_ESTABLISHMENT_WATCH_ONLY,
    )
    return tuple(m for m in order if m in active)
