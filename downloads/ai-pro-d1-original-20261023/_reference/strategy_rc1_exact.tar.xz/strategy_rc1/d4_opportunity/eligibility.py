from __future__ import annotations

from collections.abc import Mapping

from ..d2_market_state.types import TrendDirection, TrendEpisodeState, TrendIntegrity, TrendPosition, TrendPositionResult
from ..d3_boundary_intelligence.types import AnchorActivity, AnchorEpisode, AnchorValidity, EconomicBoundaryUnit
from ..runtime_guards.information_state import InfoKind, InfoValue
from .types import EntryBoundaryView, GateEvaluation, GateName


def _propagate_nonknown_bool(value: InfoValue[bool]) -> InfoValue[bool]:
    if value.kind is InfoKind.ERROR:
        return InfoValue.error(value.error_ref or "D4_GATE_INPUT_ERROR")
    if value.kind is InfoKind.UNKNOWN:
        return InfoValue.unknown()
    if value.kind is InfoKind.NA:
        return InfoValue.na()
    if value.kind is InfoKind.NONE:
        return InfoValue.none()
    return value


def market_eligibility(
    trend: TrendEpisodeState,
    *,
    opportunity_direction: TrendDirection,
    critical_information_known: InfoValue[bool],
    watch_only: bool = False,
) -> GateEvaluation:
    if watch_only:
        return GateEvaluation(GateName.MARKET_ELIGIBILITY, InfoValue.na(), "TREND_ESTABLISHMENT_WATCH_ONLY")
    info = _propagate_nonknown_bool(critical_information_known)
    if info.kind is not InfoKind.KNOWN:
        return GateEvaluation(GateName.MARKET_ELIGIBILITY, info, "CRITICAL_INFORMATION_NOT_KNOWN")
    if info.value is not True:
        return GateEvaluation(GateName.MARKET_ELIGIBILITY, InfoValue.known(False), "CRITICAL_INFORMATION_BLOCK")
    if trend.direction not in (TrendDirection.LONG, TrendDirection.SHORT) or trend.episode_id is None:
        return GateEvaluation(GateName.MARKET_ELIGIBILITY, InfoValue.known(False), "NO_ACTIVE_TREND_EPISODE")
    if trend.direction is not opportunity_direction:
        return GateEvaluation(GateName.MARKET_ELIGIBILITY, InfoValue.known(False), "TREND_DIRECTION_MISMATCH")
    if trend.integrity in (TrendIntegrity.DETERIORATING, TrendIntegrity.FAILED):
        return GateEvaluation(GateName.MARKET_ELIGIBILITY, InfoValue.known(False), f"TREND_INTEGRITY_{trend.integrity.value}")
    if trend.integrity in (TrendIntegrity.HEALTHY, TrendIntegrity.PRESSURED):
        return GateEvaluation(GateName.MARKET_ELIGIBILITY, InfoValue.known(True), "ACTIVE_MATCHING_TREND_ELIGIBLE")
    return GateEvaluation(GateName.MARKET_ELIGIBILITY, InfoValue.unknown(), "TREND_INTEGRITY_UNKNOWN")


def location_eligibility(
    trend_position: TrendPositionResult,
    *,
    mechanism_location_qualified: InfoValue[bool],
    watch_only: bool = False,
) -> GateEvaluation:
    if watch_only:
        return GateEvaluation(GateName.LOCATION_ELIGIBILITY, InfoValue.na(), "TREND_ESTABLISHMENT_WATCH_ONLY")
    if trend_position.position is TrendPosition.OVEREXTENDED:
        return GateEvaluation(GateName.LOCATION_ELIGIBILITY, InfoValue.known(False), "OVEREXTENDED")
    value = _propagate_nonknown_bool(mechanism_location_qualified)
    if value.kind is InfoKind.KNOWN:
        return GateEvaluation(
            GateName.LOCATION_ELIGIBILITY,
            value,
            "MECHANISM_LOCATION_QUALIFIED" if value.value else "MECHANISM_LOCATION_NOT_QUALIFIED",
        )
    return GateEvaluation(GateName.LOCATION_ELIGIBILITY, value, "MECHANISM_LOCATION_UNRESOLVED")


def entry_boundary_view(
    unit: EconomicBoundaryUnit | None,
    episodes: Mapping[str, AnchorEpisode],
    *,
    target_trend_episode_id: str,
    target_direction: TrendDirection,
    information_cutoff: int,
) -> EntryBoundaryView | None:
    if unit is None:
        return None
    members = tuple(unit.anchor_episode_ids)
    if any(z.information_cutoff > information_cutoff for z in unit.contact_zones):
        raise ValueError("D4_CANNOT_CONSUME_FUTURE_BOUNDARY_UNIT_GEOMETRY")
    valid_members: list[AnchorEpisode] = []
    for aid in members:
        ep = episodes.get(aid)
        if ep is None:
            continue
        if ep.started_at > information_cutoff or (ep.ended_at is not None and ep.ended_at > information_cutoff):
            raise ValueError("D4_CANNOT_CONSUME_FUTURE_ANCHOR_EPISODE_STATE")
        if ep.target_trend_episode_id != target_trend_episode_id or ep.target_direction is not target_direction:
            continue
        if (
            ep.validity is AnchorValidity.VALID
            and ep.activity in (AnchorActivity.ACTIVE, AnchorActivity.PRESSURED)
            and not ep.terminal_true_break
            and ep.ended_at is None
        ):
            valid_members.append(ep)
    return EntryBoundaryView(
        unit_id=unit.unit_id,
        member_anchor_episode_ids=members,
        valid_active=bool(valid_members),
        target_trend_episode_id=target_trend_episode_id,
        target_direction=target_direction,
        provenance={
            "unit_semantics": "D3_ECONOMIC_BOUNDARY_UNIT",
            "member_selection": "NO_MEMBER_WINNER_INVENTED",
            "valid_active_member_count": str(len(valid_members)),
        },
    )
