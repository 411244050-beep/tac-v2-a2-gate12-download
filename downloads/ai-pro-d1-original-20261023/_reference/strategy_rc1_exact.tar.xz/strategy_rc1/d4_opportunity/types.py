from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from fractions import Fraction
from typing import Mapping

from ..d2_market_state.types import TrendDirection
from ..runtime_guards.information_state import InfoValue


class OpportunityLifecycle(str, Enum):
    """WP4-owned lifecycle subset only.

    ENTRY_READY / EXECUTED deliberately do not exist in this WP4 enum because
    B7-B and execution are outside the authorized stage.
    """

    CANDIDATE = "CANDIDATE"
    SETUP_ACTIVE = "SETUP_ACTIVE"
    WAIT_CONFIRMATION = "WAIT_CONFIRMATION"
    INVALIDATED = "INVALIDATED"
    EXPIRED = "EXPIRED"


class OpportunityMechanism(str, Enum):
    NORMAL_RETEST_CONTINUATION = "NORMAL_RETEST_CONTINUATION"
    FALSE_BREAK_RECLAIM = "FALSE_BREAK_RECLAIM"
    PLATFORM_REEXPANSION = "PLATFORM_REEXPANSION"
    DEEP_STRUCTURE_TAKEOVER = "DEEP_STRUCTURE_TAKEOVER"
    TREND_ESTABLISHMENT_WATCH_ONLY = "TREND_ESTABLISHMENT_WATCH_ONLY"


class GateName(str, Enum):
    MARKET_ELIGIBILITY = "MARKET_ELIGIBILITY"
    LOCATION_ELIGIBILITY = "LOCATION_ELIGIBILITY"
    BEHAVIOR_CONFIRMATION = "BEHAVIOR_CONFIRMATION"


@dataclass(frozen=True)
class GateEvaluation:
    gate: GateName
    result: InfoValue[bool]
    reason: str


@dataclass(frozen=True)
class EntryBoundaryView:
    unit_id: str
    member_anchor_episode_ids: tuple[str, ...]
    valid_active: bool
    target_trend_episode_id: str
    target_direction: TrendDirection
    provenance: Mapping[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class LocalTrendControlRegainEvidence:
    """Causal D2 evidence interface consumed by D4.

    RC1 defines the semantic sequence but does not introduce another numeric
    threshold for the final material closed-price recovery. WP4 therefore does
    not invent one. The two semantic predicates below must be supplied from
    already-authoritative D2 price-structure evidence/provenance.
    """

    direction: TrendDirection
    adverse_reference_pivot_id: str
    adverse_reference_confirmed_at: int
    recovery_pivot_id: str
    recovery_pivot_confirmed_at: int
    countertrend_progression_failed: InfoValue[bool]
    material_original_direction_closed_price_recovery: InfoValue[bool]
    confirmation_cutoff: int
    provenance: Mapping[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.direction not in (TrendDirection.LONG, TrendDirection.SHORT):
            raise ValueError("Local Trend-Control Regain requires LONG/SHORT")
        if not self.adverse_reference_pivot_id or not self.recovery_pivot_id:
            raise ValueError("Local Trend-Control Regain requires causal pivot references")
        if self.adverse_reference_confirmed_at > self.confirmation_cutoff:
            raise ValueError("future adverse reference cannot be consumed")
        if self.recovery_pivot_confirmed_at > self.confirmation_cutoff:
            raise ValueError("future recovery pivot cannot be consumed")
        if self.recovery_pivot_confirmed_at < self.adverse_reference_confirmed_at:
            raise ValueError("recovery pivot cannot predate adverse reference confirmation")


@dataclass(frozen=True)
class MechanismObservation:
    mechanism: OpportunityMechanism
    candidate: bool
    setup_active: bool
    wait_confirmation: bool
    behavior_confirmation: InfoValue[bool]
    location_qualified: InfoValue[bool]
    setup_lineage: tuple[str, ...]
    source_event_ids: tuple[str, ...]
    watch_only: bool = False
    provenance: Mapping[str, str] = field(default_factory=dict)

    @property
    def active(self) -> bool:
        return self.candidate or self.setup_active or self.wait_confirmation or (
            self.behavior_confirmation.value is True
        )


@dataclass(frozen=True)
class OpportunityState:
    opportunity_id: str
    trend_episode_id: str
    direction: TrendDirection
    market_event_id: str
    lifecycle: OpportunityLifecycle
    mechanism_history: tuple[OpportunityMechanism, ...]
    primary_mechanism: OpportunityMechanism
    entry_boundary_unit_id: str | None
    entry_boundary_member_anchor_episode_ids: tuple[str, ...]
    created_at: int
    updated_at: int
    setup_lineage: tuple[str, ...]
    detector_evidence_ids: tuple[str, ...]
    confirmation_candidate_ids: tuple[str, ...] = ()
    confirmation_mechanism_history: tuple[OpportunityMechanism, ...] = ()
    terminated_at: int | None = None
    termination_reason: str | None = None
    provenance: Mapping[str, str] = field(default_factory=dict)

    @property
    def terminal(self) -> bool:
        return self.lifecycle in (OpportunityLifecycle.INVALIDATED, OpportunityLifecycle.EXPIRED)


@dataclass(frozen=True)
class BehaviorConfirmationCandidate:
    """B7-A pre-risk confirmation candidate only; never ENTRY_READY."""

    candidate_id: str
    opportunity_id: str
    trend_episode_id: str
    direction: TrendDirection
    market_event_id: str
    mechanism: OpportunityMechanism
    setup_lineage: tuple[str, ...]
    entry_boundary_unit_id: str | None
    entry_boundary_member_anchor_episode_ids: tuple[str, ...]
    behavior_confirmation: InfoValue[bool]
    confirmation_cutoff: int
    source_event_ids: tuple[str, ...]
    same_cutoff_only: bool = True
    provenance: Mapping[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class OpportunityIndependenceEvidence:
    previous_opportunity_terminated: bool
    material_trend_side_reseparation_or_control: bool
    new_independent_countertrend_or_boundary_return_event: bool
    provenance: Mapping[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class OpportunityTerminationEvidence:
    trend_episode_ended: bool = False
    entry_boundary_terminal_true_break_without_false_break_recovery: bool = False
    mechanism_required_structure_materially_failed: bool = False
    critical_role_or_structure_replaced_destroying_thesis: bool = False
    irrecoverable_continuity_end: bool = False
    event_cycle_completed_and_new_independent_event_rearmed: bool = False
    downstream_actionable_entry_absent: InfoValue[bool] = field(default_factory=InfoValue.unknown)
    other_same_cutoff_non_thesis_gate_failed_after_confirmation: bool = False
    independent_open_mechanism_after_consumed_confirmation: bool = False
    provenance: Mapping[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class D4CutoffView:
    information_cutoff: int
    opportunity: OpportunityState | None
    primary_observation: MechanismObservation | None
    market_eligibility: GateEvaluation
    location_eligibility: GateEvaluation
    behavior_confirmation: GateEvaluation
    confirmation_candidate: BehaviorConfirmationCandidate | None
    update_step: str = "UPDATE-011"
