"""WP4 owns UPDATE-011 only.

It may consume immutable D2/D3 state but cannot write Price Structure, Trend,
Anchor, Interaction, Break, Roles, Risk, Position, Exit, or Execution truth.
"""

D4_OWNED_UPDATE_STEPS = ("UPDATE-011",)
D4_CONSUMES = (
    "D2_PRICE_STRUCTURE_TREND_POSITION_PLATFORM",
    "D3_ANCHOR_INTERACTION_BREAK_ROLES",
)
D4_FORBIDDEN_WRITES = (
    "PRICE_STRUCTURE",
    "MARKET_TREND",
    "ANCHOR_INTERACTION_BREAK_ROLES",
    "RISK_FEASIBILITY",
    "ENTRY_READY",
    "POSITION",
    "EXIT",
    "EXECUTION",
)
