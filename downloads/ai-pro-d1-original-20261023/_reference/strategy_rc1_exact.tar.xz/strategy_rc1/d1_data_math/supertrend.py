from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction

from ..result_types import Direction
from ..runtime_guards.information_state import InfoKind, InfoValue
from .ohlc_protocol import OHLCBar

ST_MULTIPLIER = Fraction(3, 1)


@dataclass(frozen=True)
class SupertrendPoint:
    final_upper: InfoValue[Fraction]
    final_lower: InfoValue[Fraction]
    direction: Direction
    active_line: InfoValue[Fraction]


class SupertrendRecurrence:
    """RC1 + adopted post-RC1 exact final-band recurrence binding."""

    def __init__(self) -> None:
        self._segment_id: str | None = None
        self._prev_close: Fraction | None = None
        self._final_upper: Fraction | None = None
        self._final_lower: Fraction | None = None
        self._direction = Direction.UNKNOWN

    def reset(self) -> None:
        self._prev_close = None
        self._final_upper = None
        self._final_lower = None
        self._direction = Direction.UNKNOWN

    def update(
        self,
        bar: OHLCBar,
        atr14: InfoValue[Fraction],
        *,
        segment_id: str,
    ) -> SupertrendPoint:
        if self._segment_id != segment_id:
            self._segment_id = segment_id
            self.reset()

        if atr14.kind is not InfoKind.KNOWN:
            self._prev_close = bar.close
            return SupertrendPoint(
                final_upper=InfoValue.na(),
                final_lower=InfoValue.na(),
                direction=Direction.UNKNOWN,
                active_line=InfoValue.na(),
            )

        atr = atr14.require_known()
        hl2 = (bar.high + bar.low) / 2
        basic_upper = hl2 + ST_MULTIPLIER * atr
        basic_lower = hl2 - ST_MULTIPLIER * atr

        if self._final_upper is None or self._final_lower is None or self._prev_close is None:
            self._final_upper = basic_upper
            self._final_lower = basic_lower
            self._direction = Direction.UNKNOWN
            self._prev_close = bar.close
            return SupertrendPoint(
                final_upper=InfoValue.known(self._final_upper),
                final_lower=InfoValue.known(self._final_lower),
                direction=self._direction,
                active_line=InfoValue.na(),
            )

        prior_upper = self._final_upper
        prior_lower = self._final_lower
        prior_close = self._prev_close

        final_lower = basic_lower if (basic_lower > prior_lower or prior_close < prior_lower) else prior_lower
        final_upper = basic_upper if (basic_upper < prior_upper or prior_close > prior_upper) else prior_upper

        if bar.close > prior_upper:
            direction = Direction.UP
        elif bar.close < prior_lower:
            direction = Direction.DOWN
        else:
            direction = self._direction

        self._final_upper = final_upper
        self._final_lower = final_lower
        self._direction = direction
        self._prev_close = bar.close

        if direction is Direction.UP:
            active = InfoValue.known(final_lower)
        elif direction is Direction.DOWN:
            active = InfoValue.known(final_upper)
        else:
            active = InfoValue.na()

        return SupertrendPoint(
            final_upper=InfoValue.known(final_upper),
            final_lower=InfoValue.known(final_lower),
            direction=direction,
            active_line=active,
        )
