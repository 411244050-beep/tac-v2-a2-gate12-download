from __future__ import annotations

from fractions import Fraction
from typing import Protocol


class OHLCBar(Protocol):
    open_time: int
    close_time: int
    open: Fraction
    high: Fraction
    low: Fraction
    close: Fraction
