from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from fractions import Fraction
from typing import Iterable

from .canonical import CanonicalRecord, TF_15M_MS


@dataclass(frozen=True)
class HTFBar:
    symbol: str
    timeframe_ms: int
    open_time: int
    close_time: int
    open: Fraction
    high: Fraction
    low: Fraction
    close: Fraction
    base_volume: Fraction | None
    quote_volume: Fraction | None
    source_segment_id: str


def _sum_optional(values: list[Fraction | None]) -> Fraction | None:
    if any(v is None for v in values):
        return None
    return sum((v for v in values if v is not None), Fraction(0, 1))


def aggregate_completed_htf(
    records: Iterable[CanonicalRecord],
    *,
    timeframe_ms: int,
    information_cutoff: int,
) -> tuple[HTFBar, ...]:
    if timeframe_ms not in (60 * 60 * 1000, 4 * 60 * 60 * 1000):
        raise ValueError("Only causal 1H and 4H aggregation is authorized in WP1")
    required = timeframe_ms // TF_15M_MS

    buckets: dict[tuple[str, int], list[CanonicalRecord]] = defaultdict(list)
    for rec in records:
        bucket_start = (rec.bar.open_time // timeframe_ms) * timeframe_ms
        buckets[(rec.canonical_segment_id, bucket_start)].append(rec)

    out: list[HTFBar] = []
    for (segment_id, bucket_start), members in sorted(buckets.items(), key=lambda kv: kv[0][1]):
        members.sort(key=lambda r: r.bar.open_time)
        expected_opens = [bucket_start + i * TF_15M_MS for i in range(required)]
        actual_opens = [r.bar.open_time for r in members]
        if actual_opens != expected_opens:
            continue  # partial/incomplete bucket never enters Strategy
        if len({r.canonical_segment_id for r in members}) != 1:
            continue
        close_time = members[-1].bar.close_time
        if close_time > information_cutoff:
            continue
        first, last = members[0].bar, members[-1].bar
        out.append(
            HTFBar(
                symbol=first.symbol,
                timeframe_ms=timeframe_ms,
                open_time=bucket_start,
                close_time=close_time,
                open=first.open,
                high=max(r.bar.high for r in members),
                low=min(r.bar.low for r in members),
                close=last.close,
                base_volume=_sum_optional([r.bar.base_volume for r in members]),
                quote_volume=_sum_optional([r.bar.quote_volume for r in members]),
                source_segment_id=segment_id,
            )
        )
    return tuple(out)
