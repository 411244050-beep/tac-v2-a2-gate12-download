from __future__ import annotations

from fractions import Fraction

from ..runtime_guards.information_state import InfoValue


class EMARecurrence:
    def __init__(self, period: int) -> None:
        if period <= 0:
            raise ValueError("EMA period must be positive")
        self.period = period
        self._segment_id: str | None = None
        self._seed: list[Fraction] = []
        self._ema: Fraction | None = None
        self._alpha = Fraction(2, period + 1)

    def reset(self) -> None:
        self._seed.clear()
        self._ema = None

    def update(self, close: Fraction, *, segment_id: str) -> InfoValue[Fraction]:
        if self._segment_id != segment_id:
            self._segment_id = segment_id
            self.reset()

        if self._ema is None:
            self._seed.append(close)
            if len(self._seed) < self.period:
                return InfoValue.na()
            if len(self._seed) == self.period:
                self._ema = sum(self._seed, Fraction(0, 1)) / self.period
                return InfoValue.known(self._ema)
            raise AssertionError("EMA seed length invariant broken")

        self._ema = self._alpha * close + (1 - self._alpha) * self._ema
        return InfoValue.known(self._ema)
