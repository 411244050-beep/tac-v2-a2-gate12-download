from __future__ import annotations

from fractions import Fraction

from ..runtime_guards.information_state import InfoValue
from .ohlc_protocol import OHLCBar


class ATR14Recurrence:
    period = 14

    def __init__(self) -> None:
        self._segment_id: str | None = None
        self._prev_close: Fraction | None = None
        self._trs: list[Fraction] = []
        self._atr: Fraction | None = None

    def reset(self) -> None:
        self._prev_close = None
        self._trs.clear()
        self._atr = None

    def update(self, bar: OHLCBar, *, segment_id: str) -> InfoValue[Fraction]:
        if self._segment_id != segment_id:
            self._segment_id = segment_id
            self.reset()

        if self._prev_close is None:
            tr = bar.high - bar.low
        else:
            tr = max(
                bar.high - bar.low,
                abs(bar.high - self._prev_close),
                abs(bar.low - self._prev_close),
            )
        self._prev_close = bar.close

        if self._atr is None:
            self._trs.append(tr)
            if len(self._trs) < self.period:
                return InfoValue.na()
            if len(self._trs) == self.period:
                self._atr = sum(self._trs, Fraction(0, 1)) / self.period
                return InfoValue.known(self._atr)
            raise AssertionError("ATR seed length invariant broken")

        self._atr = ((self._atr * (self.period - 1)) + tr) / self.period
        return InfoValue.known(self._atr)
