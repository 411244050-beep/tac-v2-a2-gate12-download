"""D1-only reference pipeline for synthetic/reference use.

This is deliberately not a full cutoff engine and writes no D2-D6 Strategy truth.
It evaluates D1 math independently on causal 15M, completed 1H, and completed 4H streams.
"""
from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from typing import Iterable

from .d1_data_math.atr import ATR14Recurrence
from .d1_data_math.canonical import CanonicalBar, CanonicalRecord, canonicalize_15m
from .d1_data_math.ema import EMARecurrence
from .d1_data_math.htf_aggregation import HTFBar, aggregate_completed_htf
from .d1_data_math.supertrend import SupertrendPoint, SupertrendRecurrence
from .runtime_guards.information_state import InfoValue


@dataclass(frozen=True)
class D1MathPoint:
    timeframe_ms: int
    source_open_time: int
    source_close_time: int
    source_segment_id: str
    ema20: InfoValue[Fraction]
    ema50: InfoValue[Fraction]
    atr14: InfoValue[Fraction]
    supertrend: SupertrendPoint


@dataclass(frozen=True)
class D1ReferenceResult:
    canonical_records: tuple[CanonicalRecord, ...]
    htf_1h: tuple[HTFBar, ...]
    htf_4h: tuple[HTFBar, ...]
    math_15m: tuple[D1MathPoint, ...]
    math_1h: tuple[D1MathPoint, ...]
    math_4h: tuple[D1MathPoint, ...]


def _math_stream(items: Iterable[tuple[object, str]], *, timeframe_ms: int) -> tuple[D1MathPoint, ...]:
    ema20 = EMARecurrence(20)
    ema50 = EMARecurrence(50)
    atr14 = ATR14Recurrence()
    st = SupertrendRecurrence()
    points: list[D1MathPoint] = []

    for bar, segment_id in items:
        # bar is a CanonicalBar or HTFBar; both satisfy the OHLC protocol.
        e20 = ema20.update(bar.close, segment_id=segment_id)  # type: ignore[attr-defined]
        e50 = ema50.update(bar.close, segment_id=segment_id)  # type: ignore[attr-defined]
        a14 = atr14.update(bar, segment_id=segment_id)  # type: ignore[arg-type]
        stp = st.update(bar, a14, segment_id=segment_id)  # type: ignore[arg-type]
        points.append(
            D1MathPoint(
                timeframe_ms=timeframe_ms,
                source_open_time=bar.open_time,  # type: ignore[attr-defined]
                source_close_time=bar.close_time,  # type: ignore[attr-defined]
                source_segment_id=segment_id,
                ema20=e20,
                ema50=e50,
                atr14=a14,
                supertrend=stp,
            )
        )
    return tuple(points)


def evaluate_d1_reference(bars: list[CanonicalBar]) -> D1ReferenceResult:
    canon = canonicalize_15m(bars)
    cutoff = canon.information_cutoff
    if cutoff is None:
        return D1ReferenceResult((), (), (), (), (), ())

    h1 = aggregate_completed_htf(canon.records, timeframe_ms=60 * 60 * 1000, information_cutoff=cutoff)
    h4 = aggregate_completed_htf(canon.records, timeframe_ms=4 * 60 * 60 * 1000, information_cutoff=cutoff)

    math15 = _math_stream(
        ((rec.bar, rec.canonical_segment_id) for rec in canon.records),
        timeframe_ms=15 * 60 * 1000,
    )
    math1h = _math_stream(((bar, bar.source_segment_id) for bar in h1), timeframe_ms=60 * 60 * 1000)
    math4h = _math_stream(((bar, bar.source_segment_id) for bar in h4), timeframe_ms=4 * 60 * 60 * 1000)

    return D1ReferenceResult(
        canonical_records=canon.records,
        htf_1h=h1,
        htf_4h=h4,
        math_15m=math15,
        math_1h=math1h,
        math_4h=math4h,
    )
