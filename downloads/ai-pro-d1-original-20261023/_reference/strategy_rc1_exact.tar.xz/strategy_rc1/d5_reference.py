"""Public WP5 reference surface. Non-trading and runtime-unusable by current governance."""

from .d5_risk import *  # noqa: F401,F403
