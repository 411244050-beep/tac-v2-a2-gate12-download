from __future__ import annotations

from .d4_opportunity.types import D4CutoffView, OpportunityMechanism
from .ids import deterministic_id
from .runtime_guards.information_state import InfoKind, InfoValue
from .d5_risk.parameters import D5ParameterView
from .d5_risk.types import DecisionResult, DecisionState, EntryReadyAssemblyResult, RiskFeasibilityResult


def _gate_state(value: InfoValue[bool], label: str) -> DecisionResult:
    if value.kind is InfoKind.ERROR:
        return DecisionResult(DecisionState.ERROR, f"{label}_ERROR")
    if value.kind is InfoKind.UNKNOWN:
        return DecisionResult(DecisionState.UNKNOWN, f"{label}_UNKNOWN")
    if value.kind in (InfoKind.NONE, InfoKind.NA):
        return DecisionResult(DecisionState.NA, f"{label}_NA")
    return DecisionResult(DecisionState.PASS if value.value is True else DecisionState.FAIL, f"{label}_{'PASS' if value.value else 'FAIL'}")


def assemble_b7b_entry_ready(
    d4_view: D4CutoffView,
    risk: RiskFeasibilityResult,
    *,
    parameters: D5ParameterView,
) -> EntryReadyAssemblyResult:
    cutoff = d4_view.information_cutoff
    opportunity = d4_view.opportunity
    candidate = d4_view.confirmation_candidate
    oid = opportunity.opportunity_id if opportunity is not None else None
    cid = candidate.candidate_id if candidate is not None else None

    if risk.information_cutoff != cutoff:
        decision = DecisionResult(DecisionState.ERROR, "B7B_RISK_CUTOFF_MISMATCH")
    elif opportunity is None:
        decision = DecisionResult(DecisionState.NA, "NO_OPPORTUNITY")
    elif opportunity.primary_mechanism is OpportunityMechanism.TREND_ESTABLISHMENT_WATCH_ONLY:
        decision = DecisionResult(DecisionState.NA, "TREND_ESTABLISHMENT_WATCH_ONLY_NEVER_ENTRY_READY")
    elif candidate is None:
        decision = DecisionResult(DecisionState.NA, "NO_SAME_CUTOFF_B7A_CONFIRMATION")
    elif candidate.confirmation_cutoff != cutoff or not candidate.same_cutoff_only:
        decision = DecisionResult(DecisionState.ERROR, "B7A_CONFIRMATION_NOT_SAME_CUTOFF")
    elif risk.confirmation_candidate_id != candidate.candidate_id or risk.opportunity_id != opportunity.opportunity_id:
        decision = DecisionResult(DecisionState.ERROR, "B7B_LINEAGE_MISMATCH")
    else:
        gates = (
            _gate_state(d4_view.market_eligibility.result, "MARKET_ELIGIBILITY"),
            _gate_state(d4_view.location_eligibility.result, "LOCATION_ELIGIBILITY"),
            _gate_state(d4_view.behavior_confirmation.result, "BEHAVIOR_CONFIRMATION"),
            risk.decision,
        )
        error = next((g for g in gates if g.state is DecisionState.ERROR), None)
        blocked = next((g for g in gates if g.state is DecisionState.BLOCKED), None)
        failed = next((g for g in gates if g.state is DecisionState.FAIL), None)
        unknown = next((g for g in gates if g.state is DecisionState.UNKNOWN), None)
        na = next((g for g in gates if g.state is DecisionState.NA), None)
        if error is not None:
            decision = error
        elif blocked is not None:
            decision = blocked
        elif failed is not None:
            decision = failed
        elif unknown is not None:
            decision = unknown
        elif na is not None:
            decision = na
        elif not parameters.complete_strategy_parameter_snapshot or not parameters.runtime_usable:
            decision = DecisionResult(
                DecisionState.BLOCKED,
                "INCOMPLETE_STRATEGY_PARAMETER_SNAPSHOT_RUNTIME_UNUSABLE",
            )
        else:
            # Interface semantics only. The current WP5 state cannot reach this branch.
            decision = DecisionResult(DecisionState.PASS, "ALL_FOUR_SAME_CUTOFF_GATES_PASS")

    emitted = decision.state is DecisionState.PASS
    entry_ready_id = (
        deterministic_id("D4-B7B-ENTRY-READY", oid, cid, str(cutoff)) if emitted else None
    )
    return EntryReadyAssemblyResult(
        decision=decision,
        information_cutoff=cutoff,
        opportunity_id=oid,
        confirmation_candidate_id=cid,
        risk_feasibility_state=risk.decision.state,
        entry_ready_id=entry_ready_id,
        semantic_entry_ready_emitted=emitted,
        executable=False,
        runtime_usable=False,
    )
