from __future__ import annotations

from fractions import Fraction

from ..d2_market_state.types import TrendDirection
from ..runtime_guards.information_state import InfoKind, InfoValue
from .parameters import D5ParameterView
from .types import DecisionResult, DecisionState, InitialHardStopCandidate, RiskAnchorReference


def symbolic_initial_hard_stop_candidate(
    risk_anchor: RiskAnchorReference | None,
    *,
    direction: TrendDirection,
    atr_at_risk_reference: InfoValue[Fraction],
    parameters: D5ParameterView,
) -> InitialHardStopCandidate:
    formula = (
        "HardStop = RiskAnchor - theta_stop * ATR_at_risk_reference"
        if direction is TrendDirection.LONG
        else "HardStop = RiskAnchor + theta_stop * ATR_at_risk_reference"
    )
    if risk_anchor is None:
        decision = DecisionResult(DecisionState.FAIL, "NO_QUALIFIED_RISK_ANCHOR_FOR_HARD_STOP")
    elif atr_at_risk_reference.kind is InfoKind.ERROR:
        decision = DecisionResult(DecisionState.ERROR, "ATR_AT_RISK_REFERENCE_ERROR")
    elif atr_at_risk_reference.kind is InfoKind.UNKNOWN:
        decision = DecisionResult(DecisionState.UNKNOWN, "ATR_AT_RISK_REFERENCE_UNKNOWN")
    elif atr_at_risk_reference.kind in (InfoKind.NONE, InfoKind.NA):
        decision = DecisionResult(DecisionState.NA, "ATR_AT_RISK_REFERENCE_NA")
    else:
        # Current governance intentionally locks theta_stop with no value.
        decision = DecisionResult(
            DecisionState.BLOCKED,
            "THETA_STOP_LOCKED_NO_AUTHORIZED_NUMERIC_VALUE",
            {"formula_preserved": "true", "numeric_stop_forbidden_in_wp5": "true"},
        )
    return InitialHardStopCandidate(
        decision=decision,
        direction=direction,
        risk_anchor_id=(risk_anchor.risk_anchor_id if risk_anchor is not None else None),
        risk_anchor_price=(risk_anchor.price if risk_anchor is not None else None),
        symbolic_formula=formula,
        theta_stop_state=parameters.theta_stop_state.value,
        theta_stop_exact_value=parameters.theta_stop_exact_value,
        atr_at_risk_reference=atr_at_risk_reference,
        numeric_stop_price=None,
        structural_stop_clearance=None,
    )
