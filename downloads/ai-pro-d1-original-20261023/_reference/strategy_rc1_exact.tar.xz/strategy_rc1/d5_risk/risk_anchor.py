from __future__ import annotations

from dataclasses import dataclass, field
from fractions import Fraction
from typing import Mapping, Union

from ..d2_market_state.types import PivotType, StructuralLayer, StructuralPivot, TrendDirection
from ..d4_opportunity.types import BehaviorConfirmationCandidate, OpportunityMechanism, OpportunityState
from ..ids import deterministic_id
from .types import DecisionResult, DecisionState, RiskAnchorReference, RiskAnchorSelectionResult


@dataclass(frozen=True)
class _CommonRiskEvidence:
    opportunity_id: str
    confirmation_candidate_id: str
    belongs_to_opportunity_lineage: bool
    thesis_defining: bool
    risk_anchor_not_invalidated: bool
    provenance: Mapping[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class NormalRetestRiskEvidence(_CommonRiskEvidence):
    participating_minor_pivots: tuple[StructuralPivot, ...] = ()


@dataclass(frozen=True)
class FalseBreakRiskEvidence(_CommonRiskEvidence):
    wrong_side_extreme: StructuralPivot | None = None
    false_break_event_id: str = ""


@dataclass(frozen=True)
class PlatformRiskEvidence(_CommonRiskEvidence):
    adverse_defense_extreme: StructuralPivot | None = None
    platform_episode_id: str = ""


@dataclass(frozen=True)
class DeepTakeoverRiskEvidence(_CommonRiskEvidence):
    adverse_defense_extreme: StructuralPivot | None = None
    deeper_takeover_lineage_id: str = ""


@dataclass(frozen=True)
class TrendEstablishmentRiskEvidence(_CommonRiskEvidence):
    pass


MechanismRiskEvidence = Union[
    NormalRetestRiskEvidence,
    FalseBreakRiskEvidence,
    PlatformRiskEvidence,
    DeepTakeoverRiskEvidence,
    TrendEstablishmentRiskEvidence,
]


def _validate_lineage(
    opportunity: OpportunityState,
    candidate: BehaviorConfirmationCandidate,
    evidence: _CommonRiskEvidence,
    *,
    information_cutoff: int,
) -> DecisionResult | None:
    if candidate.confirmation_cutoff != information_cutoff:
        return DecisionResult(DecisionState.ERROR, "B7A_CONFIRMATION_NOT_SAME_CUTOFF")
    if candidate.opportunity_id != opportunity.opportunity_id or evidence.opportunity_id != opportunity.opportunity_id:
        return DecisionResult(DecisionState.ERROR, "RISK_OPPORTUNITY_LINEAGE_MISMATCH")
    if evidence.confirmation_candidate_id != candidate.candidate_id:
        return DecisionResult(DecisionState.ERROR, "RISK_CONFIRMATION_CANDIDATE_LINEAGE_MISMATCH")
    if candidate.trend_episode_id != opportunity.trend_episode_id or candidate.direction is not opportunity.direction:
        return DecisionResult(DecisionState.ERROR, "RISK_TREND_LINEAGE_MISMATCH")
    if candidate.market_event_id != opportunity.market_event_id:
        return DecisionResult(DecisionState.ERROR, "RISK_MARKET_EVENT_LINEAGE_MISMATCH")
    if opportunity.terminal:
        return DecisionResult(DecisionState.FAIL, "OPPORTUNITY_ALREADY_TERMINATED")
    if not evidence.belongs_to_opportunity_lineage:
        return DecisionResult(DecisionState.FAIL, "RISK_STRUCTURE_NOT_IN_OPPORTUNITY_LINEAGE")
    if not evidence.thesis_defining:
        return DecisionResult(DecisionState.FAIL, "RISK_STRUCTURE_NOT_THESIS_DEFINING")
    return None


def _validate_pivot(
    pivot: StructuralPivot,
    *,
    direction: TrendDirection,
    information_cutoff: int,
    canonical_segment_id: str,
    require_minor: bool,
) -> DecisionResult | None:
    if pivot.confirmed_at > information_cutoff:
        return DecisionResult(DecisionState.ERROR, "FUTURE_CONFIRMED_PIVOT_FORBIDDEN")
    if pivot.canonical_segment_id != canonical_segment_id:
        return DecisionResult(DecisionState.FAIL, "RISK_ANCHOR_CANONICAL_SEGMENT_MISMATCH")
    if require_minor and pivot.layer is not StructuralLayer.MINOR:
        return DecisionResult(DecisionState.FAIL, "NORMAL_RETEST_RISK_ANCHOR_MUST_BE_MINOR")
    expected_type = PivotType.LOW if direction is TrendDirection.LONG else PivotType.HIGH
    if pivot.pivot_type is not expected_type:
        return DecisionResult(DecisionState.FAIL, "RISK_ANCHOR_NOT_ON_ADVERSE_STRUCTURAL_SIDE")
    return None


def _adverse_side_price_ok(direction: TrendDirection, pivot_price: Fraction, entry_price: Fraction) -> bool:
    return pivot_price < entry_price if direction is TrendDirection.LONG else pivot_price > entry_price


def _to_reference(
    opportunity: OpportunityState,
    candidate: BehaviorConfirmationCandidate,
    pivot: StructuralPivot,
    *,
    reason: str,
    evidence_provenance: Mapping[str, str],
) -> RiskAnchorReference:
    rid = deterministic_id("D5-RISK-ANCHOR", opportunity.opportunity_id, candidate.candidate_id, pivot.pivot_id, reason)
    return RiskAnchorReference(
        risk_anchor_id=rid,
        opportunity_id=opportunity.opportunity_id,
        confirmation_candidate_id=candidate.candidate_id,
        mechanism=candidate.mechanism,
        direction=opportunity.direction,
        pivot_id=pivot.pivot_id,
        pivot_type=pivot.pivot_type,
        layer=pivot.layer,
        price=pivot.extreme_price,
        confirmed_at=pivot.confirmed_at,
        canonical_segment_id=pivot.canonical_segment_id,
        source_scale_at_extreme=pivot.scale_at_extreme,
        reason=reason,
        provenance={
            "writer": "D5_RISK_REFERENCE_ONLY",
            "source_truth": "D2_CONFIRMED_PRICE_STRUCTURE",
            "no_anchor_line_as_risk_anchor": "true",
            "not_selected_for_position_size": "true",
            **dict(evidence_provenance),
        },
    )


def select_mechanism_risk_anchor(
    opportunity: OpportunityState,
    candidate: BehaviorConfirmationCandidate,
    evidence: MechanismRiskEvidence,
    *,
    information_cutoff: int,
    canonical_segment_id: str,
    strategy_entry_reference_price: Fraction,
) -> RiskAnchorSelectionResult:
    lineage = _validate_lineage(opportunity, candidate, evidence, information_cutoff=information_cutoff)
    if lineage is not None:
        return RiskAnchorSelectionResult(lineage, None)
    if candidate.mechanism is OpportunityMechanism.TREND_ESTABLISHMENT_WATCH_ONLY:
        return RiskAnchorSelectionResult(DecisionResult(DecisionState.NA, "TREND_ESTABLISHMENT_WATCH_ONLY_RISK_NA"), None)
    if candidate.mechanism is OpportunityMechanism.NORMAL_RETEST_CONTINUATION:
        if not isinstance(evidence, NormalRetestRiskEvidence):
            return RiskAnchorSelectionResult(DecisionResult(DecisionState.ERROR, "MECHANISM_RISK_EVIDENCE_TYPE_MISMATCH"), None)
        pivots = []
        for pivot in evidence.participating_minor_pivots:
            check = _validate_pivot(
                pivot,
                direction=opportunity.direction,
                information_cutoff=information_cutoff,
                canonical_segment_id=canonical_segment_id,
                require_minor=True,
            )
            if check is not None:
                return RiskAnchorSelectionResult(check, None)
            pivots.append(pivot)
        if not pivots:
            return RiskAnchorSelectionResult(DecisionResult(DecisionState.FAIL, "NO_QUALIFIED_NORMAL_RETEST_MINOR_RISK_ANCHOR"), None)
        pivot = min(pivots, key=lambda p: p.extreme_price) if opportunity.direction is TrendDirection.LONG else max(pivots, key=lambda p: p.extreme_price)
        reason = "ADVERSE_MOST_CONFIRMED_MINOR_IN_SETUP_THROUGH_LOCAL_CONTROL_REGAIN"
    elif candidate.mechanism is OpportunityMechanism.FALSE_BREAK_RECLAIM:
        if not isinstance(evidence, FalseBreakRiskEvidence) or evidence.wrong_side_extreme is None:
            return RiskAnchorSelectionResult(DecisionResult(DecisionState.ERROR, "FALSE_BREAK_RISK_EVIDENCE_MISSING"), None)
        if not evidence.false_break_event_id:
            return RiskAnchorSelectionResult(DecisionResult(DecisionState.ERROR, "FALSE_BREAK_EVENT_LINEAGE_MISSING"), None)
        pivot = evidence.wrong_side_extreme
        check = _validate_pivot(pivot, direction=opportunity.direction, information_cutoff=information_cutoff, canonical_segment_id=canonical_segment_id, require_minor=False)
        if check is not None:
            return RiskAnchorSelectionResult(check, None)
        reason = "CONFIRMED_FALSE_BREAK_WRONG_SIDE_EXTREME"
    elif candidate.mechanism is OpportunityMechanism.PLATFORM_REEXPANSION:
        if not isinstance(evidence, PlatformRiskEvidence) or evidence.adverse_defense_extreme is None:
            return RiskAnchorSelectionResult(DecisionResult(DecisionState.ERROR, "PLATFORM_RISK_EVIDENCE_MISSING"), None)
        if not evidence.platform_episode_id:
            return RiskAnchorSelectionResult(DecisionResult(DecisionState.ERROR, "PLATFORM_EPISODE_LINEAGE_MISSING"), None)
        pivot = evidence.adverse_defense_extreme
        check = _validate_pivot(pivot, direction=opportunity.direction, information_cutoff=information_cutoff, canonical_segment_id=canonical_segment_id, require_minor=False)
        if check is not None:
            return RiskAnchorSelectionResult(check, None)
        reason = "ADVERSE_DEFENSE_EXTREME_OF_CONFIRMED_PLATFORM_EPISODE"
    elif candidate.mechanism is OpportunityMechanism.DEEP_STRUCTURE_TAKEOVER:
        if not isinstance(evidence, DeepTakeoverRiskEvidence) or evidence.adverse_defense_extreme is None:
            return RiskAnchorSelectionResult(DecisionResult(DecisionState.ERROR, "DEEP_TAKEOVER_RISK_EVIDENCE_MISSING"), None)
        if not evidence.deeper_takeover_lineage_id:
            return RiskAnchorSelectionResult(DecisionResult(DecisionState.ERROR, "DEEP_TAKEOVER_LINEAGE_MISSING"), None)
        pivot = evidence.adverse_defense_extreme
        check = _validate_pivot(pivot, direction=opportunity.direction, information_cutoff=information_cutoff, canonical_segment_id=canonical_segment_id, require_minor=False)
        if check is not None:
            return RiskAnchorSelectionResult(check, None)
        reason = "ADVERSE_DEFENSE_EXTREME_OF_DEEPER_TAKEOVER_CONFIRMATION_SEQUENCE"
    else:
        return RiskAnchorSelectionResult(DecisionResult(DecisionState.ERROR, "UNSUPPORTED_MECHANISM"), None)

    if not _adverse_side_price_ok(opportunity.direction, pivot.extreme_price, strategy_entry_reference_price):
        return RiskAnchorSelectionResult(DecisionResult(DecisionState.FAIL, "RISK_ANCHOR_NOT_ADVERSE_TO_STRATEGY_ENTRY_REFERENCE"), None)
    if not evidence.risk_anchor_not_invalidated:
        return RiskAnchorSelectionResult(DecisionResult(DecisionState.FAIL, "RISK_ANCHOR_ALREADY_INVALIDATED"), None)
    return RiskAnchorSelectionResult(
        DecisionResult(DecisionState.PASS, "QUALIFIED_MECHANISM_SPECIFIC_RISK_ANCHOR"),
        _to_reference(opportunity, candidate, pivot, reason=reason, evidence_provenance=evidence.provenance),
    )
