from __future__ import annotations

from .types import OperationalInputSet, OperationalInputSlot, OperationalInputState


REQUIRED_UNRESOLVED_OPERATIONAL_INPUTS = (
    "per_trade_account_risk",
    "per_symbol_risk_cap",
    "total_portfolio_risk_cap",
    "same_direction_aggregate_cap",
    "correlation_common_factor_budget",
    "listing_liquidity_capacity_thresholds",
    "spread_slippage_depth_feasibility_boundaries",
    "execution_allowance",
    "kill_switch_numeric_triggers",
    "PORT_007_allocation_priority_policy",
)


def current_unresolved_operational_inputs() -> OperationalInputSet:
    return OperationalInputSet(
        {
            name: OperationalInputSlot(name=name, state=OperationalInputState.UNRESOLVED)
            for name in REQUIRED_UNRESOLVED_OPERATIONAL_INPUTS
        }
    )


def validate_required_slots(inputs: OperationalInputSet) -> tuple[str, ...]:
    return tuple(name for name in REQUIRED_UNRESOLVED_OPERATIONAL_INPUTS if name not in inputs.slots)
