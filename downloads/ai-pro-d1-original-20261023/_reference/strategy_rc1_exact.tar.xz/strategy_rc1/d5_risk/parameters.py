from __future__ import annotations

from dataclasses import dataclass

from ..parameter_snapshot import ParameterSnapshot, ParameterState


@dataclass(frozen=True)
class D5ParameterView:
    snapshot_id: str
    theta_stop_state: ParameterState
    theta_stop_exact_value: str | None
    complete_strategy_parameter_snapshot: bool
    runtime_usable: bool

    def __post_init__(self) -> None:
        if self.theta_stop_state is not ParameterState.LOCKED:
            raise ValueError("WP5 current-governance contract requires theta_stop LOCKED")
        if self.theta_stop_exact_value is not None:
            raise ValueError("LOCKED theta_stop must carry no numeric value")
        if self.complete_strategy_parameter_snapshot or self.runtime_usable:
            raise ValueError("WP5 current snapshot must remain incomplete and runtime unusable")


def d5_parameter_view(snapshot: ParameterSnapshot) -> D5ParameterView:
    slot = snapshot.slot("theta_stop")
    return D5ParameterView(
        snapshot_id=snapshot.snapshot_id,
        theta_stop_state=slot.state,
        theta_stop_exact_value=slot.exact_value,
        complete_strategy_parameter_snapshot=snapshot.complete_strategy_parameter_snapshot,
        runtime_usable=snapshot.runtime_usable,
    )
