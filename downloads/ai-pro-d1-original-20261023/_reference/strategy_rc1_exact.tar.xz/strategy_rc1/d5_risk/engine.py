from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction

from ..d4_opportunity.types import D4CutoffView
from ..runtime_guards.information_state import InfoKind, InfoValue
from ..d4_b7b_entry_ready import assemble_b7b_entry_ready
from .feasibility import evaluate_risk_feasibility
from .parameters import D5ParameterView
from .risk_anchor import MechanismRiskEvidence, select_mechanism_risk_anchor
from .types import (
    AnchorSeparationView,
    DecisionResult,
    DecisionState,
    D5CutoffView,
    OperationalInputSet,
    RiskAnchorSelectionResult,
)


@dataclass(frozen=True)
class D5CutoffInput:
    information_cutoff: int
    d4_view: D4CutoffView
    risk_evidence: MechanismRiskEvidence
    canonical_segment_id: str
    strategy_entry_reference_price: InfoValue[Fraction]
    atr_at_risk_reference: InfoValue[Fraction]
    canonical_continuity_intact: InfoValue[bool]
    risk_anchor_not_invalidated: InfoValue[bool]
    operational_inputs: OperationalInputSet
    parameters: D5ParameterView

    def __post_init__(self) -> None:
        if self.d4_view.information_cutoff != self.information_cutoff:
            raise ValueError("D5_CANNOT_CONSUME_D4_VIEW_FROM_DIFFERENT_CUTOFF")
        if not self.canonical_segment_id:
            raise ValueError("canonical_segment_id required")


def update_012_013(inp: D5CutoffInput) -> D5CutoffView:
    opportunity = inp.d4_view.opportunity
    candidate = inp.d4_view.confirmation_candidate
    if opportunity is None:
        # UPDATE-012 is only meaningful for an existing D4 Opportunity.
        raise ValueError("D5_REQUIRES_D4_OPPORTUNITY_STATE")

    entry_value = inp.strategy_entry_reference_price.value if inp.strategy_entry_reference_price.kind is InfoKind.KNOWN else None
    if candidate is None:
        anchor_selection = RiskAnchorSelectionResult(DecisionResult(DecisionState.NA, "RISK_ANCHOR_SELECTION_REQUIRES_CURRENT_B7A"), None)
    elif entry_value is None:
        if inp.strategy_entry_reference_price.kind is InfoKind.ERROR:
            state = DecisionState.ERROR
        elif inp.strategy_entry_reference_price.kind is InfoKind.UNKNOWN:
            state = DecisionState.UNKNOWN
        else:
            state = DecisionState.NA
        anchor_selection = RiskAnchorSelectionResult(DecisionResult(state, "STRATEGY_ENTRY_REFERENCE_NOT_KNOWN_FOR_RISK_ANCHOR_ADVERSE_SIDE_CHECK"), None)
    else:
        anchor_selection = select_mechanism_risk_anchor(
            opportunity,
            candidate,
            inp.risk_evidence,
            information_cutoff=inp.information_cutoff,
            canonical_segment_id=inp.canonical_segment_id,
            strategy_entry_reference_price=entry_value,
        )

    risk = evaluate_risk_feasibility(
        opportunity,
        candidate,
        anchor_selection,
        information_cutoff=inp.information_cutoff,
        strategy_entry_reference_price=inp.strategy_entry_reference_price,
        atr_at_risk_reference=inp.atr_at_risk_reference,
        canonical_continuity_intact=inp.canonical_continuity_intact,
        risk_anchor_not_invalidated=inp.risk_anchor_not_invalidated,
        operational_inputs=inp.operational_inputs,
        parameters=inp.parameters,
    )
    entry_ready = assemble_b7b_entry_ready(inp.d4_view, risk, parameters=inp.parameters)
    separation = AnchorSeparationView(
        entry_anchor_unit_id=opportunity.entry_boundary_unit_id,
        risk_anchor_id=(risk.risk_anchor.risk_anchor_id if risk.risk_anchor is not None else None),
        management_anchor_id=None,
        management_anchor_state=DecisionResult(DecisionState.NA, "MANAGEMENT_ANCHOR_IS_POST_ENTRY_D6_SCOPE"),
    )
    return D5CutoffView(
        information_cutoff=inp.information_cutoff,
        anchor_separation=separation,
        risk_feasibility=risk,
        entry_ready=entry_ready,
    )
