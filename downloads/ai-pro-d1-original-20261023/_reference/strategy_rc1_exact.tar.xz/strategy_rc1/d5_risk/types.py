from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from fractions import Fraction
from types import MappingProxyType
from typing import Mapping

from ..d2_market_state.types import PivotType, StructuralLayer, TrendDirection
from ..d4_opportunity.types import OpportunityMechanism
from ..runtime_guards.information_state import InfoValue


class DecisionState(str, Enum):
    PASS = "PASS"
    FAIL = "FAIL"
    UNKNOWN = "UNKNOWN"
    NA = "N/A"
    ERROR = "ERROR"
    BLOCKED = "BLOCKED"


@dataclass(frozen=True)
class DecisionResult:
    state: DecisionState
    reason: str
    provenance: Mapping[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        object.__setattr__(self, "provenance", MappingProxyType(dict(self.provenance)))


@dataclass(frozen=True)
class RiskAnchorReference:
    risk_anchor_id: str
    opportunity_id: str
    confirmation_candidate_id: str
    mechanism: OpportunityMechanism
    direction: TrendDirection
    pivot_id: str
    pivot_type: PivotType
    layer: StructuralLayer
    price: Fraction
    confirmed_at: int
    canonical_segment_id: str
    source_scale_at_extreme: Fraction
    reason: str
    provenance: Mapping[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class AnchorSeparationView:
    entry_anchor_unit_id: str | None
    risk_anchor_id: str | None
    management_anchor_id: str | None
    management_anchor_state: DecisionResult


@dataclass(frozen=True)
class InitialHardStopCandidate:
    decision: DecisionResult
    direction: TrendDirection
    risk_anchor_id: str | None
    risk_anchor_price: Fraction | None
    symbolic_formula: str
    theta_stop_state: str
    theta_stop_exact_value: str | None
    atr_at_risk_reference: InfoValue[Fraction]
    numeric_stop_price: Fraction | None
    structural_stop_clearance: Fraction | None

    def __post_init__(self) -> None:
        if self.theta_stop_exact_value is not None:
            raise ValueError("WP5 forbids carrying a theta_stop numeric value")
        if self.numeric_stop_price is not None or self.structural_stop_clearance is not None:
            raise ValueError("WP5 forbids executable numeric Hard Stop completion")


class OperationalInputState(str, Enum):
    UNRESOLVED = "UNRESOLVED"
    KNOWN = "KNOWN"
    ERROR = "ERROR"


@dataclass(frozen=True)
class OperationalInputSlot:
    name: str
    state: OperationalInputState
    exact_value: str | None = None
    error_ref: str | None = None

    def __post_init__(self) -> None:
        if self.state is OperationalInputState.KNOWN:
            if self.exact_value is None or self.error_ref is not None:
                raise ValueError("KNOWN operational input requires exact_value only")
        elif self.state is OperationalInputState.ERROR:
            if self.error_ref is None or self.exact_value is not None:
                raise ValueError("ERROR operational input requires error_ref only")
        elif self.exact_value is not None or self.error_ref is not None:
            raise ValueError("UNRESOLVED operational input cannot carry a value")


@dataclass(frozen=True)
class OperationalInputSet:
    slots: Mapping[str, OperationalInputSlot]

    def __post_init__(self) -> None:
        object.__setattr__(self, "slots", MappingProxyType(dict(self.slots)))

    @property
    def unresolved_names(self) -> tuple[str, ...]:
        return tuple(sorted(k for k, v in self.slots.items() if v.state is OperationalInputState.UNRESOLVED))

    @property
    def error_names(self) -> tuple[str, ...]:
        return tuple(sorted(k for k, v in self.slots.items() if v.state is OperationalInputState.ERROR))

    @property
    def all_known(self) -> bool:
        return bool(self.slots) and all(v.state is OperationalInputState.KNOWN for v in self.slots.values())


@dataclass(frozen=True)
class RiskAnchorSelectionResult:
    decision: DecisionResult
    anchor: RiskAnchorReference | None


@dataclass(frozen=True)
class RiskFeasibilityResult:
    decision: DecisionResult
    information_cutoff: int
    opportunity_id: str
    confirmation_candidate_id: str | None
    mechanism: OpportunityMechanism
    direction: TrendDirection
    risk_anchor: RiskAnchorReference | None
    hard_stop: InitialHardStopCandidate
    strategy_entry_reference_price: InfoValue[Fraction]
    per_unit_structural_risk: InfoValue[Fraction]
    canonical_continuity_intact: InfoValue[bool]
    risk_anchor_not_invalidated: InfoValue[bool]
    operational_inputs: OperationalInputSet
    update_step: str = "UPDATE-012"


@dataclass(frozen=True)
class EntryReadyAssemblyResult:
    decision: DecisionResult
    information_cutoff: int
    opportunity_id: str | None
    confirmation_candidate_id: str | None
    risk_feasibility_state: DecisionState
    entry_ready_id: str | None
    semantic_entry_ready_emitted: bool
    executable: bool
    runtime_usable: bool
    update_step: str = "UPDATE-013"

    def __post_init__(self) -> None:
        if self.executable or self.runtime_usable:
            raise ValueError("WP5 non-trading reference skeleton may not be executable/runtime usable")
        if self.semantic_entry_ready_emitted and self.entry_ready_id is None:
            raise ValueError("emitted semantic ENTRY_READY requires ID")


@dataclass(frozen=True)
class D5CutoffView:
    information_cutoff: int
    anchor_separation: AnchorSeparationView
    risk_feasibility: RiskFeasibilityResult
    entry_ready: EntryReadyAssemblyResult
