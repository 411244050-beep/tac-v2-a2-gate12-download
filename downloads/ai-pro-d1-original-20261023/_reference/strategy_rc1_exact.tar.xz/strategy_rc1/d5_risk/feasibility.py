from __future__ import annotations

from fractions import Fraction

from ..d4_opportunity.types import BehaviorConfirmationCandidate, OpportunityMechanism, OpportunityState
from ..runtime_guards.information_state import InfoKind, InfoValue
from .hard_stop import symbolic_initial_hard_stop_candidate
from .operational_inputs import validate_required_slots
from .parameters import D5ParameterView
from .types import (
    DecisionResult,
    DecisionState,
    OperationalInputSet,
    RiskAnchorSelectionResult,
    RiskFeasibilityResult,
)


def _nonknown_to_decision(value: InfoValue[object], label: str) -> DecisionResult | None:
    if value.kind is InfoKind.ERROR:
        return DecisionResult(DecisionState.ERROR, f"{label}_ERROR")
    if value.kind is InfoKind.UNKNOWN:
        return DecisionResult(DecisionState.UNKNOWN, f"{label}_UNKNOWN")
    if value.kind in (InfoKind.NONE, InfoKind.NA):
        return DecisionResult(DecisionState.NA, f"{label}_NA")
    return None


def evaluate_risk_feasibility(
    opportunity: OpportunityState,
    candidate: BehaviorConfirmationCandidate | None,
    anchor_selection: RiskAnchorSelectionResult,
    *,
    information_cutoff: int,
    strategy_entry_reference_price: InfoValue[Fraction],
    atr_at_risk_reference: InfoValue[Fraction],
    canonical_continuity_intact: InfoValue[bool],
    risk_anchor_not_invalidated: InfoValue[bool],
    operational_inputs: OperationalInputSet,
    parameters: D5ParameterView,
) -> RiskFeasibilityResult:
    mechanism = opportunity.primary_mechanism
    if mechanism is OpportunityMechanism.TREND_ESTABLISHMENT_WATCH_ONLY:
        hard = symbolic_initial_hard_stop_candidate(None, direction=opportunity.direction, atr_at_risk_reference=InfoValue.na(), parameters=parameters)
        return RiskFeasibilityResult(
            DecisionResult(DecisionState.NA, "TREND_ESTABLISHMENT_WATCH_ONLY_RISK_FEASIBILITY_NA"),
            information_cutoff,
            opportunity.opportunity_id,
            None,
            mechanism,
            opportunity.direction,
            None,
            hard,
            strategy_entry_reference_price,
            InfoValue.na(),
            canonical_continuity_intact,
            risk_anchor_not_invalidated,
            operational_inputs,
        )
    if candidate is None:
        hard = symbolic_initial_hard_stop_candidate(None, direction=opportunity.direction, atr_at_risk_reference=atr_at_risk_reference, parameters=parameters)
        return RiskFeasibilityResult(
            DecisionResult(DecisionState.NA, "NO_SAME_CUTOFF_B7A_CONFIRMATION_CANDIDATE"), information_cutoff,
            opportunity.opportunity_id, None, mechanism, opportunity.direction, None, hard,
            strategy_entry_reference_price, InfoValue.na(), canonical_continuity_intact, risk_anchor_not_invalidated,
            operational_inputs,
        )
    if candidate.confirmation_cutoff != information_cutoff:
        decision = DecisionResult(DecisionState.ERROR, "STALE_B7A_CONFIRMATION_FOR_RISK")
    elif candidate.opportunity_id != opportunity.opportunity_id or candidate.trend_episode_id != opportunity.trend_episode_id:
        decision = DecisionResult(DecisionState.ERROR, "B8_B7A_OPPORTUNITY_LINEAGE_MISMATCH")
    elif candidate.mechanism is not mechanism:
        decision = DecisionResult(DecisionState.ERROR, "B8_PRIMARY_MECHANISM_MISMATCH")
    elif anchor_selection.decision.state is not DecisionState.PASS:
        decision = anchor_selection.decision
    else:
        entry_nonknown = _nonknown_to_decision(strategy_entry_reference_price, "STRATEGY_ENTRY_REFERENCE")
        continuity_nonknown = _nonknown_to_decision(canonical_continuity_intact, "CANONICAL_CONTINUITY")
        invalid_nonknown = _nonknown_to_decision(risk_anchor_not_invalidated, "RISK_ANCHOR_VALIDITY")
        if entry_nonknown is not None:
            decision = entry_nonknown
        elif continuity_nonknown is not None:
            decision = continuity_nonknown
        elif invalid_nonknown is not None:
            decision = invalid_nonknown
        elif canonical_continuity_intact.value is not True:
            decision = DecisionResult(DecisionState.FAIL, "CANONICAL_CONTINUITY_NOT_INTACT")
        elif risk_anchor_not_invalidated.value is not True:
            decision = DecisionResult(DecisionState.FAIL, "RISK_ANCHOR_ALREADY_INVALIDATED")
        else:
            decision = DecisionResult(DecisionState.PASS, "STRUCTURAL_PRECONDITIONS_AVAILABLE_PENDING_HARD_STOP_AND_OPERATIONAL_INPUTS")

    hard = symbolic_initial_hard_stop_candidate(
        anchor_selection.anchor if anchor_selection.decision.state is DecisionState.PASS else None,
        direction=opportunity.direction,
        atr_at_risk_reference=atr_at_risk_reference,
        parameters=parameters,
    )
    missing = validate_required_slots(operational_inputs)
    if decision.state is DecisionState.PASS:
        if hard.decision.state is not DecisionState.PASS:
            decision = hard.decision
        elif missing:
            decision = DecisionResult(DecisionState.BLOCKED, "REQUIRED_OPERATIONAL_INPUT_SLOTS_NOT_DECLARED")
        elif operational_inputs.error_names:
            decision = DecisionResult(DecisionState.ERROR, "OPERATIONAL_INPUT_ERROR")
        elif operational_inputs.unresolved_names:
            decision = DecisionResult(
                DecisionState.BLOCKED,
                "RISK_BUDGET_PORTFOLIO_LIQUIDITY_EXECUTION_INPUTS_UNRESOLVED",
                {"unresolved_count": str(len(operational_inputs.unresolved_names))},
            )
        elif not operational_inputs.all_known:
            decision = DecisionResult(DecisionState.UNKNOWN, "OPERATIONAL_INPUTS_NOT_ALL_KNOWN")

    # No executable numeric stop exists in WP5, so per-unit structural risk cannot be computed.
    per_unit = InfoValue.unknown() if decision.state in (DecisionState.BLOCKED, DecisionState.UNKNOWN) else InfoValue.na()
    return RiskFeasibilityResult(
        decision=decision,
        information_cutoff=information_cutoff,
        opportunity_id=opportunity.opportunity_id,
        confirmation_candidate_id=candidate.candidate_id,
        mechanism=mechanism,
        direction=opportunity.direction,
        risk_anchor=anchor_selection.anchor,
        hard_stop=hard,
        strategy_entry_reference_price=strategy_entry_reference_price,
        per_unit_structural_risk=per_unit,
        canonical_continuity_intact=canonical_continuity_intact,
        risk_anchor_not_invalidated=risk_anchor_not_invalidated,
        operational_inputs=operational_inputs,
    )
