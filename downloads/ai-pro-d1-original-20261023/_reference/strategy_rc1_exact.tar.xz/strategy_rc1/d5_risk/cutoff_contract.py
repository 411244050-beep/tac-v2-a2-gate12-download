"""WP5 owns only UPDATE-012 and the B7-B assembly interface at UPDATE-013."""

D5_OWNED_UPDATE_STEPS = ("UPDATE-012", "UPDATE-013")

UPDATE_012_CONTRACT = (
    "consume_same_cutoff_B7A_candidate",
    "select_structural_RiskAnchor",
    "preserve_symbolic_initial_HardStop",
    "evaluate_RiskFeasibility_fail_closed",
)

UPDATE_013_CONTRACT = (
    "same_cutoff_market_location_behavior_risk_assembly",
    "no_stale_cross_cutoff_gate_reuse",
    "watch_only_never_entry_ready",
    "incomplete_snapshot_blocks_runtime_entry_ready",
)
