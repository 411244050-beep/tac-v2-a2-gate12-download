from __future__ import annotations

import hashlib
import json
from typing import Any

from .result_types import freeze_payload


def canonical_json(value: Any) -> str:
    return json.dumps(
        freeze_payload(value),
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    )


def deterministic_id(namespace: str, *parts: Any, length: int = 32) -> str:
    if not namespace or not isinstance(namespace, str):
        raise ValueError("namespace must be a non-empty string")
    payload = canonical_json({"namespace": namespace, "parts": list(parts)})
    digest = hashlib.sha256(payload.encode("utf-8")).hexdigest()
    return f"{namespace}:{digest[:length]}"
