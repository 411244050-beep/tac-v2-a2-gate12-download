from __future__ import annotations

from dataclasses import replace

from ..ids import deterministic_id
from .types import (
    B3Geometry,
    BreakState,
    CausalBoundarySnapshot,
    InteractionControl,
    InteractionEvent,
    InteractionResolution,
    PriceDrivenReturnEvidence,
)


def initial_watch(candidate_id: str, target_trend_episode_id: str, target_direction) -> InteractionEvent:
    return InteractionEvent(
        event_id=deterministic_id("D3-WATCH", candidate_id, target_trend_episode_id),
        candidate_id=candidate_id,
        anchor_episode_id=None,
        target_trend_episode_id=target_trend_episode_id,
        target_direction=target_direction,
        control=InteractionControl.UNARMED,
        resolution=InteractionResolution.UNRESOLVED,
        event_reference_boundary=None,
        event_reference_scale=None,
        started_at=None,
        resolved_at=None,
        armed_at=None,
        approach_lineage_started_at=None,
        attempted_wrong_side_acceptance=False,
        material_wrong_side_separation_observed=False,
        reclaim_observed=False,
        break_state=BreakState.NONE,
        terminal=False,
        provenance={},
    )


def apply_geometry(
    event: InteractionEvent,
    *,
    geometry: B3Geometry,
    snapshot: CausalBoundarySnapshot,
    return_evidence: PriceDrivenReturnEvidence | None,
) -> InteractionEvent:
    """B3 event-control skeleton preserving no-same-cutoff re-open semantics."""
    if event.terminal or event.control is InteractionControl.RESOLVED:
        return event

    cutoff = geometry.information_cutoff
    if event.control is InteractionControl.UNARMED:
        if geometry.separated:
            return replace(event, control=InteractionControl.ARMED, armed_at=cutoff)
        return event

    if event.control is InteractionControl.ARMED:
        return_ok = return_evidence is not None and return_evidence.passed
        if return_ok and geometry.approach and event.approach_lineage_started_at is None:
            return replace(event, approach_lineage_started_at=cutoff)
        if return_ok and geometry.test:
            return replace(
                event,
                event_id=deterministic_id("D3-INTERACTION", event.candidate_id, str(cutoff), snapshot.snapshot_id),
                control=InteractionControl.INTERACTION_ACTIVE,
                started_at=cutoff,
                approach_lineage_started_at=event.approach_lineage_started_at or cutoff,
                event_reference_boundary=snapshot.boundary,
                event_reference_scale=snapshot.source_scale,
                provenance={"snapshot_id": snapshot.snapshot_id},
            )
        return event

    # INTERACTION_ACTIVE: continuous dwell stays one event. Correct-side material
    # separation resolves; the same bar is terminal for this event and cannot arm
    # the next event in this call.
    if geometry.separated and event.break_state not in (BreakState.TEMPORARY_BREAK, BreakState.RECLAIMING) and not event.attempted_wrong_side_acceptance:
        return replace(
            event,
            control=InteractionControl.RESOLVED,
            resolution=InteractionResolution.RESOLVED_CORRECT_SIDE,
            resolved_at=cutoff,
        )
    return event


def abort_approach(event: InteractionEvent, *, cutoff: int) -> InteractionEvent:
    if event.control is not InteractionControl.ARMED or event.approach_lineage_started_at is None:
        return event
    return replace(
        event,
        control=InteractionControl.RESOLVED,
        resolution=InteractionResolution.ABORTED_APPROACH,
        resolved_at=cutoff,
    )


def break_continuity(event: InteractionEvent, *, cutoff: int) -> InteractionEvent:
    if event.control not in (InteractionControl.ARMED, InteractionControl.INTERACTION_ACTIVE):
        return event
    return replace(
        event,
        control=InteractionControl.RESOLVED,
        resolution=InteractionResolution.UNKNOWN_CONTINUITY,
        resolved_at=cutoff,
    )


def rearm_after_resolution(event: InteractionEvent, *, geometry: B3Geometry) -> InteractionEvent:
    """Start a new independent armed cycle only after a later material re-separation."""
    if event.control is not InteractionControl.RESOLVED:
        return event
    if event.resolved_at is None or geometry.information_cutoff <= event.resolved_at:
        return event
    if not geometry.separated:
        return event
    return InteractionEvent(
        event_id=deterministic_id("D3-WATCH-REARM", event.candidate_id, event.event_id, str(geometry.information_cutoff)),
        candidate_id=event.candidate_id,
        anchor_episode_id=None,
        target_trend_episode_id=event.target_trend_episode_id,
        target_direction=event.target_direction,
        control=InteractionControl.ARMED,
        resolution=InteractionResolution.UNRESOLVED,
        event_reference_boundary=None,
        event_reference_scale=None,
        started_at=None,
        resolved_at=None,
        armed_at=geometry.information_cutoff,
        approach_lineage_started_at=None,
        attempted_wrong_side_acceptance=False,
        material_wrong_side_separation_observed=False,
        reclaim_observed=False,
        break_state=BreakState.NONE,
        terminal=False,
        provenance={"prior_event_id": event.event_id, "rearm": "MATERIAL_CORRECT_SIDE_SEPARATION"},
    )
