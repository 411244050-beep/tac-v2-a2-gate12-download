from __future__ import annotations

from dataclasses import replace

from ..d2_market_state.types import TrendDirection
from ..ids import deterministic_id
from ..runtime_guards.information_state import InfoValue
from .types import (
    AnchorActivity,
    AnchorEpisode,
    AnchorEvidenceDossier,
    AnchorValidity,
    BreakState,
    CandidateAvailability,
    InteractionControl,
    InteractionEvent,
    InteractionResolution,
    MathematicalBoundaryCandidate,
    QualifiedBoundaryUse,
    TrendSideMinorProgressEvidence,
)


def empty_dossier() -> AnchorEvidenceDossier:
    return AnchorEvidenceDossier(
        boundary_side_integrity=InfoValue.unknown(),
        structural_integrity=InfoValue.unknown(),
        slope_alignment=InfoValue.unknown(),
        independent_retest_evidence=InfoValue.none(),
        retest_quality=InfoValue.na(),
        current_relevance=InfoValue.unknown(),
        true_break_evidence=InfoValue.none(),
        data_confidence=InfoValue.unknown(),
    )


def maybe_start_anchor_episode(
    candidate: MathematicalBoundaryCandidate,
    event: InteractionEvent,
    *,
    target_trend_active: bool,
    candidate_terminally_invalidated: bool,
    cutoff: int,
) -> AnchorEpisode | None:
    """F1 starts PROVISIONAL only on qualifying armed Approach/Test lineage."""
    if candidate.availability is not CandidateAvailability.AVAILABLE or not target_trend_active or candidate_terminally_invalidated:
        return None
    lineage_started = event.approach_lineage_started_at is not None or event.control is InteractionControl.INTERACTION_ACTIVE
    if not lineage_started:
        return None
    aid = deterministic_id("D3-ANCHOR-EP", candidate.candidate_id, candidate.target_trend_episode_id, str(cutoff))
    return AnchorEpisode(
        anchor_episode_id=aid,
        candidate_id=candidate.candidate_id,
        target_trend_episode_id=candidate.target_trend_episode_id,
        target_direction=candidate.target_direction,
        validity=AnchorValidity.PROVISIONAL,
        activity=AnchorActivity.ACTIVE,
        started_at=cutoff,
        ended_at=None,
        interaction_event_ids=(event.event_id,),
        qualified_uses=(),
        terminal_true_break=False,
        dossier=empty_dossier(),
        provenance={"candidate_family": candidate.family.value},
    )


def attach_interaction(episode: AnchorEpisode, event: InteractionEvent) -> AnchorEpisode:
    ids = episode.interaction_event_ids
    if event.event_id not in ids:
        ids = ids + (event.event_id,)
    activity = AnchorActivity.PRESSURED if event.control is InteractionControl.INTERACTION_ACTIVE else episode.activity
    return replace(episode, interaction_event_ids=ids, activity=activity)


def add_qualified_boundary_use(episode: AnchorEpisode, use: QualifiedBoundaryUse) -> AnchorEpisode:
    if use.anchor_episode_id != episode.anchor_episode_id:
        raise ValueError("QBU belongs to another Anchor Episode")
    if use.negotiation_event_id not in episode.interaction_event_ids:
        raise ValueError("QBU requires causal interaction lineage in this episode")
    return replace(
        episode,
        validity=AnchorValidity.VALID,
        activity=AnchorActivity.ACTIVE,
        qualified_uses=episode.qualified_uses + (use,),
        dossier=replace(episode.dossier, independent_retest_evidence=InfoValue.known("QUALIFIED_BOUNDARY_USE")),
    )


def terminate_for_true_break(episode: AnchorEpisode, *, cutoff: int) -> AnchorEpisode:
    return replace(
        episode,
        validity=AnchorValidity.TERMINATED,
        activity=AnchorActivity.TERMINATED,
        ended_at=cutoff,
        terminal_true_break=True,
        dossier=replace(episode.dossier, true_break_evidence=InfoValue.known(BreakState.TRUE_BREAK.value)),
    )


def recover_from_pressure(episode: AnchorEpisode, event: InteractionEvent) -> AnchorEpisode:
    if episode.validity is AnchorValidity.VALID and event.resolution is InteractionResolution.RESOLVED_CORRECT_SIDE:
        return replace(episode, activity=AnchorActivity.ACTIVE)
    return episode


def terminate_episode(episode: AnchorEpisode, *, cutoff: int, reason: str) -> AnchorEpisode:
    return replace(
        episode,
        validity=AnchorValidity.TERMINATED,
        activity=AnchorActivity.TERMINATED,
        ended_at=cutoff,
        provenance={**dict(episode.provenance), "termination_reason": reason},
    )


def bind_event_to_episode(event: InteractionEvent, episode: AnchorEpisode) -> InteractionEvent:
    if event.candidate_id != episode.candidate_id:
        raise ValueError("event/candidate mismatch")
    return replace(event, anchor_episode_id=episode.anchor_episode_id)


def make_qualified_boundary_use(
    episode: AnchorEpisode,
    event: InteractionEvent,
    progress: TrendSideMinorProgressEvidence,
) -> QualifiedBoundaryUse:
    if event.anchor_episode_id != episode.anchor_episode_id:
        raise ValueError("event is not attached to this Anchor Episode")
    if event.resolution is not InteractionResolution.RESOLVED_CORRECT_SIDE:
        raise ValueError("Qualified Boundary Use requires correct-side resolved negotiation")
    if event.break_state is BreakState.TRUE_BREAK:
        raise ValueError("True Break cannot qualify as correct-side boundary use")
    if not progress.material_progress or progress.timeframe_ms != 15 * 60 * 1000 or progress.layer != "MINOR":
        raise ValueError("Qualified Boundary Use requires subsequent material trend-side 15M Minor progress")
    if progress.confirmed_at <= (event.resolved_at or -1):
        raise ValueError("trend-side progress must be subsequent to correct-side resolution")
    return QualifiedBoundaryUse(
        use_id=deterministic_id("D3-QBU", episode.anchor_episode_id, event.event_id, progress.pivot_id),
        anchor_episode_id=episode.anchor_episode_id,
        negotiation_event_id=event.event_id,
        correct_side_resolution_cutoff=event.resolved_at or 0,
        trend_side_minor_progress_pivot_id=progress.pivot_id,
        progress_confirmed_at=progress.confirmed_at,
    )
