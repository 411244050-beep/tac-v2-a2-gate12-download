"""D3-owned slices of RC1 F9 global update order only."""

D3_UPDATE_ORDER = (
    "UPDATE-002_CAPTURE_BAR_T_BOUNDARY_GEOMETRY_FROM_PRE_BAR_SNAPSHOTS",
    "UPDATE-007_RESOLVE_UPGRADE_INTERACTION_BREAK_USING_UPDATE002_PLUS_UPDATE005_STRUCTURE",
    "UPDATE-008_UPDATE_ANCHOR_CANDIDATE_VALIDITY_CLUSTER_ROLES_FOR_FUTURE_BARS",
)

FORBIDDEN_D3_WRITES = (
    "MarketTrend",
    "PriceStructure",
    "ENTRY_READY",
    "RiskFeasibility",
    "RiskAnchor",
    "Position",
    "Exit",
    "Execution",
)

CUTOFF_FIREWALL = {
    "bar_t_geometry_uses_only_pre_bar_snapshot": True,
    "new_bar_t_ema_st_not_back_applied_to_bar_t_high_low": True,
    "new_anchor_values_at_t_eligible_only_for_future_observer_bars": True,
    "same_bar_resolve_rearm_cannot_open_next_event": True,
}
