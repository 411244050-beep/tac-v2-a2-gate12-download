from __future__ import annotations

from fractions import Fraction
from typing import Mapping

from ..d2_market_state.types import TrendDirection
from ..ids import deterministic_id
from ..result_types import Direction
from ..runtime_guards.information_state import InfoKind, InfoValue
from .types import CandidateAvailability, CandidateFamily, MathematicalBoundaryCandidate


def build_candidate(
    *,
    symbol: str,
    source_timeframe_ms: int,
    target_trend_episode_id: str,
    target_direction: TrendDirection,
    family: CandidateFamily,
    line: InfoValue[Fraction],
    source_scale: InfoValue[Fraction],
    source_segment_id: str,
    available_at: int,
    source_continuity_ok: bool,
    st_direction: Direction | None = None,
    provenance: Mapping[str, str] | None = None,
) -> MathematicalBoundaryCandidate:
    """Create a D1 mathematical boundary candidate without creating Trend truth.

    F1 availability is explicit. ST active line is UNAVAILABLE while ST direction
    is UNKNOWN. Source-TF Trend alignment is intentionally not required by F1.
    """
    available = source_continuity_ok and line.kind is InfoKind.KNOWN and source_scale.kind is InfoKind.KNOWN
    if family is CandidateFamily.ST_ACTIVE and (st_direction is None or st_direction is Direction.UNKNOWN):
        available = False
    candidate_id = deterministic_id(
        "D3-CAND",
        symbol,
        str(source_timeframe_ms),
        target_trend_episode_id,
        target_direction.value,
        family.value,
        source_segment_id,
    )
    return MathematicalBoundaryCandidate(
        candidate_id=candidate_id,
        symbol=symbol,
        source_timeframe_ms=source_timeframe_ms,
        target_trend_episode_id=target_trend_episode_id,
        target_direction=target_direction,
        family=family,
        boundary=line if available else InfoValue.na(),
        source_scale=source_scale if available else InfoValue.na(),
        source_segment_id=source_segment_id,
        available_at=available_at,
        availability=CandidateAvailability.AVAILABLE if available else CandidateAvailability.UNAVAILABLE,
        provenance=dict(provenance or {}),
    )
