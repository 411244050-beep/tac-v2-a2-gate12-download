from __future__ import annotations

from dataclasses import replace

from .types import (
    B3Geometry,
    BreakEvaluation,
    BreakState,
    CorrectSideRecoveryEvidence,
    InteractionControl,
    InteractionEvent,
    InteractionResolution,
    StructuralAcceptanceEvidence,
)


def evaluate_break(
    event: InteractionEvent,
    *,
    geometry: B3Geometry,
    structural_acceptance: StructuralAcceptanceEvidence | None = None,
    correct_side_recovery: CorrectSideRecoveryEvidence | None = None,
) -> BreakEvaluation:
    """B4 consumes frozen B3 event reference + D2 confirmed structure evidence."""
    if event.terminal:
        return BreakEvaluation(
            event.break_state, True, event.resolution,
            event.attempted_wrong_side_acceptance,
            event.material_wrong_side_separation_observed,
            event.reclaim_observed,
            "event already terminal",
        )

    # A5: no authoritative break evidence without armed causal interaction lineage.
    if event.control is not InteractionControl.INTERACTION_ACTIVE or event.event_reference_boundary is None:
        if geometry.wrong_side_range_penetration or geometry.wrong_side_close:
            return BreakEvaluation(
                BreakState.WRONG_SIDE_UNARMED, False, InteractionResolution.UNRESOLVED,
                False, False, False, "A5: wrong side without active armed lineage"
            )
        return BreakEvaluation(BreakState.NONE, False, InteractionResolution.UNRESOLVED, False, False, False, "no active interaction")

    attempted = event.attempted_wrong_side_acceptance or geometry.wrong_side_close
    material = event.material_wrong_side_separation_observed or geometry.material_wrong_side_separation
    reclaim = event.reclaim_observed

    if geometry.wrong_side_range_penetration and not geometry.wrong_side_close:
        state = BreakState.PROBE
    elif geometry.wrong_side_close:
        state = BreakState.TEMPORARY_BREAK
    else:
        state = event.break_state if event.break_state in (BreakState.TEMPORARY_BREAK, BreakState.RECLAIMING, BreakState.PROBE) else BreakState.NONE

    sa = structural_acceptance or StructuralAcceptanceEvidence()
    if material and (sa.continuation_acceptance or sa.failed_return_acceptance):
        return BreakEvaluation(
            BreakState.TRUE_BREAK,
            True,
            InteractionResolution.RESOLVED_WRONG_SIDE,
            attempted,
            True,
            reclaim,
            "material wrong-side separation + completed wrong-side structural acceptance",
        )

    had_temp = event.break_state in (BreakState.TEMPORARY_BREAK, BreakState.RECLAIMING) or attempted
    if had_temp and not geometry.wrong_side_close:
        reclaim = True
        state = BreakState.RECLAIMING

    cr = correct_side_recovery or CorrectSideRecoveryEvidence()
    if attempted and reclaim and cr.turning_structure_confirmed and cr.material_correct_side_structural_recovery:
        return BreakEvaluation(
            BreakState.FALSE_BREAK,
            True,
            InteractionResolution.RESOLVED_CORRECT_SIDE,
            True,
            material,
            True,
            "attempted acceptance + reclaim + confirmed turning structure + material correct-side recovery",
        )

    return BreakEvaluation(state, False, InteractionResolution.UNRESOLVED, attempted, material, reclaim, "non-terminal B4 state")


def apply_break_evaluation(event: InteractionEvent, evaluation: BreakEvaluation, *, cutoff: int) -> InteractionEvent:
    updated = replace(
        event,
        attempted_wrong_side_acceptance=evaluation.attempted_wrong_side_acceptance,
        material_wrong_side_separation_observed=evaluation.material_wrong_side_separation_observed,
        reclaim_observed=evaluation.reclaim_observed,
        break_state=evaluation.break_state,
        terminal=evaluation.terminal,
    )
    if evaluation.terminal:
        updated = replace(
            updated,
            control=InteractionControl.RESOLVED,
            resolution=evaluation.resolution,
            resolved_at=cutoff,
        )
    return updated
