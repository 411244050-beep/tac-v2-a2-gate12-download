from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction

from ..parameter_snapshot import ParameterSnapshot, ParameterState


@dataclass(frozen=True)
class FrozenD3Parameters:
    theta_test: Fraction
    theta_approach: Fraction
    theta_separation: Fraction
    theta_accept: Fraction
    theta_progress: Fraction


def _frozen_fraction(snapshot: ParameterSnapshot, name: str) -> Fraction:
    slot = snapshot.slot(name)
    if slot.state is not ParameterState.FROZEN or slot.exact_value is None:
        raise ValueError(f"{name} must be FROZEN with an exact value for WP3")
    return Fraction(slot.exact_value)


def frozen_d3_parameters(snapshot: ParameterSnapshot) -> FrozenD3Parameters:
    p = FrozenD3Parameters(
        theta_test=_frozen_fraction(snapshot, "theta_test"),
        theta_approach=_frozen_fraction(snapshot, "theta_approach"),
        theta_separation=_frozen_fraction(snapshot, "theta_separation"),
        theta_accept=_frozen_fraction(snapshot, "theta_accept"),
        theta_progress=_frozen_fraction(snapshot, "theta_progress"),
    )
    if not (Fraction(0) <= p.theta_test < p.theta_approach < p.theta_separation):
        raise ValueError("RC1 B3 geometry ordering violated")
    if p.theta_accept <= 0:
        raise ValueError("theta_accept must be > 0")
    return p
