from __future__ import annotations

from ..ids import deterministic_id
from .types import CandidateAvailability, CausalBoundarySnapshot, MathematicalBoundaryCandidate, PreBarBoundaryView


def snapshot_from_candidate(candidate: MathematicalBoundaryCandidate, *, anchor_episode_id: str | None) -> CausalBoundarySnapshot | None:
    if candidate.availability is CandidateAvailability.UNAVAILABLE:
        return None
    boundary = candidate.boundary.require_known()
    scale = candidate.source_scale.require_known()
    return CausalBoundarySnapshot(
        snapshot_id=deterministic_id("D3-SNAPSHOT", candidate.candidate_id, str(candidate.available_at), anchor_episode_id or "WATCH"),
        candidate_id=candidate.candidate_id,
        anchor_episode_id=anchor_episode_id,
        symbol=candidate.symbol,
        source_timeframe_ms=candidate.source_timeframe_ms,
        target_trend_episode_id=candidate.target_trend_episode_id,
        target_direction=candidate.target_direction,
        family=candidate.family,
        boundary=boundary,
        source_scale=scale,
        source_segment_id=candidate.source_segment_id,
        available_at=candidate.available_at,
        provenance=dict(candidate.provenance),
    )


def pre_bar_view(observer_open_time: int, snapshots: list[CausalBoundarySnapshot]) -> PreBarBoundaryView:
    """UPDATE-000/002 guard: only snapshots available before bar t began."""
    eligible = [s for s in snapshots if s.available_at < observer_open_time]
    latest: dict[str, CausalBoundarySnapshot] = {}
    for s in sorted(eligible, key=lambda x: (x.available_at, x.snapshot_id)):
        latest[s.candidate_id] = s
    return PreBarBoundaryView(observer_open_time=observer_open_time, snapshots=tuple(latest.values()))
