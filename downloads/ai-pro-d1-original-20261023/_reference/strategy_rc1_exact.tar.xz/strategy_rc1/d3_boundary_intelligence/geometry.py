from __future__ import annotations

from fractions import Fraction

from ..d1_data_math.ohlc_protocol import OHLCBar
from ..d2_market_state.types import TrendDirection
from .parameters import FrozenD3Parameters
from .types import B3Geometry, CausalBoundarySnapshot, PriceDrivenReturnEvidence


def _sign(direction: TrendDirection) -> int:
    if direction is TrendDirection.LONG:
        return 1
    if direction is TrendDirection.SHORT:
        return -1
    raise ValueError("B3 geometry requires active LONG/SHORT target Trend")


def _classify_values(
    *,
    bar: OHLCBar,
    information_cutoff: int,
    reference_id: str,
    direction: TrendDirection,
    boundary: Fraction,
    scale: Fraction,
    params: FrozenD3Parameters,
) -> B3Geometry:
    s = _sign(direction)
    if scale <= 0:
        raise ValueError("source scale must be positive")
    d_close = Fraction(s) * (bar.close - boundary) / scale
    if direction is TrendDirection.LONG:
        d_range = (bar.low - boundary) / scale
    else:
        d_range = (boundary - bar.high) / scale

    test = d_range <= params.theta_test
    approach = params.theta_test < d_range <= params.theta_approach
    separated = d_close >= params.theta_separation
    hysteresis = d_range > params.theta_approach and d_close < params.theta_separation
    return B3Geometry(
        information_cutoff=information_cutoff,
        snapshot_id=reference_id,
        d_close=d_close,
        d_range_nearest=d_range,
        test=test,
        approach=approach,
        separated=separated,
        hysteresis_intermediate=hysteresis,
        wrong_side_range_penetration=d_range < 0,
        wrong_side_close=d_close < 0,
        material_wrong_side_separation=d_close <= -params.theta_accept,
    )


def classify_geometry(
    *,
    bar: OHLCBar,
    information_cutoff: int,
    snapshot: CausalBoundarySnapshot,
    params: FrozenD3Parameters,
) -> B3Geometry:
    """Exact adopted post-RC1 B3 zone classifier.

    TEST/APPROACH are mutually exclusive range predicates. SEPARATED is an
    independent close predicate and may coexist with TEST.
    """
    return _classify_values(
        bar=bar,
        information_cutoff=information_cutoff,
        reference_id=snapshot.snapshot_id,
        direction=snapshot.target_direction,
        boundary=snapshot.boundary,
        scale=snapshot.source_scale,
        params=params,
    )


def classify_event_reference_geometry(
    *,
    bar: OHLCBar,
    information_cutoff: int,
    event,
    params: FrozenD3Parameters,
) -> B3Geometry:
    """Classify active B3/B4 event against frozen reference, never Anchor drift."""
    if event.event_reference_boundary is None or event.event_reference_scale is None:
        raise ValueError("event has no frozen reference")
    return _classify_values(
        bar=bar,
        information_cutoff=information_cutoff,
        reference_id=f"EVENT_REFERENCE:{event.event_id}",
        direction=event.target_direction,
        boundary=event.event_reference_boundary,
        scale=event.event_reference_scale,
        params=params,
    )


def qualify_price_driven_return(
    *, adverse_raw_movement: Fraction,
    source_scale: Fraction,
    params: FrozenD3Parameters,
    provenance: dict[str, str] | None = None,
) -> PriceDrivenReturnEvidence:
    """F3 return threshold only; caller must provide actual raw-price movement.

    RC1 freezes the required magnitude but not an extra theta_return. This helper
    does not invent a return-origin convention; raw movement + provenance must
    come from the caller's causal price path.
    """
    if adverse_raw_movement < 0 or source_scale <= 0:
        raise ValueError("invalid adverse movement/source scale")
    minimum = (params.theta_separation - params.theta_approach) * source_scale
    return PriceDrivenReturnEvidence(
        passed=adverse_raw_movement >= minimum,
        adverse_raw_movement=adverse_raw_movement,
        minimum_required=minimum,
        provenance=dict(provenance or {}),
    )
