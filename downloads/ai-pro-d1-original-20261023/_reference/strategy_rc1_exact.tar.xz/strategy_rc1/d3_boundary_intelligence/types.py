from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from fractions import Fraction
from typing import Mapping

from ..d2_market_state.types import StructuralCorridor, TrendDirection
from ..runtime_guards.information_state import InfoValue


class CandidateFamily(str, Enum):
    EMA20 = "EMA20"
    EMA50 = "EMA50"
    ST_ACTIVE = "ST_ACTIVE"


class CandidateAvailability(str, Enum):
    AVAILABLE = "AVAILABLE"
    UNAVAILABLE = "UNAVAILABLE"


class AnchorValidity(str, Enum):
    PROVISIONAL = "PROVISIONAL"
    VALID = "VALID"
    TERMINATED = "TERMINATED"


class AnchorActivity(str, Enum):
    ACTIVE = "ACTIVE"
    PRESSURED = "PRESSURED"
    TERMINATED = "TERMINATED"


class InteractionControl(str, Enum):
    UNARMED = "UNARMED"
    ARMED = "ARMED"
    INTERACTION_ACTIVE = "INTERACTION_ACTIVE"
    RESOLVED = "RESOLVED"


class InteractionResolution(str, Enum):
    RESOLVED_CORRECT_SIDE = "RESOLVED_CORRECT_SIDE"
    RESOLVED_WRONG_SIDE = "RESOLVED_WRONG_SIDE"
    UNRESOLVED = "UNRESOLVED"
    ABORTED_APPROACH = "ABORTED_APPROACH"
    UNKNOWN_CONTINUITY = "UNKNOWN_CONTINUITY"


class BreakState(str, Enum):
    NONE = "NONE"
    WRONG_SIDE_UNARMED = "WRONG_SIDE_UNARMED"
    PROBE = "PROBE"
    TEMPORARY_BREAK = "TEMPORARY_BREAK"
    RECLAIMING = "RECLAIMING"
    TRUE_BREAK = "TRUE_BREAK"
    FALSE_BREAK = "FALSE_BREAK"


class Role(str, Enum):
    PRIMARY = "PRIMARY"
    SECONDARY = "SECONDARY"
    STRUCTURAL = "STRUCTURAL"


class RoleTransition(str, Enum):
    NONE = "NONE"
    HANDOFF = "HANDOFF"
    PROMOTION = "PROMOTION"
    REPLACEMENT = "REPLACEMENT"
    UNRESOLVED = "UNRESOLVED"


class StructuralDepthRelation(str, Enum):
    SAME_LAYER = "SAME_LAYER"
    DEEPER = "DEEPER"
    SHALLOWER = "SHALLOWER"
    UNRESOLVED = "UNRESOLVED"


@dataclass(frozen=True)
class MathematicalBoundaryCandidate:
    candidate_id: str
    symbol: str
    source_timeframe_ms: int
    target_trend_episode_id: str
    target_direction: TrendDirection
    family: CandidateFamily
    boundary: InfoValue[Fraction]
    source_scale: InfoValue[Fraction]
    source_segment_id: str
    available_at: int
    availability: CandidateAvailability
    provenance: Mapping[str, str]


@dataclass(frozen=True)
class CausalBoundarySnapshot:
    snapshot_id: str
    candidate_id: str
    anchor_episode_id: str | None
    symbol: str
    source_timeframe_ms: int
    target_trend_episode_id: str
    target_direction: TrendDirection
    family: CandidateFamily
    boundary: Fraction
    source_scale: Fraction
    source_segment_id: str
    available_at: int
    provenance: Mapping[str, str]


@dataclass(frozen=True)
class B3Geometry:
    information_cutoff: int
    snapshot_id: str
    d_close: Fraction
    d_range_nearest: Fraction
    test: bool
    approach: bool
    separated: bool
    hysteresis_intermediate: bool
    wrong_side_range_penetration: bool
    wrong_side_close: bool
    material_wrong_side_separation: bool


@dataclass(frozen=True)
class PriceDrivenReturnEvidence:
    passed: bool
    adverse_raw_movement: Fraction
    minimum_required: Fraction
    provenance: Mapping[str, str]


@dataclass(frozen=True)
class StructuralAcceptanceEvidence:
    continuation_acceptance: bool = False
    failed_return_acceptance: bool = False
    confirmed_wrong_side_minor_extreme_id: str | None = None
    renewed_wrong_side_progress_pivot_id: str | None = None
    failed_return_progress_pivot_id: str | None = None


@dataclass(frozen=True)
class CorrectSideRecoveryEvidence:
    turning_structure_confirmed: bool = False
    material_correct_side_structural_recovery: bool = False
    turning_pivot_id: str | None = None
    recovery_pivot_id: str | None = None


@dataclass(frozen=True)
class InteractionEvent:
    event_id: str
    candidate_id: str
    anchor_episode_id: str | None
    target_trend_episode_id: str
    target_direction: TrendDirection
    control: InteractionControl
    resolution: InteractionResolution
    event_reference_boundary: Fraction | None
    event_reference_scale: Fraction | None
    started_at: int | None
    resolved_at: int | None
    armed_at: int | None
    approach_lineage_started_at: int | None
    attempted_wrong_side_acceptance: bool
    material_wrong_side_separation_observed: bool
    reclaim_observed: bool
    break_state: BreakState
    terminal: bool
    provenance: Mapping[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class BreakEvaluation:
    break_state: BreakState
    terminal: bool
    resolution: InteractionResolution
    attempted_wrong_side_acceptance: bool
    material_wrong_side_separation_observed: bool
    reclaim_observed: bool
    reason: str


@dataclass(frozen=True)
class TrendSideMinorProgressEvidence:
    pivot_id: str
    confirmed_at: int
    material_progress: bool
    timeframe_ms: int
    layer: str = "MINOR"


@dataclass(frozen=True)
class QualifiedBoundaryUse:
    use_id: str
    anchor_episode_id: str
    negotiation_event_id: str
    correct_side_resolution_cutoff: int
    trend_side_minor_progress_pivot_id: str
    progress_confirmed_at: int


@dataclass(frozen=True)
class AnchorEvidenceDossier:
    boundary_side_integrity: InfoValue[str]
    structural_integrity: InfoValue[str]
    slope_alignment: InfoValue[str]
    independent_retest_evidence: InfoValue[str]
    retest_quality: InfoValue[str]
    current_relevance: InfoValue[str]
    true_break_evidence: InfoValue[str]
    data_confidence: InfoValue[str]


@dataclass(frozen=True)
class AnchorEpisode:
    anchor_episode_id: str
    candidate_id: str
    target_trend_episode_id: str
    target_direction: TrendDirection
    validity: AnchorValidity
    activity: AnchorActivity
    started_at: int
    ended_at: int | None
    interaction_event_ids: tuple[str, ...]
    qualified_uses: tuple[QualifiedBoundaryUse, ...]
    terminal_true_break: bool
    dossier: AnchorEvidenceDossier
    provenance: Mapping[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class BoundaryContactZone:
    zone_id: str
    anchor_episode_id: str
    lower: Fraction
    upper: Fraction
    information_cutoff: int
    provenance: Mapping[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if self.upper < self.lower:
            raise ValueError("contact zone upper < lower")

    def intersects(self, lower: Fraction, upper: Fraction) -> bool:
        return self.lower <= upper and lower <= self.upper


@dataclass(frozen=True)
class EconomicBoundaryUnit:
    unit_id: str
    anchor_episode_ids: tuple[str, ...]
    contact_zones: tuple[BoundaryContactZone, ...]
    is_cluster: bool
    provenance: Mapping[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class BoundaryUnitRoleEvidence:
    unit: EconomicBoundaryUnit
    at_least_one_valid_member: bool
    current_relevant: bool
    latest_qualified_use_cutoff: int | None
    terminal_true_break: bool
    active_qualifying_interaction: bool
    unresolved_conflict: bool
    structural_depth_relation_to_primary: StructuralDepthRelation = StructuralDepthRelation.UNRESOLVED


@dataclass(frozen=True)
class EntryAnchorReference:
    """Interface-only reference: Entry Anchor need not equal Primary.

    WP3 does not create Opportunity or ENTRY_READY; a later D4 layer may consume
    a validated active Economic Boundary Unit through this reference.
    """
    unit_id: str
    validation_provenance: Mapping[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class RoleAssignment:
    primary_unit_id: str | None
    secondary_unit_id: str | None
    structural_unit_ids: tuple[str, ...]
    transition: RoleTransition
    unresolved_reason: str | None


@dataclass(frozen=True)
class PreBarBoundaryView:
    observer_open_time: int
    snapshots: tuple[CausalBoundarySnapshot, ...]


@dataclass(frozen=True)
class D3CutoffView:
    information_cutoff: int
    update_002_geometry: tuple[B3Geometry, ...]
    update_007_events: tuple[InteractionEvent, ...]
    update_008_anchor_episodes: tuple[AnchorEpisode, ...]
    update_008_units: tuple[EconomicBoundaryUnit, ...]
    update_008_roles: RoleAssignment | None
