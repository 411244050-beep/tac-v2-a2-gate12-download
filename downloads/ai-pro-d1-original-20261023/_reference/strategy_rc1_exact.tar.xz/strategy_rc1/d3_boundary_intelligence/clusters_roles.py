from __future__ import annotations

from fractions import Fraction

from ..d2_market_state.types import StructuralCorridor
from ..ids import deterministic_id
from .types import (
    BoundaryContactZone,
    BoundaryUnitRoleEvidence,
    EconomicBoundaryUnit,
    RoleAssignment,
    RoleTransition,
    StructuralDepthRelation,
)


def cluster_units(zones: list[BoundaryContactZone]) -> tuple[EconomicBoundaryUnit, ...]:
    """Connected components over already-authoritative causal B3 contact zones.

    No new distance threshold or synthetic cluster center is created.
    """
    if not zones:
        return ()
    remaining = sorted(zones, key=lambda z: (z.lower, z.upper, z.anchor_episode_id))
    components: list[list[BoundaryContactZone]] = []
    current: list[BoundaryContactZone] = [remaining[0]]
    current_upper = remaining[0].upper
    for z in remaining[1:]:
        if z.lower <= current_upper:
            current.append(z)
            if z.upper > current_upper:
                current_upper = z.upper
        else:
            components.append(current)
            current = [z]
            current_upper = z.upper
    components.append(current)

    units: list[EconomicBoundaryUnit] = []
    for comp in components:
        members = tuple(sorted({z.anchor_episode_id for z in comp}))
        unit_id = deterministic_id("D3-EBU", *members, str(max(z.information_cutoff for z in comp)))
        units.append(
            EconomicBoundaryUnit(
                unit_id=unit_id,
                anchor_episode_ids=members,
                contact_zones=tuple(comp),
                is_cluster=len(members) > 1,
                provenance={"geometry": "CONNECTED_CAUSAL_B3_CONTACT_ZONES_NO_SYNTHETIC_LINE"},
            )
        )
    return tuple(units)


def unit_intersects_corridor(unit: EconomicBoundaryUnit, corridor: StructuralCorridor | None) -> bool:
    if corridor is None:
        return False
    return any(z.intersects(corridor.lower, corridor.upper) for z in unit.contact_zones)


def unit_intersects_protected_zone(unit: EconomicBoundaryUnit, *, protected_price: Fraction, protected_scale: Fraction, theta_progress: Fraction) -> bool:
    lower = protected_price - theta_progress * protected_scale
    upper = protected_price + theta_progress * protected_scale
    return any(z.intersects(lower, upper) for z in unit.contact_zones)


def current_relevance(
    unit: EconomicBoundaryUnit,
    *,
    corridor: StructuralCorridor | None,
    has_actual_market_use: bool,
    active_qualifying_interaction: bool,
) -> bool:
    return unit_intersects_corridor(unit, corridor) and (has_actual_market_use or active_qualifying_interaction)


def assign_roles(
    evidence: list[BoundaryUnitRoleEvidence],
    *,
    structural_suitable_unit_ids: set[str],
    prior_primary_unit_id: str | None = None,
    old_episode_ended: bool = False,
    takeover_depth_relation: StructuralDepthRelation = StructuralDepthRelation.UNRESOLVED,
    next_deeper_unit_id: str | None = None,
) -> RoleAssignment:
    """Event-driven role selection without score/family/distance tie-breaking.

    PRIMARY uses most-recent Qualified Boundary Use. Same-cutoff ambiguity is
    UNRESOLVED. SECONDARY requires an explicit DEEPER structural relation to the
    chosen primary; if several equally admissible units remain, it is UNRESOLVED.
    """
    eligible = [
        e for e in evidence
        if e.at_least_one_valid_member and e.current_relevant and e.latest_qualified_use_cutoff is not None
        and not e.terminal_true_break and not e.unresolved_conflict
    ]
    if not eligible:
        return RoleAssignment(None, None, tuple(sorted(structural_suitable_unit_ids)), RoleTransition.NONE, None)

    latest = max(e.latest_qualified_use_cutoff for e in eligible if e.latest_qualified_use_cutoff is not None)
    primaries = [e for e in eligible if e.latest_qualified_use_cutoff == latest]
    if len(primaries) != 1:
        return RoleAssignment(None, None, tuple(sorted(structural_suitable_unit_ids)), RoleTransition.UNRESOLVED, "multiple independent units satisfy Primary at same cutoff")
    primary = primaries[0]

    deeper = [e for e in eligible if e.unit.unit_id != primary.unit.unit_id and e.structural_depth_relation_to_primary is StructuralDepthRelation.DEEPER]
    secondary_id: str | None = None
    unresolved: str | None = None
    if deeper:
        if len(deeper) == 1:
            chosen = deeper[0]
        elif next_deeper_unit_id is not None:
            matches = [e for e in deeper if e.unit.unit_id == next_deeper_unit_id]
            chosen = matches[0] if len(matches) == 1 else None
        else:
            chosen = None
        if chosen is None:
            unresolved = "next-deeper Secondary relation not uniquely established by supplied Price Structure context"
        elif set(chosen.unit.anchor_episode_ids).isdisjoint(primary.unit.anchor_episode_ids):
            secondary_id = chosen.unit.unit_id

    if unresolved is not None:
        transition = RoleTransition.UNRESOLVED
    elif prior_primary_unit_id is None or prior_primary_unit_id == primary.unit.unit_id:
        transition = RoleTransition.NONE
    elif old_episode_ended:
        transition = RoleTransition.REPLACEMENT
    elif takeover_depth_relation is StructuralDepthRelation.DEEPER:
        transition = RoleTransition.PROMOTION
    elif takeover_depth_relation is StructuralDepthRelation.SAME_LAYER:
        transition = RoleTransition.HANDOFF
    else:
        transition = RoleTransition.UNRESOLVED
        unresolved = "takeover depth relation unresolved"

    return RoleAssignment(
        primary_unit_id=primary.unit.unit_id,
        secondary_unit_id=secondary_id,
        structural_unit_ids=tuple(sorted(structural_suitable_unit_ids)),
        transition=transition,
        unresolved_reason=unresolved,
    )


def structural_role_eligible(
    evidence: BoundaryUnitRoleEvidence,
    *,
    protected_price: Fraction,
    protected_scale: Fraction,
    theta_progress: Fraction,
) -> bool:
    """A3/F1/B5 Structural-role gate; role multiplicity remains allowed."""
    return (
        evidence.at_least_one_valid_member
        and evidence.current_relevant
        and evidence.latest_qualified_use_cutoff is not None
        and not evidence.terminal_true_break
        and not evidence.unresolved_conflict
        and unit_intersects_protected_zone(
            evidence.unit,
            protected_price=protected_price,
            protected_scale=protected_scale,
            theta_progress=theta_progress,
        )
    )
