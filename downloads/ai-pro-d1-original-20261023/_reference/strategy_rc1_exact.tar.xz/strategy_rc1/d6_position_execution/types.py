from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from fractions import Fraction
from types import MappingProxyType
from typing import Mapping

from ..d2_market_state.types import StructuralLayer, StructuralPivot, TrendDirection
from ..d5_risk.types import DecisionResult, DecisionState
from ..runtime_guards.information_state import InfoValue


class PositionProvenanceClass(str, Enum):
    AUTHORITATIVE_STRATEGY = "AUTHORITATIVE_STRATEGY"
    NONAUTHORITATIVE_SYNTHETIC_FIXTURE_ONLY = "NONAUTHORITATIVE_SYNTHETIC_FIXTURE_ONLY"


class PositionMode(str, Enum):
    ACTIVE = "ACTIVE"
    DEGRADED_PROTECTIVE = "DEGRADED_PROTECTIVE"
    CLOSED = "CLOSED"


class PositionObserverLabel(str, Enum):
    INITIAL_RISK = "INITIAL_RISK"
    STRUCTURE_CONFIRMED = "STRUCTURE_CONFIRMED"
    TREND_RIDE = "TREND_RIDE"
    PRESSURED = "PRESSURED"
    EXIT_CANDIDATE = "EXIT_CANDIDATE"


class StrategyExitReason(str, Enum):
    HARD_RISK_STOP = "HARD_RISK_STOP"
    ENTRY_THESIS_FAILURE = "ENTRY_THESIS_FAILURE"
    MANAGEMENT_STRUCTURE_FAILURE = "MANAGEMENT_STRUCTURE_FAILURE"
    MARKET_STRUCTURAL_FAILURE = "MARKET_STRUCTURAL_FAILURE"
    TREND_EPISODE_END = "TREND_EPISODE_END"


class ExitSource(str, Enum):
    EXECUTION_HARD_PROTECTION = "EXECUTION_HARD_PROTECTION"
    STRATEGY_CLOSED_BAR = "STRATEGY_CLOSED_BAR"


class ExecutionStatus(str, Enum):
    EXECUTABLE = "EXECUTABLE"
    BLOCKED = "BLOCKED"
    MISSED = "MISSED"
    FAILED = "FAILED"
    CANCELLED_BY_STRATEGY = "CANCELLED_BY_STRATEGY"
    EXPIRED = "EXPIRED"


class TrendEpisodeEndCause(str, Enum):
    NONE = "NONE"
    STRUCTURAL_FAILURE = "STRUCTURAL_FAILURE"
    AUTHORIZED_NONSTRUCTURAL = "AUTHORIZED_NONSTRUCTURAL"
    GAP = "GAP"
    UNKNOWN = "UNKNOWN"


@dataclass(frozen=True)
class FrozenEntryProvenance:
    provenance_class: PositionProvenanceClass
    entry_ready_id: str
    entry_ready_cutoff: int
    symbol: str
    direction: TrendDirection
    trend_episode_id: str
    opportunity_id: str
    market_event_id: str
    entry_boundary_unit_id: str | None
    risk_anchor_id: str
    risk_anchor_pivot_id: str
    risk_anchor_layer: StructuralLayer
    risk_anchor_price: Fraction
    risk_anchor_scale: Fraction
    risk_anchor_confirmed_at: int
    risk_anchor_timeframe_ms: int
    canonical_segment_id: str
    strategy_entry_reference_price: Fraction
    initial_hard_stop_state: DecisionState
    initial_hard_stop_numeric: Fraction | None
    provenance: Mapping[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        object.__setattr__(self, "provenance", MappingProxyType(dict(self.provenance)))
        if self.direction not in (TrendDirection.LONG, TrendDirection.SHORT):
            raise ValueError("Position entry provenance requires LONG/SHORT")
        if not self.entry_ready_id or not self.symbol or not self.trend_episode_id or not self.opportunity_id:
            raise ValueError("frozen entry provenance requires immutable lineage IDs")
        if self.risk_anchor_scale <= 0:
            raise ValueError("risk_anchor_scale must be positive")
        if self.risk_anchor_confirmed_at > self.entry_ready_cutoff:
            raise ValueError("future Risk Anchor cannot be frozen into Entry provenance")
        if self.risk_anchor_timeframe_ms <= 0:
            raise ValueError("risk_anchor_timeframe_ms must be positive")
        if not self.canonical_segment_id:
            raise ValueError("canonical_segment_id required")
        if self.provenance_class is PositionProvenanceClass.AUTHORITATIVE_STRATEGY:
            # In the current WP5/WP6 governance state no authoritative numeric
            # Hard Stop can exist; this guard also prevents synthetic numbers
            # from masquerading as current Strategy history.
            if self.initial_hard_stop_numeric is not None and self.initial_hard_stop_state is not DecisionState.PASS:
                raise ValueError("authoritative numeric Hard Stop requires PASS state")


@dataclass(frozen=True)
class StrategyPositionSnapshot:
    position_id: str
    entry: FrozenEntryProvenance
    opened_from_execution_evidence_id: str | None
    opened_real_time: int | None
    mode: PositionMode
    latest_qualified_protective_pivot: StructuralPivot | None
    current_protective_stop: InfoValue[Fraction]
    observer_label: PositionObserverLabel | None = None
    closed_exit_id: str | None = None
    provenance: Mapping[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        object.__setattr__(self, "provenance", MappingProxyType(dict(self.provenance)))
        if self.mode is PositionMode.CLOSED and self.closed_exit_id is None:
            raise ValueError("CLOSED position requires closed_exit_id")
        if self.mode is not PositionMode.CLOSED and self.closed_exit_id is not None:
            raise ValueError("open position cannot carry closed_exit_id")
        if self.entry.provenance_class is PositionProvenanceClass.AUTHORITATIVE_STRATEGY:
            if not self.opened_from_execution_evidence_id or self.opened_real_time is None:
                raise ValueError("authoritative Strategy Position requires real execution activation evidence")


@dataclass(frozen=True)
class ProtectivePivotEvidence:
    adverse_minor_pivot: StructuralPivot | None
    material_favorable_post_entry_progress: InfoValue[bool]
    trade_thesis_intact: InfoValue[bool]
    trend_thesis_intact: InfoValue[bool]
    local_trend_control_regained: InfoValue[bool]
    provenance: Mapping[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class QualifiedProtectivePivotResult:
    decision: DecisionResult
    pivot: StructuralPivot | None
    symbolic_candidate_stop: str | None
    numeric_candidate_stop: Fraction | None
    theta_stop_state: str

    def __post_init__(self) -> None:
        if self.numeric_candidate_stop is not None:
            raise ValueError("WP6 current governance forbids generating a new numeric protective stop")


@dataclass(frozen=True)
class HardProtectionEvidence:
    triggered: InfoValue[bool]
    execution_event_id: str | None
    real_event_time: int | None
    evidence_source: str = "EXTERNAL_EXECUTION_EVIDENCE_INTERFACE"

    def __post_init__(self) -> None:
        if self.triggered.value is True:
            if not self.execution_event_id or self.real_event_time is None:
                raise ValueError("known Hard Protection trigger requires execution event evidence/time")


@dataclass(frozen=True)
class TrendEpisodeEndEvidence:
    ended: InfoValue[bool]
    cause: TrendEpisodeEndCause
    provenance: Mapping[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        object.__setattr__(self, "provenance", MappingProxyType(dict(self.provenance)))
        if self.cause is TrendEpisodeEndCause.GAP and self.ended.value is True:
            raise ValueError("canonical gap may not be represented as TREND_EPISODE_END")


@dataclass(frozen=True)
class ExitCandidateEvidence:
    management_anchor_true_break: InfoValue[bool] = field(default_factory=InfoValue.unknown)
    entry_risk_anchor_wrong_side_close: InfoValue[bool] = field(default_factory=InfoValue.unknown)


@dataclass(frozen=True)
class TradeExitRecord:
    exit_id: str
    position_id: str
    primary_reason: StrategyExitReason
    source: ExitSource
    strategy_information_cutoff: int | None
    real_event_time: int | None
    concurrent_exit_conditions: tuple[StrategyExitReason, ...]
    supporting_trend_episode_ended: bool
    execution_evidence_id: str | None
    immutable: bool = True

    def __post_init__(self) -> None:
        if not self.immutable:
            raise ValueError("Trade Exit records are immutable")
        if self.source is ExitSource.STRATEGY_CLOSED_BAR and self.strategy_information_cutoff is None:
            raise ValueError("Strategy Exit requires causal closed-bar cutoff")
        if self.source is ExitSource.EXECUTION_HARD_PROTECTION:
            if self.real_event_time is None or not self.execution_evidence_id:
                raise ValueError("Hard Protection exit requires real execution evidence")


@dataclass(frozen=True)
class ExitEvaluation:
    decision: DecisionResult
    exit_record: TradeExitRecord | None
    entry_thesis_failure: DecisionResult
    management_structure_failure: DecisionResult
    market_structural_failure: DecisionResult
    trend_episode_end: DecisionResult
    exit_candidate: DecisionResult
    degraded_protective: bool


@dataclass(frozen=True)
class ExecutionIntentSnapshot:
    execution_intent_id: str
    entry_ready_id: str
    strategy_signal_cutoff: int
    status: ExecutionStatus
    status_event_id: str
    observed_at: int
    immutable_strategy_entry_ready: bool = True

    def __post_init__(self) -> None:
        if not self.immutable_strategy_entry_ready:
            raise ValueError("Execution cannot rewrite historical ENTRY_READY")


@dataclass(frozen=True)
class ReconciliationState:
    strategy_exit_id: str
    residual_real_exposure: InfoValue[bool]
    hard_protection_preserved: InfoValue[bool]
    execution_reconciliation_reference: str | None


@dataclass(frozen=True)
class D6CutoffView:
    information_cutoff: int
    position_id: str
    position_mode: PositionMode
    qualified_protective_pivot: QualifiedProtectivePivotResult
    exit_evaluation: ExitEvaluation
    new_risk_blocked: bool
    update_step: str = "UPDATE-010"
