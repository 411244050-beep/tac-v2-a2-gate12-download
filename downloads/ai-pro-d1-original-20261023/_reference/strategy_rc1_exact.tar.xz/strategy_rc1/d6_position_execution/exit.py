from __future__ import annotations

from fractions import Fraction

from ..d2_market_state.types import PivotType, ProgressRelation, StructuralPivot, TrendDirection
from ..d2_market_state.progress import same_type_progress
from ..d5_risk.types import DecisionResult, DecisionState
from ..ids import deterministic_id
from ..runtime_guards.information_state import InfoKind, InfoValue
from .parameters import D6ParameterView
from .types import (
    ExitCandidateEvidence,
    ExitEvaluation,
    ExitSource,
    HardProtectionEvidence,
    StrategyExitReason,
    StrategyPositionSnapshot,
    TradeExitRecord,
    TrendEpisodeEndCause,
    TrendEpisodeEndEvidence,
)


STRATEGY_EXIT_PRECEDENCE = (
    StrategyExitReason.MARKET_STRUCTURAL_FAILURE,
    StrategyExitReason.TREND_EPISODE_END,
    StrategyExitReason.ENTRY_THESIS_FAILURE,
    StrategyExitReason.MANAGEMENT_STRUCTURE_FAILURE,
)


def _bool_decision(value: InfoValue[bool], *, true_reason: str, false_reason: str) -> DecisionResult:
    if value.kind is InfoKind.ERROR:
        return DecisionResult(DecisionState.ERROR, f"{true_reason}_INPUT_ERROR")
    if value.kind is InfoKind.UNKNOWN:
        return DecisionResult(DecisionState.UNKNOWN, f"{true_reason}_INPUT_UNKNOWN")
    if value.kind in (InfoKind.NONE, InfoKind.NA):
        return DecisionResult(DecisionState.NA, f"{true_reason}_INPUT_NA")
    return DecisionResult(DecisionState.PASS if value.value else DecisionState.FAIL, true_reason if value.value else false_reason)


def _entry_thesis_failure(
    position: StrategyPositionSnapshot,
    new_adverse_pivot: StructuralPivot | None,
    *, information_cutoff: int,
    theta_progress: Fraction,
) -> DecisionResult:
    if new_adverse_pivot is None:
        return DecisionResult(DecisionState.NA, "NO_NEW_ADVERSE_PIVOT_FOR_ENTRY_THESIS")
    p = new_adverse_pivot
    e = position.entry
    if p.confirmed_at > information_cutoff:
        return DecisionResult(DecisionState.ERROR, "FUTURE_CONFIRMED_ENTRY_THESIS_PIVOT_FORBIDDEN")
    if p.symbol != e.symbol or p.timeframe_ms != e.risk_anchor_timeframe_ms or p.layer is not e.risk_anchor_layer:
        return DecisionResult(DecisionState.FAIL, "ENTRY_THESIS_PIVOT_NOT_CORRESPONDING_STRUCTURE_LAYER")
    if p.canonical_segment_id != e.canonical_segment_id:
        return DecisionResult(DecisionState.UNKNOWN, "ENTRY_THESIS_CONTINUITY_BROKEN")
    if p.confirmed_at <= e.risk_anchor_confirmed_at:
        return DecisionResult(DecisionState.FAIL, "ENTRY_THESIS_PIVOT_NOT_CAUSALLY_LATER_THAN_RISK_ANCHOR")
    expected = PivotType.LOW if e.direction is TrendDirection.LONG else PivotType.HIGH
    if p.pivot_type is not expected:
        return DecisionResult(DecisionState.FAIL, "ENTRY_THESIS_PIVOT_NOT_ADVERSE_TYPE")
    delta = (p.extreme_price - e.risk_anchor_price) / e.risk_anchor_scale
    failed = delta < -theta_progress if e.direction is TrendDirection.LONG else delta > theta_progress
    return DecisionResult(
        DecisionState.PASS if failed else DecisionState.FAIL,
        "ENTRY_THESIS_MATERIAL_ADVERSE_PROGRESS_CONFIRMED" if failed else "ENTRY_THESIS_MATERIAL_ADVERSE_PROGRESS_NOT_CONFIRMED",
        provenance={"normalized_delta": str(delta), "theta_progress": str(theta_progress), "source_truth": "D2_CONFIRMED_PRICE_STRUCTURE"},
    )


def _management_structure_failure(
    position: StrategyPositionSnapshot,
    new_adverse_pivot: StructuralPivot | None,
    *, theta_progress: Fraction,
) -> DecisionResult:
    reference = position.latest_qualified_protective_pivot
    if reference is None:
        return DecisionResult(DecisionState.NA, "NO_QUALIFIED_PROTECTIVE_PIVOT_MANAGEMENT_FAILURE_NA")
    if new_adverse_pivot is None:
        return DecisionResult(DecisionState.NA, "NO_NEW_ADVERSE_PIVOT_FOR_MANAGEMENT_FAILURE")
    try:
        relation = same_type_progress(reference, new_adverse_pivot, theta_progress)
    except ValueError as exc:
        if "cross-gap" in str(exc):
            return DecisionResult(DecisionState.UNKNOWN, "MANAGEMENT_STRUCTURE_CONTINUITY_BROKEN")
        return DecisionResult(DecisionState.FAIL, f"MANAGEMENT_STRUCTURE_PIVOT_NOT_COMPARABLE:{exc}")
    failed = (
        relation is ProgressRelation.MATERIAL_ADVANCE_DOWN
        if position.entry.direction is TrendDirection.LONG
        else relation is ProgressRelation.MATERIAL_ADVANCE_UP
    )
    return DecisionResult(
        DecisionState.PASS if failed else DecisionState.FAIL,
        "MANAGEMENT_STRUCTURE_MATERIAL_ADVERSE_PROGRESS_CONFIRMED" if failed else "MANAGEMENT_STRUCTURE_FAILURE_NOT_CONFIRMED",
        provenance={"progress_relation": relation.value, "source_truth": "D2_CONFIRMED_PRICE_STRUCTURE"},
    )


def _trend_end_decision(evidence: TrendEpisodeEndEvidence) -> DecisionResult:
    if evidence.cause is TrendEpisodeEndCause.GAP:
        return DecisionResult(DecisionState.NA, "CANONICAL_GAP_IS_NOT_TREND_EPISODE_END")
    if evidence.cause is TrendEpisodeEndCause.STRUCTURAL_FAILURE:
        return DecisionResult(DecisionState.NA, "STRUCTURAL_FAILURE_USES_MARKET_STRUCTURAL_FAILURE_PRIMARY_REASON")
    if evidence.cause is TrendEpisodeEndCause.UNKNOWN:
        return DecisionResult(DecisionState.UNKNOWN, "TREND_EPISODE_END_CAUSE_UNKNOWN")
    if evidence.cause is TrendEpisodeEndCause.NONE:
        return DecisionResult(DecisionState.FAIL, "TREND_EPISODE_NOT_ENDED")
    return _bool_decision(
        evidence.ended,
        true_reason="AUTHORIZED_NONSTRUCTURAL_TREND_EPISODE_END_CONFIRMED",
        false_reason="AUTHORIZED_NONSTRUCTURAL_TREND_EPISODE_END_NOT_PRESENT",
    )


def _exit_candidate(evidence: ExitCandidateEvidence) -> DecisionResult:
    values = (evidence.management_anchor_true_break, evidence.entry_risk_anchor_wrong_side_close)
    if any(v.kind is InfoKind.ERROR for v in values):
        return DecisionResult(DecisionState.ERROR, "EXIT_CANDIDATE_INPUT_ERROR")
    if any(v.value is True for v in values):
        return DecisionResult(DecisionState.PASS, "SERIOUS_NONTERMINAL_ADVERSE_EVIDENCE_ONLY")
    if any(v.kind is InfoKind.UNKNOWN for v in values):
        return DecisionResult(DecisionState.UNKNOWN, "EXIT_CANDIDATE_INPUT_UNKNOWN")
    return DecisionResult(DecisionState.FAIL, "NO_EXIT_CANDIDATE_EVIDENCE")


def evaluate_exit(
    position: StrategyPositionSnapshot,
    *,
    information_cutoff: int,
    new_adverse_pivot: StructuralPivot | None,
    protected_intermediate_structure_failed: InfoValue[bool],
    trend_episode_end: TrendEpisodeEndEvidence,
    canonical_continuity_intact: InfoValue[bool],
    hard_protection: HardProtectionEvidence,
    exit_candidate_evidence: ExitCandidateEvidence,
    parameters: D6ParameterView,
) -> ExitEvaluation:
    if hard_protection.triggered.value is True:
        if hard_protection.real_event_time is not None and hard_protection.real_event_time > information_cutoff:
            err = DecisionResult(DecisionState.ERROR, "FUTURE_HARD_PROTECTION_EXECUTION_EVIDENCE_FORBIDDEN")
            return ExitEvaluation(err, None, err, err, err, err, _exit_candidate(exit_candidate_evidence), False)
        exit_id = deterministic_id("D6-TRADE-EXIT-HARD-PROTECTION", position.position_id, hard_protection.execution_event_id)
        record = TradeExitRecord(
            exit_id=exit_id,
            position_id=position.position_id,
            primary_reason=StrategyExitReason.HARD_RISK_STOP,
            source=ExitSource.EXECUTION_HARD_PROTECTION,
            strategy_information_cutoff=None,
            real_event_time=hard_protection.real_event_time,
            concurrent_exit_conditions=(StrategyExitReason.HARD_RISK_STOP,),
            supporting_trend_episode_ended=False,
            execution_evidence_id=hard_protection.execution_event_id,
        )
        na = DecisionResult(DecisionState.NA, "TRADE_ALREADY_TERMINATED_BY_EARLIER_HARD_PROTECTION")
        return ExitEvaluation(
            DecisionResult(DecisionState.PASS, "HARD_PROTECTION_ALREADY_TERMINATED_TRADE"),
            record,
            na,
            na,
            na,
            na,
            _exit_candidate(exit_candidate_evidence),
            degraded_protective=False,
        )

    if canonical_continuity_intact.kind is InfoKind.KNOWN and canonical_continuity_intact.value is False:
        # Gap is epistemic degradation, not market failure. Preserve position/protection and block new risk.
        unknown = DecisionResult(DecisionState.UNKNOWN, "CANONICAL_CONTINUITY_GAP_DEGRADED_PROTECTIVE_NO_MARKET_FAILURE")
        return ExitEvaluation(
            unknown,
            None,
            unknown,
            unknown,
            DecisionResult(DecisionState.NA, "GAP_NOT_MARKET_STRUCTURAL_FAILURE"),
            DecisionResult(DecisionState.NA, "GAP_NOT_TREND_EPISODE_END"),
            _exit_candidate(exit_candidate_evidence),
            degraded_protective=True,
        )

    entry_failure = _entry_thesis_failure(position, new_adverse_pivot, information_cutoff=information_cutoff, theta_progress=parameters.theta_progress)
    management_failure = _management_structure_failure(position, new_adverse_pivot, theta_progress=parameters.theta_progress)
    market_failure = _bool_decision(
        protected_intermediate_structure_failed,
        true_reason="B2_PROTECTED_INTERMEDIATE_STRUCTURE_FAILURE_CONFIRMED",
        false_reason="B2_PROTECTED_INTERMEDIATE_STRUCTURE_INTACT",
    )
    trend_end = _trend_end_decision(trend_episode_end)
    exit_candidate = _exit_candidate(exit_candidate_evidence)

    passed: list[StrategyExitReason] = []
    if market_failure.state is DecisionState.PASS:
        passed.append(StrategyExitReason.MARKET_STRUCTURAL_FAILURE)
    if trend_end.state is DecisionState.PASS:
        passed.append(StrategyExitReason.TREND_EPISODE_END)
    if entry_failure.state is DecisionState.PASS:
        passed.append(StrategyExitReason.ENTRY_THESIS_FAILURE)
    if management_failure.state is DecisionState.PASS:
        passed.append(StrategyExitReason.MANAGEMENT_STRUCTURE_FAILURE)

    if not passed:
        # Preserve epistemic states rather than coercing them to a negative market fact.
        if any(x.state is DecisionState.ERROR for x in (entry_failure, management_failure, market_failure, trend_end)):
            overall = DecisionResult(DecisionState.ERROR, "EXIT_EVALUATION_HAS_ERROR_INPUT")
        elif any(x.state is DecisionState.UNKNOWN for x in (entry_failure, management_failure, market_failure, trend_end)):
            overall = DecisionResult(DecisionState.UNKNOWN, "EXIT_EVALUATION_HAS_UNKNOWN_INPUT")
        else:
            overall = DecisionResult(DecisionState.FAIL, "NO_AUTHORITATIVE_EXIT_PREDICATE_CONFIRMED")
        return ExitEvaluation(overall, None, entry_failure, management_failure, market_failure, trend_end, exit_candidate, False)

    primary = next(reason for reason in STRATEGY_EXIT_PRECEDENCE if reason in passed)
    supporting_ended = (
        trend_episode_end.ended.kind is InfoKind.KNOWN and trend_episode_end.ended.value is True
    ) or market_failure.state is DecisionState.PASS
    exit_id = deterministic_id("D6-STRATEGY-EXIT", position.position_id, str(information_cutoff), primary.value)
    record = TradeExitRecord(
        exit_id=exit_id,
        position_id=position.position_id,
        primary_reason=primary,
        source=ExitSource.STRATEGY_CLOSED_BAR,
        strategy_information_cutoff=information_cutoff,
        real_event_time=None,
        concurrent_exit_conditions=tuple(reason for reason in STRATEGY_EXIT_PRECEDENCE if reason in passed),
        supporting_trend_episode_ended=supporting_ended,
        execution_evidence_id=None,
    )
    return ExitEvaluation(
        DecisionResult(DecisionState.PASS, "STRATEGY_EXIT_FROZEN_AT_CAUSAL_CUTOFF"),
        record,
        entry_failure,
        management_failure,
        market_failure,
        trend_end,
        exit_candidate,
        False,
    )
