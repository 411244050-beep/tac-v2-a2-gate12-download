from __future__ import annotations

from fractions import Fraction

from ..d2_market_state.types import PivotType, StructuralLayer, TrendDirection
from ..d5_risk.types import DecisionResult, DecisionState
from ..runtime_guards.information_state import InfoKind
from .parameters import D6ParameterView
from .types import ProtectivePivotEvidence, QualifiedProtectivePivotResult, StrategyPositionSnapshot


def _decision_from_required_bool(value, name: str) -> DecisionResult | None:
    if value.kind is InfoKind.ERROR:
        return DecisionResult(DecisionState.ERROR, f"{name}_ERROR")
    if value.kind is InfoKind.UNKNOWN:
        return DecisionResult(DecisionState.UNKNOWN, f"{name}_UNKNOWN")
    if value.kind in (InfoKind.NONE, InfoKind.NA):
        return DecisionResult(DecisionState.NA, f"{name}_NA")
    if value.value is not True:
        return DecisionResult(DecisionState.FAIL, f"{name}_NOT_SATISFIED")
    return None


def qualify_protective_pivot(
    position: StrategyPositionSnapshot,
    evidence: ProtectivePivotEvidence,
    *,
    information_cutoff: int,
    parameters: D6ParameterView,
) -> QualifiedProtectivePivotResult:
    pivot = evidence.adverse_minor_pivot
    if pivot is None:
        return QualifiedProtectivePivotResult(
            DecisionResult(DecisionState.NA, "NO_ADVERSE_MINOR_PIVOT"), None, None, None, parameters.theta_stop_state.value
        )
    if pivot.confirmed_at > information_cutoff:
        return QualifiedProtectivePivotResult(
            DecisionResult(DecisionState.ERROR, "FUTURE_CONFIRMED_PROTECTIVE_PIVOT_FORBIDDEN"), None, None, None, parameters.theta_stop_state.value
        )
    if pivot.symbol != position.entry.symbol or pivot.canonical_segment_id != position.entry.canonical_segment_id:
        return QualifiedProtectivePivotResult(
            DecisionResult(DecisionState.FAIL, "PROTECTIVE_PIVOT_LINEAGE_OR_CONTINUITY_MISMATCH"), None, None, None, parameters.theta_stop_state.value
        )
    if pivot.layer is not StructuralLayer.MINOR:
        return QualifiedProtectivePivotResult(
            DecisionResult(DecisionState.FAIL, "QUALIFIED_PROTECTIVE_PIVOT_MUST_BE_MINOR"), None, None, None, parameters.theta_stop_state.value
        )
    expected = PivotType.LOW if position.entry.direction is TrendDirection.LONG else PivotType.HIGH
    if pivot.pivot_type is not expected:
        return QualifiedProtectivePivotResult(
            DecisionResult(DecisionState.FAIL, "PROTECTIVE_PIVOT_NOT_ADVERSE_MINOR_SIDE"), None, None, None, parameters.theta_stop_state.value
        )
    for value, name in (
        (evidence.material_favorable_post_entry_progress, "MATERIAL_FAVORABLE_POST_ENTRY_PROGRESS"),
        (evidence.trade_thesis_intact, "TRADE_THESIS_INTACT"),
        (evidence.trend_thesis_intact, "TREND_THESIS_INTACT"),
        (evidence.local_trend_control_regained, "LOCAL_TREND_CONTROL_REGAIN"),
    ):
        decision = _decision_from_required_bool(value, name)
        if decision is not None:
            return QualifiedProtectivePivotResult(decision, None, None, None, parameters.theta_stop_state.value)

    # RC1 requires an authorized stop-clearance profile for the numeric candidate.
    # Current governance keeps theta_stop LOCKED with no value, so only the
    # symbolic relationship may be represented.
    side = "-" if position.entry.direction is TrendDirection.LONG else "+"
    symbolic = f"{pivot.extreme_price} {side} theta_stop * ATR_at_protective_pivot_reference"
    return QualifiedProtectivePivotResult(
        DecisionResult(DecisionState.BLOCKED, "QUALIFIED_PROTECTIVE_PIVOT_BUT_THETA_STOP_LOCKED_NO_NUMERIC_CANDIDATE"),
        pivot,
        symbolic,
        None,
        parameters.theta_stop_state.value,
    )


def monotonic_stop_semantics(direction: TrendDirection, old_stop: Fraction, candidate_stop: Fraction) -> Fraction:
    """Pure RC1 ratchet relation; current WP6 engine never creates candidate_stop numerically."""
    if direction is TrendDirection.LONG:
        return max(old_stop, candidate_stop)
    if direction is TrendDirection.SHORT:
        return min(old_stop, candidate_stop)
    raise ValueError("monotonic stop semantics require LONG/SHORT")
