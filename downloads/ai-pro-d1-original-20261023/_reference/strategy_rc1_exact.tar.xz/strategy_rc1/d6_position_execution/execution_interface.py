from __future__ import annotations

from dataclasses import replace

from ..ids import deterministic_id
from .types import ExecutionIntentSnapshot, ExecutionStatus, ReconciliationState, TradeExitRecord


def create_execution_intent_interface(
    *, entry_ready_id: str, strategy_signal_cutoff: int, status: ExecutionStatus, status_event_id: str, observed_at: int
) -> ExecutionIntentSnapshot:
    """Create a non-ordering execution-state interface. No exchange side effect exists here."""
    return ExecutionIntentSnapshot(
        execution_intent_id=deterministic_id("D6-EXECUTION-INTENT", entry_ready_id),
        entry_ready_id=entry_ready_id,
        strategy_signal_cutoff=strategy_signal_cutoff,
        status=status,
        status_event_id=status_event_id,
        observed_at=observed_at,
    )


def transition_execution_status(
    prior: ExecutionIntentSnapshot, *, status: ExecutionStatus, status_event_id: str, observed_at: int
) -> ExecutionIntentSnapshot:
    if observed_at < prior.observed_at:
        raise ValueError("execution status cannot backdate before prior observation")
    # Return a new immutable snapshot while preserving the original Strategy signal.
    return replace(prior, status=status, status_event_id=status_event_id, observed_at=observed_at)


def reconcile_after_strategy_exit(exit_record: TradeExitRecord, state: ReconciliationState) -> ReconciliationState:
    if state.strategy_exit_id != exit_record.exit_id:
        raise ValueError("reconciliation lineage must reference frozen Strategy/Trade exit")
    return state
