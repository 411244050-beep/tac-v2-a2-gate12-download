from __future__ import annotations

from dataclasses import dataclass, replace

from ..d2_market_state.types import StructuralPivot
from ..runtime_guards.information_state import InfoValue
from .exit import evaluate_exit
from .management import qualify_protective_pivot
from .parameters import D6ParameterView
from .types import (
    D6CutoffView,
    ExitCandidateEvidence,
    HardProtectionEvidence,
    PositionMode,
    ProtectivePivotEvidence,
    StrategyPositionSnapshot,
    TrendEpisodeEndEvidence,
)


@dataclass(frozen=True)
class D6CutoffInput:
    information_cutoff: int
    position: StrategyPositionSnapshot
    protective_pivot_evidence: ProtectivePivotEvidence
    new_adverse_pivot: StructuralPivot | None
    protected_intermediate_structure_failed: InfoValue[bool]
    supporting_trend_episode_end: TrendEpisodeEndEvidence
    canonical_continuity_intact: InfoValue[bool]
    hard_protection: HardProtectionEvidence
    exit_candidate_evidence: ExitCandidateEvidence
    parameters: D6ParameterView


def update_010(inp: D6CutoffInput) -> D6CutoffView:
    if inp.position.mode is PositionMode.CLOSED:
        raise ValueError("UPDATE-010 cannot manage a closed Position")

    qpp = qualify_protective_pivot(
        inp.position,
        inp.protective_pivot_evidence,
        information_cutoff=inp.information_cutoff,
        parameters=inp.parameters,
    )
    management_position = inp.position
    if qpp.pivot is not None:
        # Structural management reference may advance even though the numeric
        # stop candidate is blocked by theta_stop. No stop widening/number is created.
        prior = inp.position.latest_qualified_protective_pivot
        if prior is None or qpp.pivot.confirmed_at > prior.confirmed_at:
            management_position = replace(inp.position, latest_qualified_protective_pivot=qpp.pivot)

    exit_eval = evaluate_exit(
        management_position,
        information_cutoff=inp.information_cutoff,
        new_adverse_pivot=inp.new_adverse_pivot,
        protected_intermediate_structure_failed=inp.protected_intermediate_structure_failed,
        trend_episode_end=inp.supporting_trend_episode_end,
        canonical_continuity_intact=inp.canonical_continuity_intact,
        hard_protection=inp.hard_protection,
        exit_candidate_evidence=inp.exit_candidate_evidence,
        parameters=inp.parameters,
    )

    if exit_eval.exit_record is not None:
        mode = PositionMode.CLOSED
    elif exit_eval.degraded_protective:
        mode = PositionMode.DEGRADED_PROTECTIVE
    else:
        mode = PositionMode.ACTIVE
    return D6CutoffView(
        information_cutoff=inp.information_cutoff,
        position_id=inp.position.position_id,
        position_mode=mode,
        qualified_protective_pivot=qpp,
        exit_evaluation=exit_eval,
        new_risk_blocked=(mode is PositionMode.DEGRADED_PROTECTIVE),
    )
