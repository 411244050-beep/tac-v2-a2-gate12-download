"""WP6 cutoff ownership contract.

Authorized scope:
- UPDATE-010 existing-position management / Strategy Exit
- non-ordering Strategy/execution boundary interfaces

Not implemented here:
- UPDATE-014 same-cutoff orchestration
- UPDATE-015 portfolio allocation
- full UPDATE-000..016 orchestrator
"""

D6_OWNED_UPDATE_STEPS = ("UPDATE-010",)
FORBIDDEN_ORCHESTRATION_STEPS = ("UPDATE-014", "UPDATE-015")
