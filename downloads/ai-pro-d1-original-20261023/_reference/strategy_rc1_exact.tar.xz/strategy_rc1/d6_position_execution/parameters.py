from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction

from ..parameter_snapshot import ParameterSnapshot, ParameterState


@dataclass(frozen=True)
class D6ParameterView:
    theta_progress: Fraction
    theta_stop_state: ParameterState
    theta_stop_exact_value: str | None
    complete_strategy_parameter_snapshot: bool
    runtime_usable: bool

    def __post_init__(self) -> None:
        if self.theta_progress < 0:
            raise ValueError("theta_progress must be nonnegative")
        if self.theta_stop_state is not ParameterState.LOCKED:
            raise ValueError("current WP6 governance requires theta_stop LOCKED")
        if self.theta_stop_exact_value is not None:
            raise ValueError("LOCKED theta_stop must carry no numeric value")
        if self.complete_strategy_parameter_snapshot or self.runtime_usable:
            raise ValueError("current WP6 snapshot must remain incomplete/runtime unusable")


def d6_parameter_view(snapshot: ParameterSnapshot) -> D6ParameterView:
    progress = snapshot.slot("theta_progress")
    stop = snapshot.slot("theta_stop")
    if progress.state is not ParameterState.FROZEN or progress.exact_value is None:
        raise ValueError("theta_progress must be FROZEN with exact value")
    return D6ParameterView(
        theta_progress=Fraction(progress.exact_value),
        theta_stop_state=stop.state,
        theta_stop_exact_value=stop.exact_value,
        complete_strategy_parameter_snapshot=snapshot.complete_strategy_parameter_snapshot,
        runtime_usable=snapshot.runtime_usable,
    )
