from __future__ import annotations

from dataclasses import replace

from ..d5_risk.types import EntryReadyAssemblyResult
from ..ids import deterministic_id
from .types import PositionMode, PositionProvenanceClass, StrategyPositionSnapshot


class StrategyPositionRegistry:
    """In-memory reference firewall for Position baseline constraints.

    This is not persistence, execution, or order placement. It only rejects
    duplicate/opposite active Strategy Position histories and reuse of one
    Opportunity as more than one initial Strategy Entry.
    """

    def __init__(self) -> None:
        self._active_by_symbol: dict[str, StrategyPositionSnapshot] = {}
        self._used_opportunity_ids: set[str] = set()

    def register(self, position: StrategyPositionSnapshot) -> None:
        symbol = position.entry.symbol
        if symbol in self._active_by_symbol:
            raise ValueError("POSITION-001/002: at most one net Strategy Position per symbol")
        if position.entry.opportunity_id in self._used_opportunity_ids:
            raise ValueError("POSITION-003: one Opportunity may create at most one initial Strategy Entry")
        if position.mode is PositionMode.CLOSED:
            raise ValueError("cannot register already-closed position as active")
        self._active_by_symbol[symbol] = position
        self._used_opportunity_ids.add(position.entry.opportunity_id)

    def close(self, position_id: str, exit_id: str) -> StrategyPositionSnapshot:
        for symbol, position in tuple(self._active_by_symbol.items()):
            if position.position_id == position_id:
                closed = replace(position, mode=PositionMode.CLOSED, closed_exit_id=exit_id)
                del self._active_by_symbol[symbol]
                return closed
        raise KeyError(position_id)

    def active(self, symbol: str) -> StrategyPositionSnapshot | None:
        return self._active_by_symbol.get(symbol)



def position_id_from_entry_ready(entry_ready_id: str, opportunity_id: str, symbol: str) -> str:
    return deterministic_id("D6-STRATEGY-POSITION", entry_ready_id, opportunity_id, symbol)


def assert_current_wp5_cannot_create_real_position(entry_ready: EntryReadyAssemblyResult) -> None:
    """Current-state guard: WP5 did not emit ENTRY_READY, so WP6 cannot create a real Position."""
    if entry_ready.semantic_entry_ready_emitted:
        raise ValueError("unexpected current-state ENTRY_READY emission; authority/state review required")
    if entry_ready.entry_ready_id is not None:
        raise ValueError("non-emitted ENTRY_READY may not carry a usable ID")


def assert_synthetic_fixture(position: StrategyPositionSnapshot) -> None:
    if position.entry.provenance_class is not PositionProvenanceClass.NONAUTHORITATIVE_SYNTHETIC_FIXTURE_ONLY:
        raise ValueError("WP6 self-check Position must be NONAUTHORITATIVE_SYNTHETIC_FIXTURE_ONLY")
