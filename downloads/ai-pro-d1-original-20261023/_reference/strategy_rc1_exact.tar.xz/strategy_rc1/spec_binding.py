"""Exact authority bindings for the WP0/WP1/WP2/WP3/WP4/WP5/WP6/WP7 non-trading reference skeleton.

This module binds metadata only. It does not create semantic authority.
"""

SPEC_ID = "TAC_CLEANROOM_V2"
SPEC_VERSION = "1.0-RC1"
RC1_RAW_SHA256 = "0e910d20f12e18662779f2977b83413f86569b230e9b08e0c2ad7a6c2afc29bc"

SOURCE_GITHUB_HEAD = "9ad115b6e9eb7fe9f5a45f60fc6c11004346d625"
SOURCE_GITHUB_TREE = "5f639389ec12ba774ff4d0e74d3f20693f2b7396"

POST_RC1_BINDINGS = {
    "tac-v2-r1-post-rc1-semantic-authority-binding-v1.json": {
        "github_blob_sha": "99cba11b434a92c73712f997ca5ab70ca1b5dd76",
        "deterministic_content_sha256": "3fe568ae8ea082bfe88b4106cb564882737884b84626dc81c4797666b232d3a1",
        "scope": "episode leg membership + B3 zone classifier",
    },
    "tac-v2-r1-post-rc1-st-final-band-recurrence-semantic-authority-binding-v1.json": {
        "github_blob_sha": "267d2002fe3290837a220e01ce0ada2e6754e672",
        "deterministic_content_sha256": "5a22d76cf9b197cf3a5c6716fe7b176dccc33a02f8a17396d92dcd3664f42473",
        "scope": "Supertrend final-band recurrence",
    },
}

CURRENT_STAGE = "RC1_NONTRADING_REFERENCE_IMPLEMENTATION_WP7"
RUNTIME_AUTHORIZED = False
TRADING_AUTHORIZED = False
TEST_AUTHORIZED = False

WP8_STAGE = "RC1_NONTRADING_REFERENCE_IMPLEMENTATION_WP8_V1"
WP8_SCOPE = "SEMANTIC_TRACEABILITY_HARNESS_SYNTHETIC_FIXTURES_ONLY"
