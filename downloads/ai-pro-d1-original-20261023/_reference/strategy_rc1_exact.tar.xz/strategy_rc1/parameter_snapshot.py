from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from types import MappingProxyType
from typing import Mapping


class ParameterState(str, Enum):
    FROZEN = "FROZEN"
    OPEN = "OPEN"
    LOCKED = "LOCKED"


@dataclass(frozen=True)
class ParameterSlot:
    name: str
    state: ParameterState
    exact_value: str | None = None

    def __post_init__(self) -> None:
        if self.state is ParameterState.FROZEN and self.exact_value is None:
            raise ValueError(f"Frozen parameter {self.name} requires exact_value")
        if self.state is not ParameterState.FROZEN and self.exact_value is not None:
            raise ValueError(f"Unfrozen parameter {self.name} must not contain a value")


@dataclass(frozen=True)
class ParameterSnapshot:
    snapshot_id: str
    slots: Mapping[str, ParameterSlot]
    complete_strategy_parameter_snapshot: bool
    runtime_usable: bool
    source_status: str

    def __post_init__(self) -> None:
        object.__setattr__(self, "slots", MappingProxyType(dict(self.slots)))

    def slot(self, name: str) -> ParameterSlot:
        try:
            return self.slots[name]
        except KeyError as exc:
            raise KeyError(f"Parameter slot not declared: {name}") from exc

    @property
    def frozen_count(self) -> int:
        return sum(s.state is ParameterState.FROZEN for s in self.slots.values())


PARTIAL_PARAMETER_SNAPSHOT_ID = "R1_PARTIAL_RESEARCH_SNAPSHOT_PROGRESS_RATE_B3_ACCEPT_OVER_995E24FBAA216C62"
PARTIAL_PARAMETER_SNAPSHOT_DETERMINISTIC_SHA256 = "a869a3a7758c0a4ff34ddfb5ae1c4e012e0600bbea6492cf12efa19a148ef5bb"

_FROZEN = {
    "theta_accept": "2.1313767840459202205981702405574439224871803906649207193085500",
    "theta_approach": "1.197268280893772873697806561124554291191704011769349520546870",
    "theta_overextension": "2.7703041968078565478295719882475244376661292176373236367284700",
    "theta_progress": "1.27112707163488491529631027277968495738450",
    "theta_rate": "0.17560145225927980894381212168524856466229325734699705827303000",
    "theta_separation": "2.24912097135367169114306428916723600671864369102654007565280",
    "theta_test": "0.5913466407600057877252533034649404155944065891655909831651470",
}


def current_partial_parameter_snapshot() -> ParameterSnapshot:
    """Bind the durable partial snapshot, overlaid by newer current governance.

    The source V5 snapshot recorded theta_stop as OPEN at that historical point.
    Current v12 governance supersedes only its current-state display and locks
    theta_stop. No numerical value is created for the locked slot.
    """
    slots: dict[str, ParameterSlot] = {
        name: ParameterSlot(name=name, state=ParameterState.FROZEN, exact_value=value)
        for name, value in _FROZEN.items()
    }
    slots.update(
        {
            "theta_minor": ParameterSlot("theta_minor", ParameterState.OPEN),
            "theta_intermediate": ParameterSlot("theta_intermediate", ParameterState.OPEN),
            "theta_major": ParameterSlot("theta_major", ParameterState.OPEN),
            "theta_stop": ParameterSlot("theta_stop", ParameterState.LOCKED),
        }
    )
    return ParameterSnapshot(
        snapshot_id=PARTIAL_PARAMETER_SNAPSHOT_ID,
        slots=slots,
        complete_strategy_parameter_snapshot=False,
        runtime_usable=False,
        source_status="PARTIAL_RESEARCH_FREEZE_NOT_STRATEGY_USABLE_WITH_CURRENT_V12_THETA_STOP_LOCK_OVERLAY",
    )
