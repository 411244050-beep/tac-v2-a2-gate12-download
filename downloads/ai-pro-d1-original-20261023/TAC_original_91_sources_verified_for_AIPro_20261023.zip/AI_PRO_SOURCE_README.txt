TAC-V2/A2 original WP8 strategy_rc1 source reference, 91 files.
D1 CanonicalBar original SHA-256: a647c3f66448dbf1cb322fd7561fdc74d3584ce2c5ef1c7450dd63837ef75b62
This is not a runnable Binance AI Pro strategy, not a trading authorization and not a replacement for science/runtime validation.
Do not import private account credentials or run signed requests.
TAC_LIVE_ENABLED=0; FULL TAC LIVE NO-GO.
